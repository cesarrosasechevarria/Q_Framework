(function(){
  const base = (()=>{
    const meta = (document.querySelector('meta[name="doc-base"]')?.getAttribute('content') || '').trim();
    const candidates = [];
    if(meta) candidates.push(meta);

    // Deriva desde el src del propio script (siempre apunta a .../docs/_assets/docs.js)
    try{
      const cs = document.currentScript;
      if(cs && cs.src){
        const u = new URL(cs.src, window.location.href);
        // quita /_assets/docs.js
        const s = u.toString().replace(/_assets\/docs\.js(\?.*)?$/, '');
        if(s) candidates.push(s);
      }
    }catch(e){}

    // Deriva desde la URL actual: .../docs/...
    try{
      const href = window.location.href;
      const m = href.match(/^(.*\/docs\/)/);
      if(m && m[1]) candidates.push(m[1]);
    }catch(e){}

    for(const c of candidates){
      try{
        const u = new URL(c, window.location.href);
        let s = u.toString();
        if(!s.endsWith('/')) s += '/';
        return s;
      }catch(e){}
    }
    return './';
  })();
  
  // Ensure docs.css is actually loaded (some pages may have wrong relative paths in older copies)
  (function ensureDocsCss(){
    try{
      const layout = document.querySelector('.layout');
      const hasCssLink = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
        .some(l => (l.getAttribute('href')||'').includes('docs.css'));
      const needs = !hasCssLink;
      // If there is a link but it failed (404), computed style will look like default block layout.
      const styleBad = layout && getComputedStyle(layout).display === 'block';
      if(needs || styleBad){
        const href = base.replace(/\/?$/, '/') + '_assets/docs.css';
        const existing = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
          .find(l => (l.getAttribute('href')||'').includes('docs.css'));
        if(existing){
          existing.setAttribute('href', href);
        }else{
          const link = document.createElement('link');
          link.rel = 'stylesheet';
          link.href = href;
          document.head.appendChild(link);
        }
      }
    }catch(e){}
  })();

const qs = (s, el=document) => el.querySelector(s);
  const qsa = (s, el=document) => Array.from(el.querySelectorAll(s));

    function loadScript(src){
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.defer = true;
      s.onload = () => resolve(true);
      s.onerror = () => reject(new Error('script_failed'));
      document.head.appendChild(s);
    });
  }

// Theme
  const htmlEl = document.documentElement;
  const saved = localStorage.getItem('qfw_doc_theme');
  if(saved){ htmlEl.setAttribute('data-theme', saved); }
  else { htmlEl.setAttribute('data-theme','light'); }
  const themeBtn = qs('#themeBtn');
  if(themeBtn){
    themeBtn.addEventListener('click', () => {
      const cur = htmlEl.getAttribute('data-theme') || 'light';
      const next = cur === 'light' ? 'dark' : 'light';
      htmlEl.setAttribute('data-theme', next);
      localStorage.setItem('qfw_doc_theme', next);
    });
  }

  // Mobile menu
  const menuBtn = qs('#menuBtn');
  const sidebar = qs('.sidebar');
  if(menuBtn && sidebar){
    menuBtn.addEventListener('click', ()=> sidebar.classList.toggle('open'));
    document.addEventListener('click', (e)=>{
      if(window.innerWidth > 860) return;
      const inSidebar = sidebar.contains(e.target);
      const isBtn = menuBtn.contains(e.target);
      if(!inSidebar && !isBtn) sidebar.classList.remove('open');
    });
  }

  // Nav
    // Nav
  async function loadNav(){
    const navEl = qs('#nav');
    if(!navEl) return;

    let nav = null;
    // 1) online fetch
    try{
      const res = await fetch(base + '_assets/nav.json', {cache:'no-store'});
      if(res.ok) nav = await res.json();
    }catch(e){}

    // 2) fallback to embedded data (offline/file://)
    if(!nav){
      nav = window.__QFW_NAV__ || null;
      if(!nav){
        try{
          await loadScript(base + '_assets/nav.data.js?v=20260207_2');
          nav = window.__QFW_NAV__ || null;
        }catch(e){}
      }
    }

    if(!nav || !nav.sections) return;

    const current = window.location.pathname.split('/').pop() || 'index.html';
    const currentFull = window.location.pathname.replace(/\\/g,'/');
    navEl.innerHTML = '';

    nav.sections.forEach(sec => {
      const wrap = document.createElement('div');
      wrap.className = 'nav-section';
      const t = document.createElement('div');
      t.className = 'nav-title';
      t.textContent = sec.title;
      wrap.appendChild(t);

      (sec.items || []).forEach(it => {
        const div = document.createElement('div');
        div.className = 'nav-item';
        const a = document.createElement('a');
        a.href = base + it.href;
        a.textContent = it.label;

        const curHref =
          currentFull.endsWith('/'+it.href) ||
          current === it.href ||
          currentFull.endsWith('/'+it.href.replace(/^(\.\/)/,''));

        if(curHref) a.classList.add('active');
        div.appendChild(a);
        wrap.appendChild(div);
      });

      navEl.appendChild(wrap);
    });
  }


  // Breadcrumbs
  function setBreadcrumbs(){
    const bc = qs('#breadcrumbs');
    if(!bc) return;
    const parts = window.location.pathname.replace(/\\/g,'/').split('/').filter(Boolean);
    const last = parts[parts.length-1] || 'index.html';
    bc.textContent = last;
  }

  // TOC
  function buildToc(){
    const tocBody = qs('#tocBody');
    const content = qs('#content');
    if(!tocBody || !content) return;
    const heads = qsa('h2, h3', content);
    if(!heads.length){
      tocBody.innerHTML = '<div class="muted">—</div>';
      return;
    }
    tocBody.innerHTML = '';
    heads.forEach(h => {
      if(!h.id){
        const slug = h.textContent.trim().toLowerCase().replace(/[^a-z0-9áéíóúñ]+/g,'-').replace(/(^-|-$)/g,'');
        h.id = slug || ('sec-' + Math.random().toString(16).slice(2));
      }
      const a = document.createElement('a');
      a.href = '#' + h.id;
      a.textContent = h.textContent;
      if(h.tagName.toLowerCase() === 'h3') a.classList.add('l3');
      tocBody.appendChild(a);
    });
  }

  // Copy buttons
  function addCopyButtons(){
    qsa('pre').forEach(pre => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'copy-btn';
      btn.textContent = 'Copiar';
      btn.addEventListener('click', async ()=>{
        const code = pre.innerText;
        try{
          await navigator.clipboard.writeText(code);
          btn.textContent = 'Copiado';
          setTimeout(()=>btn.textContent='Copiar', 900);
        }catch(e){
          btn.textContent = 'Error';
          setTimeout(()=>btn.textContent='Copiar', 900);
        }
      });
      pre.appendChild(btn);
    });
  }

  // Search
  let searchData = null;
    async function ensureSearch(){
    if(searchData) return searchData;

    // 1) online fetch
    try{
      const res = await fetch(base + '_assets/search-index.json', {cache:'no-store'});
      if(res.ok){
        searchData = await res.json();
        return searchData;
      }
    }catch(e){}

    // 2) offline fallback (embedded script)
    if(window.__QFW_SEARCH__){
      searchData = window.__QFW_SEARCH__;
      return searchData;
    }

    try{
      await loadScript(base + '_assets/search.data.js?v=20260207_2');
      if(window.__QFW_SEARCH__){
        searchData = window.__QFW_SEARCH__;
        return searchData;
      }
    }catch(e){}

    searchData = {items: []};
    return searchData;
  }



  // Search overlay (robusto: crea el overlay si la página no lo trae)
  let __overlayBound = false;
  function ensureSearchOverlay(){
    let ov = qs('#searchOverlay');
    let input = qs('#searchInput');
    let results = qs('#searchResults');
    let closeBtn = qs('#searchClose');

    if(ov && input && results && closeBtn){
      // Bind una sola vez también cuando el overlay ya viene en el HTML
      if(!__overlayBound){
        __overlayBound = true;
        closeBtn.addEventListener('click', closeSearch);
        ov.addEventListener('click', (e)=>{ if(e.target === ov) closeSearch(); });
        input.addEventListener('input', (e)=> doSearch(e.target.value));
      }
      return {ov, input, results, closeBtn};
    }

    // Crea overlay si falta
    ov = document.createElement('div');
    ov.className = 'overlay';
    ov.id = 'searchOverlay';
    ov.setAttribute('aria-hidden','true');
    ov.innerHTML = `
      <div class="overlay-card" role="dialog" aria-modal="true" aria-label="Buscar en la documentación">
        <div class="overlay-head">
          <input id="searchInput" type="search" placeholder="Busca clases, métodos, páginas…">
          <button id="searchClose" type="button" class="overlay-close">Esc</button>
        </div>
        <div id="searchResults" class="overlay-results"></div>
        <div class="overlay-foot muted">Consejos: escribe “FilterManager”, “csrf”, “GuardFilter”, “RateLimit”…</div>
      </div>
    `;
    document.body.appendChild(ov);

    input = qs('#searchInput');
    results = qs('#searchResults');
    closeBtn = qs('#searchClose');

    // Bind eventos una sola vez (como el overlay puede crearse dinámicamente)
    if(!__overlayBound){
      __overlayBound = true;
      closeBtn && closeBtn.addEventListener('click', closeSearch);
      ov.addEventListener('click', (e)=>{ if(e.target === ov) closeSearch(); });
      input && input.addEventListener('input', (e)=> doSearch(e.target.value));
    }

    return {ov, input, results, closeBtn};
  }
  function openSearch(initialQuery=''){
    const {ov, input} = ensureSearchOverlay();
    if(!ov || !input) return;
    ov.classList.add('show');
    ov.setAttribute('aria-hidden','false');

    // Si ya había texto (p.ej. usuario venía escribiendo en #q), lo conservamos
    const q = (typeof initialQuery === 'string') ? initialQuery : '';
    input.value = q;
    if(q){ doSearch(q); }
    else { renderResults([]); }

    setTimeout(()=> input.focus(), 20);
  }
  function closeSearch(){
    const ov = qs('#searchOverlay');
    if(!ov) return;
    ov.classList.remove('show');
    ov.setAttribute('aria-hidden','true');
  }
  function renderResults(items){
    const {results: out} = ensureSearchOverlay();
    if(!out) return;
    if(!items.length){
      out.innerHTML = '<div class="muted">Escribe para buscar…</div>';
      return;
    }
    out.innerHTML = '';
    items.slice(0, 30).forEach(it => {
      const div = document.createElement('div');
      div.className = 'result';
      const a = document.createElement('a');
      a.href = base + it.href;
      a.textContent = it.title;
      const sn = document.createElement('div');
      sn.className = 'snippet';
      sn.textContent = it.snippet || '';
      div.appendChild(a);
      div.appendChild(sn);
      out.appendChild(div);
    });
  }

  async function doSearch(q){
    q = (q || '').trim().toLowerCase();
    if(!q){ renderResults([]); return; }
    const data = await ensureSearch();
    const terms = q.split(/\s+/).filter(Boolean);
    const scored = [];
    for(const item of data.items){
      const hay = (item.text || '').toLowerCase();
      let score = 0;
      for(const t of terms){
        if(item.title.toLowerCase().includes(t)) score += 8;
        if(hay.includes(t)) score += 2;
      }
      if(score>0){
        scored.push({score, ...item});
      }
    }
    scored.sort((a,b)=>b.score-a.score);
    renderResults(scored);
  }

  // Search UI: soporte para páginas "manual" (botón) y páginas API (input #q)
  const searchBtn = qs('#searchBtn');
  if(searchBtn) searchBtn.addEventListener('click', ()=> openSearch(''));

  const apiSearchInput = qs('#q');
  if(apiSearchInput){
    // Mantén el layout del API, pero usa el overlay global
    apiSearchInput.addEventListener('focus', ()=> openSearch(apiSearchInput.value || ''));
    apiSearchInput.addEventListener('input', ()=> openSearch(apiSearchInput.value || ''));
    apiSearchInput.addEventListener('keydown', (e)=>{
      if(e.key === 'Escape'){ apiSearchInput.blur(); closeSearch(); }
    });
  }

  // Asegura que el overlay exista y quede enlazado incluso si la página no lo trae en el HTML
  ensureSearchOverlay();


  document.addEventListener('keydown', (e)=>{
    const isMac = navigator.platform.toLowerCase().includes('mac');
    const mod = isMac ? e.metaKey : e.ctrlKey;
    if(mod && e.key.toLowerCase() === 'k'){
      e.preventDefault(); openSearch();
    }
    if(e.key === 'Escape') closeSearch();
  });

  // Init
  loadNav();
  setBreadcrumbs();
  buildToc();
  addCopyButtons();
})();
