-- Q_Framework PRO examples schema (MySQL/MariaDB)
-- Tablas requeridas para: /auth, /admin, /blog, /api/v1
-- Recomendado: usar migraciones (php bin/console migrate) en vez de importar este SQL.
-- Nota: si el índice ya existe, MySQL/MariaDB lanzará error; en ese caso omite la línea del índice.

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NULL,
  role VARCHAR(30) NOT NULL DEFAULT 'user',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NULL,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE UNIQUE INDEX ux_users_email ON users (email);

CREATE TABLE IF NOT EXISTS blog_posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(140) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  content LONGTEXT NULL,
  author_id INT NULL,
  created_at DATETIME NULL,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE UNIQUE INDEX ux_blog_posts_slug ON blog_posts (slug);
CREATE INDEX ix_blog_posts_author ON blog_posts (author_id);
