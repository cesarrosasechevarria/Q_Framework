<?php
declare(strict_types=1);

namespace System\Security;

use System\Cache\CacheInterface;

/**
 * RateLimiter (PRO)
 * - Persistencia vía CacheInterface (FileCache por defecto)
 * - Útil para login, endpoints sensibles, APIs, etc.
 *
 * Estrategia:
 * - Guarda un payload: ['hits'=>int,'reset'=>timestamp]
 * - TTL = reset - now (decay)
 */
final class RateLimiter
{
  public function __construct(private CacheInterface $cache)
  {
  }

  /** Normaliza keys para evitar path traversal en FileCache */
  public function key(string $raw): string
  {
    $k = strtolower(trim($raw));
    $k = preg_replace('/[^a-z0-9_\-:\.]/', '_', $k);
    return $k ?: 'rl:default';
  }

  /**
   * Registra un intento y devuelve estado.
   * @return array{ok:bool,hits:int,remaining:int,reset:int,wait:int}
   */
  public function attempt(string $key, int $maxAttempts, int $decaySeconds): array
  {
    $key = $this->key($key);
    $maxAttempts = max(1, (int)$maxAttempts);
    $decaySeconds = max(1, (int)$decaySeconds);

    $now = time();
    $data = $this->cache->get($key, null);

    if (!is_array($data) || empty($data['reset']) || (int)$data['reset'] <= $now) {
      $data = ['hits' => 0, 'reset' => $now + $decaySeconds];
    }

    $hits = (int)($data['hits'] ?? 0);

    // Si ya excedió, no incrementa más (evita crecer infinito)
    if ($hits >= $maxAttempts) {
      $wait = max(1, (int)$data['reset'] - $now);
      return [
        'ok' => false,
        'hits' => $hits,
        'remaining' => 0,
        'reset' => (int)$data['reset'],
        'wait' => $wait,
      ];
    }

    $hits++;
    $data['hits'] = $hits;

    $ttl = max(1, (int)$data['reset'] - $now);
    $this->cache->set($key, $data, $ttl);

    $remaining = max(0, $maxAttempts - $hits);
    return [
      'ok' => true,
      'hits' => $hits,
      'remaining' => $remaining,
      'reset' => (int)$data['reset'],
      'wait' => 0,
    ];
  }

  public function tooManyAttempts(string $key, int $maxAttempts): bool
  {
    $key = $this->key($key);
    $data = $this->cache->get($key, null);
    if (!is_array($data)) return false;
    $now = time();
    if (empty($data['reset']) || (int)$data['reset'] <= $now) return false;
    return (int)($data['hits'] ?? 0) >= max(1, (int)$maxAttempts);
  }

  public function availableIn(string $key): int
  {
    $key = $this->key($key);
    $data = $this->cache->get($key, null);
    if (!is_array($data) || empty($data['reset'])) return 0;
    $wait = (int)$data['reset'] - time();
    return max(0, $wait);
  }

  public function clear(string $key): bool
  {
    $key = $this->key($key);
    return $this->cache->delete($key);
  }
}
