<?php
declare(strict_types=1);

namespace System\Services;

use System\Core\Crypt;

/**
 * Encrypter (compat CI)
 * - Provee métodos encrypt/decrypt como objeto.
 * - Internamente usa System\Core\Crypt (AES-256-GCM).
 */
final class Encrypter
{
  public function encrypt(string $plaintext): string
  {
    return Crypt::encrypt($plaintext);
  }

  public function decrypt(string $token): string
  {
    return Crypt::decrypt($token);
  }
}
