<?php
declare(strict_types=1);

namespace System\Database;

/**
 * DbResult (PRO)
 *
 * Resultado estructurado para operaciones DB (CRUD/queries).
 *
 * - Para APIs/CLI: devuelve ok/error/trace_id en vez de depender de excepciones.
 * - Para debug: puede incluir SQL y params (controlado desde safeArray()).
 */
final class DbResult
{
  public bool $ok = false;
  public string $action = 'query';
  public ?string $table = null;
  public ?string $sql = null;
  public array $params = [];
  public ?string $error = null;
  public ?string $state = null;   // SQLSTATE
  public ?int $code = null;       // driver error code (ej: 1064)
  public int $rowCount = 0;
  public ?string $insertId = null;
  public mixed $data = null;
  public float $time_ms = 0.0;
  public string $trace_id;
  public array $meta = [];

  public function __construct()
  {
    $this->trace_id = 'db_' . bin2hex(random_bytes(6));
  }

  /** Convierte a array completo (incluye sql/params). Útil para logs internos. */
  public function toArray(): array
  {
    return [
      'ok' => $this->ok,
      'action' => $this->action,
      'table' => $this->table,
      'sql' => $this->sql,
      'params' => $this->params,
      'error' => $this->error,
      'state' => $this->state,
      'code' => $this->code,
      'rowCount' => $this->rowCount,
      'insertId' => $this->insertId,
      'data' => $this->data,
      'time_ms' => $this->time_ms,
      'trace_id' => $this->trace_id,
      'meta' => $this->meta,
    ];
  }

  /**
   * safeArray(): serialización segura para exponer en JSON.
   *
   * opts:
   * - includeSql (bool): incluye sql
   * - includeParams (bool): incluye params
   */
  public function safeArray(array $opts = []): array
  {
    $includeSql = (bool)($opts['includeSql'] ?? false);
    $includeParams = (bool)($opts['includeParams'] ?? false);

    $out = [
      'ok' => $this->ok,
      'action' => $this->action,
      'table' => $this->table,
      'rowCount' => $this->rowCount,
      'insertId' => $this->insertId,
      'data' => $this->data,
      'error' => $this->error,
      'state' => $this->state,
      'code' => $this->code,
      'time_ms' => $this->time_ms,
      'trace_id' => $this->trace_id,
      'meta' => $this->meta,
    ];

    if ($includeSql) $out['sql'] = $this->sql;
    if ($includeParams) $out['params'] = $this->params;
    return $out;
  }

  public static function failFromThrowable(\Throwable $e, array $ctx = []): self
  {
    $r = new self();
    $r->ok = false;
    $r->action = (string)($ctx['action'] ?? 'query');
    $r->table = $ctx['table'] ?? null;
    $r->sql = $ctx['sql'] ?? null;
    $r->params = (array)($ctx['params'] ?? []);
    $r->error = $e->getMessage();

    // PDOException: getCode() suele ser SQLSTATE. errorInfo[1] es code driver.
    $r->state = (string)($e->getCode() ?? '');
    if ($e instanceof \PDOException && isset($e->errorInfo) && is_array($e->errorInfo)) {
      $r->state = (string)($e->errorInfo[0] ?? $r->state);
      $r->code = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : null;
      $r->meta['driver_message'] = $e->errorInfo[2] ?? null;
    }

    return $r;
  }
}
