<?php
declare(strict_types=1);

namespace System\Database;

/**
 * DbResult (PRO)
 *
 * Resultado estructurado para operaciones DB (CRUD/queries).
 *
 * - Para APIs/CLI: devuelve ok/error/trace_id en vez de depender de excepciones.
 * - Para debug: puede incluir SQL y params (controlado desde safeArray()).
 */
final class DbResult
{
  public bool $ok = false;
  public string $action = 'query';
  public ?string $table = null;
  public ?string $sql = null;
  public array $params = [];
  public ?string $error = null;
  public ?string $state = null;   // SQLSTATE
  public ?int $code = null;       // driver error code (ej: 1064)
  public int $rowCount = 0;
  public ?string $insertId = null;
  public mixed $data = null;
  public float $time_ms = 0.0;
  public string $trace_id;
  public array $meta = [];

  public function __construct()
  {
    $this->trace_id = 'db_' . bin2hex(random_bytes(6));
  }

  /** Convierte a array completo (incluye sql/params). Útil para logs internos. */
  public function toArray(): array
  {
    return [
      'ok' => $this->ok,
      'action' => $this->action,
      'table' => $this->table,
      'sql' => $this->sql,
      'params' => $this->params,
      'error' => $this->error,
      'state' => $this->state,
      'code' => $this->code,
      'rowCount' => $this->rowCount,
      'insertId' => $this->insertId,
      'data' => $this->data,
      'time_ms' => $this->time_ms,
      'trace_id' => $this->trace_id,
      'meta' => $this->meta,
    ];
  }

  /**
   * safeArray(): serialización segura para exponer en JSON.
   *
   * opts:
   * - includeSql (bool): incluye sql
   * - includeParams (bool): incluye params
   */
  public function safeArray(array $opts = []): array
  {
    $includeSql = (bool)($opts['includeSql'] ?? false);
    $includeParams = (bool)($opts['includeParams'] ?? false);

$hide = $opts['hide'] ?? null;          // array|string de columnas a ocultar
$hidePublic = (bool)($opts['hidePublic'] ?? false);

    

// Permite ocultar claves sensibles en data (fallback, por si alguien hizo SELECT *)
$data = $this->data;

$hideList = [];
if ($hidePublic) {
  $cfg = config('Database');
  if (isset($cfg->hiddenSelectFields) && is_array($cfg->hiddenSelectFields)) {
    $hideList = array_merge($hideList, $cfg->hiddenSelectFields);
  }
}
if ($hide) {
  if (is_string($hide)) $hide = array_map('trim', explode(',', $hide));
  if (is_array($hide)) $hideList = array_merge($hideList, $hide);
}

if ($hideList) {
  $set = [];
  foreach ($hideList as $x) {
    if (!is_string($x) && !is_numeric($x)) continue;
    $s = trim((string)$x);
    if ($s === '') continue;
    $set[strtolower($s)] = true;
  }

  $filterRow = function(array $row) use ($set): array {
    foreach ($row as $k => $_) {
      if (isset($set[strtolower((string)$k)])) unset($row[$k]);
    }
    return $row;
  };

  if (is_array($data)) {
    // Si es lista de rows
    $isList = array_keys($data) === range(0, count($data) - 1);
    if ($isList) {
      $tmp = [];
      foreach ($data as $r) {
        $tmp[] = is_array($r) ? $filterRow($r) : $r;
      }
      $data = $tmp;
    } else {
      // Row asociativo
      $data = $filterRow($data);
    }
  }
}

$out = [
      'ok' => $this->ok,
      'action' => $this->action,
      'table' => $this->table,
      'rowCount' => $this->rowCount,
      'insertId' => $this->insertId,
      'data' => $this->data,
      'error' => $this->error,
      'state' => $this->state,
      'code' => $this->code,
      'time_ms' => $this->time_ms,
      'trace_id' => $this->trace_id,
      'meta' => $this->meta,
    ];

    if ($includeSql) $out['sql'] = $this->sql;
    if ($includeParams) $out['params'] = $this->params;
    return $out;
  }


  /**
   * jsonSerialize(): por defecto, serializa como safeArray() (no expone sql/params).
   * Si necesitas el detalle completo, usa ->toArray() o ->safeArray(['includeSql'=>true,'includeParams'=>true]) en APP_DEBUG=1.
   */
  public function jsonSerialize(): mixed
  {
    // Perfil por defecto para JSON: api (oculta meta/time_ms/table por conveniencia).
    $a = $this->safeArray(['includeSql' => false, 'includeParams' => false]);
    unset($a['table'], $a['meta'], $a['time_ms'], $a['sql'], $a['params']);
    return $a;
  }

  public static function failFromThrowable(\Throwable $e, array $ctx = []): self
  {
    $r = new self();
    $r->ok = false;
    $r->action = (string)($ctx['action'] ?? 'query');
    $r->table = $ctx['table'] ?? null;
    $r->sql = $ctx['sql'] ?? null;
    $r->params = (array)($ctx['params'] ?? []);
    $r->error = $e->getMessage();

    // PDOException: getCode() suele ser SQLSTATE. errorInfo[1] es code driver.
    $r->state = (string)($e->getCode() ?? '');
    if ($e instanceof \PDOException && isset($e->errorInfo) && is_array($e->errorInfo)) {
      $r->state = (string)($e->errorInfo[0] ?? $r->state);
      $r->code = isset($e->errorInfo[1]) ? (int)$e->errorInfo[1] : null;
      $r->meta['driver_message'] = $e->errorInfo[2] ?? null;
    }

    return $r;
  }
}