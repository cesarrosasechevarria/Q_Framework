<?php
declare(strict_types=1);

namespace System\Database;

use System\Core\DB;
use System\Core\Logger;
use System\Database\DbResult;

/**
 * Model (PRO)
 *
 * Inspirado en CI4: provee CRUD seguro con $allowedFields,
 * timestamps opcionales, soft deletes opcionales, y acceso a QueryBuilder.
 */
abstract class Model
{
  protected string $table = '';
  protected string $primaryKey = 'id';
  /** @var list<string> */
  protected array $allowedFields = [];
  protected bool $protectFields = true;

  protected bool $useTimestamps = true;
  protected string $createdField = 'created_at';
  protected string $updatedField = 'updated_at';

  protected bool $useSoftDeletes = false;
  protected string $deletedField = 'deleted_at';

  protected string $dbGroup = 'default';

  /**
   * QueryBuilder activo para encadenamiento tipo CI4:
   *   $this->where(...)->orderBy(...)->findAll(10)
   */
  private ?QueryBuilder $activeBuilder = null;
  private ?Pager $lastPager = null;

  public function __construct(?Connection $db = null)
  {
    if ($db) {
      $this->db = $db;
    }
  }

  private ?Connection $db = null;

  public function db(): Connection
  {
    if ($this->db === null) {
      $this->db = DB::connect($this->dbGroup);
    }
    return $this->db;
  }

  public function builder(): QueryBuilder
  {
    if (!$this->table) {
      throw new \RuntimeException(static::class . ' debe definir $table');
    }
    return $this->db()->table($this->table);
  }

  /**
   * Filtra según allowedFields.
   */
  protected function filterAllowed(array $data, bool $includePrimary = false): array
  {
    if (!$this->protectFields) return $data;
    if (!$this->allowedFields) return $data; // compat: si no define, no bloquear

    $out = [];
    foreach ($data as $k => $v) {
      $k = (string)$k;
      if ($k === '' || $k === $this->primaryKey) {
        if ($includePrimary) $out[$k] = $v;
        continue;
      }
      if (in_array($k, $this->allowedFields, true)) {
        $out[$k] = $v;
      }
    }
    return $out;
  }

  protected function now(): string
  {
    return date('Y-m-d H:i:s');
  }

  /* =========================================
   * Query Builder Fluent (estilo CI4)
   * ========================================= */

  /** Obtiene/crea el builder activo para encadenar condiciones. */
  protected function qb(): QueryBuilder
  {
    if ($this->activeBuilder === null) {
      $this->activeBuilder = $this->builder();
    }
    return $this->activeBuilder;
  }

  /** Resetea el builder activo (evita que se “cuelen” filtros entre queries). */
  protected function resetQuery(): void
  {
    $this->activeBuilder = null;
  }

  /** Aplica soft delete por defecto a lecturas (si corresponde). */
  protected function applySoftDeletesForRead(QueryBuilder $b): QueryBuilder
  {
    if ($this->useSoftDeletes) {
      $b->whereRaw($this->deletedField . ' IS NULL');
    }
    return $b;
  }

  /** Builder listo para ejecutar una lectura (respeta encadenamiento). */
  protected function readBuilder(): QueryBuilder
  {
    $b = $this->activeBuilder ?? $this->builder();
    return $this->applySoftDeletesForRead($b);
  }

  /**
   * Fluent wrappers (devuelven el Model para seguir encadenando)
   * Nota: solo incluimos los más usados por módulos/demo; si necesitas otros,
   *       se agregan igual de fácil.
   */
  public function distinct(bool $on = true): static { $this->qb()->distinct($on); return $this; }
  public function select(string|array $fields = '*'): static { $this->qb()->select($fields); return $this; }
  public function selectRaw(string $sql): static { $this->qb()->selectRaw($sql); return $this; }

  public function join(string $table, string $on, string $type = 'INNER'): static { $this->qb()->join($table, $on, $type); return $this; }
  public function leftJoin(string $table, string $on): static { $this->qb()->leftJoin($table, $on); return $this; }
  public function rightJoin(string $table, string $on): static { $this->qb()->rightJoin($table, $on); return $this; }

  public function where(string|array $key, $val = null, bool $escape = true): static { $this->qb()->where($key, $val, $escape); return $this; }
  public function orWhere(string|array $key, $val = null, bool $escape = true): static { $this->qb()->orWhere($key, $val, $escape); return $this; }
  public function whereRaw(string $sql, array $binds = [], string $boolean = 'AND'): static { $this->qb()->whereRaw($sql, $binds, $boolean); return $this; }

  public function whereIn(string $key, array $vals, string $boolean = 'AND'): static { $this->qb()->whereIn($key, $vals, false, $boolean); return $this; }
  public function orWhereIn(string $key, array $vals): static { $this->qb()->orWhereIn($key, $vals); return $this; }
  public function whereNotIn(string $key, array $vals, string $boolean = 'AND'): static { $this->qb()->whereNotIn($key, $vals, $boolean); return $this; }
  public function orWhereNotIn(string $key, array $vals): static { $this->qb()->orWhereNotIn($key, $vals); return $this; }

  public function like(string $key, string $match, string $side = 'both', string $boolean = 'AND'): static { $this->qb()->like($key, $match, $side, $boolean); return $this; }
  public function orLike(string $key, string $match, string $side = 'both'): static { $this->qb()->like($key, $match, $side, 'OR'); return $this; }

  public function groupBy(string|array $fields): static { $this->qb()->groupBy($fields); return $this; }
  public function having(string $expr, $val = null, string $boolean='AND'): static { $this->qb()->having($expr, $val, $boolean); return $this; }

  public function orderBy(string $field, string $dir='ASC'): static { $this->qb()->orderBy($field, $dir); return $this; }
  public function orderByRaw(string $sql): static { $this->qb()->orderByRaw($sql); return $this; }

  public function limit(int $limit, int $offset = 0): static { $this->qb()->limit($limit, $offset); return $this; }
  public function offset(int $offset): static { $this->qb()->offset($offset); return $this; }

  /** Ejecuta SELECT y resetea el builder activo. */
  public function get(): Result
  {
    $b = $this->readBuilder();
    $res = $b->get();
    $this->resetQuery();
    return $res;
  }

  /** Devuelve primer registro según filtros/orden. */
  public function first(): ?array
  {
    $b = $this->readBuilder();
    $row = $b->first();
    $this->resetQuery();
    return $row;
  }

  /** Paginación (delegada al QueryBuilder) + acceso a pager() desde el Model. */
  public function paginate(int $perPage = 20, ?int $page = null, string $pageParam = 'page', ?string $baseUrl = null): array
  {
    $b = $this->readBuilder();
    $rows = $b->paginate($perPage, $page, $pageParam, $baseUrl);
    $this->lastPager = $b->pager();
    $this->resetQuery();
    return $rows;
  }

  public function pager(): ?Pager
  {
    return $this->lastPager;
  }

  public function countAllResults(): int
  {
    $b = $this->readBuilder();
    $n = $b->countAllResults();
    $this->resetQuery();
    return $n;
  }

  /** CRUD */
  public function find($id): ?array
  {
    $b = $this->builder()->where($this->primaryKey, $id);
    if ($this->useSoftDeletes) {
      $b->whereRaw($this->deletedField . ' IS NULL');
    }
    return $b->first();
  }

  public function findAll(int $limit = 0, int $offset = 0): array
  {
    $b = $this->readBuilder();
    if ($limit > 0) {
      $b->limit($limit, max(0, $offset));
    }
    $rows = $b->get()->getResultArray();
    $this->resetQuery();
    return $rows;
  }

  public function insert(array $data, bool $returnId = true)
  {
    // evita arrastrar filtros/orden previos por encadenamiento
    $this->resetQuery();
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $now = $this->now();
      if (!isset($data[$this->createdField])) $data[$this->createdField] = $now;
      if (!isset($data[$this->updatedField])) $data[$this->updatedField] = $now;
    }
    $ok = $this->builder()->insert($data);
    if (!$ok) return false;
    return $returnId ? $this->db()->lastInsertId() : true;
  }

  public function update($id, array $data): bool
  {
    $this->resetQuery();
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $data[$this->updatedField] = $this->now();
    }
    // QueryBuilder->update() retorna int rowCount; aquí devolvemos bool de ejecución.
    $rows = $this->builder()->where($this->primaryKey, $id)->update($data);
    return $rows >= 0;
  }

  public function delete($id, bool $purge = false): bool
  {
    $this->resetQuery();
    if ($this->useSoftDeletes && !$purge) {
      $rows = $this->builder()->where($this->primaryKey, $id)->update([
        $this->deletedField => $this->now(),
      ]);
      return $rows >= 0;
    }
    $rows = $this->builder()->where($this->primaryKey, $id)->delete();
    return $rows >= 0;
  }

  /* =========================================
   * DbResult wrappers (PRO)
   * ========================================= */

  /** Ejecuta SELECT (con soft-deletes) y devuelve DbResult. */
  public function getResult(array $opts = []): DbResult
  {
    $b = $this->readBuilder();
    $r = $b->getResult($opts);
    $this->resetQuery();
    return $r;
  }

  /** Primer registro con DbResult(data=row|null). */
  public function firstResult(array $opts = []): DbResult
  {
    $b = $this->readBuilder();
    $r = $b->firstResult($opts);
    $this->resetQuery();
    return $r;
  }

  /** Paginación con DbResult(data=rows, meta.pager=...). */
  public function paginateResult(int $perPage = 20, ?int $page = null, string $pageParam = 'page', ?string $baseUrl = null, array $opts = []): DbResult
  {
    $b = $this->readBuilder();
    $r = $b->paginateResult($perPage, $page, $pageParam, $baseUrl, $opts);
    $this->lastPager = $b->pager();
    $this->resetQuery();
    return $r;
  }

  /** findResult(): busca por PK y devuelve DbResult(data=row|null). */
  public function findResult($id, array $opts = []): DbResult
  {
    $b = $this->builder()->where($this->primaryKey, $id);
    if ($this->useSoftDeletes) {
      $b->whereRaw($this->deletedField . ' IS NULL');
    }
    return $b->firstResult($opts);
  }

  /** findAllResult(): lista con DbResult(data=rows). */
  public function findAllResult(int $limit = 0, int $offset = 0, array $opts = []): DbResult
  {
    $b = $this->readBuilder();
    if ($limit > 0) $b->limit($limit, max(0, $offset));
    $r = $b->getResult($opts);
    $this->resetQuery();
    return $r;
  }

  /** insertResult(): inserta y devuelve DbResult(insertId). */
  public function insertResult(array $data, array $opts = []): DbResult
  {
    $this->resetQuery();
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $now = $this->now();
      if (!isset($data[$this->createdField])) $data[$this->createdField] = $now;
      if (!isset($data[$this->updatedField])) $data[$this->updatedField] = $now;
    }
    return $this->builder()->insertResult($data, $opts);
  }

  /** updateResult(): actualiza por PK y devuelve DbResult(rowCount). */
  public function updateResult($id, array $data, array $opts = []): DbResult
  {
    $this->resetQuery();
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $data[$this->updatedField] = $this->now();
    }
    return $this->builder()->where($this->primaryKey, $id)->updateResult($data, $opts);
  }

  /** deleteResult(): soft/hard delete por PK con DbResult. */
  public function deleteResult($id, bool $purge = false, array $opts = []): DbResult
  {
    $this->resetQuery();
    if ($this->useSoftDeletes && !$purge) {
      $r = $this->builder()->where($this->primaryKey, $id)->updateResult([
        $this->deletedField => $this->now(),
      ], $opts);
      $r->action = 'delete';
      $r->meta['soft'] = true;
      return $r;
    }
    return $this->builder()->where($this->primaryKey, $id)->deleteResult($opts);
  }

  public function withDeleted(): QueryBuilder
  {
    return $this->builder();
  }

  public function onlyDeleted(): QueryBuilder
  {
    if (!$this->useSoftDeletes) {
      Logger::warning(static::class . ' onlyDeleted() sin soft deletes');
    }
    return $this->builder()->whereRaw($this->deletedField . ' IS NOT NULL');
  }
}
