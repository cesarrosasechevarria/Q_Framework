<?php
declare(strict_types=1);

namespace System\Database\Seeds;

use System\Core\DB;
use System\Database\Connection;

/**
 * SeederRunner (v9)
 *
 * Ejecuta seeders por clase.
 *
 * CLI:
 *   php bin/console seed UserSeeder
 *   php bin/console seed App\\Database\\Seeds\\UserSeeder
 *   php bin/console seed Modules\\Blog\\Database\\Seeds\\BlogSeeder
 */
final class SeederRunner
{
  public function __construct(
    private string $group = 'default'
  ) {}

  public function group(string $group): self
  {
    $this->group = $group;
    return $this;
  }

  public function connection(): Connection
  {
    return DB::connect($this->group);
  }

  /**
   * Resuelve nombre corto -> App\\Database\\Seeds\\Name
   */
  public function resolve(string $name): string
  {
    $name = trim($name);
    if ($name === '') return '';

    // Si ya viene con namespace, se usa tal cual
    if (str_contains($name, '\\')) return $name;

    return 'App\\Database\\Seeds\\' . $name;
  }

  /** Ejecuta un seeder. */
  public function run(string $name): void
  {
    $class = $this->resolve($name);
    if ($class === '' || !class_exists($class)) {
      throw new \RuntimeException("Seeder no encontrado: {$class}");
    }

    $obj = new $class();
    if (!$obj instanceof SeederInterface) {
      throw new \RuntimeException("El seeder {$class} debe implementar " . SeederInterface::class);
    }

    $db = $this->connection();
    // Un seeder suele querer transacción; pero lo dejamos a decisión del seeder.
    $obj->run($db);
  }
}
