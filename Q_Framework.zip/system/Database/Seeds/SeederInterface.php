<?php
declare(strict_types=1);

namespace System\Database\Seeds;

use System\Database\Connection;

/**
 * SeederInterface (v9)
 *
 * Un seeder es una clase que inserta datos iniciales.
 *
 * Ejemplo:
 *   namespace App\Database\Seeds;
 *   class UserSeeder implements SeederInterface {
 *     public function run(Connection $db): void { ... }
 *   }
 */
interface SeederInterface
{
  public function run(Connection $db): void;
}
