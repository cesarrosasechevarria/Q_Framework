<?php
declare(strict_types=1);

namespace System\Database\Migrations;

use System\Database\Connection;

interface MigrationInterface
{
  public function up(Connection $db): void;
  public function down(Connection $db): void;
}
