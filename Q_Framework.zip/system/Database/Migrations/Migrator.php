<?php
declare(strict_types=1);

namespace System\Database\Migrations;

use System\Database\Connection;
use System\Core\Logger;

final class Migrator
{
  /** @var string[] */
  private array $paths;

  /**
   * @param string|array<int,string> $pathOrPaths
   */
  public function __construct(
    private Connection $db,
    string|array $pathOrPaths
  ) {
    $paths = is_array($pathOrPaths) ? $pathOrPaths : [$pathOrPaths];
    $clean = [];
    foreach ($paths as $p) {
      if (!is_string($p)) continue;
      $p = rtrim(trim($p), '/\\');
      if ($p === '') continue;
      $clean[] = $p;
    }
    $this->paths = array_values(array_unique($clean));
  }

  public function ensureTable(): void
  {
    // Simple: tabla migrations (MySQL)
    $sql = "CREATE TABLE IF NOT EXISTS migrations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      batch INT NOT NULL,
      applied_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $this->db->query($sql);
  }

  /** @return string[] */
  public function applied(): array
  {
    $this->ensureTable();
    $rows = $this->db->query('SELECT name FROM migrations ORDER BY id')->all();
    $out = [];
    foreach ($rows as $r) $out[] = (string)($r['name'] ?? '');
    return array_values(array_filter($out));
  }

  /**
   * Estado de migraciones:
   * @return array{applied:string[], pending:string[]}
   */
  public function status(): array
  {
    $applied = $this->applied();
    $files = $this->migrationFiles();

    $pending = [];
    foreach ($files as $name => $file) {
      if (!in_array($name, $applied, true)) $pending[] = $name;
    }

    return [
      'applied' => $applied,
      'pending' => $pending,
    ];
  }


  /** @return array{applied:int, skipped:int} */
  public function migrate(): array
  {
    $this->ensureTable();

    $applied = $this->applied();
    $files = $this->migrationFiles();

    $row = $this->db->query('SELECT COALESCE(MAX(batch),0) as b FROM migrations')->first();
    $batch = (int)($row['b'] ?? 0);
    $batch++;

    $countApplied = 0;
    $countSkipped = 0;

    foreach ($files as $name => $file) {
      if (in_array($name, $applied, true)) { $countSkipped++; continue; }

      $mig = require $file;
      if (!$mig instanceof MigrationInterface) {
        throw new \RuntimeException("Migration {$name} debe retornar instancia de MigrationInterface");
      }

      $mig->up($this->db);
      $this->db->query(
        'INSERT INTO migrations (name, batch, applied_at) VALUES (:n,:b,NOW())',
        ['n'=>$name,'b'=>$batch]
      );
      $countApplied++;
      Logger::info('Migration applied: ' . $name);
    }

    return ['applied'=>$countApplied,'skipped'=>$countSkipped];
  }

  /** Rollback último batch (simple) */
  public function rollback(): int
  {
    $this->ensureTable();

    $row = $this->db->query('SELECT COALESCE(MAX(batch),0) as b FROM migrations')->first();
    $batch = (int)($row['b'] ?? 0);
    if ($batch <= 0) return 0;

    $rows = $this->db->query('SELECT name FROM migrations WHERE batch=:b ORDER BY id DESC', ['b'=>$batch])->all();
    $files = $this->migrationFiles();

    $count = 0;
    foreach ($rows as $r) {
      $name = (string)($r['name'] ?? '');
      $file = $files[$name] ?? null;
      if (!$file || !is_file($file)) continue;

      $mig = require $file;
      if ($mig instanceof MigrationInterface) {
        $mig->down($this->db);
        $this->db->query('DELETE FROM migrations WHERE name=:n', ['n'=>$name]);
        $count++;
        Logger::info('Migration rolled back: ' . $name);
      }
    }

    return $count;
  }

  /** @return array<string,string> name => file */
  private function migrationFiles(): array
  {
    $out = [];

    foreach ($this->paths as $dir) {
      if (!is_dir($dir)) continue;

      foreach (glob($dir . DIRECTORY_SEPARATOR . '*.php') ?: [] as $file) {
        $base = basename($file);
        $name = preg_replace('/\.php$/', '', $base);
        if (!is_string($name) || $name === '') continue;

        // Si hay colisión, gana el primero (orden por $this->paths)
        $out[$name] ??= $file;
      }
    }

    ksort($out);
    return $out;
  }
}
