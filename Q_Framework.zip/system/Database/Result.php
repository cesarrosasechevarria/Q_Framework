<?php
declare(strict_types=1);

namespace System\Database;

use PDO;
use PDOStatement;

final class Result
{
  public function __construct(private PDOStatement $stmt) {}

  /** Compat CI: getResult('array'|'object') */
  public function getResult(string $type = 'array'): array
  {
    if ($type === 'object') {
      return $this->stmt->fetchAll(PDO::FETCH_OBJ) ?: [];
    }
    return $this->stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  }

  public function getResultArray(): array
  {
    return $this->getResult('array');
  }

  /** Compat CI: getRow('array'|'object') */
  public function getRow(string $type = 'array')
  {
    if ($type === 'object') {
      $row = $this->stmt->fetch(PDO::FETCH_OBJ);
      return $row === false ? null : $row;
    }
    $row = $this->stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
  }

  public function getRowArray(): ?array
  {
    $row = $this->stmt->fetch(PDO::FETCH_ASSOC);
    return $row === false ? null : $row;
  }

  public function rowCount(): int
  {
    return $this->stmt->rowCount();
  }


  /** Sugar: all() como array assoc */
  public function all(): array
  {
  return $this->getResultArray();
  }

  /** Sugar: first() como array assoc o null */
  public function first(): ?array
  {
  return $this->getRowArray();
  }

  /** Sugar: scalar() primera columna del primer row */
  public function scalar(): mixed
  {
  $row = $this->getRow('array');
  if (!is_array($row) || $row === []) return null;
  foreach ($row as $v) return $v;
  return null;
  }

  /** Column/Pluck: lista de valores de una columna (o callback por fila) */
  public function column(string|callable $valueSpec, array $opts = []): array
  {
  $rows = $this->getResultArray();

  $unique = (bool)($opts['unique'] ?? false);
  $filterNull = (bool)($opts['filterNull'] ?? false);
  $cast = $opts['cast'] ?? null; // callable|null

  $out = [];
  foreach ($rows as $row) {
    $v = is_callable($valueSpec)
      ? $valueSpec($row)
      : $this->rowGet($row, $this->resolveFieldKey((string)$valueSpec), null);

    if ($filterNull && ($v === null || $v === '')) continue;
    if (is_callable($cast)) $v = $cast($v, $row);

    if ($unique) {
      $k = is_scalar($v) ? (string)$v : json_encode($v);
      $out[$k] = $v;
    } else {
      $out[] = $v;
    }
  }

  return $unique ? array_values($out) : $out;
  }

  /** Alias de column() */
  public function pluck(string|callable $valueSpec, array $opts = []): array
  {
  return $this->column($valueSpec, $opts);
  }

  /**
   * pairs(): arma pares key=>value (o agrupados).
   *
   * $keySpec: string (col/alias) o callable(row)=>key
   * $valueSpec:
   *  - string (col/alias)
   *  - array de cols para armar etiqueta compuesta
   *  - callable(row)=>value
   *
   * opts:
   *  - fila0 (bool), label0 (string), value0 (string)
   *  - separator (string) para valueSpec array
   *  - template (string) ej "{codigo} - {nombre}" (ignora valueSpec)
   *  - groupBy (string|callable) => retorna [group=>[k=>v]]
   *  - keep ("last"|"first") para duplicados
   *  - sortBy ("key"|"label"|callable) + sortDir ("asc"|"desc")
   *  - trim (bool), prefix (string), suffix (string)
   *  - castKey (callable), castValue (callable)
   *  - skipMissing (bool) si faltan columnas
   */
  public function pairs(string|callable $keySpec, string|array|callable $valueSpec, array $opts = []): array
  {
  $rows = $this->getResultArray();

  $fila0 = (bool)($opts['fila0'] ?? false);
  $label0 = (string)($opts['label0'] ?? 'Ninguno');
  $value0 = (string)($opts['value0'] ?? '0');

  $separator = (string)($opts['separator'] ?? ' ');
  $template = $opts['template'] ?? null;

  $groupBy = $opts['groupBy'] ?? null; // string|callable|null
  $keep = strtolower((string)($opts['keep'] ?? 'last')); // last|first
  $skipMissing = (bool)($opts['skipMissing'] ?? true);

  $trim = (bool)($opts['trim'] ?? true);
  $prefix = (string)($opts['prefix'] ?? '');
  $suffix = (string)($opts['suffix'] ?? '');

  $castKey = $opts['castKey'] ?? null;     // callable|null
  $castValue = $opts['castValue'] ?? null; // callable|null

  $sortBy = $opts['sortBy'] ?? null; // 'key'|'label'|callable|null
  $sortDir = strtolower((string)($opts['sortDir'] ?? 'asc')) === 'desc' ? 'desc' : 'asc';

  $out = $groupBy ? [] : [];

  // Inserta fila0
  if ($fila0) {
    if ($groupBy) {
      $g0 = (string)($opts['group0'] ?? '');
      if (!isset($out[$g0])) $out[$g0] = [];
      $out[$g0][$value0] = $label0;
    } else {
      $out[$value0] = $label0;
    }
  }

  foreach ($rows as $row) {
    // key
    if (is_callable($keySpec)) {
      $k = $keySpec($row);
    } else {
      $kName = $this->resolveFieldKey((string)$keySpec);
      if (!$this->rowHas($row, $kName)) {
        if ($skipMissing) continue;
        $k = null;
      } else {
        $k = $row[$kName];
      }
    }

    if (is_callable($castKey)) $k = $castKey($k, $row);
    if (!is_scalar($k) && $k !== null) $k = json_encode($k);
    $k = (string)$k;

    // value
    $v = $this->buildValue($row, $valueSpec, $template, $separator, $skipMissing);

    if (is_callable($castValue)) $v = $castValue($v, $row);
    $v = $prefix . (string)$v . $suffix;
    if ($trim) $v = trim($v);

    // group
    if ($groupBy) {
      $g = is_callable($groupBy)
        ? $groupBy($row)
        : $this->rowGet($row, $this->resolveFieldKey((string)$groupBy), '');

      if (!is_scalar($g) && $g !== null) $g = json_encode($g);
      $g = (string)$g;

      if (!isset($out[$g])) $out[$g] = [];
      if ($keep === 'first' && array_key_exists($k, $out[$g])) continue;
      $out[$g][$k] = $v;
    } else {
      if ($keep === 'first' && array_key_exists($k, $out)) continue;
      $out[$k] = $v;
    }
  }

  // Sorting
  $out = $this->applyPairsSort($out, $sortBy, $sortDir);

  return $out;
  }

  /**
   * options(): genera HTML <option>…</option> desde pairs() (escapado).
   *
   * opts extra:
   *  - selected: scalar|array (uno o varios)
   *  - disabled: array de values a deshabilitar
   */
  public function options(string|callable $keySpec, string|array|callable $valueSpec, array $opts = []): string
  {
  $selected = $opts['selected'] ?? null;
  $disabled = $opts['disabled'] ?? [];
  $selSet = $this->normalizeSet($selected);
  $disSet = $this->normalizeSet($disabled);

  $pairs = $this->pairs($keySpec, $valueSpec, $opts);

  // Si viene agrupado => <optgroup>
  $isGrouped = $pairs && is_array(reset($pairs));
  $html = '';

  if ($isGrouped) {
    foreach ($pairs as $group => $gpairs) {
      $html .= '<optgroup label="' . esc((string)$group, 'attr') . '">';
      foreach ($gpairs as $k => $v) {
        $kStr = (string)$k;
        $isSel = isset($selSet[$kStr]);
        $isDis = isset($disSet[$kStr]);
        $html .= '<option value="' . esc($kStr, 'attr') . '"'
          . ($isSel ? ' selected="selected"' : '')
          . ($isDis ? ' disabled="disabled"' : '')
          . '>' . esc((string)$v, 'html') . '</option>';
      }
      $html .= '</optgroup>';
    }
    return $html;
  }

  foreach ($pairs as $k => $v) {
    $kStr = (string)$k;
    $isSel = isset($selSet[$kStr]);
    $isDis = isset($disSet[$kStr]);
    $html .= '<option value="' . esc($kStr, 'attr') . '"'
      . ($isSel ? ' selected="selected"' : '')
      . ($isDis ? ' disabled="disabled"' : '')
      . '>' . esc((string)$v, 'html') . '</option>';
  }

  return $html;
  }

  /* ===========================
    Helpers internos (Result)
    =========================== */

  private function resolveFieldKey(string $spec): string
  {
  $s = trim($spec);

  // Si viene "tabla.col AS alias" o "expr AS alias"
  if (preg_match('/\s+AS\s+([A-Za-z_][A-Za-z0-9_]*)\s*$/i', $s, $m)) {
    return $m[1];
  }

  // Si viene "tabla.col"
  if (str_contains($s, '.')) {
    $parts = explode('.', $s);
    return trim(end($parts));
  }

  return $s;
  }

  private function rowHas(array $row, string $key): bool
  {
  return array_key_exists($key, $row);
  }

  private function rowGet(array $row, string $key, $default = null)
  {
  if (array_key_exists($key, $row)) return $row[$key];
  return $default;
  }

  private function buildValue(array $row, string|array|callable $valueSpec, mixed $template, string $separator, bool $skipMissing): string
  {
  // Template: "{a} - {b}"
  if (is_string($template) && $template !== '') {
    return preg_replace_callback('/\{([A-Za-z_][A-Za-z0-9_]*)\}/', function ($m) use ($row) {
      $k = $m[1];
      $v = $this->rowGet($row, $k, '');
      return (string)$v;
    }, $template) ?? '';
  }

  if (is_callable($valueSpec)) {
    $v = $valueSpec($row);
    return (string)$v;
  }

  if (is_array($valueSpec)) {
    $parts = [];
    foreach ($valueSpec as $col) {
      if (is_callable($col)) {
        $parts[] = (string)$col($row);
        continue;
      }
      $k = $this->resolveFieldKey((string)$col);
      if (!$this->rowHas($row, $k)) {
        if ($skipMissing) return '';
        $parts[] = '';
        continue;
      }
      $parts[] = (string)$row[$k];
    }
    return implode($separator, array_map('trim', $parts));
  }

  $k = $this->resolveFieldKey((string)$valueSpec);
  if (!$this->rowHas($row, $k)) return $skipMissing ? '' : '';
  return (string)$row[$k];
  }

  private function normalizeSet($selected): array
  {
  $set = [];
  if ($selected === null) return $set;

  $arr = is_array($selected) ? $selected : [$selected];
  foreach ($arr as $v) {
    if (!is_scalar($v) && $v !== null) $v = json_encode($v);
    $set[(string)$v] = true;
  }
  return $set;
  }

  private function applyPairsSort(array $pairs, $sortBy, string $dir): array
  {
  if ($sortBy === null) return $pairs;

  $cmp = function ($a, $b) use ($dir) {
    $r = strnatcasecmp((string)$a, (string)$b);
    return $dir === 'desc' ? -$r : $r;
  };

  // agrupado
  if ($pairs && is_array(reset($pairs))) {
    foreach ($pairs as $g => $gpairs) {
      $pairs[$g] = $this->applyPairsSort($gpairs, $sortBy, $dir);
    }
    // opcional: ordenar grupos por nombre si sortBy === 'group'
    return $pairs;
  }

  if ($sortBy === 'key') {
    uksort($pairs, fn($a,$b) => $cmp($a,$b));
    return $pairs;
  }

  if ($sortBy === 'label') {
    uasort($pairs, fn($a,$b) => $cmp($a,$b));
    return $pairs;
  }

  if (is_callable($sortBy)) {
    // sortBy(row) no aplica aquí (ya no tenemos row), pero sí puedes pasar callable(aKey,aVal,bKey,bVal)
    uasort($pairs, function($va,$vb) use ($pairs,$sortBy,$dir){
      $r = $sortBy($va,$vb);
      $r = (int)$r;
      return $dir === 'desc' ? -$r : $r;
    });
    return $pairs;
  }

  return $pairs;
  
  }

}