<?php
declare(strict_types=1);

namespace System\Database;

use PDO;
use PDOException;
use System\Database\DbResult;

final class Connection
{
  private ?string $lastError = null;

  // Cache de helpers PRO
  private ?\System\Database\Schema\Schema $schema = null;
  private ?\System\Database\Crud\Crud $crud = null;

  public function __construct(
    private string $group,
    private PDO $pdo
  ) {}

  public function group(): string { return $this->group; }

  public function pdo(): PDO { return $this->pdo; }

  /** Driver PDO (mysql, pgsql, sqlite, etc.) */
  public function driver(): string
  {
    try { return (string)$this->pdo->getAttribute(\PDO::ATTR_DRIVER_NAME); }
    catch (\Throwable $e) { return ''; }
  }

  /** Último error como string (si ocurrió) */
  public function lastError(): ?string { return $this->lastError; }

  /** Compat CI: error() -> ['code'=>..., 'message'=>...] */
  public function error(): array
  {
    $info = $this->pdo->errorInfo();
    return [
      'code' => $info[1] ?? null,
      'message' => $this->lastError ?? ($info[2] ?? null),
    ];
  }

  /** Compat CI: insertID() */
  public function insertID(): string
  {
    return (string)$this->pdo->lastInsertId();
  }

  /** Compat CI: tableExists($table) */
  /** Compat CI: tableExists($table) */
  public function tableExists(string $table): bool
  {
    $this->lastError = null;
    try {
      $driver = $this->driver();

      // MySQL/MariaDB: usa information_schema para evitar el límite de
      // "SHOW TABLES" con prepared statements cuando ATTR_EMULATE_PREPARES=false.
      if ($driver === 'mysql') {
        $sql = "SELECT 1
                FROM information_schema.tables
                WHERE table_schema = DATABASE()
                  AND table_name = :t
                LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['t' => $table]);
        return (bool)$stmt->fetchColumn();
      }

      // PostgreSQL
      if ($driver === 'pgsql') {
        $sql = "SELECT 1
                FROM information_schema.tables
                WHERE table_schema = current_schema()
                  AND table_name = :t
                LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['t' => $table]);
        return (bool)$stmt->fetchColumn();
      }

      // SQLite
      if ($driver === 'sqlite') {
        $sql = "SELECT 1
                FROM sqlite_master
                WHERE type = 'table' AND name = :t
                LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['t' => $table]);
        return (bool)$stmt->fetchColumn();
      }

      // Fallback genérico (sin prepared)
      $qt = $this->pdo->quote($table);
      $stmt = $this->pdo->query("SHOW TABLES LIKE {$qt}");
      return (bool)($stmt ? $stmt->fetchColumn() : false);

    } catch (PDOException $e) {
      $this->lastError = $e->getMessage();
      return false;
    }
  }


  /** Compat CI: getFieldData($table) -> array de columnas */
  public function getFieldData(string $table): array
  {
    try {
      $stmt = $this->pdo->query("DESCRIBE `{$table}`");
      $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
      // Normaliza llaves parecidas a Q_Framework (name, type, null, key, default, extra)
      $out = [];
      foreach ($rows as $r) {
        $out[] = [
          'name'    => $r['Field'] ?? null,
          'type'    => $r['Type'] ?? null,
          'null'    => $r['Null'] ?? null,
          'key'     => $r['Key'] ?? null,
          'default' => $r['Default'] ?? null,
          'extra'   => $r['Extra'] ?? null,
        ];
      }
      return $out;
    } catch (PDOException $e) {
      $this->lastError = $e->getMessage();
      return [];
    }
  }

  /** Compat: getIndexData($table) -> array de índices (MySQL) */
  public function getIndexData(string $table): array
  {
    try {
      $driver = $this->driver();
      if ($driver !== 'mysql') {
        return [];
      }

      $stmt = $this->pdo->query("SHOW INDEX FROM `{$table}`");
      $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
      $out = [];
      foreach ($rows as $r) {
        $out[] = [
          'table'        => $r['Table'] ?? null,
          'key_name'     => $r['Key_name'] ?? null,
          'non_unique'   => isset($r['Non_unique']) ? (int)$r['Non_unique'] : null,
          'seq_in_index' => isset($r['Seq_in_index']) ? (int)$r['Seq_in_index'] : null,
          'column_name'  => $r['Column_name'] ?? null,
          'index_type'   => $r['Index_type'] ?? null,
          'collation'    => $r['Collation'] ?? null,
          'sub_part'     => $r['Sub_part'] ?? null,
          'packed'       => $r['Packed'] ?? null,
          'null'         => $r['Null'] ?? null,
          'comment'      => $r['Comment'] ?? null,
          'index_comment' => $r['Index_comment'] ?? null,
        ];
      }
      return $out;
    } catch (PDOException $e) {
      $this->lastError = $e->getMessage();
      return [];
    }
  }

  /** Query preparada (retorna Result) */
  public function query(string $sql, array $params = []): Result
  {
    $this->lastError = null;
    try {
      $stmt = $this->pdo->prepare($sql);
      $stmt->execute($params);
      return new Result($stmt);
    } catch (PDOException $e) {
      $this->lastError = $e->getMessage();
      throw $e;
    }
  }

  /**
   * Query preparada (PRO): devuelve DbResult en vez de lanzar por defecto.
   *
   * opts:
   * - mode: 'result' (default) | 'throw'
   * - fetch: 'none'|'row'|'rows'|'scalar' (default: 'none')
   * - action: 'query'|'select'|'insert'|'update'|'delete'|'exec'
   * - table: string|null (solo para metadata)
   */
  public function queryResult(string $sql, array $params = [], array $opts = []): DbResult
  {
    $this->lastError = null;

    $mode = strtolower((string)($opts['mode'] ?? 'result'));
    $fetch = strtolower((string)($opts['fetch'] ?? 'none'));
    $action = (string)($opts['action'] ?? 'query');
    $table = $opts['table'] ?? null;

    $r = new DbResult();
    $r->action = $action;
    $r->table = is_string($table) ? $table : null;
    $r->sql = $sql;
    $r->params = $params;
    $r->meta['group'] = $this->group;
    $r->meta['driver'] = $this->driver();

    $t0 = microtime(true);
    try {
      $stmt = $this->pdo->prepare($sql);
      $stmt->execute($params);

      $r->rowCount = (int)$stmt->rowCount();
      if ($action === 'insert') {
        $r->insertId = $this->insertID();
      }

      if ($fetch === 'rows') {
        $r->data = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      } elseif ($fetch === 'row') {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $r->data = ($row === false) ? null : $row;
      } elseif ($fetch === 'scalar') {
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $r->data = ($row === false) ? null : ($row[0] ?? null);
      } else {
        $r->data = null;
      }

      $r->ok = true;
    } catch (\Throwable $e) {
      $this->lastError = $e->getMessage();
      $r = DbResult::failFromThrowable($e, [
        'action' => $action,
        'table' => $table,
        'sql' => $sql,
        'params' => $params,
      ]);
      $r->meta['group'] = $this->group;
      $r->meta['driver'] = $this->driver();
      if ($mode === 'throw') throw $e;
    } finally {
      $r->time_ms = round((microtime(true) - $t0) * 1000, 2);
    }

    return $r;
  }

  /** Alias: execResult() para DML/DDL. */
  public function execResult(string $sql, array $params = [], array $opts = []): DbResult
  {
    $opts['action'] = $opts['action'] ?? 'exec';
    $opts['fetch']  = $opts['fetch']  ?? 'none';
    return $this->queryResult($sql, $params, $opts);
  }

  public function lastInsertId(?string $name = null): string
  {
    try {
      return $this->pdo->lastInsertId($name);
    } catch (\Throwable $e) {
      return '';
    }
  }

  /** Inicia QueryBuilder */
  public function table(string $table): QueryBuilder
  {
    return new QueryBuilder($this, $table);
  }

  

/** Shortcut PRO: Schema (DDL) */
public function schema(): \System\Database\Schema\Schema
{
  if ($this->schema === null) {
    $this->schema = new \System\Database\Schema\Schema($this);
  }
  return $this->schema;
}

/** Shortcut PRO: CRUD dinámico por tabla */
public function crud(): \System\Database\Crud\Crud
{
  if ($this->crud === null) {
    $this->crud = new \System\Database\Crud\Crud($this);
  }
  return $this->crud;
}

/** Transacciones (PRO) */
  public function begin(): bool
  {
    return $this->pdo->beginTransaction();
  }

  public function commit(): bool
  {
    return $this->pdo->commit();
  }

  public function rollback(): bool
  {
    return $this->pdo->rollBack();
  }

  /**
   * Ejecuta una transacción.
   * - Si el callback lanza excepción => rollback y rethrow.
   */
  public function transaction(callable $fn): mixed
  {
    $this->begin();
    try {
      $res = $fn($this);
      $this->commit();
      return $res;
    } catch (\Throwable $e) {
      if ($this->pdo->inTransaction()) {
        try { $this->rollback(); } catch (\Throwable $e2) {}
      }
      throw $e;
    }
  }

  /**
   * Transacción con reintentos (deadlock/serialization).
   * Útil en alta concurrencia.
   */
  public function retryTransaction(callable $fn, int $attempts = 3, int $sleepMs = 60): mixed
  {
    $attempts = max(1, $attempts);
    $sleepMs = max(0, $sleepMs);

    $last = null;
    for ($i = 1; $i <= $attempts; $i++) {
      try {
        return $this->transaction($fn);
      } catch (PDOException $e) {
        $last = $e;
        if (!$this->isRetryableTxError($e) || $i === $attempts) throw $e;
        if ($sleepMs > 0) usleep($sleepMs * 1000);
      }
    }
    throw $last ?? new PDOException('Transaction failed');
  }

  private function isRetryableTxError(PDOException $e): bool
  {
    $state = $e->getCode();
    // SQLSTATE comunes
    if (in_array($state, ['40001','40P01'], true)) return true; // serialization, deadlock

    // MySQL deadlock / lock wait timeout: 1213 / 1205
    $msg = $e->getMessage();
    if (str_contains($msg, 'Deadlock found')) return true;
    if (str_contains($msg, 'Lock wait timeout exceeded')) return true;
    return false;
  }
}
