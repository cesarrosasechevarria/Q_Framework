<?php
declare(strict_types=1);

namespace System\Database\Presenter;

use System\Database\Connection;
use System\Services\Encrypter;

/**
 * ExtrasPresenter (CORE)
 *
 * Convierte una fila DB (array) en una salida “presentable” para AJAX:
 * - Encripta campos tipo id ( *_id / id_* ) si se desea.
 * - Resuelve EXTRAS declarativos:
 *   - lookup        : FK => {texto, valor}
 *   - lookup_multi  : CSV/array/json => [{texto, valor}, ...] o HTML <option>
 *   - files         : id(s) app_archivos => metadata + url
 *   - map           : mapea valores a etiquetas/clases (badge/estado)
 *   - json_get      : extrae claves de JSON guardado en un campo
 *
 * Importante:
 * - NO acepta SQL desde el cliente (seguridad).
 */
final class ExtrasPresenter
{
    private Connection $db;
    private Encrypter $enc;

    public function __construct(Connection $db, Encrypter $enc)
    {
        $this->db  = $db;
        $this->enc = $enc;
    }

    /**
     * Presenta una fila.
     *
     * @param array $row   Fila desde QueryBuilder (first()).
     * @param array|null $extras  Definición declarativa de extras.
     * @param array $opts Opciones:
     *   - encrypt_ids (bool) default true
     *   - id_fields (callable|string) callable($key,$val,$row):bool o regex
     *   - decrypt_input_ids (bool) default true (si el valor viene token)
     *   - safe_tables (array|null) allowlist opcional de tablas permitidas
     *   - safe_ident_strict (bool) default true (solo [A-Za-z0-9_])
     */
    public function presentRow(array $row, ?array $extras = null, array $opts = []): array
    {
        $opts = array_merge([
            'encrypt_ids'        => true,
            'decrypt_input_ids'  => true,
            'id_fields'          => null,
            'safe_tables'        => null,
            'safe_ident_strict'  => true,
        ], $opts);

        if ($extras && is_array($extras)) {
            $row = $this->applyExtras($row, $extras, $opts);
        }

        if (!empty($opts['encrypt_ids'])) {
            $row = $this->encryptIdFields($row, $opts);
        }

        return $row;
    }

    /**
     * Presenta varias filas (lista).
     */
    public function presentRows(array $rows, ?array $extras = null, array $opts = []): array
    {
        $out = [];
        foreach ($rows as $r) {
            $out[] = is_array($r) ? $this->presentRow($r, $extras, $opts) : $r;
        }
        return $out;
    }

    // =========================================================
    // EXTRAS
    // =========================================================

    private function applyExtras(array $row, array $extras, array $opts): array
    {
        foreach ($extras as $field => $spec) {
            if (!is_string($field) || $field === '') continue;
            if (!is_array($spec)) continue;

            $type = strtolower((string)($spec['type'] ?? $spec['tipo'] ?? ''));
            if ($type === '') continue;

            $value = $row[$field] ?? null;

            switch ($type) {
                case 'lookup':
                    $row[$field] = $this->extraLookup($value, $spec, $opts);
                    break;

                case 'lookup_multi':
                    $row[$field] = $this->extraLookupMulti($value, $spec, $opts);
                    break;

                // Alias útil: generar <option> directamente
                case 'combo':
                case 'options':
                case 'options_html':
                    $spec['as'] = 'options_html';
                    $row[$field] = $this->extraLookupMulti($value, $spec, $opts);
                    break;

                case 'files':
                case 'file':
                    $row[$field] = $this->extraFiles($value, $spec, $opts);
                    break;

                case 'map':
                case 'badge':
                    $row[$field] = $this->extraMap($value, $spec);
                    break;

                case 'json_get':
                    $row[$field] = $this->extraJsonGet($value, $spec);
                    break;

                default:
                    // tipo no soportado: lo deja igual
                    break;
            }
        }

        return $row;
    }

    /**
     * lookup: FK -> {texto, valor} o texto/valor/row.
     *
     * spec:
     *  - type: lookup
     *  - table: "clientes"
     *  - value: "cli_id"      (columna id)
     *  - label: "cli_nombre"  (columna texto)
     *  - where: {estado:"activo"} (opcional)
     *  - as: "pair"|"text"|"value"|"row" (default pair)
     *  - keys: {texto:"texto", valor:"valor"} (opcional)
     *  - encrypt_value: bool (default true)
     */
    private function extraLookup($fk, array $spec, array $opts)
    {
        if ($fk === null || $fk === '') {
            return $spec['null'] ?? null;
        }

        $table = (string)($spec['table'] ?? $spec['tabla'] ?? '');
        $valueCol = (string)($spec['value'] ?? $spec['id'] ?? $spec['pk'] ?? '');
        $labelCol = (string)($spec['label'] ?? $spec['nombre'] ?? $spec['texto'] ?? '');

        if (!$this->safeIdent($table, $opts) || !$this->safeIdent($valueCol, $opts) || !$this->safeIdent($labelCol, $opts)) {
            return $spec['null'] ?? null;
        }

        if (is_array($opts['safe_tables']) && !in_array($table, $opts['safe_tables'], true)) {
            return $spec['null'] ?? null;
        }

        // si el FK vino token (AJAX), lo desencripta
        if (!empty($opts['decrypt_input_ids']) && is_string($fk) && !is_numeric($fk)) {
            $dec = $this->tryDecrypt($fk);
            if ($dec !== null) $fk = $dec;
        }

        $qb = $this->db->table($table)->select("$labelCol AS __label, $valueCol AS __value")->where($valueCol, $fk);

        $whereExtra = $spec['where'] ?? null;
        if (is_array($whereExtra)) {
            foreach ($whereExtra as $k => $v) {
                if (!is_string($k) || !$this->safeIdent($k, $opts)) continue;
                $qb->where($k, $v);
            }
        }

        $r = $qb->first();
        if (!$r) return $spec['null'] ?? null;

        $as = strtolower((string)($spec['as'] ?? 'pair'));
        $encryptValue = array_key_exists('encrypt_value', $spec) ? (bool)$spec['encrypt_value'] : true;

        $valOut = $r['__value'] ?? null;
        if ($encryptValue && $valOut !== null && $valOut !== '') {
            $valOut = $this->enc->encrypt((string)$valOut);
        }

        if ($as === 'text')  return (string)($r['__label'] ?? '');
        if ($as === 'value') return $valOut;
        if ($as === 'row')   return $r;

        // default: pair
        $keys = $spec['keys'] ?? null;
        $kTexto = is_array($keys) ? (string)($keys['texto'] ?? 'texto') : 'texto';
        $kValor = is_array($keys) ? (string)($keys['valor'] ?? 'valor') : 'valor';

        return [
            $kTexto => $r['__label'] ?? '',
            $kValor => $valOut,
        ];
    }

    /**
     * lookup_multi: CSV/array/json -> lista de pares / map / options html.
     *
     * spec:
     *  - type: lookup_multi
     *  - table, value, label
     *  - source: "csv"|"json"|"array"|"auto" (default auto)
     *  - as: "list"|"map"|"options_html"|"values"|"labels" (default list)
     *  - include_none: bool (si options_html) agrega <option value="0">Ninguno</option>
     *  - none_value: "0" (opcional)
     *  - none_label: "Ninguno" (opcional)
     *  - encrypt_value: bool default true
     *  - keep_order: bool default true (reordena según ids de entrada)
     */
    private function extraLookupMulti($val, array $spec, array $opts)
    {
        $table = (string)($spec['table'] ?? $spec['tabla'] ?? '');
        $valueCol = (string)($spec['value'] ?? $spec['id'] ?? $spec['pk'] ?? '');
        $labelCol = (string)($spec['label'] ?? $spec['nombre'] ?? $spec['texto'] ?? '');

        if (!$this->safeIdent($table, $opts) || !$this->safeIdent($valueCol, $opts) || !$this->safeIdent($labelCol, $opts)) {
            return $spec['null'] ?? (strtolower((string)($spec['as'] ?? '')) === 'options_html' ? '' : []);
        }

        if (is_array($opts['safe_tables']) && !in_array($table, $opts['safe_tables'], true)) {
            return $spec['null'] ?? [];
        }

        // Parse ids
        $ids = $this->parseIds($val, (string)($spec['source'] ?? 'auto'));

        // si venían tokens, intenta desencriptar
        if (!empty($opts['decrypt_input_ids'])) {
            $ids2 = [];
            foreach ($ids as $id) {
                if (is_string($id) && !is_numeric($id)) {
                    $dec = $this->tryDecrypt($id);
                    $ids2[] = $dec !== null ? $dec : $id;
                } else {
                    $ids2[] = $id;
                }
            }
            $ids = $ids2;
        }

        // limpiar vacíos
        $ids = array_values(array_filter($ids, fn($x) => $x !== null && $x !== ''));
        $ids = array_values(array_unique($ids, SORT_REGULAR));

        $as = strtolower((string)($spec['as'] ?? 'list'));
        $encryptValue = array_key_exists('encrypt_value', $spec) ? (bool)$spec['encrypt_value'] : true;
        $keepOrder = array_key_exists('keep_order', $spec) ? (bool)$spec['keep_order'] : true;

        if (!$ids) {
            if ($as === 'options_html') {
                $html = '';
                if (!empty($spec['include_none'])) {
                    $nv = (string)($spec['none_value'] ?? '0');
                    $nl = (string)($spec['none_label'] ?? 'Ninguno');
                    $html .= "<option value=\"" . htmlspecialchars($nv) . "\">" . htmlspecialchars($nl) . "</option>";
                }
                return $html;
            }
            return $spec['null'] ?? [];
        }

        $qb = $this->db->table($table)->select("$labelCol AS __label, $valueCol AS __value")->whereIn($valueCol, $ids);
        $rows = $qb->get()->getResultArray();

        // index by value for order rebuild
        $by = [];
        foreach ($rows as $r) {
            $key = (string)($r['__value'] ?? '');
            $by[$key] = $r;
        }

        if ($keepOrder) {
            $ordered = [];
            foreach ($ids as $id) {
                $k = (string)$id;
                if (isset($by[$k])) $ordered[] = $by[$k];
            }
            $rows = $ordered;
        }

        // build outputs
        if ($as === 'values') {
            $out = [];
            foreach ($rows as $r) {
                $v = $r['__value'] ?? null;
                if ($encryptValue && $v !== null && $v !== '') $v = $this->enc->encrypt((string)$v);
                $out[] = $v;
            }
            return $out;
        }

        if ($as === 'labels') {
            return array_map(fn($r) => (string)($r['__label'] ?? ''), $rows);
        }

        if ($as === 'map') {
            $out = [];
            foreach ($rows as $r) {
                $v = $r['__value'] ?? null;
                $k = $v;
                if ($encryptValue && $v !== null && $v !== '') $k = $this->enc->encrypt((string)$v);
                $out[(string)$k] = (string)($r['__label'] ?? '');
            }
            return $out;
        }

        if ($as === 'options_html') {
            $html = '';
            if (!empty($spec['include_none'])) {
                $nv = (string)($spec['none_value'] ?? '0');
                $nl = (string)($spec['none_label'] ?? 'Ninguno');
                $html .= "<option value=\"" . htmlspecialchars($nv) . "\">" . htmlspecialchars($nl) . "</option>";
            }

            foreach ($rows as $r) {
                $v = $r['__value'] ?? '';
                if ($encryptValue && $v !== null && $v !== '') $v = $this->enc->encrypt((string)$v);

                $t = (string)($r['__label'] ?? '');
                $html .= "<option value=\"" . htmlspecialchars((string)$v) . "\">" . htmlspecialchars($t) . "</option>";
            }
            return $html;
        }

        // default: list de pares
        $keys = $spec['keys'] ?? null;
        $kTexto = is_array($keys) ? (string)($keys['texto'] ?? 'texto') : 'texto';
        $kValor = is_array($keys) ? (string)($keys['valor'] ?? 'valor') : 'valor';

        $out = [];
        foreach ($rows as $r) {
            $v = $r['__value'] ?? null;
            if ($encryptValue && $v !== null && $v !== '') $v = $this->enc->encrypt((string)$v);

            $out[] = [
                $kTexto => (string)($r['__label'] ?? ''),
                $kValor => $v,
            ];
        }
        return $out;
    }

    /**
     * files: id(s) -> metadata + url (desde app_archivos)
     *
     * spec:
     *  - type: files
     *  - as: "file"|"files" (auto si es múltiple)
     *  - base_url: "uploads/archivos" (default)
     *  - encrypt_id: bool default true (devuelve arch_id token)
     */
    private function extraFiles($val, array $spec, array $opts)
    {
        $ids = $this->parseIds($val, (string)($spec['source'] ?? 'auto'));

        if (!empty($opts['decrypt_input_ids'])) {
            $ids2 = [];
            foreach ($ids as $id) {
                if (is_string($id) && !is_numeric($id)) {
                    $dec = $this->tryDecrypt($id);
                    $ids2[] = $dec !== null ? $dec : $id;
                } else {
                    $ids2[] = $id;
                }
            }
            $ids = $ids2;
        }

        $ids = array_values(array_filter($ids, fn($x) => $x !== null && $x !== ''));
        $ids = array_values(array_unique($ids, SORT_REGULAR));

        if (!$ids) return $spec['null'] ?? (is_array($val) ? [] : null);

        $rows = $this->db->table('app_archivos')
            ->select('arch_id, arch_tabla, arch_columna, arch_idtabla, arch_documento')
            ->whereIn('arch_id', $ids)
            ->get()
            ->getResultArray();

        $base = trim((string)($spec['base_url'] ?? 'uploads/archivos'), '/');

        $encryptId = array_key_exists('encrypt_id', $spec) ? (bool)$spec['encrypt_id'] : true;

        // index para reordenar
        $by = [];
        foreach ($rows as $r) $by[(string)$r['arch_id']] = $r;

        $out = [];
        foreach ($ids as $id) {
            $k = (string)$id;
            if (!isset($by[$k])) continue;
            $r = $by[$k];

            $doc = json_decode((string)($r['arch_documento'] ?? ''), true) ?: [];
            $docNombre = (string)($doc['doc_nombre'] ?? '');
            $docFile   = (string)($doc['doc_file'] ?? '');
            $mime      = (string)($doc['doc_mime'] ?? '');
            $ext       = (string)($doc['doc_ext'] ?? '');
            $size      = (int)($doc['doc_tam'] ?? 0);

            $url = $this->baseUrlJoin($base . '/' . $r['arch_tabla'] . '/' . $r['arch_columna'] . '/' . $docNombre);

            $idOut = $r['arch_id'];
            if ($encryptId && $idOut !== null && $idOut !== '') {
                $idOut = $this->enc->encrypt((string)$idOut);
            }

            $out[] = [
                'id'      => $idOut,
                'name'    => $docFile,
                'stored'  => $docNombre,
                'mime'    => $mime,
                'ext'     => $ext,
                'size'    => $size,
                'url'     => $url,
                'table'   => $r['arch_tabla'],
                'column'  => $r['arch_columna'],
                'row_id'  => $r['arch_idtabla'],
            ];
        }

        $as = strtolower((string)($spec['as'] ?? 'auto'));
        if ($as === 'file') return $out[0] ?? null;
        if ($as === 'files') return $out;

        // auto: si entrada parecía múltiple, lista; si no, solo uno
        $multiple = is_array($val) || (is_string($val) && str_contains($val, ','));
        return $multiple ? $out : ($out[0] ?? null);
    }

    /**
     * map/badge: transforma valores a un mapa o a un objeto (badge/text/class)
     *
     * spec:
     *  - type: map
     *  - map: {activa:"Activa", vencida:"Vencida"}
     *  - default: "—"
     *  - as: "value"|"badge"
     *  - classes: {activa:"success", vencida:"warning"} (si badge)
     */
    private function extraMap($val, array $spec)
    {
        $map = $spec['map'] ?? $spec['values'] ?? null;
        if (!is_array($map)) return $val;

        $key = is_string($val) ? strtolower(trim($val)) : $val;
        $def = $spec['default'] ?? ($spec['null'] ?? $val);

        $as = strtolower((string)($spec['as'] ?? 'value'));

        if ($as === 'badge') {
            $classes = $spec['classes'] ?? [];
            $text = $map[$key] ?? $def;
            $cls  = is_array($classes) ? ($classes[$key] ?? ($classes['default'] ?? 'primary')) : 'primary';
            return ['text' => $text, 'class' => $cls, 'value' => $val];
        }

        return $map[$key] ?? $def;
    }

    /**
     * json_get: extrae claves de un JSON string.
     *
     * spec:
     *  - type: json_get
     *  - key: "a.b.c"  o  keys: ["a","b"]
     *  - default: null
     */
    private function extraJsonGet($val, array $spec)
    {
        if (!is_string($val) || trim($val) === '') return $spec['default'] ?? null;

        $obj = json_decode($val, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($obj)) return $spec['default'] ?? null;

        if (isset($spec['keys']) && is_array($spec['keys'])) {
            $out = [];
            foreach ($spec['keys'] as $k) {
                if (!is_string($k) || $k === '') continue;
                $out[$k] = $obj[$k] ?? null;
            }
            return $out;
        }

        $path = (string)($spec['key'] ?? '');
        if ($path === '') return $spec['default'] ?? null;

        $parts = explode('.', $path);
        $cur = $obj;
        foreach ($parts as $p) {
            if (!is_array($cur) || !array_key_exists($p, $cur)) return $spec['default'] ?? null;
            $cur = $cur[$p];
        }

        return $cur;
    }

    // =========================================================
    // ID Encryption
    // =========================================================

    private function encryptIdFields(array $row, array $opts): array
    {
        $matcher = $opts['id_fields'] ?? null;

        foreach ($row as $k => $v) {
            if (!is_string($k) || $k === '') continue;
            if (is_array($v)) continue; // no toca objetos/listas

            $isId = $this->isIdField($k, $v, $row, $matcher);
            if (!$isId) continue;

            if ($v === null || $v === '') continue;

            // evita re-encriptar tokens: si decrypt da algo, asumimos token
            if (is_string($v) && !is_numeric($v)) {
                $dec = $this->tryDecrypt($v);
                if ($dec !== null) {
                    $row[$k] = $v; // ya es token
                    continue;
                }
            }

            $row[$k] = $this->enc->encrypt((string)$v);
        }

        return $row;
    }

    private function isIdField(string $key, $val, array $row, $matcher = null): bool
    {
        if (is_callable($matcher)) {
            return (bool)$matcher($key, $val, $row);
        }

        if (is_string($matcher) && $matcher !== '') {
            return (bool)preg_match($matcher, $key);
        }

        // default (tu lógica, corregida)
        return (strpos($key, '_id') !== false) || (strpos($key, 'id_') !== false);
    }

    // =========================================================
    // Utils
    // =========================================================

    private function parseIds($val, string $source = 'auto'): array
    {
        $source = strtolower(trim($source));

        if ($source === 'array' && is_array($val)) return array_values($val);

        if ($source === 'json') {
            if (is_string($val)) {
                $d = json_decode($val, true);
                return (json_last_error() === JSON_ERROR_NONE && is_array($d)) ? array_values($d) : [];
            }
            return is_array($val) ? array_values($val) : [];
        }

        if ($source === 'csv') {
            if (is_string($val)) {
                $parts = array_map('trim', explode(',', $val));
                return array_values(array_filter($parts, fn($x) => $x !== ''));
            }
            return is_array($val) ? array_values($val) : [];
        }

        // auto
        if (is_array($val)) return array_values($val);

        if (is_string($val)) {
            $s = trim($val);
            if ($s === '') return [];
            if ($s[0] === '[' || $s[0] === '{') {
                $d = json_decode($s, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($d)) return array_values($d);
            }
            if (str_contains($s, ',')) {
                $parts = array_map('trim', explode(',', $s));
                return array_values(array_filter($parts, fn($x) => $x !== ''));
            }
            return [$s];
        }

        return [$val];
    }

    private function tryDecrypt(string $token): ?string
    {
        try {
            $d = $this->enc->decrypt($token);
            if ($d === null || $d === false) return null;
            $s = (string)$d;
            return $s === '' ? null : $s;
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function safeIdent(string $s, array $opts): bool
    {
        $s = trim($s);
        if ($s === '') return false;

        if (!empty($opts['safe_ident_strict'])) {
            return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $s);
        }

        // modo “menos estricto” (si algún día necesitas esquema.tabla)
        return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_\.]*$/', $s);
    }

    private function baseUrlJoin(string $path): string
    {
        $path = ltrim($path, '/');

        // base_url() es CORE en tu framework
        if (function_exists('base_url')) {
            return base_url($path);
        }

        // fallback
        $host = ($_SERVER['HTTP_HOST'] ?? '');
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        return $host ? ($scheme . '://' . $host . '/' . $path) : ('/' . $path);
    }
}
