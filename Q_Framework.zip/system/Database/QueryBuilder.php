<?php
declare(strict_types=1);

namespace System\Database;

use System\Core\Security;

final class QueryBuilder
{
  private array $select = ['*'];
  private bool $distinct = false;

  private array $joins = [];

  /**
   * Tokens de WHERE/HAVING.
   * - Condición legacy: [bool, expr]
   * - Group start: ['type'=>'groupStart','bool'=>'AND|OR','not'=>bool]
   * - Group end: ['type'=>'groupEnd']
   */
  private array $wheres = [];
  private array $havings = [];
  private array $groupBys = [];
  private array $orderBys = [];

  private ?int $limit = null;
  private ?int $offset = null;

  /** @var array<string,mixed> */
  private array $params = [];
  private int $pIndex = 0;

  /** @var array<string,mixed> */
  private array $setData = [];

  private ?Pager $pager = null;

  public function __construct(
    private Connection $db,
    private string $table
  ) {
    $this->table = $this->escapeTable($table);
  }

  private function strictIdentifiers(): bool
  {
    $cfg = config('Database');
    return !empty($cfg->strictIdentifiers);
  }

  private function protectWrites(): bool
  {
    $cfg = config('Database');
    return !empty($cfg->protectWrites);
  }

  /** Bloquea tokens peligrosos en SQL raw (multi-statement, comentarios). */
  private function guardRawSql(string $sql, string $context = 'raw'): void
  {
    $s = strtolower($sql);
    if (str_contains($s, "\0")) throw new \InvalidArgumentException("SQL inválido ({$context})");
    if (str_contains($s, ';') || str_contains($s, '--') || str_contains($s, '/*') || str_contains($s, '*/') || str_contains($s, '#')) {
      throw new \InvalidArgumentException("SQL raw no permitido ({$context}). Usa métodos seguros o revisa el SQL.");
    }
  }

  private function quoteChar(): string
  {
    $d = $this->db->driver();
    return ($d === 'pgsql') ? '"' : '`';
  }

  private function quoteIdent(string $name): string
  {
    $q = $this->quoteChar();
    $name = trim($name);
    if ($name === '') throw new \InvalidArgumentException('Identificador vacío');
    // Permitir solo [A-Za-z0-9_]
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $name)) {
      throw new \InvalidArgumentException('Identificador inválido: ' . $name);
    }
    return $q . $name . $q;
  }

  /** Escapa identificadores tipo schema.table o table.column */
  private function escapeDotted(string $ident): string
  {
    $parts = array_map('trim', explode('.', $ident));
    $out = [];
    foreach ($parts as $p) $out[] = $this->quoteIdent($p);
    return implode('.', $out);
  }

  /** Escapa tabla con alias opcional: users u / users AS u / schema.users u */
  private function escapeTable(string $table): string
  {
    $table = trim($table);
    if ($table === '') throw new \InvalidArgumentException('Tabla vacía');

    // Permitir raw (solo si strictIdentifiers=false)
    if (!$this->strictIdentifiers()) {
      $this->guardRawSql($table, 'table');
      return $table;
    }

    if (!preg_match('/^([A-Za-z_][A-Za-z0-9_\.]*)(?:\s+(?:AS\s+)?([A-Za-z_][A-Za-z0-9_]*))?$/i', $table, $m)) {
      throw new \InvalidArgumentException('Tabla inválida. Usa joinRaw/selectRaw si necesitas expresiones.');
    }

    $base = $this->escapeDotted($m[1]);
    if (!empty($m[2])) {
      $alias = $this->quoteIdent($m[2]);
      return $base . ' ' . $alias;
    }
    return $base;
  }

  /** Escapa columna con alias opcional y soporta * o table.* en SELECT */
  private function escapeSelectField(string $field): string
  {
    $field = trim($field);
    if ($field === '') throw new \InvalidArgumentException('Campo vacío');

    if ($field === '*') return '*';

    // Permitir raw solo si strictIdentifiers=false
    if (!$this->strictIdentifiers()) {
      $this->guardRawSql($field, 'select');
      return $field;
    }

    // table.* permitido
    if (preg_match('/^([A-Za-z_][A-Za-z0-9_\.]*?)\.\*$/', $field, $m)) {
      return $this->escapeDotted($m[1]) . '.*';
    }

    if (!preg_match('/^([A-Za-z_][A-Za-z0-9_\.]*)(?:\s+(?:AS\s+)?([A-Za-z_][A-Za-z0-9_]*))?$/i', $field, $m)) {
      throw new \InvalidArgumentException('Campo inválido en SELECT. Usa selectRaw() para expresiones.');
    }

    $base = $this->escapeDotted($m[1]);
    if (!empty($m[2])) return $base . ' AS ' . $this->quoteIdent($m[2]);
    return $base;
  }

  private function escapeColumn(string $field): string
  {
    $field = trim($field);
    if ($field === '') throw new \InvalidArgumentException('Campo vacío');

    if (!$this->strictIdentifiers()) {
      $this->guardRawSql($field, 'column');
      return $field;
    }

    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_\.]*$/', $field)) {
      throw new \InvalidArgumentException('Columna inválida. Usa whereRaw/orderByRaw si necesitas expresiones.');
    }
    return $this->escapeDotted($field);
  }

  private function escapeOrderField(string $field): string
  {
    return $this->escapeColumn($field);
  }

  public function selectRaw(string $sql): self
  {
    $sql = trim($sql);
    if ($sql === '') return $this;
    $this->guardRawSql($sql, 'selectRaw');
    $this->select[] = $sql;
    return $this;
  }

  public function whereRaw(string $sql, array $binds = [], string $boolean = 'AND'): self
  {
    $sql = trim($sql);
    if ($sql === '') return $this;
    $boolean = strtoupper($boolean) === 'OR' ? 'OR' : 'AND';
    $this->guardRawSql($sql, 'whereRaw');

    // Reemplaza ? por placeholders propios
    foreach ($binds as $v) {
      $ph = $this->nextParam($v);
      $sql = preg_replace('/\?/', $ph, $sql, 1) ?? $sql;
    }

    $this->wheres[] = [$boolean, $sql];
    return $this;
  }

  public function orderByRaw(string $sql): self
  {
    $sql = trim($sql);
    if ($sql === '') return $this;
    $this->guardRawSql($sql, 'orderByRaw');
    $this->orderBys[] = $sql;
    return $this;
  }

  public function db(): Connection { return $this->db; }
  public function getTable(): string { return $this->table; }

  public function distinct(bool $on = true): self
  {
    $this->distinct = $on;
    return $this;
  }

  public function select(string|array $fields = '*'): self
  {
    $this->select = [];

    if (is_array($fields)) {
      foreach ($fields as $f) {
        $f = trim((string)$f);
        if ($f === '') continue;
        $this->select[] = $this->escapeSelectField($f);
      }
    } else {
      $fields = trim((string)$fields);
      if ($fields === '' || $fields === '*') {
        $this->select = ['*'];
        return $this;
      }
      $list = array_map('trim', explode(',', $fields));
      foreach ($list as $f) {
        if ($f === '') continue;
        $this->select[] = $this->escapeSelectField($f);
      }
    }

    if (!$this->select) $this->select = ['*'];
    return $this;
  }

  public function join(string $table, string $on, string $type = 'INNER'): self
  {
    $type = strtoupper(trim($type));
    if (!in_array($type, ['INNER','LEFT','RIGHT','FULL','LEFT OUTER','RIGHT OUTER'], true)) $type = 'INNER';

    $t = $this->escapeTable($table);
    $this->guardRawSql($on, 'join.on');
    $this->joins[] = "{$type} JOIN {$t} ON {$on}";
    return $this;
  }

  public function leftJoin(string $table, string $on): self { return $this->join($table, $on, 'LEFT'); }
  public function rightJoin(string $table, string $on): self { return $this->join($table, $on, 'RIGHT'); }

  /** where:
   * - where('a', 1) => a = :p
   * - where('a >', 1) => a > :p
   * - where('a = 1') => raw
   * - where(['a'=>1,'b'=>2])
   */
  public function where(string|array $key, $val = null, bool $escape = true): self
  {
    return $this->addWhere('AND', $key, $val, $escape);
  }

  public function orWhere(string|array $key, $val = null, bool $escape = true): self
  {
    return $this->addWhere('OR', $key, $val, $escape);
  }

  public function whereIn(string $key, array $vals, bool $not = false, string $boolean='AND'): self
  {
    $boolean = strtoupper($boolean) === 'OR' ? 'OR' : 'AND';

    // Columna segura
    $col = $key;
    if ($this->strictIdentifiers()) {
      $col = $this->escapeColumn($key);
    } else {
      $this->guardRawSql($col, 'whereIn.column');
    }

    $placeholders = [];
    foreach ($vals as $v) {
      $ph = $this->nextParam($v);
      $placeholders[] = $ph;
    }
    if (!$placeholders) $placeholders[] = 'NULL';
    $op = $not ? 'NOT IN' : 'IN';
    $this->wheres[] = [$boolean, "{$col} {$op} (" . implode(',', $placeholders) . ")"];
    return $this;
  }

  public function like(string $key, string $match, string $side='both', string $boolean='AND', bool $not=false): self
  {
    $boolean = strtoupper($boolean) === 'OR' ? 'OR' : 'AND';

    // Columna segura
    $col = $key;
    if ($this->strictIdentifiers()) {
      $col = $this->escapeColumn($key);
    } else {
      $this->guardRawSql($col, 'like.column');
    }

    $side = strtolower($side);
    $val = $match;
    if ($side === 'before') $val = "%{$match}";
    elseif ($side === 'after') $val = "{$match}%";
    else $val = "%{$match}%";
    $ph = $this->nextParam($val);
    $op = $not ? 'NOT LIKE' : 'LIKE';
    $this->wheres[] = [$boolean, "{$col} {$op} {$ph}"];
    return $this;
  }

  public function orLike(string $key, string $match, string $side='both'): self
  {
    return $this->like($key, $match, $side, 'OR');
  }

  /**
   * Agrupación de condiciones (WHERE) estilo CI:
   *   ->groupStart()->where(...)->orWhere(...)->groupEnd()
   */
  public function groupStart(string $boolean = 'AND', bool $not = false): self
  {
    $boolean = strtoupper($boolean) === 'OR' ? 'OR' : 'AND';
    $this->wheres[] = ['type' => 'groupStart', 'bool' => $boolean, 'not' => $not];
    return $this;
  }

  public function orGroupStart(): self { return $this->groupStart('OR'); }
  public function notGroupStart(string $boolean = 'AND'): self { return $this->groupStart($boolean, true); }
  public function orNotGroupStart(): self { return $this->groupStart('OR', true); }

  public function groupEnd(): self
  {
    $this->wheres[] = ['type' => 'groupEnd'];
    return $this;
  }

  public function groupBy(string|array $fields): self
  {
    $list = is_array($fields) ? $fields : array_map('trim', explode(',', (string)$fields));
    foreach ($list as $f) {
      $f = trim((string)$f);
      if ($f === '') continue;
      $this->groupBys[] = $this->escapeColumn($f);
    }
    return $this;
  }

  public function having(string $expr, $val = null, string $boolean='AND'): self
  {
    $boolean = strtoupper($boolean) === 'OR' ? 'OR' : 'AND';
    if ($val === null) {
      $this->havings[] = [$boolean, $expr];
      return $this;
    }
    $ph = $this->nextParam($val);
    // Si expr ya trae operador, lo respetamos
    $this->havings[] = [$boolean, "{$expr} {$ph}"];
    return $this;
  }

  public function orderBy(string $field, string $dir='ASC'): self
  {
    $dir = strtoupper(trim($dir));
    if (!in_array($dir, ['ASC','DESC'], true)) $dir = 'ASC';

    $f = $this->escapeOrderField($field);
    $this->orderBys[] = "{$f} {$dir}";
    return $this;
  }

  public function limit(int $limit, int $offset = 0): self
  {
    $this->limit = max(0, $limit);
    $this->offset = max(0, $offset);
    return $this;
  }

  public function offset(int $offset): self
  {
    $this->offset = max(0, $offset);
    return $this;
  }

  public function set(array $data): self
  {
    foreach ($data as $k=>$v) {
      $this->setData[$k] = $v;
    }
    return $this;
  }

  /** Ejecuta SELECT */
  /**
   * Último Pager generado por paginate()
   */
  public function pager(): ?Pager
  {
    return $this->pager;
  }

  /**
   * Paginación PRO (QueryBuilder)
   *
   * Ejemplo:
   *   $data  = $db->table('usuarios')->where('activo',1)->paginate(10);
   *   $pager = $db->table('usuarios')->where('activo',1)->pager();
   *   echo $pager?->render();
   *
   * - Preserva querystring actual (excepto page param)
   * - Genera URLs con base_url() + path actual
   */
  public function paginate(int $perPage = 20, ?int $page = null, string $pageParam = 'page', ?string $baseUrl = null): array
  {
    $perPage = max(1, $perPage);

    // Página actual (si no se pasa)
    if ($page === null) {
      // intenta desde Request service; si no existe, usa $_GET
      try {
        $req = service('request');
        $page = (int)($req?->getGet($pageParam, 1) ?? 1);
      } catch (\Throwable $e) {
        $page = (int)($_GET[$pageParam] ?? 1);
      }
    }
    $page = max(1, (int)$page);

    // Total (respeta where/join/group/having)
    $total = $this->countAllResults();

    $totalPages = max(1, (int)ceil($total / $perPage));
    if ($page > $totalPages) $page = $totalPages;

    $offset = ($page - 1) * $perPage;

    // Data
    $this->limit($perPage, $offset);
    $rows = $this->get()->getResultArray();

    // Base URL (por defecto: URL actual sin query)
    if ($baseUrl === null) {
      try {
        $req = service('request');
        $path = $req?->path() ?? '/';
      } catch (\Throwable $e) {
        $path = (string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/');
      }
      $baseUrl = \url($path === '/' ? '' : $path);
    }

    // Preserva query string (menos page)
    $q = $_GET ?? [];
    if (is_array($q)) unset($q[$pageParam]); else $q = [];

    // Config de paginación (opcional)
    $cfg = null;
    $omitFirst = true;
    $window = 2;
    try {
      $cfg = config('Pagination');
      $omitFirst = (bool)($cfg->omitFirstPage ?? true);
      $window = (int)($cfg->window ?? 2);
    } catch (\Throwable $e) {}

    $this->pager = new Pager(
      totalRows: $total,
      perPage: $perPage,
      currentPage: $page,
      baseUrl: (string)$baseUrl,
      pageParam: $pageParam,
      preserveQuery: $q,
      window: max(1, $window),
      omitFirstPage: $omitFirst
    );

    return $rows;
  }

public function get(): Result
  {
    $sql = $this->compileSelect();
    return $this->db->query($sql, $this->params);
  }

  /**
   * getResult() (PRO): SELECT con resultado estructurado.
   *
   * opts (además de los de Connection::queryResult):
   * - fetch: 'rows' (default) | 'row' | 'scalar' | 'none'
   * - mode:  'result' (default) | 'throw'
   */
  public function getResult(array $opts = []): DbResult
  {
    $sql = $this->compileSelect();
    $opts['action'] = $opts['action'] ?? 'select';
    $opts['fetch']  = $opts['fetch']  ?? 'rows';
    $opts['table']  = $opts['table']  ?? $this->table;
    return $this->db->queryResult($sql, $this->params, $opts);
  }

  /** firstResult() (PRO): primer registro (o null) con resultado estructurado. */
  public function firstResult(array $opts = []): DbResult
  {
    $this->limit(1);
    $opts['fetch'] = $opts['fetch'] ?? 'row';
    return $this->getResult($opts);
  }

  public function first(): ?array
  {
    $this->limit(1);
    $row = $this->get()->getRowArray();
    return $row ?: null;
  }

  /** Inserta y retorna DbResult con insertId. */
  public function insertResult(array $data, array $opts = []): DbResult
  {
    $cols = array_keys($data);
    $colsEsc = [];
    foreach ($cols as $c) $colsEsc[] = $this->escapeColumn((string)$c);

    $phs = [];
    $params = [];
    foreach ($data as $k=>$v) {
      $ph = ':i' . ($this->pIndex++);
      $phs[] = $ph;
      $params[substr($ph,1)] = $v;
    }

    $sql = "INSERT INTO {$this->table} (" . implode(',', $colsEsc) . ") VALUES (" . implode(',', $phs) . ")";
    $opts['action'] = $opts['action'] ?? 'insert';
    $opts['fetch']  = $opts['fetch']  ?? 'none';
    $opts['table']  = $opts['table']  ?? $this->table;

    $r = $this->db->queryResult($sql, $params, $opts);
    if ($r->ok) $r->insertId = $this->db->insertID();
    return $r;
  }

  /** Insert batch (PRO) con DbResult. */
  public function insertBatchResult(array $rows, array $opts = []): DbResult
  {
    if (!$rows) {
      $r = new DbResult();
      $r->ok = true;
      $r->action = 'insert';
      $r->table = $this->table;
      $r->rowCount = 0;
      $r->data = 0;
      return $r;
    }

    if (!isset($rows[0]) || !is_array($rows[0])) {
      return DbResult::failFromThrowable(new \InvalidArgumentException('insertBatch: $rows debe ser una lista de filas'), [
        'action' => 'insert',
        'table' => $this->table,
      ]);
    }
    $first = $rows[0];
    if (!$first) {
      $r = new DbResult();
      $r->ok = true;
      $r->action = 'insert';
      $r->table = $this->table;
      $r->rowCount = 0;
      $r->data = 0;
      return $r;
    }

    $cols = array_keys($first);
    $colsEsc = [];
    foreach ($cols as $c) $colsEsc[] = $this->escapeColumn((string)$c);

    $valuesSql = [];
    $params = [];
    foreach ($rows as $i => $row) {
      if (!is_array($row)) {
        return DbResult::failFromThrowable(new \InvalidArgumentException('insertBatch: fila inválida en índice ' . $i), [
          'action' => 'insert',
          'table' => $this->table,
        ]);
      }
      $rowCols = array_keys($row);
      sort($rowCols);
      $baseCols = $cols;
      sort($baseCols);
      if ($rowCols !== $baseCols) {
        return DbResult::failFromThrowable(new \InvalidArgumentException('insertBatch: todas las filas deben tener las mismas columnas'), [
          'action' => 'insert',
          'table' => $this->table,
        ]);
      }

      $phs = [];
      foreach ($cols as $c) {
        $ph = ':b' . ($this->pIndex++);
        $phs[] = $ph;
        $params[substr($ph, 1)] = $row[$c];
      }
      $valuesSql[] = '(' . implode(',', $phs) . ')';
    }

    $sql = "INSERT INTO {$this->table} (" . implode(',', $colsEsc) . ") VALUES " . implode(',', $valuesSql);
    $opts['action'] = $opts['action'] ?? 'insert';
    $opts['fetch']  = $opts['fetch']  ?? 'none';
    $opts['table']  = $opts['table']  ?? $this->table;
    $r = $this->db->queryResult($sql, $params, $opts);
    if ($r->ok) $r->rowCount = (int)($r->rowCount ?? 0);
    return $r;
  }

  /** Update (PRO): devuelve DbResult con rowCount. */
  public function updateResult(array $data = [], array $opts = []): DbResult
  {
    try {
      if ($data) $this->set($data);
      if (!$this->setData) {
        $r = new DbResult();
        $r->ok = true;
        $r->action = 'update';
        $r->table = $this->table;
        $r->rowCount = 0;
        $r->data = 0;
        return $r;
      }

      if ($this->protectWrites() && !$this->wheres) {
        throw new \RuntimeException('UPDATE sin WHERE bloqueado (DB_PROTECT_WRITES=true).');
      }

      $sets = [];
      $params = $this->params;
      foreach ($this->setData as $k=>$v) {
        $ph = ':u' . ($this->pIndex++);
        $col = $this->escapeColumn((string)$k);
        $sets[] = "{$col} = {$ph}";
        $params[substr($ph,1)] = $v;
      }

      $sql = "UPDATE {$this->table} SET " . implode(', ', $sets) . $this->compileWhereOnly();
      $opts['action'] = $opts['action'] ?? 'update';
      $opts['fetch']  = $opts['fetch']  ?? 'none';
      $opts['table']  = $opts['table']  ?? $this->table;
      return $this->db->queryResult($sql, $params, $opts);
    } catch (\Throwable $e) {
      return DbResult::failFromThrowable($e, [
        'action' => 'update',
        'table' => $this->table,
      ]);
    }
  }

  /** Delete (PRO): devuelve DbResult con rowCount. */
  public function deleteResult(array $opts = []): DbResult
  {
    try {
      if ($this->protectWrites() && !$this->wheres) {
        throw new \RuntimeException('DELETE sin WHERE bloqueado (DB_PROTECT_WRITES=true).');
      }

      $sql = "DELETE FROM {$this->table}" . $this->compileWhereOnly();
      $opts['action'] = $opts['action'] ?? 'delete';
      $opts['fetch']  = $opts['fetch']  ?? 'none';
      $opts['table']  = $opts['table']  ?? $this->table;
      return $this->db->queryResult($sql, $this->params, $opts);
    } catch (\Throwable $e) {
      return DbResult::failFromThrowable($e, [
        'action' => 'delete',
        'table' => $this->table,
      ]);
    }
  }

  /** countAllResultsResult() (PRO): devuelve DbResult con data=int */
  public function countAllResultsResult(array $opts = []): DbResult
  {
    $opts['action'] = $opts['action'] ?? 'count';
    $opts['fetch']  = $opts['fetch']  ?? 'row';
    $opts['table']  = $opts['table']  ?? $this->table;

    // Caso rápido: sin DISTINCT, sin GROUP/HAVING
    if (!$this->distinct && !$this->groupBys && !$this->havings) {
      $bak = [
        'select' => $this->select,
        'distinct' => $this->distinct,
        'orderBys' => $this->orderBys,
        'limit' => $this->limit,
        'offset' => $this->offset,
      ];
      try {
        $this->select = ['COUNT(*) as __count'];
        $this->distinct = false;
        $this->orderBys = [];
        $this->limit = null;
        $this->offset = null;

        $sql = $this->compileSelect();
        $r = $this->db->queryResult($sql, $this->params, $opts);
        if ($r->ok) {
          $r->data = (int)(is_array($r->data) ? ($r->data['__count'] ?? 0) : 0);
        }
        return $r;
      } finally {
        $this->select = $bak['select'];
        $this->distinct = (bool)$bak['distinct'];
        $this->orderBys = $bak['orderBys'];
        $this->limit = $bak['limit'];
        $this->offset = $bak['offset'];
      }
    }

    // Caso PRO: DISTINCT o GROUP/HAVING => COUNT(*) FROM (<select>)
    $bak = [
      'select' => $this->select,
      'distinct' => $this->distinct,
      'orderBys' => $this->orderBys,
      'limit' => $this->limit,
      'offset' => $this->offset,
    ];

    try {
      $this->orderBys = [];
      $this->limit = null;
      $this->offset = null;

      if ($this->groupBys || $this->havings) {
        $this->select = ['1'];
        $this->distinct = false;
      }

      $inner = $this->compileSelect();
      $sql = "SELECT COUNT(*) as __count FROM ({$inner}) __qfw_count";
      $r = $this->db->queryResult($sql, $this->params, $opts);
      if ($r->ok) {
        $r->data = (int)(is_array($r->data) ? ($r->data['__count'] ?? 0) : 0);
      }
      return $r;
    } finally {
      $this->select = $bak['select'];
      $this->distinct = (bool)$bak['distinct'];
      $this->orderBys = $bak['orderBys'];
      $this->limit = $bak['limit'];
      $this->offset = $bak['offset'];
    }
  }

  /** paginateResult() (PRO): data=rows, meta.pager=Pager::toArray() */
  public function paginateResult(int $perPage = 20, ?int $page = null, string $pageParam = 'page', ?string $baseUrl = null, array $opts = []): DbResult
  {
    $perPage = max(1, $perPage);

    // Página actual
    if ($page === null) {
      try {
        $req = service('request');
        $page = (int)($req?->getGet($pageParam, 1) ?? 1);
      } catch (\Throwable $e) {
        $page = (int)($_GET[$pageParam] ?? 1);
      }
    }
    $page = max(1, (int)$page);

    $countRes = $this->countAllResultsResult(['mode' => $opts['mode'] ?? 'result']);
    if (!$countRes->ok) {
      $countRes->action = 'paginate';
      $countRes->meta['stage'] = 'count';
      return $countRes;
    }
    $total = (int)($countRes->data ?? 0);

    $totalPages = max(1, (int)ceil($total / $perPage));
    if ($page > $totalPages) $page = $totalPages;
    $offset = ($page - 1) * $perPage;

    // Data
    $this->limit($perPage, $offset);
    $dataRes = $this->getResult(['mode' => $opts['mode'] ?? 'result', 'fetch' => 'rows']);
    if (!$dataRes->ok) {
      $dataRes->action = 'paginate';
      $dataRes->meta['stage'] = 'data';
      $dataRes->meta['total'] = $total;
      return $dataRes;
    }
    $rows = is_array($dataRes->data) ? $dataRes->data : [];

    // Base URL
    if ($baseUrl === null) {
      try {
        $req = service('request');
        $path = $req?->path() ?? '/';
      } catch (\Throwable $e) {
        $path = (string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/');
      }
      $baseUrl = \url($path === '/' ? '' : $path);
    }

    $q = $_GET ?? [];
    if (is_array($q)) unset($q[$pageParam]); else $q = [];

    $omitFirst = true;
    $window = 2;
    try {
      $cfg = config('Pagination');
      $omitFirst = (bool)($cfg->omitFirstPage ?? true);
      $window = (int)($cfg->window ?? 2);
    } catch (\Throwable $e) {}

    $this->pager = new Pager(
      totalRows: $total,
      perPage: $perPage,
      currentPage: $page,
      baseUrl: (string)$baseUrl,
      pageParam: $pageParam,
      preserveQuery: $q,
      window: max(1, $window),
      omitFirstPage: $omitFirst
    );

    $r = new DbResult();
    $r->ok = true;
    $r->action = 'paginate';
    $r->table = $this->table;
    $r->data = $rows;
    $r->rowCount = count($rows);
    $r->meta['pager'] = $this->pager->toArray();
    $r->meta['total'] = $total;
    $r->meta['totalPages'] = $totalPages;
    $r->meta['page'] = $page;
    $r->meta['perPage'] = $perPage;
    return $r;
  }

  /**
   * exists(): devuelve true si la consulta produce al menos 1 fila.
   *
   * - Útil para validaciones (duplicidad, permisos, estado) sin hacer COUNT(*).
   * - Respeta where/join/group/having.
   */
  public function exists(): bool
  {
    $bak = [
      'select' => $this->select,
      'distinct' => $this->distinct,
      'orderBys' => $this->orderBys,
      'limit' => $this->limit,
      'offset' => $this->offset,
    ];

    $this->select = ['1'];
    $this->distinct = false;
    $this->orderBys = [];
    $this->limit = 1;
    $this->offset = null;

    $v = $this->get()->scalar();

    $this->select = $bak['select'];
    $this->distinct = (bool)$bak['distinct'];
    $this->orderBys = $bak['orderBys'];
    $this->limit = $bak['limit'];
    $this->offset = $bak['offset'];

    return $v !== null;
  }

  /** Inverso de exists() */
  public function doesntExist(): bool
  {
    return !$this->exists();
  }

  /**
   * value(): devuelve el valor de una columna en la primera fila (o null).
   *
   * Ejemplo:
   *   $email = $db->table('users')->where('id', 10)->value('email');
   */
  public function value(string $column): mixed
  {
    $bak = [
      'select' => $this->select,
      'distinct' => $this->distinct,
      'limit' => $this->limit,
      'offset' => $this->offset,
    ];

    $this->select((string)$column);
    $this->distinct = false;
    $this->limit = 1;
    $this->offset = null;

    $v = $this->get()->scalar();

    $this->select = $bak['select'];
    $this->distinct = (bool)$bak['distinct'];
    $this->limit = $bak['limit'];
    $this->offset = $bak['offset'];

    return $v;
  }

  public function column(string|callable $valueSpec, array $opts = []): array
  {
    // OJO: no tocamos where/join/etc. Solo ejecutamos con el select actual.
    return $this->get()->column($valueSpec, $opts);
  }

  public function pluck(string|callable $valueSpec, array $opts = []): array
  {
    return $this->column($valueSpec, $opts);
  }

  public function pairs(string|callable $keySpec, string|array|callable $valueSpec, array $opts = []): array
  {
    // autoSelect: útil si no quieres acordarte de select()
    $auto = (bool)($opts['autoSelect'] ?? false);

    $bak = $this->select;
    if ($auto && ($this->select === ['*'] || $this->select === [])) {
      $fields = [];
      if (is_string($keySpec)) $fields[] = (string)$keySpec;
      if (is_string($valueSpec)) $fields[] = (string)$valueSpec;
      if (is_array($valueSpec)) {
        foreach ($valueSpec as $c) if (is_string($c)) $fields[] = $c;
      }
      if (isset($opts['groupBy']) && is_string($opts['groupBy'])) $fields[] = (string)$opts['groupBy'];

      // Si no pudimos inferir campos, dejamos select actual
      if ($fields) $this->select($fields);
    }

    $res = $this->get()->pairs($keySpec, $valueSpec, $opts);
    $this->select = $bak;

    return $res;
  }

  public function options(string|callable $keySpec, string|array|callable $valueSpec, array $opts = []): string
  {
    $auto = (bool)($opts['autoSelect'] ?? false);

    $bak = $this->select;
    if ($auto && ($this->select === ['*'] || $this->select === [])) {
      $fields = [];
      if (is_string($keySpec)) $fields[] = (string)$keySpec;
      if (is_string($valueSpec)) $fields[] = (string)$valueSpec;
      if (is_array($valueSpec)) {
        foreach ($valueSpec as $c) if (is_string($c)) $fields[] = $c;
      }
      if (isset($opts['groupBy']) && is_string($opts['groupBy'])) $fields[] = (string)$opts['groupBy'];
      if ($fields) $this->select($fields);
    }

    $html = $this->get()->options($keySpec, $valueSpec, $opts);
    $this->select = $bak;

    return $html;
  }

  /** Cuenta resultados (respeta where/join/group/having). */
  public function countAllResults(): int
  {
    // Caso rápido: sin DISTINCT, sin GROUP/HAVING
    if (!$this->distinct && !$this->groupBys && !$this->havings) {
      $bak = [
        'select' => $this->select,
        'distinct' => $this->distinct,
        'orderBys' => $this->orderBys,
        'limit' => $this->limit,
        'offset' => $this->offset,
      ];

      $this->select = ['COUNT(*) as __count'];
      $this->distinct = false;
      $this->orderBys = [];
      $this->limit = null;
      $this->offset = null;

      $row = $this->get()->getRowArray();
      $n = (int)($row['__count'] ?? 0);

      $this->select = $bak['select'];
      $this->distinct = (bool)$bak['distinct'];
      $this->orderBys = $bak['orderBys'];
      $this->limit = $bak['limit'];
      $this->offset = $bak['offset'];

      return $n;
    }

    // Caso PRO: DISTINCT o GROUP/HAVING
    // Para contar correctamente, envolvemos el SELECT en un subquery:
    //   SELECT COUNT(*) FROM ( <SELECT sin ORDER/LIMIT/OFFSET> ) t
    $bak = [
      'select' => $this->select,
      'distinct' => $this->distinct,
      'orderBys' => $this->orderBys,
      'limit' => $this->limit,
      'offset' => $this->offset,
    ];

    // Sin ORDER/LIMIT/OFFSET para el conteo
    $this->orderBys = [];
    $this->limit = null;
    $this->offset = null;

    // Optimización: si hay GROUP/HAVING, no necesitamos el SELECT real para contar grupos
    if ($this->groupBys || $this->havings) {
      $this->select = ['1'];
      $this->distinct = false;
    }

    $inner = $this->compileSelect();
    $sql = "SELECT COUNT(*) as __count FROM ({$inner}) __qfw_count";
    $row = $this->db->query($sql, $this->params)->getRowArray();
    $n = (int)($row['__count'] ?? 0);

    // Restore
    $this->select = $bak['select'];
    $this->distinct = (bool)$bak['distinct'];
    $this->orderBys = $bak['orderBys'];
    $this->limit = $bak['limit'];
    $this->offset = $bak['offset'];

    return $n;
  }

  public function orWhereIn(string $key, array $vals): self { return $this->whereIn($key, $vals, false, 'OR'); }
  public function whereNotIn(string $key, array $vals, string $boolean='AND'): self { return $this->whereIn($key, $vals, true, $boolean); }
  public function orWhereNotIn(string $key, array $vals): self { return $this->whereIn($key, $vals, true, 'OR'); }


  /** Inserta y retorna insertID */
  public function insert(array $data): string
  {
    $cols = array_keys($data);
    $colsEsc = [];
    foreach ($cols as $c) $colsEsc[] = $this->escapeColumn((string)$c);

    $phs = [];
    $params = [];
    foreach ($data as $k=>$v) {
      $ph = ':i' . ($this->pIndex++);
      $phs[] = $ph;
      $params[substr($ph,1)] = $v;
    }

    $sql = "INSERT INTO {$this->table} (" . implode(',', $colsEsc) . ") VALUES (" . implode(',', $phs) . ")";
    $this->db->query($sql, $params);
    return $this->db->insertID();
  }


  /**
   * Inserción múltiple (batch).
   *
   * - $rows debe ser una lista de arrays asociativos con las MISMAS columnas.
   * - Retorna cantidad de filas insertadas (rowCount).
   */
  public function insertBatch(array $rows): int
  {
    if (!$rows) return 0;

    // normaliza si viene un solo row
    if (isset($rows[0]) && is_array($rows[0])) {
      $first = $rows[0];
    } else {
      throw new \InvalidArgumentException('insertBatch: $rows debe ser una lista de filas');
    }
    if (!$first) return 0;

    $cols = array_keys($first);
    if (!$cols) return 0;

    $colsEsc = [];
    foreach ($cols as $c) $colsEsc[] = $this->escapeColumn((string)$c);

    $valuesSql = [];
    $params = [];

    foreach ($rows as $i => $row) {
      if (!is_array($row)) {
        throw new \InvalidArgumentException('insertBatch: fila inválida en índice ' . $i);
      }
      // valida mismas columnas
      $rowCols = array_keys($row);
      sort($rowCols);
      $baseCols = $cols; 
      sort($baseCols);
      if ($rowCols !== $baseCols) {
        throw new \InvalidArgumentException('insertBatch: todas las filas deben tener las mismas columnas');
      }

      $phs = [];
      foreach ($cols as $c) {
        $ph = ':b' . ($this->pIndex++);
        $phs[] = $ph;
        $params[substr($ph, 1)] = $row[$c];
      }
      $valuesSql[] = '(' . implode(',', $phs) . ')';
    }

    $sql = "INSERT INTO {$this->table} (" . implode(',', $colsEsc) . ") VALUES " . implode(',', $valuesSql);
    $res = $this->db->query($sql, $params);
    return $res->rowCount();
  }



  /** Update usando where(s) */
  public function update(array $data = []): int
  {
    if ($data) $this->set($data);
    if (!$this->setData) return 0;

    if ($this->protectWrites() && !$this->wheres) {
      throw new \RuntimeException('UPDATE sin WHERE bloqueado (DB_PROTECT_WRITES=true).');
    }

    $sets = [];
    $params = $this->params; // include where params
    foreach ($this->setData as $k=>$v) {
      $ph = ':u' . ($this->pIndex++);
      $col = $this->escapeColumn((string)$k);
      $sets[] = "{$col} = {$ph}";
      $params[substr($ph,1)] = $v;
    }

    $sql = "UPDATE {$this->table} SET " . implode(', ', $sets) . $this->compileWhereOnly();
    $res = $this->db->query($sql, $params);
    return $res->rowCount();
  }

  /** Delete (hard) usando where(s) */
  public function delete(): int
  {
    if ($this->protectWrites() && !$this->wheres) {
      throw new \RuntimeException('DELETE sin WHERE bloqueado (DB_PROTECT_WRITES=true).');
    }

    $sql = "DELETE FROM {$this->table}" . $this->compileWhereOnly();
    $res = $this->db->query($sql, $this->params);
    return $res->rowCount();
  }

  /** Devuelve SQL SELECT compilado (debug) */
  public function getCompiledSelect(): string
  {
    return $this->compileSelect();
  }

  // =======================
  // Internals
  // =======================

  private function addWhere(string $boolean, string|array $key, $val, bool $escape): self
  {
    $boolean = strtoupper($boolean) === 'OR' ? 'OR' : 'AND';

    if (is_array($key)) {
      foreach ($key as $k=>$v) {
        $this->addWhere($boolean, (string)$k, $v, $escape);
        $boolean = 'AND'; // para siguientes dentro del array
      }
      return $this;
    }

    $k = trim((string)$key);
    if ($k === '') return $this;

    // RAW where: permitido SOLO si $escape=false (o usa whereRaw())
    if ($val === null) {
      if ($escape) {
        throw new \InvalidArgumentException('where(raw) no permitido por defecto. Usa whereRaw() o pasa $escape=false.');
      }
      $this->guardRawSql($k, 'where.raw');
      $this->wheres[] = [$boolean, $k];
      return $this;
    }

    // operador embebido (a >, a <=, a !=)
    $op = '=';
    $field = $k;
    if (preg_match('/\s*(<=|>=|!=|<>|=|<|>)\s*$/', $k, $m)) {
      $op = $m[1];
      $field = trim(substr($k, 0, -strlen($m[0])));
    }

    $fieldSql = $escape ? $this->escapeColumn($field) : $field;
    if (!$escape) $this->guardRawSql($fieldSql, 'where.field');

    $ph = $this->nextParam($val);
    $this->wheres[] = [$boolean, "{$fieldSql} {$op} {$ph}"];
    return $this;
  }

  private function nextParam($val): string
  {
    $name = 'p' . ($this->pIndex++);
    $this->params[$name] = $val;
    return ':' . $name;
  }

  private function compileSelect(): string
  {
    $sel = implode(',', $this->select);
    $sql = "SELECT " . ($this->distinct ? "DISTINCT " : "") . $sel . " FROM {$this->table}";

    if ($this->joins) $sql .= " " . implode(' ', $this->joins);

    $sql .= $this->compileWhereOnly();

    if ($this->groupBys) $sql .= " GROUP BY " . implode(',', $this->groupBys);

    if ($this->havings) {
      $sql .= " HAVING " . $this->compileBoolList($this->havings);
    }

    if ($this->orderBys) $sql .= " ORDER BY " . implode(', ', $this->orderBys);

    if ($this->limit !== null) {
      $sql .= " LIMIT " . (int)$this->limit;
      if ($this->offset) $sql .= " OFFSET " . (int)$this->offset;
    }

    return $sql;
  }

  private function compileWhereOnly(): string
  {
    if (!$this->wheres) return '';
    return " WHERE " . $this->compileBoolList($this->wheres);
  }

  private function compileBoolList(array $items): string
  {
    $out = '';
    $first = true;
    $stack = [];

    foreach ($items as $it) {
      // Token groupStart/groupEnd
      if (is_array($it) && isset($it['type'])) {
        $type = (string)$it['type'];
        if ($type === 'groupStart') {
          $bool = strtoupper((string)($it['bool'] ?? 'AND')) === 'OR' ? 'OR' : 'AND';
          $not = !empty($it['not']);
          $prefix = $first ? '' : " {$bool} ";
          $out .= $prefix . ($not ? 'NOT ' : '') . '(';
          $stack[] = true;
          $first = true; // primera condición dentro del grupo
          continue;
        }
        if ($type === 'groupEnd') {
          $out .= ')';
          if ($stack) array_pop($stack);
          $first = false; // el grupo cuenta como una condición
          continue;
        }
      }

      // Legacy: [bool, expr]
      if (!is_array($it) || count($it) < 2) continue;
      $bool = strtoupper((string)($it[0] ?? 'AND')) === 'OR' ? 'OR' : 'AND';
      $expr = (string)($it[1] ?? '');
      if ($expr === '') continue;

      $prefix = $first ? '' : " {$bool} ";
      $out .= $prefix . '(' . $expr . ')';
      $first = false;
    }

    return $out;
  }


  
}