<?php
declare(strict_types=1);

namespace System\Database\Crud;

use System\Database\Connection;

/**
 * CRUD Service (PRO)
 *
 * Uso:
 *   $crud = service('crud');                // por defecto DB group
 *   $t = $crud->table('usuarios', [
 *     'primaryKey'   => 'id_usuario',
 *     'protectFields'=> true,
 *     'allowedFields'=> ['nombres','email','estado'],
 *     'useTimestamps'=> true,
 *     'useSoftDeletes'=> true,
 *     'deletedField' => 'deleted_at',
 *   ]);
 *
 *   $id = $t->create(['nombres'=>'Ana','email'=>'a@b.com']);
 *   $row = $t->find($id);
 *   $t->update($id, ['estado'=>'activo']);
 *   $t->delete($id); // soft por defecto si useSoftDeletes=true
 */
final class Crud
{
  public function __construct(private Connection $db) {}

  public function db(): Connection { return $this->db; }

  /**
   * Devuelve un CRUD de tabla con opciones.
   *
   * Opciones soportadas (todas opcionales):
   * - primaryKey: string (default 'id')
   * - protectFields: bool (default false)
   * - allowedFields: list<string> (default [])
   * - useTimestamps: bool (default false)
   * - createdField: string (default 'created_at')
   * - updatedField: string (default 'updated_at')
   * - useSoftDeletes: bool (default false)
   * - deletedField: string (default 'deleted_at')
   */
  public function table(string $table, array $options = []): TableCrud
  {
    return new TableCrud($this->db, $table, $options);
  }

  /** Alias */
  public function on(string $table, array $options = []): TableCrud
  {
    return $this->table($table, $options);
  }

  /** Clona el servicio con otra conexión */
  public function with(Connection $db): self
  {
    return new self($db);
  }
}
