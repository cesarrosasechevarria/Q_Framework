<?php
declare(strict_types=1);

namespace System\Database\Crud;

use System\Database\Connection;
use System\Database\DbResult;
use System\Database\QueryBuilder;

/**
 * TableCrud: CRUD dinámico por tabla (sin necesidad de crear un Model).
 *
 * Nota:
 * - Internamente usa QueryBuilder (insert/update/delete/get/first/paginate).
 * - Tiene modo soft deletes y timestamps (opcional).
 * - Si protectFields=true, filtra por allowedFields (whitelist).
 */
final class TableCrud
{
  private string $table;
  private string $primaryKey;

  private bool $protectFields = false;
  /** @var list<string> */
  private array $allowedFields = [];

  private bool $useTimestamps = false;
  private string $createdField = 'created_at';
  private string $updatedField = 'updated_at';

  private bool $useSoftDeletes = false;
  private string $deletedField = 'deleted_at';

  public function __construct(
    private Connection $db,
    string $table,
    array $options = []
  ) {
    $this->table = $this->sanitizeIdent($table, 'table');
    $this->primaryKey = $this->sanitizeIdent((string)($options['primaryKey'] ?? 'id'), 'primaryKey');

    $this->protectFields = (bool)($options['protectFields'] ?? false);
    $this->allowedFields = array_values(array_filter((array)($options['allowedFields'] ?? []), fn($x)=>is_string($x) && $x!==''));

    $this->useTimestamps = (bool)($options['useTimestamps'] ?? false);
    $this->createdField  = $this->sanitizeIdent((string)($options['createdField'] ?? 'created_at'), 'createdField');
    $this->updatedField  = $this->sanitizeIdent((string)($options['updatedField'] ?? 'updated_at'), 'updatedField');

    $this->useSoftDeletes = (bool)($options['useSoftDeletes'] ?? false);
    $this->deletedField   = $this->sanitizeIdent((string)($options['deletedField'] ?? 'deleted_at'), 'deletedField');
  }

  public function db(): Connection { return $this->db; }
  public function tableName(): string { return $this->table; }

  /** Obtiene un QueryBuilder nuevo para la tabla */
  public function builder(): QueryBuilder
  {
    return $this->db->table($this->table);
  }

  /** Crea un registro y retorna insertId (string). */
  public function create(array $data): string
  {
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $now = $this->now();
      $data[$this->createdField] = $data[$this->createdField] ?? $now;
      $data[$this->updatedField] = $data[$this->updatedField] ?? $now;
    }
    return $this->builder()->insert($data);
  }

  /**
   * createResult() (PRO): crea registro y devuelve DbResult.
   * - r.insertId: id insertado (si aplica)
   */
  public function createResult(array $data, array $opts = []): DbResult
  {
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $now = $this->now();
      $data[$this->createdField] = $data[$this->createdField] ?? $now;
      $data[$this->updatedField] = $data[$this->updatedField] ?? $now;
    }
    $r = $this->builder()->insertResult($data, $opts);
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  /** Alias */
  public function insert(array $data): string
  {
    return $this->create($data);
  }

  /** Alias PRO */
  public function insertResult(array $data, array $opts = []): DbResult
  {
    return $this->createResult($data, $opts);
  }

  /** Busca por PK. */
  public function find($id, bool $withDeleted = false): ?array
  {
    $qb = $this->builder()->where($this->primaryKey, $id);
    if ($this->useSoftDeletes && !$withDeleted) {
      $qb = $this->whereNotDeleted($qb);
    }
    return $qb->first();
  }

  /** findResult() (PRO): busca por PK y devuelve DbResult(data=row|null). */
  public function findResult($id, bool $withDeleted = false, array $opts = []): DbResult
  {
    $qb = $this->builder()->where($this->primaryKey, $id);
    if ($this->useSoftDeletes && !$withDeleted) {
      $qb = $this->whereNotDeleted($qb);
    }
    $r = $qb->firstResult($opts);
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  /** Devuelve lista; si soft deletes, excluye borrados por defecto. */
  public function all(int $limit = 0, int $offset = 0, bool $withDeleted = false): array
  {
    $qb = $this->builder();
    if ($this->useSoftDeletes && !$withDeleted) {
      $qb = $this->whereNotDeleted($qb);
    }
    if ($limit > 0) $qb->limit($limit, max(0,$offset));
    return $qb->get()->getResultArray();
  }

  /** allResult() (PRO): lista y devuelve DbResult(data=rows). */
  public function allResult(int $limit = 0, int $offset = 0, bool $withDeleted = false, array $opts = []): DbResult
  {
    $qb = $this->builder();
    if ($this->useSoftDeletes && !$withDeleted) {
      $qb = $this->whereNotDeleted($qb);
    }
    if ($limit > 0) $qb->limit($limit, max(0, $offset));
    $r = $qb->getResult($opts);
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  /** Actualiza por PK; retorna filas afectadas. */
  public function update($id, array $data): int
  {
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $data[$this->updatedField] = $this->now();
    }
    return $this->builder()->where($this->primaryKey, $id)->update($data);
  }

  /** updateResult() (PRO): actualiza y devuelve DbResult(rowCount). */
  public function updateResult($id, array $data, array $opts = []): DbResult
  {
    $data = $this->filterAllowed($data);
    if ($this->useTimestamps) {
      $data[$this->updatedField] = $this->now();
    }
    $r = $this->builder()->where($this->primaryKey, $id)->updateResult($data, $opts);
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  /**
   * Delete por PK:
   * - Si useSoftDeletes=true y $purge=false => soft delete (UPDATE deletedField=NOW()).
   * - Si $purge=true => hard delete.
   */
  public function delete($id, bool $purge = false): int
  {
    if ($this->useSoftDeletes && !$purge) {
      return $this->builder()
        ->where($this->primaryKey, $id)
        ->update([$this->deletedField => $this->now()]);
    }
    return $this->builder()->where($this->primaryKey, $id)->delete();
  }

  /** deleteResult() (PRO): soft/hard delete con DbResult. */
  public function deleteResult($id, bool $purge = false, array $opts = []): DbResult
  {
    if ($this->useSoftDeletes && !$purge) {
      $r = $this->builder()
        ->where($this->primaryKey, $id)
        ->updateResult([$this->deletedField => $this->now()], $opts);
      $r->action = 'delete';
      $r->meta['soft'] = true;
      $r->table = $r->table ?? $this->table;
      return $r;
    }
    $r = $this->builder()->where($this->primaryKey, $id)->deleteResult($opts);
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  /** Restaura un registro soft-deleted (set deletedField NULL). */
  public function restore($id): int
  {
    if (!$this->useSoftDeletes) return 0;
    // whereRaw para IS NOT NULL y luego update a null.
    $qb = $this->builder()->where($this->primaryKey, $id);
    $qb = $qb->whereRaw($this->bt($this->deletedField) . " IS NOT NULL");
    return $qb->update([$this->deletedField => null]);
  }

  /** restoreResult() (PRO): restaura soft-delete y devuelve DbResult. */
  public function restoreResult($id, array $opts = []): DbResult
  {
    if (!$this->useSoftDeletes) {
      $r = new DbResult();
      $r->ok = true;
      $r->action = 'restore';
      $r->table = $this->table;
      $r->rowCount = 0;
      $r->data = 0;
      $r->meta['softDeletes'] = false;
      return $r;
    }
    $qb = $this->builder()->where($this->primaryKey, $id);
    $qb = $qb->whereRaw($this->bt($this->deletedField) . " IS NOT NULL");
    $r = $qb->updateResult([$this->deletedField => null], $opts);
    $r->action = 'restore';
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  /** Pagina usando QueryBuilder->paginate() */
  public function paginate(int $perPage = 20, ?int $page = null, string $pageParam = 'page', ?string $baseUrl = null, bool $withDeleted = false): array
  {
    $qb = $this->builder();
    if ($this->useSoftDeletes && !$withDeleted) {
      $qb = $this->whereNotDeleted($qb);
    }
    return $qb->paginate($perPage, $page, $pageParam, $baseUrl);
  }

  /** paginateResult() (PRO): devuelve DbResult(data=rows, meta.pager=...). */
  public function paginateResult(int $perPage = 20, ?int $page = null, string $pageParam = 'page', ?string $baseUrl = null, bool $withDeleted = false, array $opts = []): DbResult
  {
    $qb = $this->builder();
    if ($this->useSoftDeletes && !$withDeleted) {
      $qb = $this->whereNotDeleted($qb);
    }
    $r = $qb->paginateResult($perPage, $page, $pageParam, $baseUrl, $opts);
    $r->table = $r->table ?? $this->table;
    return $r;
  }

  // =====================
  // Internals
  // =====================

  private function now(): string
  {
    return date('Y-m-d H:i:s');
  }

  private function filterAllowed(array $data): array
  {
    if (!$this->protectFields) return $data;
    if (!$this->allowedFields) return [];
    $out = [];
    foreach ($this->allowedFields as $k) {
      if (array_key_exists($k, $data)) $out[$k] = $data[$k];
    }
    return $out;
  }

  private function whereNotDeleted(QueryBuilder $qb): QueryBuilder
  {
    // deletedField IS NULL (usamos whereRaw por ser "IS NULL")
    return $qb->whereRaw($this->bt($this->deletedField) . " IS NULL");
  }

  private function sanitizeIdent(string $s, string $label): string
  {
    $s = trim($s);
    if ($s === '') throw new \InvalidArgumentException("{$label} vacío");
    // allow dotted (schema.table) y underscore
    if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$/', $s)) {
      throw new \InvalidArgumentException("{$label} inválido: {$s}");
    }
    return $s;
  }

  private function bt(string $field): string
  {
    // backticks para cada parte si viene con puntos
    $parts = explode('.', $field);
    $parts = array_map(fn($p)=>'`'.$p.'`', $parts);
    return implode('.', $parts);
  }
}
