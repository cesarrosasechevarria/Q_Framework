<?php
declare(strict_types=1);

namespace System\Database\Schema;

use System\Database\Connection;
use System\Database\DbResult;

/**
 * ============================================================
 * Q_Framework - Schema (DDL helper)
 * ============================================================
 * Crea / asegura tablas a partir de un arreglo de columnas.
 *
 * Objetivo:
 * - Mover la creación de tablas (DDL) al CORE del framework.
 * - Permitir "base columns" opcionales y configurables.
 *
 * ColumnSpec (por columna):
 * - name|nombre (string)  : nombre de columna
 * - type (string)         : VARCHAR|INT|DECIMAL|JSON|POINT|...
 * - length (int|null)     : para tipos con longitud
 * - precision (int|null)  : DECIMAL
 * - scale (int|null)      : DECIMAL
 * - nullable (bool)       : true/false (default true)
 * - default (mixed|null)  : default literal (string|int|float|bool|null)
 * - unsigned (bool)       : para enteros
 * - auto_increment (bool) : para PK autoincrement
 * - primary (bool)        : marca como PK (solo soportamos PK simple en CREATE)
 * - unique (bool)         : crea índice UNIQUE (solo en CREATE)
 * - comment (string|null) : comentario
 * - values (array|string) : ENUM/SET (opcional)
 */
final class Schema
{
  /** Base columns por defecto (opcionales) */
  private const DEFAULT_BASE_COLUMNS = [
    [
      'name' => 'tabla_id',
      'type' => 'INT',
      'length' => 11,
      'unsigned' => true,
      'nullable' => false,
      'auto_increment' => true,
      'primary' => true,
    ],
    [
      'name' => 'fecha',
      'type' => 'DATE',
      'nullable' => true,
      'default' => null,
    ],
    [
      'name' => 'fecha_dmy',
      'type' => 'VARCHAR',
      'length' => 20,
      'nullable' => true,
      'default' => null,
    ],
    [
      'name' => 'borrado',
      'type' => 'TINYINT',
      'length' => 1,
      'unsigned' => true,
      'nullable' => false,
      'default' => 0,
    ],
  ];

  public function __construct(private Connection $db) {}

  /**
   * Asegura una tabla y (opcionalmente) altera columnas.
   *
   * Opciones:
   * - alter (bool) : si existe, hace ADD/MODIFY columnas (default false)
   * - engine (string)  : InnoDB (default)
   * - charset (string) : utf8mb4 (default)
   * - collate (string) : utf8mb4_unicode_ci (default)
   * - base_columns (bool|array):
   *     false => no agrega base columns
   *     true  => agrega DEFAULT_BASE_COLUMNS
   *     array => columnas base custom (ColumnSpec list). Si quieres además incluir
   *             las default, usa base_columns_include_default=true
   * - base_columns_include_default (bool): si base_columns es array, mergea con default
   */
  public function ensureArray(string $table, array $columns, array $options = []): array
  {
    $table = trim($table);
    if (!$this->isSafeIdentifier($table)) {
      throw new \InvalidArgumentException('Nombre de tabla inválido.');
    }

    $opt = array_merge([
      'alter' => false,
      'engine' => 'InnoDB',
      'charset' => 'utf8mb4',
      'collate' => 'utf8mb4_unicode_ci',
      'base_columns' => false,
      'base_columns_include_default' => false,
    ], $options);

    // Normaliza columnas y aplica base columns según opciones
    $columns = $this->normalizeColumns($columns);
    $columns = $this->applyBaseColumns($columns, $opt['base_columns'], (bool)$opt['base_columns_include_default']);

    // Si no hay columnas, no hacemos nada
    if (!$columns) {
      return ['ok' => false, 'created' => false, 'altered' => false, 'message' => 'No hay columnas para crear.'];
    }

    if (!$this->db->tableExists($table)) {
      $sql = $this->buildCreateTableSql($table, $columns, $opt);
      $this->db->query($sql);
      return ['ok' => true, 'created' => true, 'altered' => false, 'message' => 'Tabla creada.'];
    }

    if (!empty($opt['alter'])) {
      $changed = $this->alterColumns($table, $columns);
      return ['ok' => true, 'created' => false, 'altered' => $changed, 'message' => $changed ? 'Tabla alterada.' : 'Sin cambios.'];
    }

    return ['ok' => true, 'created' => false, 'altered' => false, 'message' => 'Ya existe.'];
  }

  public function ensure(string $table, array $columns, array $options = []): DbResult
  {
    $t0 = microtime(true);
    $r = new \System\Database\DbResult();
    $r->action = 'schema';
    $r->table = $table;

    try {
      $out = $this->ensureArray($table, $columns, $options);
      $r->ok = (bool)($out['ok'] ?? false);
      $r->data = $out;
      $r->meta['created'] = (bool)($out['created'] ?? false);
      $r->meta['altered'] = (bool)($out['altered'] ?? false);
    } catch (\Throwable $e) {
      $r->ok = false;
      $r->error = $e->getMessage();
    } finally {
      $r->time_ms = (microtime(true) - $t0) * 1000;
    }

    return $r;
  }



  /**
   * ensureResult() (PRO): igual que ensure(), pero devuelve DbResult
   * en vez de lanzar por defecto (útil para APIs/CLI).
   */
  public function ensureResult(string $table, array $columns, array $options = []): DbResult
  {
    // Alias seguro (ensure() ya devuelve DbResult)
    return $this->ensure($table, $columns, $options);
  }

  // ------------------------------------------------------------
  // Internals
  // ------------------------------------------------------------

  private function applyBaseColumns(array $columns, $baseColumnsOpt, bool $includeDefault): array
  {
    // base_columns = false => nada
    if ($baseColumnsOpt === false || $baseColumnsOpt === null) {
      return $columns;
    }

    // base_columns = true => default
    if ($baseColumnsOpt === true) {
      return $this->mergeColumns(self::DEFAULT_BASE_COLUMNS, $columns);
    }

    // base_columns = array => custom (y opcionalmente default)
    if (is_array($baseColumnsOpt)) {
      $custom = $this->normalizeColumns($baseColumnsOpt);

      // Si es array de strings => subset de default
      if ($this->isStringList($baseColumnsOpt)) {
        $subset = $this->defaultSubsetByNames($baseColumnsOpt);
        return $this->mergeColumns($subset, $columns);
      }

      if ($includeDefault) {
        $base = $this->mergeColumns(self::DEFAULT_BASE_COLUMNS, $custom);
        return $this->mergeColumns($base, $columns);
      }
      return $this->mergeColumns($custom, $columns);
    }

    // Cualquier otro caso => no base columns
    return $columns;
  }

  private function defaultSubsetByNames(array $names): array
  {
    $names = array_map('strtolower', array_map('trim', $names));
    $out = [];
    foreach (self::DEFAULT_BASE_COLUMNS as $c) {
      $n = strtolower((string)($c['name'] ?? ''));
      if ($n && in_array($n, $names, true)) {
        $out[] = $c;
      }
    }
    return $out;
  }

  private function isStringList(array $arr): bool
  {
    if (!$arr) return false;
    foreach ($arr as $v) {
      if (!is_string($v)) return false;
    }
    return true;
  }

  private function mergeColumns(array $a, array $b): array
  {
    // b sobreescribe por nombre
    $map = [];
    foreach ($a as $c) {
      $c = $this->normalizeColumn($c);
      if (!$c) continue;
      $map[strtolower($c['name'])] = $c;
    }
    foreach ($b as $c) {
      $c = $this->normalizeColumn($c);
      if (!$c) continue;
      $map[strtolower($c['name'])] = $c;
    }
    return array_values($map);
  }

  private function normalizeColumns(array $columns): array
  {
    $out = [];
    foreach ($columns as $col) {
      $n = $this->normalizeColumn($col);
      if ($n) $out[] = $n;
    }
    return $out;
  }

  private function normalizeColumn($col): ?array
  {
    if (!is_array($col)) return null;

    $name = (string)($col['name'] ?? $col['nombre'] ?? '');
    $name = trim($name);
    if ($name === '' || !$this->isSafeIdentifier($name)) {
      return null;
    }

    $type = strtoupper(trim((string)($col['type'] ?? $col['db_type'] ?? 'VARCHAR')));
    if ($type === '') $type = 'VARCHAR';

    $out = [
      'name' => $name,
      'type' => $type,
      'length' => isset($col['length']) ? (is_numeric($col['length']) ? (int)$col['length'] : null) : null,
      'precision' => isset($col['precision']) ? (is_numeric($col['precision']) ? (int)$col['precision'] : null) : null,
      'scale' => isset($col['scale']) ? (is_numeric($col['scale']) ? (int)$col['scale'] : null) : null,
      'nullable' => array_key_exists('nullable', $col) ? (bool)$col['nullable'] : true,
      'default' => $col['default'] ?? null,
      'unsigned' => array_key_exists('unsigned', $col) ? (bool)$col['unsigned'] : false,
      'auto_increment' => array_key_exists('auto_increment', $col) ? (bool)$col['auto_increment'] : false,
      'primary' => array_key_exists('primary', $col) ? (bool)$col['primary'] : false,
      'unique' => array_key_exists('unique', $col) ? (bool)$col['unique'] : false,
      'comment' => isset($col['comment']) ? (string)$col['comment'] : null,
      'values' => $col['values'] ?? null,
    ];

    // Sane defaults
    if ($out['auto_increment']) {
      $out['nullable'] = false;
    }
    if ($out['primary']) {
      $out['nullable'] = false;
    }

    return $out;
  }

  private function buildCreateTableSql(string $table, array $columns, array $opt): string
  {
    $defs = [];
    $pk = null;
    $uniques = [];

    foreach ($columns as $c) {
      $defs[] = $this->buildColumnDefinition($c);
      if (!empty($c['primary']) && $pk === null) {
        $pk = $c['name'];
      }
      if (!empty($c['unique'])) {
        $uniques[] = $c['name'];
      }
    }

    if ($pk !== null) {
      $defs[] = 'PRIMARY KEY (' . $this->qi($pk) . ')';
    }

    foreach ($uniques as $u) {
      $key = 'uniq_' . preg_replace('/[^A-Za-z0-9_]/', '_', $table . '_' . $u);
      $defs[] = 'UNIQUE KEY ' . $this->qi($key) . ' (' . $this->qi($u) . ')';
    }

    $engine  = preg_replace('/[^A-Za-z0-9_]/', '', (string)$opt['engine']);
    $charset = preg_replace('/[^A-Za-z0-9_]/', '', (string)$opt['charset']);
    $collate = preg_replace('/[^A-Za-z0-9_]/', '', (string)$opt['collate']);
    if ($engine === '')  $engine = 'InnoDB';
    if ($charset === '') $charset = 'utf8mb4';
    if ($collate === '') $collate = 'utf8mb4_unicode_ci';

    return 'CREATE TABLE IF NOT EXISTS ' . $this->qi($table) . " (\n  "
      . implode(",\n  ", $defs)
      . "\n) ENGINE={$engine} DEFAULT CHARSET={$charset} COLLATE={$collate};";
  }

  private function alterColumns(string $table, array $desired): bool
  {
    // Nota: este alter es MySQL/MariaDB oriented (usa DESCRIBE + SHOW INDEX)
    $existing = $this->db->getFieldData($table);
    $map = [];
    foreach ($existing as $r) {
      $n = strtolower((string)($r['name'] ?? ''));
      if ($n) $map[$n] = $r;
    }

    // Índices existentes (para PRIMARY/UNIQUE/KEY, requerido por AUTO_INCREMENT)
    $idxRows = method_exists($this->db, 'getIndexData') ? $this->db->getIndexData($table) : [];
    $idx = $this->normalizeIndexRows($idxRows);
    $existingKeyNames = array_change_key_case(array_fill_keys(array_keys($idx), true), CASE_LOWER);

    $hasPrimary = isset($idx['PRIMARY']);
    $primaryCols = $hasPrimary ? ($idx['PRIMARY']['cols'] ?? []) : [];

    $desiredPrimary = null;
    $desiredUniques = [];
    $desiredAutoInc = [];
    foreach ($desired as $c) {
      if ($desiredPrimary === null && !empty($c['primary'])) {
        $desiredPrimary = $c['name'];
      }
      if (!empty($c['unique'])) {
        $desiredUniques[] = $c['name'];
      }
      if (!empty($c['auto_increment'])) {
        $desiredAutoInc[] = $c['name'];
      }
    }

    $changes = [];

    // 1) Cambios de columnas
    foreach ($desired as $c) {
      $name = strtolower($c['name']);
      if (!isset($map[$name])) {
        $changes[] = 'ADD COLUMN ' . $this->buildColumnDefinition($c);
        continue;
      }

      $ex = $map[$name];
      $exType  = strtoupper((string)($ex['type'] ?? ''));
      $exNull  = strtoupper((string)($ex['null'] ?? ''));
      $exDef   = $ex['default'] ?? null;
      $exExtra = strtolower((string)($ex['extra'] ?? ''));

      $wantType = strtoupper($this->buildTypeOnly($c));
      $wantNull = $c['nullable'] ? 'YES' : 'NO';
      $wantDef  = $c['default'] ?? null;
      $wantAI   = !empty($c['auto_increment']);

      $typeDiff = $this->normalizeMysqlType($exType) !== $this->normalizeMysqlType($wantType);
      $nullDiff = $exNull !== $wantNull;
      $defDiff  = $this->normalizeDefaultForCompare($exDef) !== $this->normalizeDefaultForCompare($wantDef);
      $aiDiff   = (strpos($exExtra, 'auto_increment') !== false) !== $wantAI;

      if ($typeDiff || $nullDiff || $defDiff || $aiDiff) {
        $changes[] = 'MODIFY COLUMN ' . $this->buildColumnDefinition($c);
      }
    }

    // 2) Cambios de llaves/índices mínimos (PRIMARY, UNIQUE por columna y KEY para AUTO_INCREMENT)
    // PRIMARY (solo si no existe aún)
    if ($desiredPrimary !== null && !$hasPrimary) {
      $changes[] = 'ADD PRIMARY KEY (' . $this->qi($desiredPrimary) . ')';
      $hasPrimary = true;
      $primaryCols = [$desiredPrimary];
    }

    // Si ya existe PRIMARY y es diferente, NO lo cambiamos (seguridad).
    $primaryIsDifferent = ($desiredPrimary !== null && $hasPrimary && $primaryCols && (strtolower($primaryCols[0]) !== strtolower($desiredPrimary)));

    // UNIQUE por columna (si falta)
    foreach (array_values(array_unique($desiredUniques)) as $col) {
      if ($this->hasSingleColumnUnique($idx, $col)) {
        continue;
      }
      $keyName = $this->makeIndexName('uniq', $table, [$col], $existingKeyNames);
      $existingKeyNames[strtolower($keyName)] = true;
      $changes[] = 'ADD UNIQUE KEY ' . $this->qi($keyName) . ' (' . $this->qi($col) . ')';
    }

    // AUTO_INCREMENT debe ser KEY.
    // - Si el AUTO_INCREMENT también es PRIMARY (y la PRIMARY existe/matchea), ok.
    // - Si hay PRIMARY distinta, agregamos UNIQUE (si era primary) o KEY (si no).
    foreach (array_values(array_unique($desiredAutoInc)) as $col) {
      $colLower = strtolower($col);
      $isPrimaryDesired = ($desiredPrimary !== null && strtolower($desiredPrimary) === $colLower);

      // ya está cubierto por PRIMARY actual?
      if ($hasPrimary && $primaryCols && strtolower($primaryCols[0]) === $colLower) {
        continue;
      }

      // ya existe algún índice que comience por la columna?
      if ($this->hasIndexStartingWith($idx, $col)) {
        continue;
      }

      if ($isPrimaryDesired && $primaryIsDifferent) {
        // No podemos cambiar PRIMARY sin riesgo: creamos UNIQUE para cumplir AI y mantener PK existente
        $keyName = $this->makeIndexName('uniq', $table, [$col], $existingKeyNames);
        $existingKeyNames[strtolower($keyName)] = true;
        $changes[] = 'ADD UNIQUE KEY ' . $this->qi($keyName) . ' (' . $this->qi($col) . ')';
      } else {
        $keyName = $this->makeIndexName('idx', $table, [$col], $existingKeyNames);
        $existingKeyNames[strtolower($keyName)] = true;
        $changes[] = 'ADD KEY ' . $this->qi($keyName) . ' (' . $this->qi($col) . ')';
      }
    }

    if (!$changes) return false;

    $sql = 'ALTER TABLE ' . $this->qi($table) . ' ' . implode(', ', $changes) . ';';
    $this->db->query($sql);
    return true;
  }

  private function buildTypeOnly(array $c): string
  {
    $type = strtoupper($c['type'] ?? 'VARCHAR');

    // VARCHAR/CHAR requieren longitud en MySQL/MariaDB.
    if (in_array($type, ['VARCHAR','CHAR','VARBINARY','BINARY'], true)) {
      $len = $c['length'] ?? null;
      if (!is_int($len) || $len <= 0) {
        $defaults = [
          'VARCHAR' => 255,
          'CHAR' => 1,
          'VARBINARY' => 255,
          'BINARY' => 1,
        ];
        $c['length'] = $defaults[$type];
      }
    }

    // ENUM/SET
    if (in_array($type, ['ENUM','SET'], true)) {
      $vals = $c['values'] ?? null;
      if (is_string($vals)) {
        // permite: "a,b,c" o "'a','b'"
        $vals = array_filter(array_map('trim', explode(',', $vals)));
      }
      if (is_array($vals) && $vals) {
        $escaped = array_map(fn($v) => "'" . str_replace("'", "''", (string)$v) . "'", $vals);
        return $type . '(' . implode(',', $escaped) . ')';
      }
      return $type . "('')";
    }

    // DECIMAL
    if ($type === 'DECIMAL') {
      $p = $c['precision'] ?? null;
      $s = $c['scale'] ?? null;
      if (is_int($p) && is_int($s)) return "DECIMAL({$p},{$s})";
      return 'DECIMAL(10,2)';
    }

    // Tipos con longitud
    $lenTypes = ['VARCHAR','CHAR','INT','TINYINT','SMALLINT','MEDIUMINT','BIGINT','VARBINARY','BINARY'];
    if (in_array($type, $lenTypes, true) && isset($c['length']) && is_int($c['length']) && $c['length'] > 0) {
      $type .= '(' . (int)$c['length'] . ')';
    }

    // GPS compat: si viene como GPS, lo tratamos como POINT
    if ($type === 'GPS') {
      $type = 'POINT';
    }

    // UNSIGNED
    if (!empty($c['unsigned']) && preg_match('/INT/i', $type)) {
      $type .= ' UNSIGNED';
    }

    return $type;
  }

  private function buildColumnDefinition(array $c): string
  {
    $name = $c['name'];
    $sql = $this->qi($name) . ' ' . $this->buildTypeOnly($c);

    // NULL / NOT NULL
    $sql .= (!empty($c['nullable']) ? ' NULL' : ' NOT NULL');

    // DEFAULT
    if (array_key_exists('default', $c)) {
      if ($c['default'] === null) {
        if (!empty($c['nullable'])) {
          $sql .= ' DEFAULT NULL';
        }
      } else {
        $sql .= ' DEFAULT ' . $this->quoteDefault($c['default']);
      }
    }

    // AUTO_INCREMENT
    if (!empty($c['auto_increment'])) {
      $sql .= ' AUTO_INCREMENT';
    }

    // COMMENT
    if (!empty($c['comment'])) {
      $sql .= " COMMENT '" . str_replace("'", "''", (string)$c['comment']) . "'";
    }

    return $sql;
  }

  private function quoteDefault($v): string
  {
    // Permite expresiones: RAW:CURRENT_TIMESTAMP
    if (is_string($v) && str_starts_with($v, 'RAW:')) {
      return substr($v, 4);
    }
    if (is_bool($v)) return $v ? '1' : '0';
    if (is_int($v) || is_float($v)) return (string)$v;
    return "'" . str_replace("'", "''", (string)$v) . "'";
  }

  private function normalizeMysqlType(string $t): string
  {
    // Normaliza espacios y mayúsculas
    $t = strtoupper(trim(preg_replace('/\s+/', ' ', $t)));

    // MySQL 8+ puede omitir display width: INT vs INT(11)
    $t = preg_replace('/\b(TINYINT|SMALLINT|MEDIUMINT|INT|INTEGER|BIGINT)\s*\(\s*\d+\s*\)/', '$1', $t);

    // Homologaciones
    $t = preg_replace('/\bINTEGER\b/', 'INT', $t);
    $t = preg_replace('/\bBOOL(EAN)?\b/', 'TINYINT', $t);

    // Compacta espacios de UNSIGNED, ZEROFILL, etc
    $t = preg_replace('/\s+/', ' ', trim($t));
    return $t;
  }

  private function normalizeDefaultForCompare($v): ?string
  {
    if ($v === null) return null;
    if (is_bool($v)) return $v ? '1' : '0';
    if (is_int($v) || is_float($v)) return (string)$v;
    return (string)$v;
  }

  /**
   * Agrupa SHOW INDEX en una estructura por nombre de llave.
   * return: [ 'KEYNAME' => ['unique'=>bool, 'cols'=>['col1','col2',..]] ]
   */
  private function normalizeIndexRows(array $rows): array
  {
    $out = [];
    foreach ($rows as $r) {
      $k = (string)($r['key_name'] ?? $r['Key_name'] ?? '');
      $c = (string)($r['column_name'] ?? $r['Column_name'] ?? '');
      $seq = (int)($r['seq_in_index'] ?? $r['Seq_in_index'] ?? 0);
      $nonUnique = (int)($r['non_unique'] ?? $r['Non_unique'] ?? 1);
      if ($k === '' || $c === '') continue;

      if (!isset($out[$k])) {
        $out[$k] = ['unique' => ($nonUnique === 0), 'cols' => []];
      }
      // coloca por posición
      $out[$k]['cols'][$seq] = $c;
      // si alguna fila dice non_unique=0, mantenemos unique=true
      if ($nonUnique === 0) $out[$k]['unique'] = true;
    }

    // normaliza orden
    foreach ($out as $k => $info) {
      ksort($info['cols']);
      $out[$k]['cols'] = array_values($info['cols']);
    }

    return $out;
  }

  private function hasSingleColumnUnique(array $idx, string $col): bool
  {
    foreach ($idx as $name => $info) {
      if (empty($info['unique'])) continue;
      $cols = $info['cols'] ?? [];
      if (count($cols) === 1 && strtolower((string)$cols[0]) === strtolower($col)) {
        return true;
      }
    }
    return false;
  }

  private function hasIndexStartingWith(array $idx, string $col): bool
  {
    foreach ($idx as $name => $info) {
      $cols = $info['cols'] ?? [];
      if (!$cols) continue;
      if (strtolower((string)$cols[0]) === strtolower($col)) {
        return true;
      }
    }
    return false;
  }

  private function makeIndexName(string $type, string $table, array $cols, array $existingKeyNamesLower): string
  {
    $prefix = ($type === 'uniq') ? 'uniq' : 'idx';
    $base = strtolower($prefix . '_' . $table . '_' . implode('_', $cols));
    $base = preg_replace('/[^a-z0-9_]/', '_', $base);
    $name = substr($base, 0, 60);

    $i = 0;
    $candidate = $name;
    while (isset($existingKeyNamesLower[strtolower($candidate)])) {
      $i++;
      $suffix = '_' . substr(md5($base . ':' . $i), 0, 6);
      $candidate = substr($name, 0, 60 - strlen($suffix)) . $suffix;
    }
    return $candidate;
  }

  private function qi(string $ident): string
  {
    // backticks
    return '`' . str_replace('`', '``', $ident) . '`';
  }

  private function isSafeIdentifier(string $ident): bool
  {
    return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $ident);
  }
}
