<?php
declare(strict_types=1);

namespace System\Database\Schema;

use System\Database\Connection;
use System\Database\DbResult;

/**
 * ============================================================
 * Q_Framework - Schema (DDL helper)
 * ============================================================
 * Crea / asegura tablas a partir de un arreglo de columnas.
 *
 * Objetivo:
 * - Mover la creación de tablas (DDL) al CORE del framework.
 * - Permitir "base columns" opcionales y configurables.
 *
 * ColumnSpec (por columna):
 * - name|nombre (string)  : nombre de columna
 * - type (string)         : VARCHAR|INT|DECIMAL|JSON|POINT|...
 * - length (int|null)     : para tipos con longitud
 * - precision (int|null)  : DECIMAL
 * - scale (int|null)      : DECIMAL
 * - nullable (bool)       : true/false (default true)
 * - default (mixed|null)  : default literal (string|int|float|bool|null)
 * - unsigned (bool)       : para enteros
 * - auto_increment (bool) : para PK autoincrement
 * - primary (bool)        : marca como PK (solo soportamos PK simple en CREATE)
 * - unique (bool)         : crea índice UNIQUE (solo en CREATE)
 * - comment (string|null) : comentario
 * - values (array|string) : ENUM/SET (opcional)
 */
final class Schema
{
  /** Base columns por defecto (opcionales) */
  private const DEFAULT_BASE_COLUMNS = [
    [
      'name' => 'tabla_id',
      'type' => 'INT',
      'length' => 11,
      'unsigned' => true,
      'nullable' => false,
      'auto_increment' => true,
      'primary' => true,
    ],
    [
      'name' => 'fecha',
      'type' => 'DATE',
      'nullable' => true,
      'default' => null,
    ],
    [
      'name' => 'fecha_dmy',
      'type' => 'VARCHAR',
      'length' => 20,
      'nullable' => true,
      'default' => null,
    ],
    [
      'name' => 'borrado',
      'type' => 'TINYINT',
      'length' => 1,
      'unsigned' => true,
      'nullable' => false,
      'default' => 0,
    ],
  ];

  public function __construct(private Connection $db) {}

  /**
   * Asegura una tabla y (opcionalmente) altera columnas.
   *
   * Opciones:
   * - alter (bool) : si existe, hace ADD/MODIFY columnas (default false)
   * - engine (string)  : InnoDB (default)
   * - charset (string) : utf8mb4 (default)
   * - collate (string) : utf8mb4_unicode_ci (default)
   * - base_columns (bool|array):
   *     false => no agrega base columns
   *     true  => agrega DEFAULT_BASE_COLUMNS
   *     array => columnas base custom (ColumnSpec list). Si quieres además incluir
   *             las default, usa base_columns_include_default=true
   * - base_columns_include_default (bool): si base_columns es array, mergea con default
   */
  public function ensure(string $table, array $columns, array $options = []): array
  {
    $table = trim($table);
    if (!$this->isSafeIdentifier($table)) {
      throw new \InvalidArgumentException('Nombre de tabla inválido.');
    }

    $opt = array_merge([
      'alter' => false,
      'engine' => 'InnoDB',
      'charset' => 'utf8mb4',
      'collate' => 'utf8mb4_unicode_ci',
      'base_columns' => false,
      'base_columns_include_default' => false,
    ], $options);

    // Normaliza columnas y aplica base columns según opciones
    $columns = $this->normalizeColumns($columns);
    $columns = $this->applyBaseColumns($columns, $opt['base_columns'], (bool)$opt['base_columns_include_default']);

    // Si no hay columnas, no hacemos nada
    if (!$columns) {
      return ['ok' => false, 'created' => false, 'altered' => false, 'message' => 'No hay columnas para crear.'];
    }

    if (!$this->db->tableExists($table)) {
      $sql = $this->buildCreateTableSql($table, $columns, $opt);
      $this->db->query($sql);
      return ['ok' => true, 'created' => true, 'altered' => false, 'message' => 'Tabla creada.'];
    }

    if (!empty($opt['alter'])) {
      $changed = $this->alterColumns($table, $columns);
      return ['ok' => true, 'created' => false, 'altered' => $changed, 'message' => $changed ? 'Tabla alterada.' : 'Sin cambios.'];
    }

    return ['ok' => true, 'created' => false, 'altered' => false, 'message' => 'Ya existe.'];
  }

  /**
   * ensureResult() (PRO): igual que ensure(), pero devuelve DbResult
   * en vez de lanzar por defecto (útil para APIs/CLI).
   */
  public function ensureResult(string $table, array $columns, array $options = []): DbResult
  {
    $t0 = microtime(true);
    try {
      $out = $this->ensure($table, $columns, $options);
      $r = new DbResult();
      $r->ok = (bool)($out['ok'] ?? false);
      $r->action = 'schema';
      $r->table = $table;
      $r->data = $out;
      $r->meta['created'] = (bool)($out['created'] ?? false);
      $r->meta['altered'] = (bool)($out['altered'] ?? false);
      $r->time_ms = round((microtime(true) - $t0) * 1000, 2);
      return $r;
    } catch (\Throwable $e) {
      $r = DbResult::failFromThrowable($e, ['action' => 'schema', 'table' => $table]);
      $r->time_ms = round((microtime(true) - $t0) * 1000, 2);
      return $r;
    }
  }

  // ------------------------------------------------------------
  // Internals
  // ------------------------------------------------------------

  private function applyBaseColumns(array $columns, $baseColumnsOpt, bool $includeDefault): array
  {
    // base_columns = false => nada
    if ($baseColumnsOpt === false || $baseColumnsOpt === null) {
      return $columns;
    }

    // base_columns = true => default
    if ($baseColumnsOpt === true) {
      return $this->mergeColumns(self::DEFAULT_BASE_COLUMNS, $columns);
    }

    // base_columns = array => custom (y opcionalmente default)
    if (is_array($baseColumnsOpt)) {
      $custom = $this->normalizeColumns($baseColumnsOpt);

      // Si es array de strings => subset de default
      if ($this->isStringList($baseColumnsOpt)) {
        $subset = $this->defaultSubsetByNames($baseColumnsOpt);
        return $this->mergeColumns($subset, $columns);
      }

      if ($includeDefault) {
        $base = $this->mergeColumns(self::DEFAULT_BASE_COLUMNS, $custom);
        return $this->mergeColumns($base, $columns);
      }
      return $this->mergeColumns($custom, $columns);
    }

    // Cualquier otro caso => no base columns
    return $columns;
  }

  private function defaultSubsetByNames(array $names): array
  {
    $names = array_map('strtolower', array_map('trim', $names));
    $out = [];
    foreach (self::DEFAULT_BASE_COLUMNS as $c) {
      $n = strtolower((string)($c['name'] ?? ''));
      if ($n && in_array($n, $names, true)) {
        $out[] = $c;
      }
    }
    return $out;
  }

  private function isStringList(array $arr): bool
  {
    if (!$arr) return false;
    foreach ($arr as $v) {
      if (!is_string($v)) return false;
    }
    return true;
  }

  private function mergeColumns(array $a, array $b): array
  {
    // b sobreescribe por nombre
    $map = [];
    foreach ($a as $c) {
      $c = $this->normalizeColumn($c);
      if (!$c) continue;
      $map[strtolower($c['name'])] = $c;
    }
    foreach ($b as $c) {
      $c = $this->normalizeColumn($c);
      if (!$c) continue;
      $map[strtolower($c['name'])] = $c;
    }
    return array_values($map);
  }

  private function normalizeColumns(array $columns): array
  {
    $out = [];
    foreach ($columns as $col) {
      $n = $this->normalizeColumn($col);
      if ($n) $out[] = $n;
    }
    return $out;
  }

  private function normalizeColumn($col): ?array
  {
    if (!is_array($col)) return null;

    $name = (string)($col['name'] ?? $col['nombre'] ?? '');
    $name = trim($name);
    if ($name === '' || !$this->isSafeIdentifier($name)) {
      return null;
    }

    $type = strtoupper(trim((string)($col['type'] ?? $col['db_type'] ?? 'VARCHAR')));
    if ($type === '') $type = 'VARCHAR';

    $out = [
      'name' => $name,
      'type' => $type,
      'length' => isset($col['length']) ? (is_numeric($col['length']) ? (int)$col['length'] : null) : null,
      'precision' => isset($col['precision']) ? (is_numeric($col['precision']) ? (int)$col['precision'] : null) : null,
      'scale' => isset($col['scale']) ? (is_numeric($col['scale']) ? (int)$col['scale'] : null) : null,
      'nullable' => array_key_exists('nullable', $col) ? (bool)$col['nullable'] : true,
      'default' => $col['default'] ?? null,
      'unsigned' => array_key_exists('unsigned', $col) ? (bool)$col['unsigned'] : false,
      'auto_increment' => array_key_exists('auto_increment', $col) ? (bool)$col['auto_increment'] : false,
      'primary' => array_key_exists('primary', $col) ? (bool)$col['primary'] : false,
      'unique' => array_key_exists('unique', $col) ? (bool)$col['unique'] : false,
      'comment' => isset($col['comment']) ? (string)$col['comment'] : null,
      'values' => $col['values'] ?? null,
    ];

    // Sane defaults
    if ($out['auto_increment']) {
      $out['nullable'] = false;
    }
    if ($out['primary']) {
      $out['nullable'] = false;
    }

    return $out;
  }

  private function buildCreateTableSql(string $table, array $columns, array $opt): string
  {
    $defs = [];
    $pk = null;
    $uniques = [];

    foreach ($columns as $c) {
      $defs[] = $this->buildColumnDefinition($c);
      if (!empty($c['primary']) && $pk === null) {
        $pk = $c['name'];
      }
      if (!empty($c['unique'])) {
        $uniques[] = $c['name'];
      }
    }

    if ($pk !== null) {
      $defs[] = 'PRIMARY KEY (' . $this->qi($pk) . ')';
    }

    foreach ($uniques as $u) {
      $key = 'uniq_' . preg_replace('/[^A-Za-z0-9_]/', '_', $table . '_' . $u);
      $defs[] = 'UNIQUE KEY ' . $this->qi($key) . ' (' . $this->qi($u) . ')';
    }

    $engine  = preg_replace('/[^A-Za-z0-9_]/', '', (string)$opt['engine']);
    $charset = preg_replace('/[^A-Za-z0-9_]/', '', (string)$opt['charset']);
    $collate = preg_replace('/[^A-Za-z0-9_]/', '', (string)$opt['collate']);
    if ($engine === '')  $engine = 'InnoDB';
    if ($charset === '') $charset = 'utf8mb4';
    if ($collate === '') $collate = 'utf8mb4_unicode_ci';

    return 'CREATE TABLE IF NOT EXISTS ' . $this->qi($table) . " (\n  "
      . implode(",\n  ", $defs)
      . "\n) ENGINE={$engine} DEFAULT CHARSET={$charset} COLLATE={$collate};";
  }

  private function alterColumns(string $table, array $desired): bool
  {
    $existing = $this->db->getFieldData($table);
    $map = [];
    foreach ($existing as $r) {
      $n = strtolower((string)($r['name'] ?? ''));
      if ($n) $map[$n] = $r;
    }

    $changes = [];
    foreach ($desired as $c) {
      $name = strtolower($c['name']);
      if (!isset($map[$name])) {
        $changes[] = 'ADD COLUMN ' . $this->buildColumnDefinition($c);
        continue;
      }

      // Compara type + null + default + extra(auto_increment)
      $ex = $map[$name];
      $exType = strtoupper((string)($ex['type'] ?? ''));
      $exNull = strtoupper((string)($ex['null'] ?? ''));
      $exDef  = $ex['default'] ?? null;
      $exExtra= strtolower((string)($ex['extra'] ?? ''));

      $wantType = strtoupper($this->buildTypeOnly($c));
      $wantNull = $c['nullable'] ? 'YES' : 'NO';
      $wantDef  = $c['default'] ?? null;
      $wantAI   = !empty($c['auto_increment']);

      $typeDiff = $this->normalizeMysqlType($exType) !== $this->normalizeMysqlType($wantType);
      $nullDiff = $exNull !== $wantNull;
      $defDiff  = ($exDef !== $wantDef);
      $aiDiff   = (strpos($exExtra, 'auto_increment') !== false) !== $wantAI;

      if ($typeDiff || $nullDiff || $defDiff || $aiDiff) {
        $changes[] = 'MODIFY COLUMN ' . $this->buildColumnDefinition($c);
      }
    }

    if (!$changes) return false;
    $sql = 'ALTER TABLE ' . $this->qi($table) . ' ' . implode(', ', $changes) . ';';
    $this->db->query($sql);
    return true;
  }

  private function buildTypeOnly(array $c): string
  {
    $type = strtoupper($c['type'] ?? 'VARCHAR');

    // VARCHAR/CHAR requieren longitud en MySQL/MariaDB.
    if (in_array($type, ['VARCHAR','CHAR','VARBINARY','BINARY'], true)) {
      $len = $c['length'] ?? null;
      if (!is_int($len) || $len <= 0) {
        $defaults = [
          'VARCHAR' => 255,
          'CHAR' => 1,
          'VARBINARY' => 255,
          'BINARY' => 1,
        ];
        $c['length'] = $defaults[$type];
      }
    }

    // ENUM/SET
    if (in_array($type, ['ENUM','SET'], true)) {
      $vals = $c['values'] ?? null;
      if (is_string($vals)) {
        // permite: "a,b,c" o "'a','b'"
        $vals = array_filter(array_map('trim', explode(',', $vals)));
      }
      if (is_array($vals) && $vals) {
        $escaped = array_map(fn($v) => "'" . str_replace("'", "''", (string)$v) . "'", $vals);
        return $type . '(' . implode(',', $escaped) . ')';
      }
      return $type . "('')";
    }

    // DECIMAL
    if ($type === 'DECIMAL') {
      $p = $c['precision'] ?? null;
      $s = $c['scale'] ?? null;
      if (is_int($p) && is_int($s)) return "DECIMAL({$p},{$s})";
      return 'DECIMAL(10,2)';
    }

    // Tipos con longitud
    $lenTypes = ['VARCHAR','CHAR','INT','TINYINT','SMALLINT','MEDIUMINT','BIGINT','VARBINARY','BINARY'];
    if (in_array($type, $lenTypes, true) && isset($c['length']) && is_int($c['length']) && $c['length'] > 0) {
      $type .= '(' . (int)$c['length'] . ')';
    }

    // GPS compat: si viene como GPS, lo tratamos como POINT
    if ($type === 'GPS') {
      $type = 'POINT';
    }

    // UNSIGNED
    if (!empty($c['unsigned']) && preg_match('/INT/i', $type)) {
      $type .= ' UNSIGNED';
    }

    return $type;
  }

  private function buildColumnDefinition(array $c): string
  {
    $name = $c['name'];
    $sql = $this->qi($name) . ' ' . $this->buildTypeOnly($c);

    // NULL / NOT NULL
    $sql .= (!empty($c['nullable']) ? ' NULL' : ' NOT NULL');

    // DEFAULT
    if (array_key_exists('default', $c)) {
      if ($c['default'] === null) {
        if (!empty($c['nullable'])) {
          $sql .= ' DEFAULT NULL';
        }
      } else {
        $sql .= ' DEFAULT ' . $this->quoteDefault($c['default']);
      }
    }

    // AUTO_INCREMENT
    if (!empty($c['auto_increment'])) {
      $sql .= ' AUTO_INCREMENT';
    }

    // COMMENT
    if (!empty($c['comment'])) {
      $sql .= " COMMENT '" . str_replace("'", "''", (string)$c['comment']) . "'";
    }

    return $sql;
  }

  private function quoteDefault($v): string
  {
    // Permite expresiones: RAW:CURRENT_TIMESTAMP
    if (is_string($v) && str_starts_with($v, 'RAW:')) {
      return substr($v, 4);
    }
    if (is_bool($v)) return $v ? '1' : '0';
    if (is_int($v) || is_float($v)) return (string)$v;
    return "'" . str_replace("'", "''", (string)$v) . "'";
  }

  private function normalizeMysqlType(string $t): string
  {
    // Normaliza espacios y mayúsculas
    $t = strtoupper(trim(preg_replace('/\s+/', ' ', $t)));
    return $t;
  }

  private function qi(string $ident): string
  {
    // backticks
    return '`' . str_replace('`', '``', $ident) . '`';
  }

  private function isSafeIdentifier(string $ident): bool
  {
    return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $ident);
  }
}
