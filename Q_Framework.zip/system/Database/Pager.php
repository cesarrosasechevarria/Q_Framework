<?php
declare(strict_types=1);

namespace System\Database;

/**
 * Pager PRO (simple y práctico)
 *
 * - Genera URLs por página preservando query string actual
 * - Template HTML usando clases QFW (qfw-btn, etc.)
 *
 * Uso:
 *   $data = $builder->paginate(10);
 *   $pager = $builder->pager();
 *   echo $pager?->render();
 */
final class Pager
{
  public function __construct(
    private int $totalRows,
    private int $perPage,
    private int $currentPage,
    private string $baseUrl,
    private string $pageParam = 'page',
    private array $preserveQuery = [],
    private int $window = 2,
    private bool $omitFirstPage = true
  ) {}

  public function totalRows(): int { return $this->totalRows; }
  public function perPage(): int { return $this->perPage; }
  public function currentPage(): int { return $this->currentPage; }

  /** Serialización útil para respuestas JSON (APIs). */
  public function toArray(): array
  {
    return [
      'totalRows' => $this->totalRows,
      'perPage' => $this->perPage,
      'currentPage' => $this->currentPage,
      'totalPages' => $this->totalPages(),
      'baseUrl' => $this->baseUrl,
      'pageParam' => $this->pageParam,
      'hasPrev' => $this->hasPrev(),
      'hasNext' => $this->hasNext(),
      'prevUrl' => $this->prevUrl(),
      'nextUrl' => $this->nextUrl(),
      'firstUrl' => $this->firstUrl(),
      'lastUrl' => $this->lastUrl(),
      'links' => $this->linksArray(),
    ];
  }

  
  /* =========================
     Aliases (compat / API)
     ========================= */

  /** Alias: page() (compat con Paginator/API) */
  public function page(): int { return $this->currentPage; }

  /** Alias: total() (compat con Paginator/API) */
  public function total(): int { return $this->totalRows; }

  /** Alias: pages() (compat con Paginator/API) */
  public function pages(): int { return $this->totalPages(); }

  /** Alias: next() URL */
  public function next(): ?string { return $this->nextUrl(); }

  /** Alias: prev() URL */
  public function prev(): ?string { return $this->prevUrl(); }

  /** Alias: links() HTML */
  public function links(?string $template = null): string { return $this->render($template); }


public function totalPages(): int
  {
    if ($this->perPage <= 0) return 1;
    return max(1, (int)ceil($this->totalRows / $this->perPage));
  }

  public function hasPrev(): bool { return $this->currentPage > 1; }
  public function hasNext(): bool { return $this->currentPage < $this->totalPages(); }

  public function prevUrl(): ?string { return $this->hasPrev() ? $this->pageUrl($this->currentPage - 1) : null; }
  public function nextUrl(): ?string { return $this->hasNext() ? $this->pageUrl($this->currentPage + 1) : null; }

  public function firstUrl(): string { return $this->pageUrl(1); }
  public function lastUrl(): string { return $this->pageUrl($this->totalPages()); }

  public function pageUrl(int $page): string
  {
    $page = max(1, min($this->totalPages(), $page));
    $q = $this->preserveQuery;

    if ($page === 1 && $this->omitFirstPage) {
      unset($q[$this->pageParam]);
    } else {
      $q[$this->pageParam] = $page;
    }

    $qs = http_build_query($q, '', '&', PHP_QUERY_RFC3986);
    return $this->baseUrl . ($qs ? ('?' . $qs) : '');
  }

  /**
   * Links de páginas como array (por si quieres render custom).
   * Cada item: ['page'=>int,'url'=>string,'current'=>bool]
   */
  public function linksArray(): array
  {
    $total = $this->totalPages();
    $cur = $this->currentPage;

    $start = max(1, $cur - $this->window);
    $end   = min($total, $cur + $this->window);

    // Asegura un bloque razonable cuando estás al inicio/fin
    if ($cur <= 1 + $this->window) {
      $end = min($total, 1 + ($this->window * 2));
    } elseif ($cur >= $total - $this->window) {
      $start = max(1, $total - ($this->window * 2));
    }

    $out = [];
    for ($p = $start; $p <= $end; $p++) {
      $out[] = [
        'page' => $p,
        'url' => $this->pageUrl($p),
        'current' => ($p === $cur),
      ];
    }
    return $out;
  }

  /**
   * Render HTML.
   *
   * Por defecto usa el template configurado en `app/Config/Pager.php`.
   * Para personalizar el HTML, copia el template core:
   *   system/Views/_system/pagers/qfw_default.php
   * a:
   *   app/Views/_system/pagers/qfw_default.php
   */
  public function render(?string $template = null): string
  {
    if ($this->totalPages() <= 1) return '';

    $cfg = config('Pager');
    $tpl = $template ?? (string)($cfg->template ?? 'pagers/qfw_default');

    // Layout normalmente vacío para que sea un partial.
    $layout = (string)($cfg->layout ?? '');
    return \System\Core\View::render($tpl, [
      'pager' => $this,
      'pagerCfg' => $cfg,
    ], $layout);
  }
}
