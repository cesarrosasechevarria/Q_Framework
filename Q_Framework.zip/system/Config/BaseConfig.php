<?php
declare(strict_types=1);

namespace System\Config;

/**
 * BaseConfig minimalista (Q_Framework).
 * - Permite overrides por env() en el constructor de cada Config.
 */
abstract class BaseConfig
{
}
