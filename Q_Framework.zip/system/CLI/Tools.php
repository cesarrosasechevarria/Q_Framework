<?php
declare(strict_types=1);

namespace System\CLI;

use System\Core\Modules;
use System\Core\RouteCollection;

/**
 * Herramientas PRO para CLI.
 */
final class Tools
{
  private static function println(string $s = ''): void
  {
    echo $s . PHP_EOL;
  }

  private static function cacheDir(): string
  {
    $dir = base_path('storage/cache');
    if (!is_dir($dir)) {
      @mkdir($dir, 0775, true);
    }
    return $dir;
  }

  /**
   * Compila rutas frescas (sin usar cache).
   *
   * @return array<string, mixed>
   */
  private static function compileRoutesFresh(): array
  {
    $routesFile = base_path('app/Config/Routes.php');
    if (!is_file($routesFile)) {
      throw new \RuntimeException('No existe app/Config/Routes.php');
    }

    $routesDef = require $routesFile;
    if (!is_callable($routesDef)) {
      throw new \RuntimeException('Routes.php debe retornar un callable: function(RouteCollection $routes) { ... }');
    }

    $col = new RouteCollection();
    $routesDef($col);
    Modules::routes($col);

    return $col->compile();
  }

  public static function doctor(): void
  {
    $env = (string) env('APP_ENV', 'production');
    $debug = env_bool('APP_DEBUG', false);
    $routeCache = env_bool('ROUTE_CACHE', false);

    self::println('Q_Framework Doctor');
    self::println('------------------');
    self::println('PHP: ' . PHP_VERSION);
    self::println('Env: ' . $env . ' | Debug: ' . ($debug ? 'true' : 'false') . ' | RouteCache: ' . ($routeCache ? 'true' : 'false'));
    self::println('BasePath: ' . base_path());

    $checks = [];

    // APP_KEY
    $appKey = (string) env('APP_KEY', '');
    $checks[] = ['APP_KEY', $appKey !== '' && strlen($appKey) >= 16, $appKey !== '' ? ('len=' . strlen($appKey)) : 'vacío'];

    // Writable dirs
    $write = base_path('write');
    $storage = base_path('storage');
    $cache = base_path('storage/cache');

    foreach (['write' => $write, 'storage' => $storage, 'storage/cache' => $cache] as $name => $dir) {
      $ok = is_dir($dir) && is_writable($dir);
      $checks[] = ['writable:' . $name, $ok, $dir];
    }

    // Vendor
    $vendor = base_path('vendor');
    $checks[] = ['vendor/', is_dir($vendor), $vendor];
    $checks[] = ['vendor/autoload.php', is_file(base_path('vendor/autoload.php')), 'composer autoload (opcional)'];

    // Routes cache file
    $cacheFile = base_path('storage/cache/routes.' . $env . '.php');
    $checks[] = ['routes cache file', is_file($cacheFile), $cacheFile];

    
    // Cache / Redis (infra)
    try {
      $cacheCfg = \config('Cache');
      $driver = strtolower((string)($cacheCfg->driver ?? 'file'));
      $checks[] = ['cache driver', in_array($driver, ['file','redis'], true), $driver];

      if ($driver === 'redis') {
        $c = \System\Core\Providers::container();
        $okHas = $c->has('redis');
        $checks[] = ['redis binding', $okHas, $okHas ? 'container:redis' : 'no (habilita App\\Providers\\InfraServiceProvider)'];

        if ($okHas) {
          /** @var \System\Cache\RedisClient $r */
          $r = $c->get('redis');
          $pong = $r->ping();
          $checks[] = ['redis ping', (bool)$pong, $pong ? 'PONG' : 'fail'];

          // Set/Get TTL quick test
          $k = 'qfw:doctor:' . bin2hex(random_bytes(4));
          $v = (string)time();
          $okSet = $r->set($k, $v, 2);
          $okGet = ($r->get($k) === $v);
          $checks[] = ['redis set/get', $okSet && $okGet, $okSet && $okGet ? 'ok' : 'fail'];
          $r->del($k);
        }
      }
    } catch (\Throwable $e) {
      $checks[] = ['cache/redis check', false, $e->getMessage()];
    }

    // Database groups (infra)
    try {
      $dbCfg = \config('Database');
      if (is_array($dbCfg->connections ?? null)) {
        foreach ($dbCfg->connections as $name => $cfg) {
          $n = (string)$name;
          if ($n === '') continue;
          $dsn = is_array($cfg) ? (string)($cfg['dsn'] ?? '') : '';
          if ($dsn === '') continue;

          try {
            \System\Core\DB::pdo($n);
            $checks[] = ['db:' . $n, true, 'ok'];
          } catch (\Throwable $e2) {
            $checks[] = ['db:' . $n, false, $e2->getMessage()];
          }
        }
      }
    } catch (\Throwable $e) {
      $checks[] = ['db groups check', false, $e->getMessage()];
    }

    // Metrics driver (infra)
    try {
      $obs = \config('Observability');
      $md = strtolower((string)($obs->metricsDriver ?? 'file'));
      $checks[] = ['metrics driver', in_array($md, ['file','redis'], true), $md];

      if ($md === 'redis' && !empty($obs->metricsEnabled)) {
        $c = \System\Core\Providers::container();
        $checks[] = ['metrics redis binding', $c->has('redis'), $c->has('redis') ? 'ok' : 'missing'];
      }
    } catch (\Throwable $e) {
      $checks[] = ['metrics check', false, $e->getMessage()];
    }

// Summary
    foreach ($checks as $c) {
      [$label, $ok, $info] = $c;
      self::println(sprintf('%-22s %s  %s', $label, ($ok ? '✅' : '❌'), $info));
    }

    self::println();
    self::println('Consejos:');
    self::println('- Generar APP_KEY: php bin/console make:key');
    self::println('- Cache de rutas:  php bin/console route:cache');
    self::println('- Ver rutas:       php bin/console route:list');
    self::println('- Lint core:       php bin/console lint');
  }

  /**
   * Lint de PHP (php -l) para app/ + system/ + tests/.
   */
  public static function lint(): int
  {
    $root = base_path();
    $targets = [
      $root . '/app',
      $root . '/system',
      $root . '/tests',
      $root . '/bootstrap.php',
      $root . '/autoload.php',
    ];

    $files = [];
    foreach ($targets as $t) {
      if (is_file($t) && str_ends_with($t, '.php')) {
        $files[] = $t;
        continue;
      }
      if (!is_dir($t)) continue;
      $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($t, \FilesystemIterator::SKIP_DOTS));
      foreach ($it as $file) {
        /** @var \SplFileInfo $file */
        $p = $file->getPathname();
        if (!str_ends_with($p, '.php')) continue;
        $files[] = $p;
      }
    }

    $files = array_values(array_unique($files));
    sort($files);

    $php = PHP_BINARY;
    $errors = 0;

    self::println('Lint (php -l) ... archivos: ' . count($files));

    foreach ($files as $f) {
      $cmd = escapeshellarg($php) . ' -l ' . escapeshellarg($f) . ' 2>&1';
      $out = [];
      $code = 0;
      exec($cmd, $out, $code);
      if ($code !== 0) {
        $errors++;
        self::println('❌ ' . str_replace($root . '/', '', $f));
        foreach ($out as $line) self::println('   ' . $line);
      }
    }

    if ($errors === 0) {
      self::println('✅ Lint OK');
      return 0;
    }

    self::println('❌ Lint con errores: ' . $errors);
    return 1;
  }

  public static function routeList(): void
  {
    $routes = self::compileRoutesFresh();

    self::println('METHOD  PATH                                     USES                                           NAME');
    self::println(str_repeat('-', 106));

    foreach ($routes as $method => $map) {
      if (!is_string($method) || str_starts_with($method, '_') || !is_array($map)) continue;
      foreach ($map as $path => $def) {
        if (!is_array($def)) $def = ['uses' => (string)$def];
        $uses = (string)($def['uses'] ?? '');
        $as   = (string)($def['as'] ?? '');

        self::println(sprintf(
          '%-6s %-40s %-45s %s',
          $method,
          (string)$path,
          substr($uses, 0, 45),
          $as
        ));
      }
    }

    // Show scoped AutoRoutes if defined
    $auto = is_array($routes['_auto'] ?? null) ? (array)$routes['_auto'] : [];
    if ($auto) {
      self::println('');
      self::println('SCOPED AUTOROUTE');
      self::println(str_repeat('-', 106));
      foreach ($auto as $s) {
        if (!is_array($s)) continue;
        $p = (string)($s['prefix'] ?? '/');
        $ns = implode(', ', (array)($s['namespaces'] ?? []));
        $filters = (array)(($s['opts']['filters'] ?? null) ?: []);
        $f = $filters ? ('filters: ' . implode(',', $filters)) : '';
        self::println(sprintf('AUTO   %-40s %-45s %s', $p . '/*', substr($ns, 0, 45), $f));
      }
    }
  }

  public static function routeCache(?string $env = null): void
  {
    $env = $env ?: (string) env('APP_ENV', 'production');

    $routes = self::compileRoutesFresh();

    $dir = self::cacheDir();
    $file = $dir . '/routes.' . $env . '.php';

    $export = var_export($routes, true);
    $php = "<?php\n// Generated by Q_Framework CLI route:cache (" . date('c') . ")\nreturn " . $export . ";\n";

    file_put_contents($file, $php);

    self::println('✅ Routes cache generado: ' . $file);
    self::println('   Tip: activa en .env -> ROUTE_CACHE=1');
  }

  public static function routeClear(bool $all = false, ?string $env = null): void
  {
    $dir = self::cacheDir();

    if ($all) {
      $files = glob($dir . '/routes.*.php') ?: [];
      $n = 0;
      foreach ($files as $f) {
        if (is_file($f)) { @unlink($f); $n++; }
      }
      self::println('✅ Routes cache limpiado (all): ' . $n);
      return;
    }

    $env = $env ?: (string) env('APP_ENV', 'production');
    $file = $dir . '/routes.' . $env . '.php';
    if (is_file($file)) {
      @unlink($file);
      self::println('✅ Routes cache eliminado: ' . $file);
    } else {
      self::println('ℹ️ No existe: ' . $file);
    }
  }
}
