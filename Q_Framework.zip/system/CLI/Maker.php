<?php
declare(strict_types=1);

namespace System\CLI;

final class Maker
{
  public static function controller(string $name): void
  {
    $class = self::studly($name);
    $path  = base_path("app/Controllers/{$class}.php");
    if (is_file($path)) { echo "Ya existe: $path\n"; return; }

    $tpl = file_get_contents(base_path('system/CLI/stubs/controller.stub'));
    $tpl = str_replace('{{class}}', $class, $tpl);

    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, $tpl);
    echo "Creado: $path\n";
  }

  public static function model(string $name, string $table, string $pk): void
  {
    $class = self::studly($name);
    $path  = base_path("app/Models/{$class}.php");
    if (is_file($path)) { echo "Ya existe: $path\n"; return; }

    $tpl = file_get_contents(base_path('system/CLI/stubs/model.stub'));
    $tpl = str_replace(['{{class}}','{{table}}','{{pk}}'], [$class,$table,$pk], $tpl);

    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, $tpl);
    echo "Creado: $path\n";
  }

  public static function filter(string $name): void
  {
    $class = self::studly($name);
    $path  = base_path("app/Filters/{$class}.php");
    if (is_file($path)) { echo "Ya existe: $path\n"; return; }

    $tpl = file_get_contents(base_path('system/CLI/stubs/filter.stub'));
    $tpl = str_replace('{{class}}', $class, $tpl);

    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, $tpl);
    echo "Creado: $path\n";
  }

  
  public static function migration(string $name): void
  {
    $slug = self::snake($name);
    $ts = date('Y_m_d_His');
    $file = "{$ts}_{$slug}.php";
    $path = base_path("app/Database/Migrations/{$file}");
    if (is_file($path)) { echo "Ya existe: $path\n"; return; }

    $tpl = file_get_contents(base_path('system/CLI/stubs/migration.stub'));
    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, $tpl);
    echo "Creado: $path\n";
  }

  public static function module(string $name): void
  {
    $mod = self::studly($name);
    $base = base_path("app/Modules/{$mod}");

    if (is_dir($base)) { echo "Ya existe módulo: $base\n"; return; }

    @mkdir($base . '/Controllers', 0775, true);
    @mkdir($base . '/Models', 0775, true);
    @mkdir($base . '/Views/' . strtolower($mod), 0775, true);
    @mkdir($base . '/Database/Migrations', 0775, true);
    @mkdir($base . '/Database/Seeds', 0775, true);
    @mkdir($base . '/Support', 0775, true);

    $modulePhp = "<?php\ndeclare(strict_types=1);\n\nnamespace Modules\\{$mod};\n\nfinal class Module\n{\n  public const NAME = '{$mod}';\n  public const VERSION = '1.0.0';\n}\n";
    file_put_contents($base . '/Module.php', $modulePhp);

    $routesPhp = "<?php\ndeclare(strict_types=1);\n\nuse System\\Core\\RouteCollection;\n\nreturn function(RouteCollection \$routes){\n  // Ejemplo: \$routes->get('/{$mod}', 'Modules\\{$mod}\\Controllers\\{$mod}@index', ['as'=>'{$mod}.index']);\n};\n";
    file_put_contents($base . '/Routes.php', $routesPhp);

    echo "Módulo creado: {$mod}\n";
  }
public static function seed(string $name): void
  {
    $class = self::studly($name);
    $path  = base_path("app/Database/Seeds/{$class}.php");
    if (is_file($path)) { echo "Ya existe: $path\n"; return; }

    $tpl = file_get_contents(base_path('system/CLI/stubs/seed.stub'));
    $tpl = str_replace('{{class}}', $class, $tpl);

    @mkdir(dirname($path), 0775, true);
    file_put_contents($path, $tpl);
    echo "Creado: $path\n";
  }

  public static function key(): void
  {
    $raw = random_bytes(32);
    $val = 'base64:' . base64_encode($raw);

    $envFile = base_path('.env');
    $content = is_file($envFile) ? file_get_contents($envFile) : '';
    if ($content === false) $content = '';

    if (preg_match('/^APP_KEY=.*$/m', $content)) {
      $content = preg_replace('/^APP_KEY=.*$/m', 'APP_KEY='.$val, $content);
    } else {
      $content = rtrim($content) . "\nAPP_KEY=".$val."\n";
    }

    file_put_contents($envFile, $content);
    echo "APP_KEY generado y guardado en .env\n";
  }

  private static function studly(string $s): string
  {
    $s = preg_replace('/[^a-zA-Z0-9_]/', ' ', $s);
    $s = str_replace(' ', '', ucwords(trim($s)));
    return $s ?: 'Unnamed';
  }
}
