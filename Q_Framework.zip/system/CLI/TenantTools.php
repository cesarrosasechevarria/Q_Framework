<?php
declare(strict_types=1);

namespace System\CLI;

use System\Core\Tenant;
use System\Core\ModuleState;

/**
 * Tenancy tools (PRO)
 *
 * Enfoque:
 * - Provisionar tenants por carpeta (app/Tenants/<tenant>) y write/tenants/<tenant>
 * - Ejecutar migraciones/seeds por tenant (cargando .env del tenant via Tenant::switch)
 * - Gestionar módulos por tenant (ModuleState JSON)
 *
 * Nota: si Config\Tenancy::$registry = 'db' o 'both', tenant:list intentará leer desde DB group 'system'
 *       (configurable en Tenancy.php). Si no existe, solo listará filesystem.
 */
final class TenantTools
{
  private static function println(string $s = ''): void
  {
    echo $s . PHP_EOL;
  }

  private static function dieUsage(string $msg, string $usage, int $code = 1): void
  {
    self::println($msg);
    self::println($usage);
    exit($code);
  }

  public static function list(): void
  {
    // Tenant::boot() ya corre en bootstrap.php
    $known = Tenant::knownTenants();
    if (!$known) {
      self::println('No se encontraron tenants (filesystem/db).');
      return;
    }
    self::println('Tenants:');
    foreach ($known as $t) {
      self::println('  - ' . $t);
    }
  }

  public static function create(array $argv): void
  {
    $tenant = $argv[2] ?? '';
    $tenant = self::sanitize($tenant);

    if ($tenant === '') {
      self::dieUsage('Falta tenant.', 'Uso: php qfw tenant:create <tenant> [--no-env]');
    }

    $cfg = \config('Tenancy');
    $tenantsPath = base_path((string)($cfg->tenantsPath ?? 'app/Tenants'));
    $dir = rtrim($tenantsPath, '/\\') . '/' . $tenant;

    if (is_dir($dir)) {
      self::println("Tenant ya existe: {$tenant} ({$dir})");
    } else {
      @mkdir($dir, 0775, true);
      self::println("Tenant creado: {$tenant} ({$dir})");
    }

    // crea write dirs
    Tenant::switch($tenant);
    $base = Tenant::writeBase();
    self::println("Write dir: {$base}");

    $noEnv = in_array('--no-env', $argv, true);

    if (!$noEnv) {
      $envFile = $dir . '/.env';
      if (!is_file($envFile)) {
        $tpl = self::tenantEnvTemplate($tenant);
        @file_put_contents($envFile, $tpl);
        self::println("Se generó: {$envFile}");
      } else {
        self::println("Ya existe: {$envFile}");
      }
    }
  }

  public static function env(array $argv): void
  {
    $tenant = self::sanitize($argv[2] ?? '');
    if ($tenant === '') {
      self::dieUsage('Falta tenant.', 'Uso: php qfw tenant:env <tenant>');
    }
    $cfg = \config('Tenancy');
    $tenantsPath = base_path((string)($cfg->tenantsPath ?? 'app/Tenants'));
    $dir = rtrim($tenantsPath, '/\\') . '/' . $tenant;
    @mkdir($dir, 0775, true);

    $envFile = $dir . '/.env';
    $tpl = self::tenantEnvTemplate($tenant);
    @file_put_contents($envFile, $tpl);
    self::println("Plantilla .env escrita: {$envFile}");
  }

  public static function migrate(array $argv): void
  {
    $tenant = self::sanitize($argv[2] ?? '');
    $group  = $argv[3] ?? 'default';

    if ($tenant === '') {
      self::dieUsage('Falta tenant.', 'Uso: php qfw tenant:migrate <tenant> [group]');
    }

    Tenant::switch($tenant);

    $res = \Config\Services::migrator($group)->migrate();
    $applied = (int)($res['applied'] ?? 0);
    $skipped = (int)($res['skipped'] ?? 0);

    self::println("Tenant={$tenant} migrations aplicadas: {$applied} (skip: {$skipped}) group={$group}");
  }

  public static function rollback(array $argv): void
  {
    $tenant = self::sanitize($argv[2] ?? '');
    $group  = $argv[3] ?? 'default';

    if ($tenant === '') {
      self::dieUsage('Falta tenant.', 'Uso: php qfw tenant:rollback <tenant> [group]');
    }

    Tenant::switch($tenant);

    $n = \Config\Services::migrator($group)->rollback();
    self::println("Tenant={$tenant} rollback realizado: {$n} group={$group}");
  }

  public static function seed(array $argv): void
  {
    $tenant = self::sanitize($argv[2] ?? '');
    $name   = $argv[3] ?? null;
    $group  = $argv[4] ?? 'default';

    if ($tenant === '' || !$name) {
      self::dieUsage('Faltan parámetros.', 'Uso: php qfw tenant:seed <tenant> <SeederName> [group]');
    }

    Tenant::switch($tenant);

    \Config\Services::seeder($group)->run((string)$name);
    self::println("Tenant={$tenant} seeder ejecutado: {$name} group={$group}");
  }

  public static function modules(array $argv): void
  {
    $tenant = self::sanitize($argv[2] ?? '');
    $op     = strtolower((string)($argv[3] ?? 'list'));
    $arg    = (string)($argv[4] ?? '');

    if ($tenant === '') {
      self::dieUsage('Falta tenant.', 'Uso: php qfw tenant:modules <tenant> [list|enable|disable|save] [...]');
    }

    Tenant::switch($tenant);

    if ($op === 'list') {
      $s = ModuleState::load();
      self::println("Tenant={$tenant} modules.json (mode={$s['mode']})");
      self::println('  enabled:  ' . implode(', ', $s['enabled']));
      self::println('  disabled: ' . implode(', ', $s['disabled']));
      return;
    }

    if ($op === 'enable') {
      if ($arg === '') self::dieUsage('Falta módulo.', 'Uso: php qfw tenant:modules <tenant> enable <ModuleName>');
      ModuleState::enable($arg);
      self::println("Tenant={$tenant} módulo habilitado: {$arg}");
      return;
    }

    if ($op === 'disable') {
      if ($arg === '') self::dieUsage('Falta módulo.', 'Uso: php qfw tenant:modules <tenant> disable <ModuleName>');
      ModuleState::disable($arg);
      self::println("Tenant={$tenant} módulo deshabilitado: {$arg}");
      return;
    }

    if ($op === 'save') {
      // Uso:
      // php qfw tenant:modules <tenant> save --mode=override --enabled=ERP,Reportes --disabled=Academico
      $mode = self::optValue($argv, '--mode', 'override');
      $en   = self::optValue($argv, '--enabled', '');
      $dis  = self::optValue($argv, '--disabled', '');

      $enabled = $en !== '' ? array_values(array_filter(array_map('trim', explode(',', $en)))) : [];
      $disabled = $dis !== '' ? array_values(array_filter(array_map('trim', explode(',', $dis)))) : [];

      ModuleState::save($enabled, $disabled, $mode);
      self::println("Tenant={$tenant} modules.json guardado (mode={$mode})");
      return;
    }

    self::dieUsage('Operación inválida.', 'Uso: php qfw tenant:modules <tenant> [list|enable|disable|save]');
  }

  private static function optValue(array $argv, string $name, string $default = ''): string
  {
    foreach ($argv as $a) {
      if (!is_string($a)) continue;
      if (str_starts_with($a, $name . '=')) {
        return (string)substr($a, strlen($name . '='));
      }
    }
    return $default;
  }

  private static function sanitize(string $raw): string
  {
    $raw = strtolower(trim($raw));
    if ($raw === '') return '';
    $raw = preg_replace('/[^a-z0-9_\-]/', '', $raw);
    return substr($raw, 0, 50);
  }

  private static function tenantEnvTemplate(string $tenant): string
  {
    $tenant = self::sanitize($tenant) ?: 'tenant';
    return "# Tenant env override: {$tenant}
# Ubicación: app/Tenants/{$tenant}/.env
#
# Recomendación (PRO): una BD por tenant.
# Si usas DB_CONNECTIONS_JSON con grupo 'system' para el registry, NO lo pongas aquí,
# déjalo en el .env raíz.

APP_NAME=\"ERP {$tenant}\"
BASE_URL=\"auto\"

# DB del tenant (grupo default)
DB_DSN=\"mysql:host=127.0.0.1;dbname=erp_{$tenant};charset=utf8mb4\"
DB_USER=\"{$tenant}_user\"
DB_PASS=\"\"

# Branding
BRAND_PRIMARY=\"#2563eb\"

";
  }
}
