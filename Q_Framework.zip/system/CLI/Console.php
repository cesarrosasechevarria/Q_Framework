<?php
declare(strict_types=1);

namespace System\CLI;

final class Console
{
  public static function run(array $argv): void
  {
    $cmd = $argv[1] ?? 'help';

    switch ($cmd) {
      case 'doctor':
        Tools::doctor();
        break;

      case 'lint':
        $code = Tools::lint();
        exit($code);
        break;

      case 'route:list':
        Tools::routeList();
        break;

      case 'route:cache':
        $env = $argv[2] ?? null;
        Tools::routeCache(is_string($env) ? $env : null);
        break;

      case 'route:clear':
        $all = in_array('--all', $argv, true);
        $env = $argv[2] ?? null;
        if ($env === '--all') $env = null;
        Tools::routeClear($all, is_string($env) ? $env : null);
        break;

      case 'make:controller':
        $name = $argv[2] ?? null;
        if (!$name) { echo "Uso: php bin/console make:controller Nombre\n"; exit(1); }
        Maker::controller($name);
        break;

      case 'make:model':
        $name  = $argv[2] ?? null;
        $table = $argv[3] ?? null;
        $pk    = $argv[4] ?? 'id';
        if (!$name || !$table) { echo "Uso: php bin/console make:model Nombre tabla [pk]\n"; exit(1); }
        Maker::model($name, $table, $pk);
        break;

      case 'make:filter':
        $name = $argv[2] ?? null;
        if (!$name) { echo "Uso: php bin/console make:filter Nombre\n"; exit(1); }
        Maker::filter($name);
        break;

      case 'make:migration':
        $name = $argv[2] ?? null;
        if (!$name) { echo "Uso: php bin/console make:migration Nombre\n"; exit(1); }
        Maker::migration($name);
        break;

      case 'make:module':
        $name = $argv[2] ?? null;
        if (!$name) { echo "Uso: php bin/console make:module NombreModulo\n"; exit(1); }
        Maker::module($name);
        break;

      case 'make:seed':
        $name = $argv[2] ?? null;
        if (!$name) { echo "Uso: php bin/console make:seed NombreSeeder\n"; exit(1); }
        Maker::seed($name);
        break;

      case 'migrate:status':
        $group = $argv[2] ?? null;
        $st = \Config\Services::migrator($group)->status();
        echo "Grupo: " . ($group ?: 'default') . "\n";
        echo "Aplicadas: " . count($st['applied']) . "\n";
        echo "Pendientes: " . count($st['pending']) . "\n";
        if (!empty($st['pending'])) {
          echo " - " . implode("\n - ", $st['pending']) . "\n";
        }
        break;

      case 'migrate':
        $group = $argv[2] ?? null;
        $res = \Config\Services::migrator($group)->migrate();
        echo "Migrations aplicadas: {$res['applied']} (skip: {$res['skipped']})\n";
        break;

      case 'migrate:rollback':
        $group = $argv[2] ?? null;
        $n = \Config\Services::migrator($group)->rollback();
        echo "Rollback realizado: {$n}\n";
        break;

      case 'seed':
        $name  = $argv[2] ?? null;
        $group = $argv[3] ?? 'default';
        if (!$name) { echo "Uso: php bin/console seed NombreSeeder [group]\n"; exit(1); }
        \Config\Services::seeder($group)->run($name);
        echo "Seeder ejecutado: {$name} (group={$group})\n";
        break;


      case 'tenant:list':
        TenantTools::list();
        break;

      case 'tenant:create':
        TenantTools::create($argv);
        break;

      case 'tenant:env':
        TenantTools::env($argv);
        break;

      case 'tenant:migrate':
        TenantTools::migrate($argv);
        break;

      case 'tenant:rollback':
        TenantTools::rollback($argv);
        break;

      case 'tenant:seed':
        TenantTools::seed($argv);
        break;

      case 'tenant:modules':
        TenantTools::modules($argv);
        break;

      case 'make:key':
        Maker::key();
        break;

      case 'test':
        $stop = in_array('--stop', $argv, true);
        $code = \System\Testing\Runner::run(dirname(__DIR__, 2), $stop);
        exit($code);
        break;

      case 'help':
      default:
        self::help();
        break;
    }
  }

  private static function help(): void
  {
    echo "Q_Framework PRO+ CLI
";
    echo "Comandos:
";
    echo "  help
";
    echo "  doctor
";
    echo "  lint
";
    echo "  route:list
";
    echo "  route:cache [env]
";
    echo "  route:clear [env] [--all]
";
    echo "  make:controller Nombre
";
    echo "  make:model Nombre tabla [pk]
";
    echo "  make:filter Nombre
";
    echo "  make:migration Nombre
";
    echo "  make:module NombreModulo
";
    echo "  make:seed NombreSeeder
";
    echo "  make:key
";
    echo "  migrate:status [group]
";
    echo "  migrate [group]
";
    echo "  migrate:rollback [group]
";
    echo "  seed NombreSeeder [group]
";
    echo "  tenant:list\n";
    echo "  tenant:create <tenant> [--no-env]\n";
    echo "  tenant:env <tenant>\n";
    echo "  tenant:migrate <tenant> [group]\n";
    echo "  tenant:rollback <tenant> [group]\n";
    echo "  tenant:seed <tenant> <SeederName> [group]\n";
    echo "  tenant:modules <tenant> [list|enable|disable|save]\n";
    echo "  test [--stop]
";
  }

}
