<?php
declare(strict_types=1);

namespace System\Testing;

/**
 * TestCase minimal (sin dependencias externas)
 * - assertTrue/assertFalse/assertEquals/assertContains
 */
abstract class TestCase
{
  private int $assertions = 0;

  public function assertions(): int { return $this->assertions; }

  public function resetAssertions(): void { $this->assertions = 0; }

  protected function assertTrue($cond, string $message = 'Expected true'): void
  {
    $this->assertions++;
    if (!$cond) throw new \Exception($message);
  }

  protected function assertFalse($cond, string $message = 'Expected false'): void
  {
    $this->assertions++;
    if ($cond) throw new \Exception($message);
  }

  protected function assertEquals($expected, $actual, string $message = 'Not equals'): void
  {
    $this->assertions++;
    if ($expected != $actual) {
      throw new \Exception($message . "\nExpected: " . var_export($expected,true) . "\nActual: " . var_export($actual,true));
    }
  }

  protected function assertContains(string $needle, string $haystack, string $message = 'Not contains'): void
  {
    $this->assertions++;
    if (!str_contains($haystack, $needle)) throw new \Exception($message . " ({$needle})");
  }
}
