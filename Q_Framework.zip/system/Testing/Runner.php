<?php
declare(strict_types=1);

namespace System\Testing;

/**
 * Runner simple:
 * - Descubre tests en /tests/*Test.php
 * - Ejecuta métodos que empiecen por "test"
 */
final class Runner
{
  public static function run(string $basePath, bool $stopOnFailure = false): int
  {
    $testsDir = rtrim($basePath, '/\\') . DIRECTORY_SEPARATOR . 'tests';
    if (!is_dir($testsDir)) {
      echo "No existe carpeta tests/\n";
      return 1;
    }

    $files = glob($testsDir . DIRECTORY_SEPARATOR . '*Test.php') ?: [];
    sort($files);

    $total = 0;
    $assertions = 0;
    $failures = 0;

    foreach ($files as $f) {
      require_once $f;
    }

    // Encuentra clases que extiendan TestCase
    foreach (get_declared_classes() as $class) {
      if (!is_subclass_of($class, TestCase::class)) continue;
      $ref = new \ReflectionClass($class);
      if ($ref->isAbstract()) continue;
      $inst = $ref->newInstance();

      foreach ($ref->getMethods(\ReflectionMethod::IS_PUBLIC) as $m) {
        if (!str_starts_with($m->getName(), 'test')) continue;
        $total++;
        $name = $ref->getShortName() . '::' . $m->getName();
        try {
          if (method_exists($inst, 'resetAssertions')) $inst->resetAssertions();
          $inst->{$m->getName()}();
          $assertions += $inst->assertions();
          echo "✔ {$name}\n";
        } catch (\Throwable $e) {
          $failures++;
          echo "✘ {$name}\n";
          echo "  " . trim($e->getMessage()) . "\n";
          if ($stopOnFailure) return 1;
        }
      }
    }

    echo "\nTests: {$total}, Failures: {$failures}\n";
    return $failures > 0 ? 1 : 0;
  }
}
