<?php
declare(strict_types=1);

namespace System\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;

final class SecurityHeadersFilter implements FilterInterface
{
  public function before(Request $request, Response $response): ?Response
  {
    return null;
  }

  public function after(Request $request, Response $response): ?Response
  {
    // Seguridad estándar (OWASP baseline)
    $response->header('X-Frame-Options', 'SAMEORIGIN');
    $response->header('X-Content-Type-Options', 'nosniff');
    $response->header('Referrer-Policy', 'strict-origin-when-cross-origin');
    $response->header('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    $response->header('Cross-Origin-Opener-Policy', 'same-origin');
    $response->header('Cross-Origin-Resource-Policy', 'same-origin');
    $response->header('X-Permitted-Cross-Domain-Policies', 'none');

    // HSTS solo en HTTPS
    if ($request->isSecure()) {
      $response->header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    }

    $cfg = config('App');
    if (!empty($cfg->CSPEnabled)) {
      $nonce = \System\Core\Csp::nonce();

      $styleUnsafe = !empty($cfg->CSPAllowUnsafeInlineStyles) ? " 'unsafe-inline'" : '';
      $styleNonce  = $nonce ? " 'nonce-{$nonce}'" : '';
      $scriptNonce = $nonce ? " 'nonce-{$nonce}'" : '';

      $csp = "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self'; " .
             "img-src 'self' data: blob:; font-src 'self' data:; " .
             "style-src 'self'{$styleUnsafe}{$styleNonce}; script-src 'self'{$scriptNonce}; connect-src 'self'";

      $extra = trim((string)($cfg->CSPExtra ?? ''));
      if ($extra !== '') $csp .= "; " . $extra;
      else $csp .= ";";

      $h = !empty($cfg->CSPReportOnly) ? 'Content-Security-Policy-Report-Only' : 'Content-Security-Policy';
      $response->header($h, $csp);
    }

    return null;
  }
}
