<?php
declare(strict_types=1);

namespace System\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;
use System\Core\Session;

/**
 * GuardFilter (v9 PRO)
 *
 * Protege rutas/grupos por condiciones de sesión SIN repetir lógica en controllers.
 *
 * Uso (por ruta o group):
 *   'guard' => [
 *     'require' => 'user' | ['user','tenant'],
 *     'any'     => ['k1','k2'],                     // al menos una verdadera
 *     'match'   => ['user.role' => 'admin', 'user.active' => 1],
 *     'redirect'=> '/auth/login' | '@auth.login' | '/',  // fallback si no cumple
 *     'remember'=> true,                             // guarda intended URL para volver luego (default true)
 *     'intended_key' => '_qfw_intended',             // key session donde guardar intended
 *     'status'  => 302 | 401 | 403,                  // para JSON (default 401) y redirect (default 302)
 *     'message' => 'Acceso denegado',                // para JSON
 *   ]
 *
 * Notas:
 * - Dot-notation soportado: "user.role" => session('user')['role'].
 * - Si la ruta usa guard como boolean true sin config, se asume require='user'.
 */
final class GuardFilter implements FilterInterface
{
  private array $args = [];

  public function setArgs(array $args): void
  {
    $this->args = $args;
  }

  public function before(Request $request, Response $response): ?Response
  {
    // opt-in: si lo usas, se permite iniciar sesión
    Session::ensureStarted();
    $s = new Session();

    $cfg = $this->normalize($this->args);

    // 1) require (ALL)
    foreach ($cfg['require'] as $k) {
      $v = $this->getDot($s, $k);
      if (!$this->truthy($v)) {
        return $this->deny($request, $response, $s, $cfg);
      }
    }

    // 2) any (AT LEAST ONE)
    if (!empty($cfg['any'])) {
      $okAny = false;
      foreach ($cfg['any'] as $k) {
        $v = $this->getDot($s, $k);
        if ($this->truthy($v)) { $okAny = true; break; }
      }
      if (!$okAny) return $this->deny($request, $response, $s, $cfg);
    }

    // 3) match (EQUALS / IN)
    foreach ($cfg['match'] as $k => $expected) {
      $v = $this->getDot($s, (string)$k);
      if (!$this->matches($v, $expected)) {
        return $this->deny($request, $response, $s, $cfg);
      }
    }

    return null;
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }

  // =========================
  // Helpers
  // =========================

  private function normalize(array $cfg): array
  {
    // Compat: si viene como ['key'=>'user']
    if (isset($cfg['key']) && !isset($cfg['require'])) {
      $cfg['require'] = $cfg['key'];
    }

    $require = $cfg['require'] ?? [];
    $any     = $cfg['any'] ?? [];
    $match   = $cfg['match'] ?? [];

    // boolean guard true sin config => require user
    if ($require === [] && $any === [] && $match === [] && (isset($cfg['_implicit']) && $cfg['_implicit'] === true)) {
      $require = 'user';
    }

    $require = is_string($require) ? [$require] : (array)$require;
    $any     = is_string($any) ? [$any] : (array)$any;
    $match   = is_array($match) ? $match : [];

    $require = array_values(array_filter(array_map('strval', $require), fn($x) => trim($x) !== ''));
    $any     = array_values(array_filter(array_map('strval', $any), fn($x) => trim($x) !== ''));

    $redir = $cfg['redirect'] ?? null;
    if (!is_string($redir) || trim($redir) === '') $redir = '/';

    $remember = $cfg['remember'] ?? true;
    $remember = ($remember === true || $remember === 1 || $remember === '1');

    $intendedKey = $cfg['intended_key'] ?? '_qfw_intended';
    if (!is_string($intendedKey) || trim($intendedKey) === '') $intendedKey = '_qfw_intended';

    $status = (int)($cfg['status'] ?? 0);
    if ($status <= 0) $status = 401;

    $redirectStatus = (int)($cfg['redirect_status'] ?? 302);
    if ($redirectStatus < 300 || $redirectStatus > 399) $redirectStatus = 302;

    $message = $cfg['message'] ?? 'Acceso denegado';
    if (!is_string($message) || $message === '') $message = 'Acceso denegado';

    return [
      'require'  => $require,
      'any'      => $any,
      'match'    => $match,
      'redirect' => $redir,
      'remember' => $remember,
      'intended_key' => $intendedKey,
      'status'   => $status,
      'redirect_status' => $redirectStatus,
      'message'  => $message,
    ];
  }

  private function deny(Request $request, Response $response, Session $session, array $cfg): Response
  {
    // Si es JSON/API => responde JSON (no redirect)
    if ($request->wantsJson()) {
      return $response->json([
        'error'   => true,
        'status'  => $cfg['status'] ?? 401,
        'message' => $cfg['message'] ?? 'Acceso denegado',
      ], (int)($cfg['status'] ?? 401));
    }

    // Guarda intended URL para volver luego (solo GET)
    if (!empty($cfg['remember']) && strtoupper($request->method()) === 'GET') {
      $full = $this->fullUrl($request);
      // evita guardar el mismo login (si coincide con redirect exacto)
      $session->set((string)$cfg['intended_key'], $full);
    }

    $redir = (string)($cfg['redirect'] ?? '/');
    $redir = trim($redir);

    // @routeName => route_url()
    if ($redir !== '' && $redir[0] === '@') {
      $name = substr($redir, 1);
      try {
        $redir = route_url($name ?: 'home');
      } catch (\Throwable $e) {
        $redir = base_url('/');
      }
    } else {
      $redir = base_url($redir === '' ? '/' : $redir);
    }

    return $response->redirect($redir, (int)($cfg['redirect_status'] ?? 302));
  }

  private function fullUrl(Request $request): string
  {
    $uri = $_SERVER['REQUEST_URI'] ?? $request->path();
    if (!is_string($uri) || $uri === '') $uri = $request->path();
    // Normaliza con base_url
    return base_url($uri[0] === '/' ? $uri : '/' . $uri);
  }

  private function truthy(mixed $v): bool
  {
    if ($v === null) return false;
    if ($v === false) return false;
    if (is_string($v) && trim($v) === '') return false;
    if (is_array($v) && count($v) === 0) return false;
    return true;
  }

  private function matches(mixed $value, mixed $expected): bool
  {
    // expected: array => IN
    if (is_array($expected)) {
      foreach ($expected as $ev) {
        if ($this->matches($value, $ev)) return true;
      }
      return false;
    }

    if (is_bool($expected)) return (bool)$value === $expected;
    if (is_int($expected)) return (int)$value === $expected;
    if (is_float($expected)) return (float)$value === $expected;

    if (is_scalar($expected) && is_scalar($value)) {
      return (string)$value === (string)$expected;
    }

    return $value == $expected;
  }

  /**
   * Dot-notation: "user.role" => session('user')['role']
   */
  private function getDot(Session $s, string $key): mixed
  {
    $key = trim($key);
    if ($key === '') return null;

    if (!str_contains($key, '.')) {
      return $s->get($key);
    }

    $parts = explode('.', $key);
    $base = array_shift($parts);
    $cur = $s->get((string)$base);

    foreach ($parts as $p) {
      if (is_array($cur)) {
        $cur = $cur[$p] ?? null;
        continue;
      }
      if (is_object($cur)) {
        $cur = $cur->{$p} ?? null;
        continue;
      }
      return null;
    }

    return $cur;
  }
}
