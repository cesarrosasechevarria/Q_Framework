<?php
declare(strict_types=1);

namespace System\Filters;

use System\Core\Csrf;
use System\Core\FilterInterface;
use System\Core\HttpException;
use System\Core\Request;
use System\Core\Response;

/**
 * CsrfFilter (PRO)
 * - Valida CSRF en métodos inseguros
 * - Storage configurable: cookie (recomendado) o session
 */
final class CsrfFilter implements FilterInterface
{
  public function before(Request $request, Response $response): ?Response
  {
    if (!Csrf::enabled()) return null;

    $m = $request->method();

    // Métodos seguros: no validar
    if (in_array($m, ['GET','HEAD','OPTIONS'], true)) {
      return null;
    }

    $incoming = Csrf::fromRequest();
    if ($incoming === '' || !Csrf::verify($incoming)) {
      // Deja que el handler global devuelva HTML o JSON según Accept
      throw new HttpException(419, $incoming === '' ? 'CSRF token missing' : 'CSRF token mismatch');
    }

    // Rotate (opcional)
    if (Csrf::rotate()) {
      Csrf::regenerate();
    }

    return null;
  }

  public function after(Request $request, Response $response): ?Response
  {
    if (!Csrf::enabled()) return null;

    // Para frontend AJAX/API: devolvemos token actual para refrescar metas sin recargar.
    // Esto ayuda especialmente si csrfRotate=true.
    if ($request->wantsJson()) {
      $tok = Csrf::token();
      if ($tok !== '') {
        $response->header(Csrf::headerName(), $tok);
        $response->header('X-CSRF-KEY', Csrf::key());
        $response->header('X-CSRF-HEADER', Csrf::headerName());
      }
    }

    return null;
  }

}
