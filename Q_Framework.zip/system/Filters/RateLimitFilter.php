<?php
declare(strict_types=1);

namespace System\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;

/**
 * RateLimitFilter (PRO)
 *
 * Uso:
 *  - En rutas: ['filters' => ['rate:max=60&decay=60&by=ip&prefix=rl:api']]
 *
 * Parámetros:
 *  - max     : int (máximo de hits)
 *  - decay   : int (ventana en segundos)
 *  - by      : ip|path|ip_path|token|ip_token (default: ip)
 *  - prefix  : string (default: rl:rate)
 *  - message : string (opcional, soporta {wait})
 *
 * Respuesta:
 *  - API/AJAX => JSON 429 + Retry-After
 *  - Web      => HTML simple 429
 */
final class RateLimitFilter implements FilterInterface
{
  private array $args = [];

  public function setArgs(array $args): void { $this->args = $args; }

  public function before(Request $request, Response $response): ?Response
  {
    $sec = config('Security');

    $max    = (int)($this->args['max']   ?? (int)($sec->apiMaxAttempts ?? 120));
    $decay  = (int)($this->args['decay'] ?? (int)($sec->apiDecaySeconds ?? 60));
    $by     = (string)($this->args['by'] ?? 'ip');
    $prefix = (string)($this->args['prefix'] ?? ($sec->apiRatePrefix ?? 'rl:api'));
    $msgTpl = (string)($this->args['message'] ?? 'Demasiadas solicitudes. Intenta nuevamente en {wait}s.');

    if ($max <= 0) $max = 120;
    if ($decay <= 0) $decay = 60;
    if ($prefix === '') $prefix = 'rl:rate';

    $ip    = $request->ip();
    $path  = $request->path();
    $token = (string)($_SERVER['QFW_API_TOKEN'] ?? '');

    $keyParts = [];
    switch (strtolower($by)) {
      case 'path':     $keyParts = [$path]; break;
      case 'ip_path':  $keyParts = [$ip, $path]; break;
      case 'token':    $keyParts = [$token ?: 'no_token']; break;
      case 'ip_token': $keyParts = [$ip, $token ?: 'no_token']; break;
      case 'ip':
      default:         $keyParts = [$ip]; break;
    }

    $key = rtrim($prefix, ':') . ':' . implode(':', array_map('strval', $keyParts));

    $lim = service('ratelimiter');
    $st = $lim->attempt($key, $max, $decay);

    if ($st['ok']) return null;

    $wait = (int)($st['wait'] ?? 1);
    $msg  = str_replace('{wait}', (string)$wait, $msgTpl);

    $response->header('Retry-After', (string)$wait);

    if ($request->wantsJson()) {
      return $response->json([
        'status' => 429,
        'error' => true,
        'message' => $msg,
        'retry_after' => $wait,
        'limit' => $max,
        'window' => $decay,
      ], 429);
    }

    return $response->setStatus(429)->html(
      '<h1>429 - Too Many Requests</h1><p>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</p>'
    );
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }
}
