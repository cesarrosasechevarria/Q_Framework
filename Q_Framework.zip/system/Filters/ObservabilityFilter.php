<?php
declare(strict_types=1);

namespace System\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;
use System\Core\Tenant;
use System\Core\Logger;
use System\Observability\Context;
use System\Observability\Tracer;
use System\Observability\Metrics;

final class ObservabilityFilter implements FilterInterface
{
  public function before(Request $request, Response $response): ?Response
  {
    $cfg = \config('Observability');
    if (empty($cfg->enabled)) {
      return null;
    }

    $tenant = Tenant::id();
    $rid = $request->header('X-Request-Id');
    $tp = $request->header((string)($cfg->traceHeader ?? 'traceparent'));

    Context::init(
      tenant: $tenant,
      requestId: is_string($rid) ? trim($rid) : null,
      traceparent: is_string($tp) ? trim($tp) : null
    );

    if (!empty($cfg->logEnabled)) {
      Logger::info('request.start', [
        'method' => $request->method(),
        'path'   => $request->path(),
        'ip'     => $request->ip(),
        'ua'     => $request->userAgent(),
      ]);
    }

    return null;
  }

  public function after(Request $request, Response $response): ?Response
  {
    $cfg = \config('Observability');
    if (empty($cfg->enabled)) {
      return $response;
    }

    // Propaga IDs
    $response->header('X-Request-Id', Context::requestId());
    if (!empty($cfg->tracingEnabled)) {
      $response->header((string)($cfg->traceHeader ?? 'traceparent'), Context::traceparent());
    }

    $dur = Context::elapsedSeconds();
    $status = $response->status();

    if (!empty($cfg->metricsEnabled)) {
      Metrics::observeHttp($request->method(), $request->path(), $status, $dur);
    }

    if (!empty($cfg->logEnabled)) {
      Logger::info('request.end', [
        'method' => $request->method(),
        'path'   => $request->path(),
        'status' => $status,
        'dur_ms' => round($dur * 1000, 3),
      ]);
    }

    return $response;
  }
}
