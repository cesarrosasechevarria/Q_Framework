<?php
declare(strict_types=1);

namespace System\Observability;

use System\Core\Tenant;
use System\Core\Providers;
use System\Cache\RedisClient;

/**
 * Metrics (Prometheus)
 *
 * Driver:
 * - file  (por defecto): write/metrics[/<tenant>]/metrics.json con lock de archivo
 * - redis (PRO): guarda el mismo JSON en Redis (aproximado bajo alta concurrencia)
 *
 * Config:
 * - app/Config/Observability.php (OBS_METRICS_DRIVER, OBS_METRICS_ENABLED, OBS_METRICS_ROUTE, etc.)
 * - app/Providers/InfraServiceProvider.php registra el cliente Redis compartido (id: 'redis')
 */
final class Metrics
{
  private static function driver(): string
  {
    $cfg = \config('Observability');
    $d = strtolower((string)($cfg->metricsDriver ?? 'file'));
    return ($d === 'redis') ? 'redis' : 'file';
  }

  private static function file(): string
  {
    $cfg = \config('Observability');

    // Permite override por config/env: OBS_METRICS_PATH (relativo o absoluto)
    $path = (string)($cfg->metricsPath ?? '');
    $path = trim($path);

    if ($path === '') {
      $dir = Tenant::writePath('metrics');
    } else {
      $isAbs = str_starts_with($path, '/') || preg_match('/^[A-Za-z]:\\\\/', $path);
      $base = $isAbs ? $path : base_path($path);

      // Si multi-tenant está activo, separar por tenant para evitar colisiones
      $tenCfg = \config('Tenancy');
      if (!empty($tenCfg->enabled)) {
        $base = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . Tenant::id();
      }
      $dir = $base;
    }

    @mkdir($dir, 0775, true);
    return rtrim($dir, '/\\') . '/metrics.json';
  }

  private static function redis(): ?RedisClient
  {
    try {
      $c = Providers::container();
      if ($c->has('redis')) {
        $r = $c->get('redis');
        return ($r instanceof RedisClient) ? $r : null;
      }
    } catch (\Throwable $e) {
      // ignore
    }
    return null;
  }

  private static function redisKey(): string
  {
    $cache = \config('Cache');
    $tid = Tenant::id();
    $prefix = (string)($cache->prefix ?? 'qfw');
    $prefix = rtrim($prefix, ':') . ':' . $tid . ':';
    return $prefix . '__metrics__';
  }

  private static function readData(): array
  {
    $driver = self::driver();

    if ($driver === 'redis') {
      $r = self::redis();
      if ($r) {
        $raw = $r->get(self::redisKey());
        $data = is_string($raw) && trim($raw) !== '' ? json_decode($raw, true) : null;
        return is_array($data) ? $data : ['counters'=>[], 'hist'=>[]];
      }
      // fallback: si no hay redis disponible, no romper (usa file)
      $driver = 'file';
    }

    $file = self::file();
    $raw = @file_get_contents($file);
    $data = is_string($raw) && trim($raw) !== '' ? json_decode($raw, true) : null;
    return is_array($data) ? $data : ['counters'=>[], 'hist'=>[]];
  }

  private static function writeData(array $data): void
  {
    $driver = self::driver();

    if ($driver === 'redis') {
      $r = self::redis();
      if ($r) {
        $r->set(self::redisKey(), json_encode($data, JSON_UNESCAPED_SLASHES));
        return;
      }
      $driver = 'file';
    }

    $file = self::file();
    @file_put_contents($file, json_encode($data, JSON_UNESCAPED_SLASHES));
  }

  public static function observeHttp(string $method, string $path, int $status, float $durationSeconds): void
  {
    $cfg = \config('Observability');
    if (empty($cfg->metricsEnabled)) return;

    $path = self::normalizePath($path);
    $tenant = Tenant::id();

    // ===========================
    // Driver redis (PRO)
    // ===========================
    if (self::driver() === 'redis') {
      $r = self::redis();
      if ($r) {
        $data = self::readData();

        $keyC = "method=$method|path=$path|status=$status|tenant=$tenant";
        $data['counters']['http_requests_total'][$keyC] = (int)($data['counters']['http_requests_total'][$keyC] ?? 0) + 1;

        $buckets = [0.05,0.1,0.25,0.5,1,2.5,5,10];
        $hKey = "method=$method|path=$path|tenant=$tenant";
        $h = $data['hist']['http_request_duration_seconds'][$hKey] ?? ['count'=>0,'sum'=>0,'buckets'=>[]];
        $h['count'] = (int)$h['count'] + 1;
        $h['sum'] = (float)$h['sum'] + (float)$durationSeconds;
        foreach ($buckets as $b) {
          $bk = (string)$b;
          $h['buckets'][$bk] = (int)($h['buckets'][$bk] ?? 0) + (($durationSeconds <= $b) ? 1 : 0);
        }
        $h['buckets']['+Inf'] = (int)($h['buckets']['+Inf'] ?? 0) + 1;
        $data['hist']['http_request_duration_seconds'][$hKey] = $h;

        self::writeData($data);
        return;
      }
      // si no hay redis, cae a file (no rompe)
    }

    // ===========================
    // Driver file (default)
    // ===========================
    $file = self::file();
    $fh = @fopen($file, 'c+');
    if (!$fh) return;

    @flock($fh, LOCK_EX);
    $raw = stream_get_contents($fh);
    $data = is_string($raw) && trim($raw) !== '' ? json_decode($raw, true) : null;
    if (!is_array($data)) $data = ['counters'=>[], 'hist'=>[]];

    $keyC = "method=$method|path=$path|status=$status|tenant=$tenant";
    $data['counters']['http_requests_total'][$keyC] = (int)($data['counters']['http_requests_total'][$keyC] ?? 0) + 1;

    $buckets = [0.05,0.1,0.25,0.5,1,2.5,5,10];
    $hKey = "method=$method|path=$path|tenant=$tenant";
    $h = $data['hist']['http_request_duration_seconds'][$hKey] ?? ['count'=>0,'sum'=>0,'buckets'=>[]];
    $h['count'] = (int)$h['count'] + 1;
    $h['sum'] = (float)$h['sum'] + (float)$durationSeconds;
    foreach ($buckets as $b) {
      $bk = (string)$b;
      $h['buckets'][$bk] = (int)($h['buckets'][$bk] ?? 0) + (($durationSeconds <= $b) ? 1 : 0);
    }
    $h['buckets']['+Inf'] = (int)($h['buckets']['+Inf'] ?? 0) + 1;
    $data['hist']['http_request_duration_seconds'][$hKey] = $h;

    // write back
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($data, JSON_UNESCAPED_SLASHES));
    fflush($fh);
    @flock($fh, LOCK_UN);
    fclose($fh);
  }

  public static function renderPrometheus(): string
  {
    $data = self::readData();

    $out = [];
    // Counters
    $out[] = "# TYPE http_requests_total counter";
    foreach (($data['counters']['http_requests_total'] ?? []) as $k => $v) {
      $labels = self::labels($k);
      $out[] = "http_requests_total{$labels} " . (int)$v;
    }

    // Histogram
    $out[] = "# TYPE http_request_duration_seconds histogram";
    foreach (($data['hist']['http_request_duration_seconds'] ?? []) as $k => $h) {
      $labelsBase = self::labels($k);
      $b = (array)($h['buckets'] ?? []);

      // Convert to cumulative in ascending order.
      $order = [];
      foreach ($b as $le => $_) {
        if ($le === '+Inf') continue;
        $order[] = (float)$le;
      }
      sort($order);

      $cum = 0;
      foreach ($order as $leF) {
        $le = (string)$leF;
        $cum += (int)($b[$le] ?? 0);
        $lb = self::addLabel($labelsBase, 'le', $le);
        $out[] = "http_request_duration_seconds_bucket" . $lb . " " . $cum;
      }

      $cumInf = (int)($h['count'] ?? 0);
      $lbInf = self::addLabel($labelsBase, 'le', '+Inf');
      $out[] = "http_request_duration_seconds_bucket" . $lbInf . " " . $cumInf;
      $out[] = "http_request_duration_seconds_sum{$labelsBase} " . (float)($h['sum'] ?? 0);
      $out[] = "http_request_duration_seconds_count{$labelsBase} " . (int)($h['count'] ?? 0);
    }

    return implode("\n", $out) . "\n";
  }

  private static function labels(string $packed): string
  {
    $pairs = explode('|', $packed);
    $lab = [];
    foreach ($pairs as $p) {
      if ($p === '' || !str_contains($p,'=')) continue;
      [$k,$v] = explode('=', $p, 2);
      $k = trim($k); $v = trim($v);
      if ($k === '') continue;
      $v = str_replace('"', '\"', $v);
      $lab[] = $k . '="' . $v . '"';
    }
    return '{' . implode(',', $lab) . '}';
  }

  private static function addLabel(string $labels, string $k, string $v): string
  {
    $labels = trim($labels);
    if ($labels === '' || $labels[0] !== '{') return '{' . $k . '="' . str_replace('"','\"',$v) . '"}';
    $inner = trim($labels, '{}');
    $v = str_replace('"','\"',$v);
    if ($inner === '') return '{' . $k . '="' . $v . '"}';
    return '{' . $inner . ',' . $k . '="' . $v . '"}';
  }

  private static function normalizePath(string $path): string
  {
    $path = $path ?: '/';
    $path = preg_replace('#/+#', '/', $path) ?? $path;
    // reduce cardinality
    $path = preg_replace('#\b\d+\b#', '{id}', $path) ?? $path;
    $path = preg_replace('#\b[0-9a-f]{16,}\b#i', '{hex}', $path) ?? $path;
    return $path;
  }
}
