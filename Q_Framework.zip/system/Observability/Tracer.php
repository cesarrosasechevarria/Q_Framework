<?php
declare(strict_types=1);

namespace System\Observability;

final class Tracer
{
  public static function parseTraceparent(?string $h): array
  {
    if (!$h) return [null, null];
    $h = trim($h);
    if ($h === '') return [null, null];
    $parts = explode('-', $h);
    if (count($parts) < 4) return [null, null];
    $traceId = $parts[1] ?? '';
    $parent = $parts[2] ?? '';
    if (!preg_match('/^[0-9a-f]{32}$/i', $traceId)) return [null,null];
    if (!preg_match('/^[0-9a-f]{16}$/i', $parent)) return [null,null];
    return [strtolower($traceId), strtolower($parent)];
  }

  public static function newTraceId(): string
  {
    return bin2hex(random_bytes(16));
  }

  public static function newSpanId(): string
  {
    return bin2hex(random_bytes(8));
  }

  public static function buildTraceparent(string $traceId, string $spanId, string $flags='01'): string
  {
    return '00-' . strtolower($traceId) . '-' . strtolower($spanId) . '-' . $flags;
  }
}
