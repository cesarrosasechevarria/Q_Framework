<?php
declare(strict_types=1);

namespace System\Observability;

/**
 * Request context para Observabilidad.
 * - request_id: correlación
 * - trace_id/span_id + traceparent (W3C)
 * - tenant
 */
final class Context
{
  private static bool $inited = false;
  private static float $t0 = 0.0;

  private static string $requestId = '';
  private static string $traceId = '';
  private static string $spanId = '';
  private static string $traceparent = '';
  private static string $tenant = 'default';

  /**
   * Inicializa contexto (una vez por request).
   *
   * Soporta named arguments usados por el filtro:
   *   Context::init(tenant: 'acme', requestId: '...', traceparent: '00-...')
   */
  public static function init(
    string $tenant,
    ?string $requestId = null,
    ?string $traceparent = null,
    ?string $traceId = null,
    ?string $spanId = null
  ): void {
    if (self::$inited) return;
    self::$inited = true;
    self::$t0 = microtime(true);
    self::$tenant = $tenant;

    self::$requestId = self::sanitizeId($requestId) ?: self::uuid();

    $parentSpan = null;
    if ($traceId === null || $traceId === '') {
      [$tpTrace, $tpParent] = Tracer::parseTraceparent($traceparent);
      if ($tpTrace) {
        $traceId = $tpTrace;
        $parentSpan = $tpParent;
      }
    }

    self::$traceId = ($traceId && preg_match('/^[0-9a-f]{32}$/i', $traceId)) ? strtolower($traceId) : Tracer::newTraceId();
    self::$spanId  = ($spanId  && preg_match('/^[0-9a-f]{16}$/i', $spanId))  ? strtolower($spanId)  : Tracer::newSpanId();

    // traceparent saliente
    self::$traceparent = Tracer::buildTraceparent(self::$traceId, self::$spanId, '01');
  }

  public static function requestId(): string { return self::$requestId; }
  public static function traceId(): string { return self::$traceId; }
  public static function spanId(): string { return self::$spanId; }
  public static function tenant(): string { return self::$tenant; }
  public static function traceparent(): string { return self::$traceparent; }

  public static function startedAt(): float { return self::$t0; }

  public static function elapsed(): float
  {
    return self::$t0 > 0 ? (microtime(true) - self::$t0) : 0.0;
  }

  /** Alias usado por el filtro */
  public static function elapsedSeconds(): float
  {
    return self::elapsed();
  }

  public static function toArray(): array
  {
    if (!self::$inited) return [];
    return [
      'tenant' => self::$tenant,
      'request_id' => self::$requestId,
      'trace_id' => self::$traceId,
      'span_id' => self::$spanId,
      'traceparent' => self::$traceparent,
    ];
  }

  private static function sanitizeId(?string $v): string
  {
    if ($v === null) return '';
    $v = trim($v);
    if ($v === '' || strlen($v) > 128) return '';
    return (string)(preg_replace('/[^a-zA-Z0-9\-_:]/', '', $v) ?? '');
  }

  private static function uuid(): string
  {
    $b = random_bytes(16);
    $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
    $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
    $hex = bin2hex($b);
    return substr($hex,0,8).'-'.substr($hex,8,4).'-'.substr($hex,12,4).'-'.substr($hex,16,4).'-'.substr($hex,20,12);
  }
}
