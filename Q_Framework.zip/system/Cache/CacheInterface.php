<?php
declare(strict_types=1);

namespace System\Cache;

interface CacheInterface
{
  public function get(string $key, mixed $default = null): mixed;

  /**
   * Indica si existe una clave (y no está expirada).
   * Nota: si guardas explícitamente null como valor, se considera "no existe".
   */
  public function has(string $key): bool;

  public function set(string $key, mixed $value, int $ttlSeconds = 3600): bool;
  public function delete(string $key): bool;
  public function clear(): bool;
  public function remember(string $key, int $ttlSeconds, callable $fn): mixed;
}
