<?php
declare(strict_types=1);

namespace System\Cache;

/**
 * RedisClient: usa ext-redis si está disponible; si no, fallback RESP mínimo.
 * Soporta comandos: GET, SET, DEL, SCAN, AUTH, SELECT, PING
 */
final class RedisClient
{
  private ?\Redis $ext = null;
  private $sock = null;

  public function __construct(
    private string $host,
    private int $port,
    private float $timeout = 1.5,
    private bool $persistent = false,
    private string $auth = '',
    private int $db = 0,
  ) {}

  public function connect(): void
  {
    if (class_exists('Redis')) {
      $r = new \Redis();
      $ok = $this->persistent
        ? $r->pconnect($this->host, $this->port, $this->timeout)
        : $r->connect($this->host, $this->port, $this->timeout);
      if (!$ok) throw new \RuntimeException('Redis connect failed');
      if ($this->auth !== '') {
        if (!$r->auth($this->auth)) throw new \RuntimeException('Redis auth failed');
      }
      if ($this->db > 0) {
        if (!$r->select($this->db)) throw new \RuntimeException('Redis select failed');
      }
      $this->ext = $r;
      return;
    }

    $errno = 0; $errstr = '';
    $this->sock = @fsockopen($this->host, $this->port, $errno, $errstr, $this->timeout);
    if (!$this->sock) {
      throw new \RuntimeException('Redis socket connect failed: ' . $errstr);
    }
    stream_set_timeout($this->sock, (int)$this->timeout, (int)(($this->timeout - (int)$this->timeout) * 1e6));

    if ($this->auth !== '') {
      $this->raw(['AUTH', $this->auth]);
    }
    if ($this->db > 0) {
      $this->raw(['SELECT', (string)$this->db]);
    }
  }

  public function ping(): bool
  {
    $r = $this->raw(['PING']);
    return $r === 'PONG' || $r === true;
  }

  public function get(string $key): ?string
  {
    $r = $this->raw(['GET', $key]);
    if ($r === null || $r === false) return null;
    return is_string($r) ? $r : null;
  }

  public function set(string $key, string $value, int $ttl = 0): bool
  {
    if ($ttl > 0) {
      $r = $this->raw(['SET', $key, $value, 'EX', (string)$ttl]);
    } else {
      $r = $this->raw(['SET', $key, $value]);
    }
    return $r === 'OK' || $r === true;
  }

  public function del(string $key): bool
  {
    $r = $this->raw(['DEL', $key]);
    return is_int($r) ? ($r >= 0) : (bool)$r;
  }

  /** @return array{0:string,1:array<int,string>} */
  public function scan(string $cursor, string $match, int $count = 200): array
  {
    $r = $this->raw(['SCAN', $cursor, 'MATCH', $match, 'COUNT', (string)$count]);
    if (!is_array($r) || count($r) < 2) return ['0', []];
    $next = is_string($r[0] ?? '') ? $r[0] : '0';
    $keys = is_array($r[1] ?? null) ? $r[1] : [];
    $out = [];
    foreach ($keys as $k) {
      if (is_string($k)) $out[] = $k;
    }
    return [$next, $out];
  }

  // =========================
  // RESP helpers
  // =========================

  private function raw(array $parts)
  {
    if ($this->ext) {
      $cmd = array_shift($parts);
      if ($cmd === null) return null;
      return $this->ext->rawCommand($cmd, ...$parts);
    }
    if (!$this->sock) $this->connect();
    $payload = "*" . count($parts) . "\r\n";
    foreach ($parts as $p) {
      $p = (string)$p;
      $payload .= "$" . strlen($p) . "\r\n" . $p . "\r\n";
    }
    fwrite($this->sock, $payload);
    return $this->readResp();
  }

  private function readLine(): string
  {
    $line = fgets($this->sock);
    if ($line === false) throw new \RuntimeException('Redis read failed');
    return rtrim($line, "\r\n");
  }

  private function readResp()
  {
    $line = $this->readLine();
    if ($line === '') return '';
    $prefix = $line[0];
    $payload = substr($line, 1);

    switch ($prefix) {
      case '+':
        return $payload;
      case '-':
        throw new \RuntimeException('Redis error: ' . $payload);
      case ':':
        return (int)$payload;
      case '$':
        $len = (int)$payload;
        if ($len < 0) return null;
        $data = '';
        while (strlen($data) < $len) {
          $chunk = fread($this->sock, $len - strlen($data));
          if ($chunk === false || $chunk === '') break;
          $data .= $chunk;
        }
        // consume CRLF
        fread($this->sock, 2);
        return $data;
      case '*':
        $n = (int)$payload;
        if ($n < 0) return null;
        $arr = [];
        for ($i=0; $i<$n; $i++) {
          $arr[] = $this->readResp();
        }
        return $arr;
      default:
        return $line;
    }
  }
}
