<?php
declare(strict_types=1);

namespace System\Cache;

final class RedisCache implements CacheInterface
{
  private RedisClient $client;

  public function __construct(RedisClient $client, private string $prefix = '')
  {
    $this->client = $client;
    $this->client->connect();
  }

  private function k(string $key): string
  {
    $p = $this->prefix;
    return $p !== '' ? $p . $key : $key;
  }

  public function get(string $key, mixed $default = null): mixed
  {
    $raw = $this->client->get($this->k($key));
    if ($raw === null) return $default;
    if (str_starts_with($raw, 'php:')) {
      $v = @unserialize(substr($raw, 4));
      return $v === false && substr($raw, 4) !== 'b:0;' ? $default : $v;
    }
    if (str_starts_with($raw, 'json:')) {
      $v = json_decode(substr($raw, 5), true);
      return $v === null ? $default : $v;
    }
    return $raw;
  }

  public function has(string $key): bool
  {
    return $this->client->get($this->k($key)) !== null;
  }

  public function set(string $key, mixed $value, int $ttlSeconds = 3600): bool
  {
    // Guardamos siempre como php serialize (seguro para arrays/objetos simples)
    $raw = 'php:' . serialize($value);
    return $this->client->set($this->k($key), $raw, $ttlSeconds);
  }

  public function delete(string $key): bool
  {
    return $this->client->del($this->k($key));
  }

  public function clear(): bool
  {
    // Limpia SOLO el prefijo (tenant-safe)
    $prefix = $this->prefix;
    if ($prefix === '') {
      // sin prefijo, no hacemos flushall por seguridad
      return false;
    }
    $cursor = '0';
    $match = $prefix . '*';
    do {
      [$cursor, $keys] = $this->client->scan($cursor, $match, 500);
      foreach ($keys as $k) {
        $this->client->del($k);
      }
    } while ($cursor !== '0');
    return true;
  }

  public function remember(string $key, int $ttlSeconds, callable $fn): mixed
  {
    $v = $this->get($key, null);
    if ($v !== null) return $v;
    $v = $fn();
    $this->set($key, $v, $ttlSeconds);
    return $v;
  }
}
