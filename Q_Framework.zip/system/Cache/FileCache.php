<?php
declare(strict_types=1);

namespace System\Cache;

final class FileCache implements CacheInterface
{
  public function __construct(private string $dir)
  {
    @mkdir($this->dir, 0775, true);
  }

  private function path(string $key): string
  {
    $safe = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', $key);
    return rtrim($this->dir, '/\\') . DIRECTORY_SEPARATOR . $safe . '.cache.php';
  }

  public function get(string $key, mixed $default = null): mixed
  {
    $p = $this->path($key);
    if (!is_file($p)) return $default;

    $data = @include $p;
    if (!is_array($data)) return $default;

    $exp = (int)($data['exp'] ?? 0);
    if ($exp > 0 && $exp < time()) {
      @unlink($p);
      return $default;
    }

    return $data['val'] ?? $default;
  }

  public function has(string $key): bool
  {
    $p = $this->path($key);
    if (!is_file($p)) return false;

    $data = @include $p;
    if (!is_array($data)) return false;

    $exp = (int)($data['exp'] ?? 0);
    if ($exp > 0 && $exp < time()) {
      @unlink($p);
      return false;
    }

    return true;
  }

  public function set(string $key, mixed $value, int $ttlSeconds = 3600): bool
  {
    $p = $this->path($key);
    $exp = $ttlSeconds > 0 ? (time() + $ttlSeconds) : 0;

    $payload = var_export(['exp' => $exp, 'val' => $value], true);
    $php = "<?php\nreturn {$payload};\n";

    return (bool)@file_put_contents($p, $php, LOCK_EX);
  }

  public function delete(string $key): bool
  {
    $p = $this->path($key);
    return is_file($p) ? @unlink($p) : true;
  }

  public function clear(): bool
  {
    $ok = true;
    foreach (glob(rtrim($this->dir,'/\\') . DIRECTORY_SEPARATOR . '*.cache.php') ?: [] as $f) {
      $ok = $ok && @unlink($f);
    }
    return $ok;
  }

  public function remember(string $key, int $ttlSeconds, callable $fn): mixed
  {
    $v = $this->get($key, null);
    if ($v !== null) return $v;
    $v = $fn();
    $this->set($key, $v, $ttlSeconds);
    return $v;
  }
}
