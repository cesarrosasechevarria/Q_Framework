<?php
declare(strict_types=1);

namespace System\Cache;

/**
 * PairCode: patrón "código corto" -> "valor completo" con TTL.
 *
 * Útil para:
 * - Formularios dinámicos (token -> JSON de estructura)
 * - Enlaces temporales (token -> filtros, parámetros, payload)
 * - Evitar enviar payload grande al navegador
 *
 * Funciona con cualquier CacheInterface (File/Redis). Para producción se recomienda Redis.
 */
final class PairCode
{
  /**
   * Genera un código (url-safe) y guarda el valor bajo un namespace con TTL.
   * Retorna SOLO el código, para enviarlo al cliente.
   */
  public static function issue(
    CacheInterface $cache,
    mixed $value,
    int $ttlSeconds = 900,
    string $namespace = 'pair',
    int $randomBytes = 12
  ): string {
    $randomBytes = max(6, min(32, $randomBytes));
    $namespace = self::sanitizeNamespace($namespace);

    // Evita colisiones (muy improbable)
    for ($i = 0; $i < 5; $i++) {
      $code = self::token($randomBytes);
      $key = self::key($namespace, $code);
      if (!$cache->has($key)) {
        $cache->set($key, $value, $ttlSeconds);
        return $code;
      }
    }

    // Fallback extremo
    $code = self::token(18) . '-' . dechex(time());
    $cache->set(self::key($namespace, $code), $value, $ttlSeconds);
    return $code;
  }

  /** Lee sin borrar (multi-uso). */
  public static function get(CacheInterface $cache, string $code, string $namespace = 'pair', mixed $default = null): mixed
  {
    return $cache->get(self::key(self::sanitizeNamespace($namespace), $code), $default);
  }

  /** Lee y borra (single-use). */
  public static function pull(CacheInterface $cache, string $code, string $namespace = 'pair', mixed $default = null): mixed
  {
    $key = self::key(self::sanitizeNamespace($namespace), $code);
    $val = $cache->get($key, $default);
    $cache->delete($key);
    return $val;
  }

  public static function forget(CacheInterface $cache, string $code, string $namespace = 'pair'): bool
  {
    return $cache->delete(self::key(self::sanitizeNamespace($namespace), $code));
  }

  public static function key(string $namespace, string $code): string
  {
    $namespace = self::sanitizeNamespace($namespace);
    $code = trim($code);
    return 'pair:' . $namespace . ':' . $code;
  }

  private static function sanitizeNamespace(string $namespace): string
  {
    $namespace = strtolower(trim($namespace));
    $namespace = preg_replace('/[^a-z0-9_\-\.]/', '_', $namespace) ?? 'pair';
    return $namespace !== '' ? $namespace : 'pair';
  }

  /** Token url-safe (base64url, sin padding). */
  private static function token(int $bytes): string
  {
    $raw = random_bytes($bytes);
    return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
  }
}
