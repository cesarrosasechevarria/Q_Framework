<?php
declare(strict_types=1);

function paginate(int $total, int $perPage, int $page, string $pattern): \System\Core\Paginator
{
  return new \System\Core\Paginator($total, $perPage, $page, $pattern);
}
