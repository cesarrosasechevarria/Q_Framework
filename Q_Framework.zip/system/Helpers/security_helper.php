<?php
declare(strict_types=1);

function csrf_token(): string
{
  return \System\Core\Csrf::token();
}

function csrf_field(): string
{
  $sec = config('Security');
  if (empty($sec->csrfEnabled)) return '';

  $key = (string)($sec->csrfKey ?? '_token');
  $token = csrf_token();
  return '<input type="hidden" name="'.htmlspecialchars($key,ENT_QUOTES,'UTF-8').'" value="'.htmlspecialchars($token,ENT_QUOTES,'UTF-8').'">';
}

function csrf_key(): string
{
  return \System\Core\Csrf::key();
}

function csrf_header(): string
{
  return \System\Core\Csrf::headerName();
}

/**
 * Meta tags CSRF para frontend (AJAX/fetch).
 * Imprime:
 *  - <meta name="csrf-key" content="...">
 *  - <meta name="csrf-token" content="...">
 *  - <meta name="csrf-header" content="...">
 */
function csrf_meta(): string
{
  $sec = config('Security');
  if (empty($sec->csrfEnabled)) return '';

  $k = htmlspecialchars(csrf_key(), ENT_QUOTES, 'UTF-8');
  $t = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
  $h = htmlspecialchars(csrf_header(), ENT_QUOTES, 'UTF-8');

  return "<meta name=\"csrf-key\" content=\"{$k}\">\n"
       . "<meta name=\"csrf-token\" content=\"{$t}\">\n"
       . "<meta name=\"csrf-header\" content=\"{$h}\">\n";
}



function random_str(int $len = 32): string
{
  return \System\Core\Security::randomString($len);
}

function hash_password(string $plain): string
{
  return \System\Core\Security::hashPassword($plain);
}

function verify_password(string $plain, string $hash): bool
{
  return \System\Core\Security::verifyPassword($plain, $hash);
}

/**
 * Retorna el usuario autenticado sin iniciar sesión si no hay cookie.
 */
function auth_user(): ?array
{
  $s = session_optional();
  if (!$s) return null;
  $u = $s->get('user');
  return is_array($u) ? $u : null;
}


/**
 * CSP Nonce (si App::$CSPEnabled = true).
 * - Se genera una sola vez por request y se guarda en $GLOBALS['__qfw_csp_nonce'].
 * - Úsalo en vistas: <script <?= csp_attr() ?>> ... </script>
 */
function csp_nonce(): string
{
  return \System\Core\Csp::nonce();

}

function csp_attr(): string
{
  return \System\Core\Csp::attr();

}
