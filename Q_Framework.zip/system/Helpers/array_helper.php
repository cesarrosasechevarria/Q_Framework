<?php
declare(strict_types=1);

/**
 * Array Helper (System)
 * Utilidades comunes para arrays (dot notation).
 */

if (!function_exists('array_get')) {
  function array_get(array $array, string $key, $default = null)
  {
    if ($key === '') return $default;
    if (array_key_exists($key, $array)) return $array[$key];

    $segments = explode('.', $key);
    $cur = $array;
    foreach ($segments as $seg) {
      if (!is_array($cur) || !array_key_exists($seg, $cur)) return $default;
      $cur = $cur[$seg];
    }
    return $cur;
  }
}

if (!function_exists('array_has')) {
  function array_has(array $array, string $key): bool
  {
    return array_get($array, $key, '__qfw__missing__') !== '__qfw__missing__';
  }
}

if (!function_exists('array_set')) {
  function array_set(array &$array, string $key, $value): void
  {
    if ($key === '') return;

    $segments = explode('.', $key);
    $cur =& $array;
    foreach ($segments as $seg) {
      if (!is_array($cur)) $cur = [];
      if (!array_key_exists($seg, $cur) || !is_array($cur[$seg])) {
        $cur[$seg] = [];
      }
      $cur =& $cur[$seg];
    }
    $cur = $value;
  }
}

if (!function_exists('array_forget')) {
  function array_forget(array &$array, string $key): void
  {
    if ($key === '') return;

    $segments = explode('.', $key);
    $cur =& $array;
    while (count($segments) > 1) {
      $seg = array_shift($segments);
      if (!isset($cur[$seg]) || !is_array($cur[$seg])) return;
      $cur =& $cur[$seg];
    }
    $last = array_shift($segments);
    unset($cur[$last]);
  }
}
