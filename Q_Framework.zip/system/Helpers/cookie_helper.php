<?php
declare(strict_types=1);

function cookie_get(string $name, $default = null)
{
  return \System\Core\Cookie::get($name, $default);
}

function cookie_set(string $name, string $value, int $minutes = 0): void
{
  \System\Core\Cookie::set($name, $value, $minutes);
}

function cookie_delete(string $name): void
{
  \System\Core\Cookie::delete($name);
}
