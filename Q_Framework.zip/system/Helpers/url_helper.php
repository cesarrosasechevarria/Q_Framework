<?php
declare(strict_types=1);

/**
 * URL Helper (System)
 *
 * ⚡ En modo Lazy Load normalmente lo cargas cuando lo necesites:
 *   helper('url');  o  protected array $helpers = ['url'];
 *
 * Nota importante:
 * - En Q_Framework algunas funciones URL son CORE (siempre disponibles) para evitar errores comunes:
 *   - url(), base_url(), route(), route_url()
 * - Este helper agrega utilidades adicionales muy usadas en frameworks (CI/Laravel-like).
 */

if (!function_exists('site_url')) {
  /** Alias de base_url() para compatibilidad */
  function site_url(string $path = ''): string
  {
    return base_url($path);
  }
}

if (!function_exists('asset_url')) {
  /**
   * URL para assets (no fuerza indexPage).
   * Ej: asset_url('assets/app.css')
   */
  function asset_url(string $path = ''): string
  {
    return base_url($path);
  }
}

if (!function_exists('current_url')) {
  /** URL actual (absoluta) */
  function current_url(): string
  {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $uri    = $_SERVER['REQUEST_URI'] ?? '/';
    return $scheme . '://' . $host . $uri;
  }
}

if (!function_exists('previous_url')) {
  /** URL anterior (referer). Si no existe, retorna base_url($fallback). */
  function previous_url(string $fallback = '/'): string
  {
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    return $ref !== '' ? $ref : base_url($fallback);
  }
}

if (!function_exists('uri_string')) {
  /** URI string sin dominio, sin query, opcionalmente sin slashes */
  function uri_string(bool $trimSlashes = true): string
  {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($uri, PHP_URL_PATH) ?? '/';
    if ($trimSlashes) $path = trim($path, '/');
    return $path;
  }
}

if (!function_exists('url_is')) {
  /**
   * Compara el URI actual con un patrón (soporta *):
   *  url_is('admin/*'), url_is('login'), url_is('/')
   */
  function url_is(string $pattern): bool
  {
    $u = '/' . uri_string(true);
    if ($u === '//') $u = '/';
    $pattern = trim($pattern);
    if ($pattern === '') return false;
    if ($pattern[0] !== '/') $pattern = '/' . $pattern;
    $pattern = rtrim($pattern, '/');
    if ($pattern === '') $pattern = '/';

    // wildcard
    $regex = '#^' . str_replace(['\*', '\/'], ['.*', '/'], preg_quote($pattern, '#')) . '$#';
    return (bool)preg_match($regex, rtrim($u, '/')) || (bool)preg_match($regex, $u);
  }
}

if (!function_exists('prep_url')) {
  /** Asegura que la URL tenga scheme. */
  function prep_url(string $url): string
  {
    $url = trim($url);
    if ($url === '') return '';
    if (preg_match('#^https?://#i', $url)) return $url;
    return 'http://' . $url;
  }
}

if (!function_exists('anchor')) {
  /**
   * Genera un <a> seguro.
   * anchor('docs', 'Docs', ['class'=>'btn'])
   */
  function anchor(string $href, string $title = '', array $attrs = []): string
  {
    $href = str_starts_with($href, 'http') ? $href : base_url($href);
    $title = $title !== '' ? $title : $href;

    $a = '';
    foreach ($attrs as $k => $v) {
      $k = preg_replace('/[^a-zA-Z0-9_\-:]/', '', (string)$k);
      $a .= ' ' . $k . '="' . e((string)$v) . '"';
    }

    return '<a href="' . e($href) . '"' . $a . '>' . e($title) . '</a>';
  }
}

if (!function_exists('add_query')) {
  /** Agrega/actualiza parámetros de query en una URL */
  function add_query(string $url, array $params): string
  {
    $parts = parse_url($url);
    if (!$parts) return $url;

    $query = [];
    if (!empty($parts['query'])) parse_str($parts['query'], $query);
    $query = array_merge($query, $params);

    $parts['query'] = http_build_query($query);
    return build_url($parts);
  }
}

if (!function_exists('remove_query')) {
  /** Remueve claves de query de una URL */
  function remove_query(string $url, array $keys): string
  {
    $parts = parse_url($url);
    if (!$parts) return $url;

    $query = [];
    if (!empty($parts['query'])) parse_str($parts['query'], $query);
    foreach ($keys as $k) unset($query[$k]);

    $parts['query'] = $query ? http_build_query($query) : '';
    return build_url($parts);
  }
}

if (!function_exists('build_url')) {
  /** Reconstruye una URL desde parse_url() */
  function build_url(array $p): string
  {
    $scheme   = isset($p['scheme']) ? $p['scheme'] . '://' : '';
    $user     = $p['user'] ?? '';
    $pass     = isset($p['pass']) ? ':' . $p['pass']  : '';
    $auth     = ($user || $pass) ? "$user$pass@" : '';
    $host     = $p['host'] ?? '';
    $port     = isset($p['port']) ? ':' . $p['port'] : '';
    $path     = $p['path'] ?? '';
    $query    = isset($p['query']) && $p['query'] !== '' ? '?' . $p['query'] : '';
    $fragment = isset($p['fragment']) ? '#' . $p['fragment'] : '';
    return "$scheme$auth$host$port$path$query$fragment";
  }
}

if (!function_exists('redirect')) {
  /** Redirección simple */
  function redirect(string $to, int $status = 302): never
  {
    header('Location: ' . $to, true, $status);
    exit;
  }
}
