<?php
declare(strict_types=1);

/** Retorna el timezone configurado en Config\App */
function app_timezone(): string
{
  $cfg = config('App');
  return (string)($cfg->appTimezone ?? 'UTC');
}

/** Retorna el locale configurado (o negociado) */
function app_locale(): string
{
  // Si Request ya lo resolvió, úsalo
  if (isset($GLOBALS['__qfw_locale']) && is_string($GLOBALS['__qfw_locale']) && $GLOBALS['__qfw_locale'] !== '') {
    return $GLOBALS['__qfw_locale'];
  }
  $cfg = config('App');
  return (string)($cfg->defaultLocale ?? 'en');
}
