<?php
declare(strict_types=1);

/**
 * Helper de vistas (opcional).
 * Nota: e()/esc() ya están definidas en system/Support/Functions.php (core),
 * pero dejamos fallback por compatibilidad si alguien las elimina.
 */

if (!function_exists('esc')) {
  function esc(mixed $value, string $context = 'html', bool $doubleEncode = true): string
  {
    if ($value === null) return '';
    if (is_array($value) || is_object($value)) {
      $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }
    $str = (string)$value;

    $ctx = strtolower(trim($context));
    switch ($ctx) {
      case 'url':
        return str_replace('%2F','/', rawurlencode($str));
      case 'js':
        return json_encode($str, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
      case 'css':
        $str = preg_replace('/[\x00-\x1F\x7F]/u', '', $str) ?? '';
        return $str;
      case 'attr':
      case 'html':
      default:
        return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', $doubleEncode);
    }
  }
}

if (!function_exists('e')) {
  function e(mixed $value): string
  {
    return esc($value, 'html', true);
  }
}
