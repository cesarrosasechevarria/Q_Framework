<?php
declare(strict_types=1);

/**
 * Text Helper (System)
 * Utilidades comunes para strings.
 */

if (!function_exists('str_limit')) {
  function str_limit(string $text, int $limit = 100, string $end = '...'): string
  {
    $text = trim($text);
    if ($limit <= 0) return '';
    if (mb_strlen($text, 'UTF-8') <= $limit) return $text;
    return rtrim(mb_substr($text, 0, $limit, 'UTF-8')) . $end;
  }
}

if (!function_exists('word_limiter')) {
  function word_limiter(string $text, int $limit = 40, string $end = '...'): string
  {
    $text = trim(preg_replace('/\s+/u', ' ', $text) ?? '');
    if ($text === '') return '';
    $words = preg_split('/\s+/u', $text) ?: [];
    if (count($words) <= $limit) return $text;
    return implode(' ', array_slice($words, 0, $limit)) . $end;
  }
}

if (!function_exists('slugify')) {
  function slugify(string $text, string $sep = '-'): string
  {
    $text = trim($text);
    if ($text === '') return '';
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text) ?: $text;
    $text = strtolower($text);
    $text = preg_replace('/[^a-z0-9]+/', $sep, $text) ?? '';
    $text = trim($text, $sep);
    return $text;
  }
}
