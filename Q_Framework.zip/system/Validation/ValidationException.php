<?php
declare(strict_types=1);

namespace System\Validation;

use System\Core\HttpException;

/**
 * ValidationException: status 422 con errores de validación.
 */
class ValidationException extends HttpException
{
    public array $errors;

    public function __construct(array $errors, string $message = 'Validación fallida')
    {
        $this->errors = $errors;
        parent::__construct(422, $message, ['errors' => $errors], []);
    }
}
