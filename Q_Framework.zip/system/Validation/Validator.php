<?php
declare(strict_types=1);

namespace System\Validation;

/**
 * Validator (simple pero PRO)
 *
 * - Reglas con pipe: "required|min:3|max:50|email"
 * - Reglas array: ['required','min:3']
 * - Errores por campo
 * - Mensajes por regla
 *
 * Reglas incluidas:
 * required, min, max, email, integer, numeric, in, regex, alpha_dash
 */
final class Validator
{
  /** @var array<string, callable> */
  private static array $extensions = [];

  /** @var array<string, string> */
  private static array $extensionMessages = [];

  /** Registra reglas personalizadas: Validator::extend('phone', fn($v,$arg,$data)=>true, 'Mensaje'); */
  public static function extend(string $rule, callable $fn, ?string $message = null): void
  {
    $rule = strtolower(trim($rule));
    if ($rule === '') return;
    self::$extensions[$rule] = $fn;
    if (is_string($message) && $message !== '') self::$extensionMessages[$rule] = $message;
  }


  /** @var array<string, string> */
  private array $messages = [];

  /** @var array<string, string[]> */
  private array $errors = [];

  public function __construct(array $messages = [])
  {
    $this->messages = $messages;
  }

  public function errors(): array
  {
    return $this->errors;
  }

  public function passes(array $data, array $rules, array $customMessages = []): bool
  {
    $this->errors = [];

    foreach ($rules as $field => $ruleDef) {
      $value = $data[$field] ?? null;

      $fieldRules = $this->normalizeRules($ruleDef);

      foreach ($fieldRules as $rule) {
        [$name, $arg] = $this->parseRule($rule);

        $ok = $this->applyRule($name, $value, $arg, $data);

        if (!$ok) {
          $msg = $this->messageFor($field, $name, $customMessages);
          $msg = str_replace(['{field}','{arg}'], [$field, (string)$arg], $msg);
          $this->errors[$field][] = $msg;
        }
      }
    }

    return empty($this->errors);
  }

  private function normalizeRules(mixed $ruleDef): array
  {
    if (is_string($ruleDef)) {
      $parts = array_map('trim', explode('|', $ruleDef));
      return array_values(array_filter($parts, fn($x) => $x !== ''));
    }

    if (is_array($ruleDef)) {
      return array_values(array_filter(array_map('trim', array_map('strval', $ruleDef))));
    }

    return [];
  }

  private function parseRule(string $rule): array
  {
    $rule = trim($rule);
    if ($rule === '') return ['', null];

    // Soporta estilo CI4: rule[param]
    if (preg_match('/^([A-Za-z0-9_]+)\[(.*)\]$/', $rule, $m)) {
      return [strtolower(trim($m[1])), (string)$m[2]];
    }

    // Estilo: rule:param
    if (str_contains($rule, ':')) {
      [$name, $arg] = explode(':', $rule, 2);
      return [strtolower(trim($name)), trim($arg)];
    }

    return [strtolower($rule), null];
  }

  private function messageFor(string $field, string $rule, array $custom): string
  {
    // custom: field.rule => msg
    $k = $field . '.' . $rule;
    if (isset($custom[$k])) return (string)$custom[$k];

    // custom: rule => msg
    if (isset($custom[$rule])) return (string)$custom[$rule];

    // base messages
    if (isset($this->messages[$k])) return $this->messages[$k];
    if (isset($this->messages[$rule])) return $this->messages[$rule];

    // mensajes por defecto de reglas extendidas
    if (isset(self::$extensionMessages[$rule])) return self::$extensionMessages[$rule];

    return 'El campo {field} no es válido (' . $rule . ').';
  }

  private function applyRule(string $rule, mixed $value, mixed $arg, array $data): bool
  {
    $rule = strtolower(trim($rule));

    // required: acepta "0" como valor válido
    if ($rule === 'required') {
      if ($value === null) return false;
      if (is_string($value) && trim($value) === '') return false;
      if (is_array($value) && count($value) === 0) return false;
      return true;
    }

    // si no es required y está vacío, no validar demás reglas
    if ($value === null || (is_string($value) && trim($value) === '')) return true;

    // Reglas personalizadas (extend)
    if (isset(self::$extensions[$rule])) {
      try {
        return (bool) call_user_func(self::$extensions[$rule], $value, $arg, $data);
      } catch (\Throwable $e) {
        return false;
      }
    }

    $s = is_scalar($value) ? (string)$value : '';
    $len = function(string $x): int {
      return function_exists('mb_strlen') ? mb_strlen($x, 'UTF-8') : strlen($x);
    };

    return match ($rule) {
      'min' => $len($s) >= (int)$arg,
      'max' => $len($s) <= (int)$arg,
      'email' => (bool)filter_var($s, FILTER_VALIDATE_EMAIL),
      'integer' => (bool)preg_match('/^-?\d+$/', $s),
      'numeric' => is_numeric($s),
      'in' => in_array($s, array_map('trim', explode(',', (string)$arg)), true),
      'regex' => @preg_match((string)$arg, $s) === 1,
      'alpha_dash' => (bool)preg_match('/^[a-zA-Z0-9_\-]+$/', $s),
      default => true,
    };
  }
}
