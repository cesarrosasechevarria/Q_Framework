<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Minimal DotEnv loader (compatible)
 * Reglas PRO:
 * - Ignora líneas vacías/comentarios
 * - Soporta KEY=VALUE con comillas
 * - Si una variable ya fue seteada con valor NO vacío, no la sobre-escribe con otra línea posterior vacía
 *   (protege contra duplicados accidentales en el .env).
 */
final class Env
{
  public static function load(string $path): void
  {
    if (!is_file($path)) return;

    $lines = file($path, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
      $line = trim((string)$line);
      if ($line === '' || str_starts_with($line, '#')) continue;
      if (!str_contains($line, '=')) continue;

      [$k, $v] = explode('=', $line, 2);
      $k = trim($k);
      $v = trim($v);

      // strip quotes
      $v = trim($v, "\"'");

      // Regla: no permitir que un duplicado vacío pise uno ya válido
      if (array_key_exists($k, $_ENV) && (string)($_ENV[$k] ?? '') !== '' && $v === '') {
        continue;
      }

      // Por compatibilidad, el último valor NO vacío puede sobre-escribir al anterior
      if (array_key_exists($k, $_ENV) && $v === '') continue;

      $_ENV[$k] = $v;
    }
  }
}
