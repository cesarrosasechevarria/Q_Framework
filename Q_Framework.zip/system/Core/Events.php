<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Events (Hook system)
 *
 * Objetivo:
 * - Permitir extensiones sin acoplar el kernel.
 * - Disparar eventos en puntos clave del ciclo: routing, controller, response.
 *
 * Uso:
 *   Events::on('before.controller', function(array $ctx){ ... });
 *   Events::trigger('before.controller', ['class'=>$c,'method'=>$m]);
 *
 * En app:
 *   app/Config/Events.php devuelve un array con listeners.
 */
final class Events
{
  /** @var array<string, array<int, array{priority:int, fn:callable}>> */
  private static array $listeners = [];

  private static bool $booted = false;

  public static function boot(): void
  {
    if (self::$booted) return;
    self::$booted = true;

    $file = base_path('app/Config/Events.php');
    if (!is_file($file)) return;

    $cfg = require $file;
    if (!is_array($cfg)) return;

    foreach ($cfg as $event => $list) {
      if (!is_array($list)) continue;
      foreach ($list as $def) {
        $fn = $def['fn'] ?? null;
        $priority = (int)($def['priority'] ?? 0);

        if (is_string($fn) && class_exists($fn)) {
          // Listener como clase invocable: __invoke($payload)
          $obj = new $fn();
          if (is_callable($obj)) self::on((string)$event, $obj, $priority);
          continue;
        }

        if (is_callable($fn)) {
          self::on((string)$event, $fn, $priority);
        }
      }
    }
  }

  public static function on(string $event, callable $fn, int $priority = 0): void
  {
    $event = strtolower(trim($event));
    if ($event === '') return;

    self::$listeners[$event] ??= [];
    self::$listeners[$event][] = ['priority' => $priority, 'fn' => $fn];

    // Ordena por prioridad DESC
    usort(self::$listeners[$event], fn($a,$b) => ($b['priority'] <=> $a['priority']));
  }

  public static function trigger(string $event, mixed $payload = null): void
  {
    $event = strtolower(trim($event));
    if ($event === '') return;

    if (!self::$booted) self::boot();

    foreach (self::$listeners[$event] ?? [] as $item) {
      try {
        ($item['fn'])($payload);
      } catch (\Throwable $e) {
        // Nunca romper el request por un listener, pero loguea en dev.
        Logger::error('Event listener error: ' . $event, [
          'message' => $e->getMessage(),
          'file' => $e->getFile(),
          'line' => $e->getLine(),
        ]);
      }
    }
  }
}
