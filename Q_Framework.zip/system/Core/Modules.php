<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Module Manager (v8)
 *
 * Objetivo:
 * - Permitir paquetes/modulos sin ensuciar app.
 * - Cada modulo vive en: app/Modules/<NombreModulo>/
 *
 * Estructura recomendada:
 * app/Modules/Blog/
 *   Controllers/
 *   Views/
 *   Routes.php          (retorna callable(RouteCollection $routes))
 *   Module.php          (opcional: metadata)
 *   Database/Migrations (opcional)
 *   Language/es/*.php   (opcional)
 */
final class Modules
{
  /** @var array<int,string>|null */
  private static ?array $enabled = null;

  public static function enabled(): array
  {
    if (self::$enabled !== null) return self::$enabled;

    $cfg = config('Modules');
    $path = (string)($cfg->path ?? 'app/Modules');
    $abs  = base_path($path);

    $enabled = (array)($cfg->enabled ?? []);
    $enabled = array_values(array_filter(array_map('strval', $enabled)));

    $auto = !empty($cfg->autoDiscover);

    if ($auto && is_dir($abs)) {
      foreach (scandir($abs) ?: [] as $d) {
        if ($d === '.' || $d === '..') continue;
        if (!is_dir($abs . DIRECTORY_SEPARATOR . $d)) continue;
        if (!in_array($d, $enabled, true)) $enabled[] = $d;
      }
    }

    // Runtime toggles (plugins)
    if (!empty($cfg->runtimeToggle)) {
      $enabled = \System\Core\PluginManager::apply($enabled, $abs, $cfg);
    }

    self::$enabled = $enabled;
    return self::$enabled;
  }

  public static function routes(RouteCollection $routes): void
  {
    $cfg = config('Modules');
    $path = (string)($cfg->path ?? 'app/Modules');
    $abs  = base_path($path);

    foreach (self::enabled() as $mod) {
      $file = $abs . DIRECTORY_SEPARATOR . $mod . DIRECTORY_SEPARATOR . 'Routes.php';
      if (!is_file($file)) continue;

      $def = require $file;
      if (is_callable($def)) {
        $def($routes);
      }
    }
  }

  /** @return string[] directorios de vistas en orden */
  public static function viewPaths(): array
  {
    $cfg = config('Modules');
    $path = (string)($cfg->path ?? 'app/Modules');
    $abs  = base_path($path);

    $paths = [];
    foreach (self::enabled() as $mod) {
      $dir = $abs . DIRECTORY_SEPARATOR . $mod . DIRECTORY_SEPARATOR . 'Views';
      if (is_dir($dir)) $paths[] = $dir;
    }
    return $paths;
  }


  /** @return string[] directorios de migrations en orden */
  public static function migrationPaths(): array
  {
    $cfg = config('Modules');
    $path = (string)($cfg->path ?? 'app/Modules');
    $abs  = base_path($path);

    $paths = [];
    foreach (self::enabled() as $mod) {
      $dir = $abs . DIRECTORY_SEPARATOR . $mod . DIRECTORY_SEPARATOR . 'Database' . DIRECTORY_SEPARATOR . 'Migrations';
      if (is_dir($dir)) $paths[] = $dir;
    }
    return $paths;
  }
}
