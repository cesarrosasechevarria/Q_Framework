<?php
declare(strict_types=1);

namespace System\Core;

use System\Core\Debug\Toolbar;

final class Response
{
  private int $status = 200;

  private array $headers = [];
  private string $body = '';

  public function setStatus(int $code): self { $this->status = $code; return $this; }
  public function status(): int { return $this->status; }

  /** Devuelve el cuerpo tal como se enviará. */
  public function body(): string { return $this->body; }

  /** Reemplaza el cuerpo. */
  public function setBody(string $body): self { $this->body = $body; return $this; }

  /** Agrega al final del cuerpo (útil para debug/inyección). */
  public function appendBody(string $chunk): self { $this->body .= $chunk; return $this; }

  /** Headers actuales (normalizados en el array interno). */
  public function headers(): array { return $this->headers; }

  /** Obtiene header (case-insensitive). */
  public function getHeader(string $name): ?string
  {
    $name = strtolower(trim($name));
    foreach ($this->headers as $k => $v) {
      if (strtolower($k) === $name) return (string)$v;
    }
    return null;
  }

  /** Existe header (case-insensitive). */
  public function hasHeader(string $name): bool
  {
    return $this->getHeader($name) !== null;
  }

  /** Es redirección HTTP (Location header + status 3xx). */
  public function isRedirect(): bool
  {
    return ($this->status >= 300 && $this->status < 400) && $this->hasHeader('Location');
  }

  /** Set header (último gana). */
  public function header(string $k, string $v): self
  {
    $k = trim($k);
    $v = (string)$v;
    // Bloqueo simple contra CRLF injection
    if ($k === '' || preg_match('/[\r\n]/', $k . $v)) {
      return $this;
    }
    $this->headers[$k] = trim($v);
    return $this;
  }

  private function charset(): string
  {
    $cfg = config('App');
    return (string)($cfg->charset ?? 'UTF-8');
  }

  public function html(string $html): self
  {
    $this->header('Content-Type', 'text/html; charset=' . $this->charset());
    $this->body = $html;
    return $this;
  }

  public function text(string $text, int $status = 200): self
  {
    $this->setStatus($status);
    $this->header('Content-Type', 'text/plain; charset=' . $this->charset());
    $this->body = $text;
    return $this;
  }

  public function json($data, int $status = 200): self
  {
    $this->setStatus($status);
    $this->header('Content-Type', 'application/json; charset=' . $this->charset());
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
      // No romper la app: responde un JSON de error controlado
      $this->setStatus(500);
      $err = function_exists('json_last_error_msg') ? json_last_error_msg() : 'json_encode failed';
      $this->body = '{"error":"json_encode_failed","message":' . json_encode($err, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '}';
      return $this;
    }
    $this->body = $json;
    return $this;
  }

  public function redirect(string $url, int $status = 302): self
  {
    $safe = $url;

    // Detecta externo: scheme http(s) o schemeless //host
    $isExternal = (bool)preg_match('#^(https?:)?//#i', $url);

    if ($isExternal) {
      $cfg = config('Security');

      $allowAll = !empty($cfg->allowExternalRedirects);
      $allowedHosts = $cfg->allowedRedirectHosts ?? [];

      if (!$allowAll) {
        // allowlist opcional
        $host = strtolower((string)(parse_url($url, PHP_URL_HOST) ?? ''));
        $allowed = array_map('strtolower', is_array($allowedHosts) ? $allowedHosts : []);

        if ($host === '' || empty($allowed) || !in_array($host, $allowed, true)) {
          $safe = '/';
          try {
            // Si baseURL es 'auto/' (default), preferimos la raíz real detectada.
            if (function_exists('base_url')) {
              $safe = base_url('/');
            }
          } catch (\Throwable $e) { /* ignore */ }
        }
      }
    }

    $this->setStatus($status);
    $this->header('Location', $safe);
    $this->body = '';
    return $this;
  }

  public function contentType(): string
  {
    foreach ($this->headers as $k => $v) {
      if (strtolower($k) === 'content-type') return strtolower($v);
    }
    return '';
  }

  public function isHtml(): bool
  {
    $ct = $this->contentType();
    return $ct !== '' && str_contains($ct, 'text/html');
  }

  public function send(): void
  {
    // Debug toolbar injection (solo HTML)
    $ct = $this->contentType();
    if ($ct && str_contains($ct, 'text/html')) {
      // No inyectar en AJAX
      $isAjax = strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
      $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
      if (!$isAjax && !str_contains($accept, 'application/json')) {
        $this->body = Toolbar::inject($this->body);
      }
    }

    http_response_code($this->status);
    foreach ($this->headers as $k => $v) header("$k: $v");
    echo $this->body;
  }
}
