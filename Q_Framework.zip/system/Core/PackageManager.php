<?php
declare(strict_types=1);

namespace System\Core;

/**
 * PackageManager (v8)
 * Packages in: packages/<Vendor>/<Package>
 */
final class PackageManager
{
    private string $path;

    public function __construct(string $path)
    {
        $this->path = rtrim($path,'/');
    }

    public function discover(): array
    {
        $packages = [];
        if (!is_dir($this->path)) return $packages;

        foreach (glob($this->path.'/*/*', GLOB_ONLYDIR) as $dir) {
            $cfg = $dir.'/package.json';
            if (is_file($cfg)) {
                $meta = json_decode(file_get_contents($cfg), true);
                $packages[] = [
                    'dir'=>$dir,
                    'meta'=>$meta
                ];
            }
        }
        return $packages;
    }
}
