<?php
declare(strict_types=1);

namespace System\Core;

final class Helper
{
  public static function load(string $name): void
  {
    $name = trim($name);

    // Sanitizar nombre de helper (evita path traversal)
    if ($name === '' || str_contains($name, "\0") || str_contains($name, '..')) return;
    if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) return;

    $sys = base_path("system/Helpers/{$name}_helper.php");
    $appSystem = base_path("app/Helpers/system/{$name}_helper.php");
    $app = base_path("app/Helpers/{$name}_helper.php");

    $sysExists = is_file($sys);

    $appSystemExists = is_file($appSystem);
    $appExists = is_file($app);
// ✅ Prioridad: system primero
    // ✅ Si el usuario crea un helper con el mismo nombre que uno del system, NO se permite (evita shadowing).
    if ($sysExists && ($appSystemExists || $appExists)) {
      $cfg = \config('App');
      $debug = !empty($cfg->debug);

      $msg = "Helper conflict: '{$name}' existe en system y app. "
           . "No está permitido sobrescribir helpers del sistema. "
           . "Renombra tu helper en app/Helpers a otro nombre (ej: '{$name}_custom').";

      // En desarrollo, fallar explícitamente para que se corrija rápido.
      if ($debug) {
        throw new \RuntimeException($msg);
      }

      // En producción, ignorar el app helper y cargar el del sistema.
      // (Opcional: log)
      require_once $sys;
      return;
    }

    if ($sysExists) {
      require_once $sys;
      return;
    }

    if ($appSystemExists) {
      require_once $appSystem;
      return;
    }

    if ($appExists) {
      require_once $app;
      return;
    }
}

  public static function loadGlobals(): void
  {
    $cfg = \config('App'); // Config\App object
    $helpers = $cfg->globalHelpers ?? [];
    foreach ($helpers as $h) self::load((string)$h);
  }
}
