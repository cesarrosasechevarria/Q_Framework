<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Estado runtime de módulos (activar/desactivar) por tenant.
 * Guarda en JSON en write/tenants/<tenant>/modules/modules.json
 */
final class ModuleState
{
  private static function file(): string
  {
    $cfg = \config('Modules');
    $dir = Tenant::writePath('modules');
    @mkdir($dir, 0775, true);
    $file = (string)($cfg->stateFile ?? 'modules.json');
    return rtrim($dir,'/\\') . '/' . ltrim($file,'/\\');
  }

  /** @return array{enabled:array,disabled:array,mode:string} */
  public static function load(): array
  {
    $def = ['enabled'=>[], 'disabled'=>[], 'mode'=>'override'];
    $p = self::file();
    if (!is_file($p)) return $def;
    $raw = @file_get_contents($p);
    if (!is_string($raw) || trim($raw) === '') return $def;
    $d = json_decode($raw, true);
    if (!is_array($d)) return $def;
    $mode = strtolower((string)($d['mode'] ?? 'override'));
    if (!in_array($mode, ['override','merge'], true)) $mode = 'override';
    $en = array_values(array_filter(array_map('strval', (array)($d['enabled'] ?? []))));
    $dis = array_values(array_filter(array_map('strval', (array)($d['disabled'] ?? []))));
    return ['enabled'=>$en, 'disabled'=>$dis, 'mode'=>$mode];
  }

  public static function save(array $enabled, array $disabled = [], string $mode = 'override'): bool
  {
    $mode = strtolower($mode);
    if (!in_array($mode, ['override','merge'], true)) $mode = 'override';
    $payload = [
      'mode' => $mode,
      'enabled' => array_values(array_filter(array_map('strval', $enabled))),
      'disabled' => array_values(array_filter(array_map('strval', $disabled))),
      'updated_at' => date('c'),
    ];
    $p = self::file();
    return (bool)@file_put_contents($p, json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX);
  }

  public static function enable(string $module): bool
  {
    $s = self::load();
    $en = $s['enabled'];
    $dis = $s['disabled'];
    if (!in_array($module, $en, true)) $en[] = $module;
    $dis = array_values(array_filter($dis, fn($m) => $m !== $module));
    return self::save($en, $dis, $s['mode']);
  }

  public static function disable(string $module): bool
  {
    $s = self::load();
    $en = array_values(array_filter($s['enabled'], fn($m) => $m !== $module));
    $dis = $s['disabled'];
    if (!in_array($module, $dis, true)) $dis[] = $module;
    return self::save($en, $dis, $s['mode']);
  }
}
