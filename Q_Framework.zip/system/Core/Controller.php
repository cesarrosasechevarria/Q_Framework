<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Controlador base del framework.
 *
 * Nota importante:
 * - Se permite que los controladores hijos declaren su propio __construct().
 * - El kernel inyecta Request/Response mediante __qfw_setContext() antes de invocar el constructor del controlador.
 * - Si tu controlador define __construct() y deseas recibir Request/Response por parámetros,
 *   simplemente tipa los parámetros: __construct(Request $request, Response $response).
 */
abstract class Controller
{
  protected Request $request;
  protected Response $response;

  /**
   * Establece el contexto de ejecución (Request/Response). Lo llama el kernel.
   */
  public function __qfw_setContext(Request $request, Response $response): void
  {
    $this->request  = $request;
    $this->response = $response;
  }

  /**
   * Constructor opcional.
   * Si un controlador hijo llama parent::__construct(), este método no romperá nada.
   */
  public function __construct(?Request $request = null, ?Response $response = null)
  {
    if ($request && $response) {
      $this->__qfw_setContext($request, $response);
    }
  }

  protected function view(string $name, array $data = [], ?string $layout = null): string
  {
    return View::render($name, $data, $layout);
  }

  protected function json($data, int $status = 200): Response
  {
    return $this->response->json($data, $status);
  }

  protected function redirect(string $url, int $status = 302): Response
  {
    return $this->response->redirect($url, $status);
  }
}
