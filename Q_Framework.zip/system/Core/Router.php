<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Router PRO
 *
 * Features:
 * - Route cache (ROUTE_CACHE=1) -> storage/cache/routes.<env>.php
 * - 405 Method Not Allowed detection (returns allowed methods list)
 *
 * Note: AutoRoute is handled in App (kernel) to keep routing logic centralized.
 */
final class Router
{
  /**
   * Compiled routes map:
   *   [ 'GET' => [ '/path' => ['uses'=>...], ... ], ... , '_names' => [...]]
   */
  private array $routes = [];

  /** @var array<string,array<string,mixed>> */
  private array $exact = [];

  /** @var array<string,list<array{re:string,def:mixed,types:array<string,string>}>> */
  private array $patterns = [];

  /** @var array<int,array{prefix:string,namespaces:array,opts:array}> */
  private array $autoScopes = [];

  /** Case sensitivity for path matching (from Config\Routing). */
  private bool $caseSensitivePaths = true;

  public function __construct($routesDef)
  {
    // ============================
    // Route cache (per env)
    // ============================
    $env = (string) env('APP_ENV', 'production');
    $useCache = env_bool('ROUTE_CACHE', false);
    $cacheFile = base_path('storage/cache/routes.' . $env . '.php');

    if ($useCache && is_file($cacheFile)) {
      $cached = require $cacheFile;
      if (is_array($cached) && !empty($cached)) {
        $this->routes = $cached;
        $this->autoScopes = is_array($this->routes['_auto'] ?? null) ? $this->routes['_auto'] : [];
        Routes::setNames($this->routes['_names'] ?? []);
        $cfg = config('Routing');
        $this->caseSensitivePaths = (bool)($cfg->caseSensitivePaths ?? true);
        $this->buildIndex();
        return;
      }
      // Si el cache está corrupto, continúa a build fresh.
    }

    // ============================
    // Build fresh
    // ============================
    if (is_callable($routesDef)) {
      $col = new RouteCollection();
      $routesDef($col);

      // Módulos (Routes.php por módulo)
      \System\Core\Modules::routes($col);

      $this->routes = $col->compile();
    } elseif (is_array($routesDef)) {
      $this->routes = $routesDef;
    } else {
      $this->routes = [];
    }

    $this->autoScopes = is_array($this->routes['_auto'] ?? null) ? $this->routes['_auto'] : [];

    Routes::setNames($this->routes['_names'] ?? []);

    $cfg = config('Routing');
    $this->caseSensitivePaths = (bool)($cfg->caseSensitivePaths ?? true);

    // Índices para acelerar matches
    $this->buildIndex();
  }

  /**
   * Returns scoped AutoRoute definitions compiled from RouteCollection::auto().
   */
  public function autoScopes(): array
  {
    return $this->autoScopes;
  }

  /**
   * Resolve a route.
   *
   * @return array{0:?array,1:array,2:array} [$routeDef, $params, $allowed]
   *   - $routeDef: normalized array with at least 'uses'
   *   - $params: associative params (named) or empty
   *   - $allowed: allowed HTTP methods if the path exists for other methods (405), else []
   */
  public function resolve(Request $req): array
  {
    $method = $req->method();
    $path   = $req->path();

    // 1) Match in current method
    // Exact (O(1))
    $exact = $this->exact[$method] ?? null;
    if (is_array($exact) && isset($exact[$path])) {
      return [$this->normalizeDef($exact[$path]), [], []];
    }

    // Case-insensitive exact match (optional)
    if (!$this->caseSensitivePaths) {
      $p2 = strtolower($path);
      if (is_array($exact) && isset($exact[$p2])) {
        return [$this->normalizeDef($exact[$p2]), [], []];
      }
    }

    // Fallback (compat con cache viejo)
    $map = $this->routes[$method] ?? [];
    if (isset($map[$path])) {
      return [$this->normalizeDef($map[$path]), [], []];
    }

    // Patterns (precompilados)
    $patterns = $this->patterns[$method] ?? null;
    if (is_array($patterns)) {
      foreach ($patterns as $it) {
        $m = $this->matchRegex((string)$it['re'], $path, (array)($it['types'] ?? []));
        if ($m !== null) {
          return [$this->normalizeDef($it['def']), $m, []];
        }
      }
    } else {
      // compat: cache viejo sin índices
      foreach ($map as $route => $def) {
        $route = (string)$route;
        if (!str_contains($route, '{')) continue;
        $m = $this->matchPattern($route, $path);
        if ($m !== null) {
          return [$this->normalizeDef($def), $m, []];
        }
      }
    }

    // 2) Not found: compute allowed methods (405)
    $allowed = $this->allowedMethodsForPath($path, $method);

    return [null, [], $allowed];
  }


  /**
   * Construye índices (exact/pattern) una sola vez por carga de rutas.
   * Esto evita recorrer todas las rutas en cada request.
   */
  private function buildIndex(): void
  {
    $this->exact = [];
    $this->patterns = [];

    foreach ($this->routes as $method => $map) {
      if (!is_string($method) || str_starts_with($method, '_')) continue;
      if (!is_array($map)) continue;

      $this->exact[$method] = [];
      $this->patterns[$method] = [];

      foreach ($map as $route => $def) {
        $route = (string)$route;

        if (!str_contains($route, '{')) {
          $this->exact[$method][$route] = $def;

          if (!$this->caseSensitivePaths) {
            $lower = strtolower($route);
            if (!isset($this->exact[$method][$lower])) {
              $this->exact[$method][$lower] = $def;
            } elseif ($lower !== $route && env_bool('APP_DEBUG', false)) {
              throw new \RuntimeException("Route conflict (case-insensitive) for {$method}: '{$route}' collides with '{$lower}'. Use a single canonical case for route paths.");
            }
          }

          continue;
        }

        // precompile {param[:type]} -> named groups + type casting
        $types = [];
        $regex = $this->compileRouteRegex($route, $types);

        $this->patterns[$method][] = ['re' => $regex, 'def' => $def, 'types' => $types];
      }
    }
  }

  private function normalizeDef($def): array
  {
    if (is_string($def)) return ['uses' => $def];
    if (!is_array($def)) return ['uses' => ''];
    return $def;
  }

  /**
   * Match a "{param}" pattern route.
   * Returns params array or null if no match.
   */
  /**
   * Match usando regex precompilado.
   */
  private function matchRegex(string $regex, string $path, array $types = []): ?array
  {
    if (!preg_match($regex, $path, $matches)) return null;
    $params = [];
    foreach ($matches as $k => $v) {
      if (!is_string($k)) continue;
      $params[$k] = $this->castParam($v, (string)($types[$k] ?? ''));
    }
    return $params;
  }

  private function matchPattern(string $route, string $path): ?array
  {
    $types = [];
    $regex = $this->compileRouteRegex($route, $types);

    if (!preg_match($regex, $path, $matches)) {
      return null;
    }

    $params = [];
    foreach ($matches as $k => $v) {
      if (!is_string($k)) continue;
      $params[$k] = $this->castParam($v, (string)($types[$k] ?? ''));
    }
    return $params;
  }

  /**
   * Returns allowed methods for a given path (exact or pattern match), excluding current method.
   */
  private function allowedMethodsForPath(string $path, string $currentMethod): array
  {
    $allowed = [];
    $pathKey = $this->caseSensitivePaths ? $path : strtolower($path);

    foreach ($this->routes as $method => $map) {
      if (!is_string($method) || str_starts_with($method, '_')) continue;
      if ($method === $currentMethod) continue;
      if (!is_array($map)) continue;

      // exact
      $ex = $this->exact[$method] ?? null;
      if (is_array($ex) && isset($ex[$pathKey])) {
        $allowed[] = $method;
        continue;
      }

      // compat exact
      if (isset($map[$path]) || (!$this->caseSensitivePaths && isset($map[$pathKey]))) {
        $allowed[] = $method;
        continue;
      }

      // patterns (precompilados)
      $pat = $this->patterns[$method] ?? null;
      if (is_array($pat)) {
        foreach ($pat as $it) {
          if ($this->matchRegex((string)$it['re'], $path, (array)($it['types'] ?? [])) !== null) { $allowed[] = $method; break; }
        }
      } else {
        foreach ($map as $route => $def) {
          $route = (string)$route;
          if (!str_contains($route, '{')) continue;
          if ($this->matchPattern($route, $path) !== null) { $allowed[] = $method; break; }
        }
      }
    }

    $allowed = array_values(array_unique($allowed));
    sort($allowed);
    return $allowed;
  }

  /**
   * Compiles a route pattern like:
   *   /posts/{id:int}  /files/{path:*}
   * into a regex with named groups.
   */
  private function compileRouteRegex(string $route, array &$types): string
  {
    $types = [];

    $regex = preg_replace_callback('#\{([a-zA-Z_][a-zA-Z0-9_]*)(?::([^}]+))?\}#', function($m) use (&$types){
      $name = (string)$m[1];
      $type = isset($m[2]) ? strtolower(trim((string)$m[2])) : '';
      $types[$name] = $type;
      $re = $this->typeToRegex($type);
      return '(?P<' . $name . '>' . $re . ')';
    }, $route);

    $flags = '';
    if (!$this->caseSensitivePaths) $flags = 'i';

    return '#^' . rtrim((string)$regex, '/') . '$#' . $flags;
  }

  private function typeToRegex(string $type): string
  {
    $type = strtolower(trim($type));

    // custom regex: {id:re:\d{4}}
    if (str_starts_with($type, 're:')) {
      $raw = trim(substr($type, 3));
      return $raw !== '' ? $raw : '[^/]+';
    }

    return match($type) {
      '', 'any', 'mixed', 'mixto', 'text', 'string' => '[^/]+',
      'int', 'integer' => '\\d+',
      'num', 'number', 'float', 'decimal' => '-?\\d+(?:\\.\\d+)?',
      'alpha' => '[A-Za-z]+',
      'alnum' => '[A-Za-z0-9]+',
      'slug' => '[A-Za-z0-9_-]+',
      'uuid' => '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}',
      'hex' => '[0-9a-fA-F]+',
      '*', 'path', 'rest' => '.+',
      default => '[^/]+',
    };
  }

  private function castParam(mixed $value, string $type): mixed
  {
    $type = strtolower(trim($type));
    if ($value === null) return null;
    $v = (string)$value;

    return match($type) {
      'int', 'integer' => (int)$v,
      'num', 'number', 'float', 'decimal' => (float)$v,
      'bool', 'boolean' => in_array(strtolower($v), ['1','true','yes','on'], true),
      default => $v,
    };
  }
}
