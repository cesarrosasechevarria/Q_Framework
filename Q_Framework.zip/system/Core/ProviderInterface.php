<?php
declare(strict_types=1);

namespace System\Core;

/**
 * ProviderInterface (Service Provider)
 *
 * Objetivo:
 * - Permitir que la app/extensiones registren servicios, listeners, rutas, validadores,
 *   middlewares, etc, sin modificar el núcleo.
 *
 * Ciclo:
 *  - register(): registrar bindings/configuración (sin side-effects fuertes)
 *  - boot(): ejecutar después del registro (puede depender de Request/Routes/Events)
 */
interface ProviderInterface
{
  public function register(): void;
  public function boot(): void;
}
