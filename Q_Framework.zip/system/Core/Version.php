<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Q_Framework Version
 */
final class Version
{
  public const VERSION = '1.0.0';
}
