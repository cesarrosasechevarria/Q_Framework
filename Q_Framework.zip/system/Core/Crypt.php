<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Crypt (PRO minimal)
 * - AES-256-GCM default (auth+confidentiality)
 * - Key from Config\Encryption or env(APP_KEY/ENC_KEY)
 * - Supports APP_KEY=base64:... (32 bytes recommended)
 */
final class Crypt
{
  private static function cipher(): string
  {
    $cfg = config('Encryption');
    return (string)($cfg->cipher ?? env('ENC_CIPHER', 'aes-256-gcm'));
  }

  /** Normaliza key a 32 bytes. Acepta APP_KEY base64:... */
  private static function key(): string
  {
    $cfg = config('Encryption');
    $key = (string)($cfg->key ?? env('APP_KEY', env('ENC_KEY', '')));
    $key = trim($key);

    if ($key === '') {
      throw new \RuntimeException('APP_KEY/ENC_KEY no configurado. Define APP_KEY=base64:... en .env o configura Config\Encryption.php');
    }

    // base64:...
    if (str_starts_with($key, 'base64:')) {
      $raw = base64_decode(substr($key, 7), true);
      if ($raw === false) throw new \RuntimeException('APP_KEY base64 inválido');
      $keyBin = $raw;
    } else {
      $keyBin = $key;
    }

    // AES-256 requiere 32 bytes -> derivación determinística
    if (strlen($keyBin) !== 32) {
      $keyBin = hash('sha256', $keyBin, true);
    }

    return $keyBin;
  }

  
  private static function b64urlEncode(string $bin): string
  {
    // base64url (RFC 4648 §5) sin padding
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
  }

  private static function b64urlDecode(string $b64url): string
  {
    $b64 = strtr($b64url, '-_', '+/');
    $pad = strlen($b64) % 4;
    if ($pad) $b64 .= str_repeat('=', 4 - $pad);
    $bin = base64_decode($b64, true);
    if ($bin === false) throw new \RuntimeException('Token inválido');
    return $bin;
  }

public static function encrypt(string $plaintext, array $aad = []): string
  {
    $cipher = self::cipher();
    $key = self::key();
    $ivLen = openssl_cipher_iv_length($cipher);
    if ($ivLen <= 0) throw new \RuntimeException('Cipher inválido: ' . $cipher);

    $iv = random_bytes($ivLen);
    $tag = '';
    $aadStr = $aad ? json_encode($aad, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : '';

    $ct = openssl_encrypt($plaintext, $cipher, $key, OPENSSL_RAW_DATA, $iv, $tag, $aadStr, 16);
    if ($ct === false) throw new \RuntimeException('No se pudo encriptar');

    // Pack: v1|iv|tag|ct  (base64url)
    $bin = "QFW1" . $iv . $tag . $ct;
    return self::b64urlEncode($bin);
  }

  public static function decrypt(string $token, array $aad = []): string
  {
    $cipher = self::cipher();
    $key = self::key();
    $aadStr = $aad ? json_encode($aad, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : '';

    $bin = self::b64urlDecode($token);

    if (substr($bin, 0, 4) !== "QFW1") throw new \RuntimeException('Formato no soportado');
    $bin = substr($bin, 4);

    $ivLen = openssl_cipher_iv_length($cipher);
    $iv = substr($bin, 0, $ivLen);
    $tag = substr($bin, $ivLen, 16);
    $ct  = substr($bin, $ivLen + 16);

    $pt = openssl_decrypt($ct, $cipher, $key, OPENSSL_RAW_DATA, $iv, $tag, $aadStr);
    if ($pt === false) throw new \RuntimeException('No se pudo desencriptar (key/tag/aad)');
    return $pt;
  }
}
