<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Tenant manager (multi-tenant)
 * - Resuelve tenant por header/query/subdomain/path
 * - Carga overrides de .env por tenant (si existe)
 * - Expone rutas write/tenants/<tenant>/...
 */
final class Tenant
{
  private static bool $booted = false;
  private static string $id = 'default';
  private static array $known = [];

  public static function boot(): void
  {
    if (self::$booted) return;
    self::$booted = true;

    $cfg = \config('Tenancy');
    if (empty($cfg->enabled)) {
      self::$id = (string)($cfg->defaultTenant ?? 'default');
      define('TENANT_ID', self::$id);
      return;
    }

    self::$known = self::discoverKnownTenants((string)($cfg->tenantsPath ?? 'app/Tenants'));

    $strategy = strtolower(trim((string)($cfg->strategy ?? 'auto')));
    $candidate = '';

    $envTid = (string)\env('TENANT_ID', '');
    if (trim($envTid) !== '') {
      $candidate = $envTid;
    }


    if ($candidate === '') {
    if ($strategy === 'auto') {
      $candidate = self::fromHeader((string)($cfg->header ?? 'X-Tenant-ID'))
        ?: self::fromQuery((string)($cfg->queryParam ?? 'tenant'))
        ?: self::fromSubdomain()
        ?: self::fromPath((string)($cfg->pathPrefix ?? 't'));
    } elseif ($strategy === 'header') {
      $candidate = self::fromHeader((string)($cfg->header ?? 'X-Tenant-ID'));
    } elseif ($strategy === 'query') {
      $candidate = self::fromQuery((string)($cfg->queryParam ?? 'tenant'));
    } elseif ($strategy === 'subdomain') {
      $candidate = self::fromSubdomain();
    } elseif ($strategy === 'path') {
      $candidate = self::fromPath((string)($cfg->pathPrefix ?? 't'));
    }


    }
    $fallback = (string)($cfg->defaultTenant ?? 'default');
    $id = self::sanitize($candidate) ?: self::sanitize($fallback) ?: 'default';

    if (!empty($cfg->onlyKnownTenants) && self::$known) {
      if (!in_array($id, self::$known, true)) {
        $id = in_array($fallback, self::$known, true) ? $fallback : (self::$known[0] ?? 'default');
      }
    }

    self::$id = $id;
    if (!defined('TENANT_ID')) define('TENANT_ID', self::$id);

    // Ensure tenant write dirs
    $base = self::writeBase();
    @mkdir($base . '/logs', 0775, true);
    @mkdir($base . '/cache', 0775, true);
    @mkdir($base . '/sessions', 0775, true);
    @mkdir($base . '/metrics', 0775, true);
    @mkdir($base . '/modules', 0775, true);

    // Tenant env override
    if (!empty($cfg->loadTenantEnv)) {
      $tenantsPath = base_path((string)($cfg->tenantsPath ?? 'app/Tenants'));
      $env1 = $tenantsPath . '/' . self::$id . '/.env';
      if (is_file($env1)) Env::load($env1);

      // Opcional: overrides en write/tenants/<id>/.env
      $env2 = self::writeBase() . '/.env';
      if (is_file($env2)) Env::load($env2);
    }
  }

  public static function id(): string
  {
    return self::$id;
  }

  /** Cambia tenant en runtime (útil en CLI). No redefine TENANT_ID. */
  public static function switch(string $tenant): void
  {
    $t = self::sanitize($tenant) ?: 'default';
    self::$id = $t;

    // crea carpetas básicas
    $b = self::writeBase();
    @mkdir($b . '/logs', 0775, true);
    @mkdir($b . '/cache', 0775, true);
    @mkdir($b . '/sessions', 0775, true);
    @mkdir($b . '/metrics', 0775, true);
    @mkdir($b . '/modules', 0775, true);

    // Carga overrides .env del tenant si está habilitado (útil en CLI)
    $cfg = \config('Tenancy');
    if (!empty($cfg->enabled) && !empty($cfg->loadTenantEnv)) {
      $tenantsPath = base_path((string)($cfg->tenantsPath ?? 'app/Tenants'));
      $env1 = $tenantsPath . '/' . self::$id . '/.env';
      if (is_file($env1)) Env::load($env1);

      $env2 = self::writeBase() . '/.env';
      if (is_file($env2)) Env::load($env2);
    }

    // Reseteos para evitar “leaks” de config/servicios/conexiones entre tenants
    if (function_exists('config_clear_cache')) {
      config_clear_cache();
    }
    if (class_exists('\\Config\\Services') && method_exists('\\Config\\Services', 'reset')) {
      \Config\Services::reset();
    }
    if (class_exists('\\System\\Core\\DB') && method_exists('\\System\\Core\\DB', 'reset')) {
      \System\Core\DB::reset();
    }
  }

  public static function writeBase(): string
  {
    $cfg = \config('Tenancy');
    if (empty($cfg->enabled)) {
      return rtrim(WRITEPATH, '/\\');
    }
    $rel = (string)($cfg->tenantsWritePath ?? 'write/tenants');
    return base_path(trim($rel,'/\\')) . '/' . self::$id;
  }

  public static function writePath(string $sub = ''): string
  {
    $b = self::writeBase();
    return $sub ? rtrim($b,'/\\') . '/' . ltrim($sub,'/\\') : $b;
  }

  public static function knownTenants(): array
  {
    return self::$known;
  }

  private static function fromHeader(string $header): string
  {
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
    return (string)($_SERVER[$key] ?? '');
  }

  private static function fromQuery(string $param): string
  {
    return (string)($_GET[$param] ?? '');
  }

  private static function fromSubdomain(): string
  {
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = preg_replace('/:\\d+$/', '', $host);
    if ($host === '' || $host === 'localhost') return '';

    $parts = explode('.', $host);
    if (count($parts) < 3) return '';
    return (string)($parts[0] ?? '');
  }

  private static function fromPath(string $prefix): string
  {
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $path = parse_url($uri, PHP_URL_PATH) ?: '/';
    $path = trim($path, '/');
    if ($path === '') return '';

    $seg = explode('/', $path);
    if ($prefix !== '') {
      if (($seg[0] ?? '') !== $prefix) return '';
      return (string)($seg[1] ?? '');
    }

    return (string)($seg[0] ?? '');
  }

  private static function sanitize(string $raw): string
  {
    $raw = strtolower(trim($raw));
    if ($raw === '') return '';
    $raw = preg_replace('/[^a-z0-9_\-]/', '', $raw);
    return substr($raw, 0, 50);
  }

  private static function discoverKnownTenants(string $rel): array
  {
    $abs = base_path($rel);
    if (!is_dir($abs)) return [];
    $out = [];
    foreach (scandir($abs) ?: [] as $d) {
      if ($d === '.' || $d === '..') continue;
      if (!is_dir($abs . '/' . $d)) continue;
      $id = self::sanitize($d);
      if ($id !== '') $out[] = $id;
    }
    sort($out);
    return $out;
  }
}
