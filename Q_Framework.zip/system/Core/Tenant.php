<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Tenant manager (multi-tenant)
 * - Resuelve tenant por header/query/subdomain/path
 * - (PRO) Puede validar contra registry (filesystem/db) y soporta strictUnknownTenant
 * - Carga overrides de .env por tenant (si existe)
 * - Expone rutas write/tenants/<tenant>/...
 */
final class Tenant
{
  private static bool $booted = false;
  private static string $id = 'default';
  private static array $known = [];

  public static function boot(): void
  {
    if (self::$booted) return;
    self::$booted = true;

    $cfg = \config('Tenancy');

    // Tenancy deshabilitado => tenant fijo
    if (empty($cfg->enabled)) {
      self::$id = (string)($cfg->defaultTenant ?? 'default');
      define('TENANT_ID', self::$id);
      return;
    }

    // Descubrir tenants conocidos (según registry)
    self::$known = self::discoverKnownTenants($cfg);

    $strategy  = strtolower(trim((string)($cfg->strategy ?? 'auto')));
    $candidate = '';

    // Override explícito desde env (útil en CLI)
    $envTid = (string)\env('TENANT_ID', '');
    if (trim($envTid) !== '') {
      $candidate = $envTid;
    }

    // Auto-detect
    if ($candidate === '') {
      if ($strategy === 'auto') {
        $candidate = self::fromHeader((string)($cfg->header ?? 'X-Tenant-ID'))
          ?: self::fromQuery((string)($cfg->queryParam ?? 'tenant'))
          ?: self::fromSubdomain($cfg)
          ?: self::fromPath((string)($cfg->pathPrefix ?? 't'));
      } elseif ($strategy === 'header') {
        $candidate = self::fromHeader((string)($cfg->header ?? 'X-Tenant-ID'));
      } elseif ($strategy === 'query') {
        $candidate = self::fromQuery((string)($cfg->queryParam ?? 'tenant'));
      } elseif ($strategy === 'subdomain') {
        $candidate = self::fromSubdomain($cfg);
      } elseif ($strategy === 'path') {
        $candidate = self::fromPath((string)($cfg->pathPrefix ?? 't'));
      }
    }

    $fallback = (string)($cfg->defaultTenant ?? 'default');

    $candidateId = self::sanitize($candidate);
    $fallbackId  = self::sanitize($fallback) ?: 'default';

    // Si viene vacío (ej dominio base), usar fallback y NO marcar inválido.
    $id = $candidateId !== '' ? $candidateId : $fallbackId;

    // Validación contra conocidos
    if (!empty($cfg->onlyKnownTenants) && !empty(self::$known)) {
      if ($candidateId !== '' && !in_array($candidateId, self::$known, true)) {

        // Modo pro: no "caer" silenciosamente a default
        if (!empty($cfg->strictUnknownTenant)) {
          if (!defined('TENANT_INVALID')) define('TENANT_INVALID', true);
          if (!defined('TENANT_CANDIDATE')) define('TENANT_CANDIDATE', $candidateId);
        }

        // Fallback seguro
        $id = in_array($fallbackId, self::$known, true) ? $fallbackId : (self::$known[0] ?? $fallbackId);

      } else {
        // OK
        $id = ($candidateId !== '') ? $candidateId : $fallbackId;
      }
    }

    self::$id = $id;
    if (!defined('TENANT_ID')) define('TENANT_ID', self::$id);

    // Ensure tenant write dirs
    $base = self::writeBase();
    @mkdir($base . '/logs', 0775, true);
    @mkdir($base . '/cache', 0775, true);
    @mkdir($base . '/sessions', 0775, true);
    @mkdir($base . '/metrics', 0775, true);
    @mkdir($base . '/modules', 0775, true);

    // Tenant env override (solo si tenant válido o si strict no está activado)
    // - Si strictUnknownTenant y TENANT_INVALID, evitamos cargar .env de un tenant desconocido
    $isInvalid = defined('TENANT_INVALID') && TENANT_INVALID === true;
    if (!empty($cfg->loadTenantEnv) && !$isInvalid) {
      $tenantsPath = base_path((string)($cfg->tenantsPath ?? 'app/Tenants'));
      $env1 = $tenantsPath . '/' . self::$id . '/.env';
      if (is_file($env1)) Env::load($env1);

      // Opcional: overrides en write/tenants/<id>/.env
      $env2 = self::writeBase() . '/.env';
      if (is_file($env2)) Env::load($env2);
    }
  }

  public static function id(): string
  {
    return self::$id;
  }

  /** Cambia tenant en runtime (útil en CLI). No redefine TENANT_ID. */
  public static function switch(string $tenant): void
  {
    $t = self::sanitize($tenant) ?: 'default';
    self::$id = $t;

    // crea carpetas básicas
    $b = self::writeBase();
    @mkdir($b . '/logs', 0775, true);
    @mkdir($b . '/cache', 0775, true);
    @mkdir($b . '/sessions', 0775, true);
    @mkdir($b . '/metrics', 0775, true);
    @mkdir($b . '/modules', 0775, true);

    // Carga overrides .env del tenant si está habilitado (útil en CLI)
    $cfg = \config('Tenancy');
    if (!empty($cfg->enabled) && !empty($cfg->loadTenantEnv)) {
      $tenantsPath = base_path((string)($cfg->tenantsPath ?? 'app/Tenants'));
      $env1 = $tenantsPath . '/' . self::$id . '/.env';
      if (is_file($env1)) Env::load($env1);

      $env2 = self::writeBase() . '/.env';
      if (is_file($env2)) Env::load($env2);
    }

    // Reseteos para evitar “leaks” de config/servicios/conexiones entre tenants
    if (function_exists('config_clear_cache')) {
      config_clear_cache(null, '*');
    }
    if (class_exists('\\Config\\Services') && method_exists('\\Config\\Services', 'reset')) {
      \Config\Services::reset();
    }
    if (class_exists('\\System\\Core\\DB') && method_exists('\\System\\Core\\DB', 'reset')) {
      \System\Core\DB::reset();
    }
  }

  public static function writeBase(): string
  {
    $cfg = \config('Tenancy');
    if (empty($cfg->enabled)) {
      return rtrim(WRITEPATH, '/\\');
    }
    $rel = (string)($cfg->tenantsWritePath ?? 'write/tenants');
    return base_path(trim($rel,'/\\')) . '/' . self::$id;
  }

  public static function writePath(string $sub = ''): string
  {
    $b = self::writeBase();
    return $sub ? rtrim($b,'/\\') . '/' . ltrim($sub,'/\\') : $b;
  }

  public static function knownTenants(): array
  {
    return self::$known;
  }

  private static function fromHeader(string $header): string
  {
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
    return (string)($_SERVER[$key] ?? '');
  }

  private static function fromQuery(string $param): string
  {
    return (string)($_GET[$param] ?? '');
  }

  /**
   * Subdomain tenant (profesional)
   * - respeta baseDomains y reservedSubdomains (Config\Tenancy)
   */
  private static function fromSubdomain(object $cfg): string
  {
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = preg_replace('/:\\d+$/', '', $host);
    if ($host === '' || $host === 'localhost') return '';
    // IP => no subdomain tenant
    if (preg_match('/^\\d{1,3}(\\.\\d{1,3}){3}$/', $host)) return '';

    $reserved = array_map('strtolower', (array)($cfg->reservedSubdomains ?? []));
    $baseDomains = array_values(array_filter(array_map('strtolower', (array)($cfg->baseDomains ?? []))));

    // Si se configuró baseDomains, exigimos match
    if (!empty($baseDomains)) {
      foreach ($baseDomains as $bd) {
        $bd = trim($bd);
        if ($bd === '') continue;
        if ($host === $bd) return '';
        if (str_ends_with($host, '.' . $bd)) {
          $parts = explode('.', $host);
          // tenant es el primer label
          $tenant = (string)($parts[0] ?? '');
          $tenant = self::sanitize($tenant);
          if ($tenant === '' || in_array($tenant, $reserved, true)) return '';
          return $tenant;
        }
      }
      return '';
    }

    // Fallback legacy: requiere al menos 3 partes
    $parts = explode('.', $host);
    if (count($parts) < 3) return '';
    $tenant = self::sanitize((string)($parts[0] ?? ''));
    if ($tenant === '' || in_array($tenant, $reserved, true)) return '';
    return $tenant;
  }

  private static function fromPath(string $prefix): string
  {
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $path = parse_url($uri, PHP_URL_PATH) ?: '/';
    $path = trim($path, '/');
    if ($path === '') return '';

    $seg = explode('/', $path);
    if ($prefix !== '') {
      if (($seg[0] ?? '') !== $prefix) return '';
      return (string)($seg[1] ?? '');
    }

    return (string)($seg[0] ?? '');
  }

  private static function sanitize(string $raw): string
  {
    $raw = strtolower(trim($raw));
    if ($raw === '') return '';
    $raw = preg_replace('/[^a-z0-9_\-]/', '', $raw);
    return substr($raw, 0, 50);
  }

  /**
   * Descubre tenants conocidos según Config\Tenancy::$registry
   * - filesystem: carpetas en app/Tenants/<tenant>
   * - db: tabla en DB group (por defecto "system")
   * - both: merge
   */
  private static function discoverKnownTenants(object $cfg): array
  {
    $mode = strtolower(trim((string)($cfg->registry ?? 'filesystem')));
    $out = [];

    if ($mode === 'filesystem' || $mode === 'both' || $mode === '') {
      $rel = (string)($cfg->tenantsPath ?? 'app/Tenants');
      $out = array_merge($out, self::discoverKnownTenantsFromFs($rel));
    }

    if ($mode === 'db' || $mode === 'both') {
      $out = array_merge($out, self::discoverKnownTenantsFromDb($cfg));
    }

    $out = array_values(array_unique(array_filter($out)));
    sort($out);
    return $out;
  }

  private static function discoverKnownTenantsFromFs(string $rel): array
  {
    $abs = base_path($rel);
    if (!is_dir($abs)) return [];
    $out = [];
    foreach (scandir($abs) ?: [] as $d) {
      if ($d === '.' || $d === '..') continue;
      if (!is_dir($abs . '/' . $d)) continue;
      $id = self::sanitize($d);
      if ($id !== '') $out[] = $id;
    }
    return $out;
  }

  private static function discoverKnownTenantsFromDb(object $cfg): array
  {
    $group = (string)($cfg->registryGroup ?? 'system');
    $table = (string)($cfg->registryTable ?? 'tenants');
    $idCol = (string)($cfg->registryIdColumn ?? 'id');

    $statusCol = (string)($cfg->registryStatusColumn ?? 'status');
    $activeVal = (string)($cfg->registryActiveValue ?? 'active');

    try {
      $conn = \System\Core\DB::connect($group);
      $qb = $conn->table($table)->select($idCol);

      if ($statusCol !== '' && $activeVal !== '') {
        $qb->where([$statusCol => $activeVal]);
      }

      $r = $qb->getResult(['fetch' => 'rows', 'action' => 'tenant.registry']);
      if (!$r->ok || !is_array($r->data)) return [];

      $out = [];
      foreach ($r->data as $row) {
        if (!is_array($row)) continue;
        $id = self::sanitize((string)($row[$idCol] ?? ''));
        if ($id !== '') $out[] = $id;
      }
      return $out;

    } catch (\Throwable $e) {
      return [];
    }
  }
}
