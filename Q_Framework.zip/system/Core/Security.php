<?php
declare(strict_types=1);

namespace System\Core;

final class Security
{
  public static function randomString(int $len = 32): string
  {
    $bytes = (int)ceil($len / 2);
    return substr(bin2hex(random_bytes($bytes)), 0, $len);
  }

  public static function hashPassword(string $plain): string
  {
    return password_hash($plain, PASSWORD_DEFAULT);
  }

  public static function verifyPassword(string $plain, string $hash): bool
  {
    return password_verify($plain, $hash);
  }

  public static function hmac(string $data, string $key, string $algo = 'sha256'): string
  {
    return hash_hmac($algo, $data, $key);
  }

  public static function cleanPath(string $path): string
  {
    $path = str_replace("\0", '', $path);
    $path = preg_replace('#/+#', '/', $path);
    return $path;
  }
}
