<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Session manager (lazy)
 * - Por defecto NO inicia sesión.
 * - Solo inicia cuando llamas session() o cuando un filtro/controlador lo necesita.
 *
 * Flash PRO:
 * - flashSet / flashPull / flashPeek / flashHas / flashAll / flashKeep / reflash / flashClear
 * - Compatibilidad: flash('k','v') y flash('k') (consume)
 */
final class Session
{
  private static bool $started = false;
  private static bool $flashTicked = false;

  /** @var array<string,mixed> */
  private static array $options = [
    'name' => 'QFWSESSID',
    'save_path' => null,
  ];

  /**
   * Configura opciones (NO inicia).
   */
  public static function configure(array $options = []): void
  {
    self::$options = array_merge(self::$options, $options);
  }

  /**
   * Inicia la sesión solo cuando es necesario.
   */
  public static function ensureStarted(): void
  {
    if (self::$started) return;

    $cfg = config('Session');
    $app = config('App');

    if (!headers_sent()) {
      $savePath = self::$options['save_path'] ?? null;
      if ($savePath) {
        if (!is_dir($savePath)) @mkdir($savePath, 0775, true);
        ini_set('session.save_path', (string)$savePath);
      }

      $name = self::$options['name'] ?? ($cfg->name ?? null);
      if (is_string($name) && $name !== '') session_name($name);

      ini_set('session.use_strict_mode', '1');
      ini_set('session.use_only_cookies', '1');

      // Cookie params
      $secure = !empty($cfg->cookieSecure)
        || (!empty($app->forceGlobalSecureRequests))
        || (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

      // Confiar en proto detrás de proxy SOLO si Request::isSecure() lo valida (trusted proxies / proxyIPs)
      $ctx = \System\Core\KernelContext::current();
      if ($ctx) {
        try { $secure = $secure || $ctx->request()->isSecure(); } catch (\Throwable $e) {}
      }

      $httponly = !empty($cfg->cookieHttpOnly);
      $samesite = (string)($cfg->cookieSameSite ?? 'Lax');
      $lifetime = (int)($cfg->lifetime ?? 0);

      // PHP ini
      ini_set('session.cookie_httponly', $httponly ? '1' : '0');
      ini_set('session.cookie_secure', $secure ? '1' : '0');
      ini_set('session.cookie_samesite', $samesite);

      // Lifetime
      if ($lifetime > 0) {
        ini_set('session.gc_maxlifetime', (string)$lifetime);
        ini_set('session.cookie_lifetime', (string)$lifetime);
      }
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
      session_start();
    }

    self::$started = true;

    // Flash rotate (1 vez por request)
    self::flashBoot();
  }

  public static function isStarted(): bool
  {
    return session_status() === PHP_SESSION_ACTIVE;
  }

  /**
   * ¿Existe cookie de sesión? (sin iniciar sesión)
   */
  public static function hasCookie(): bool
  {
    $cfg = config('Session');
    $name = (string)($cfg->name ?? self::$options['name'] ?? 'QFWSESSID');
    return isset($_COOKIE[$name]);
  }

  public function get(string $key, $default = null)
  {
    self::ensureStarted();
    return $_SESSION[$key] ?? $default;
  }

  public function set(string $key, $value): void
  {
    self::ensureStarted();
    $_SESSION[$key] = $value;
  }

  public function remove(string $key): void
  {
    self::ensureStarted();
    unset($_SESSION[$key]);
  }

  // ============================
  // Flash PRO
  // ============================

  private static function flashBoot(): void
  {
    // Se ejecuta 1 vez por request (después de session_start)
    if (self::$flashTicked) return;
    self::$flashTicked = true;

    if (!isset($_SESSION['_qfw_flash']) || !is_array($_SESSION['_qfw_flash'])) {
      $_SESSION['_qfw_flash'] = ['new' => [], 'old' => []];
      return;
    }

    $f = $_SESSION['_qfw_flash'];

    // Soporte legacy: antes era un array plano ['key'=>value]
    $hasNewOld = (is_array($f) && (array_key_exists('new', $f) || array_key_exists('old', $f)));
    if (!$hasNewOld) {
      $_SESSION['_qfw_flash'] = ['new' => [], 'old' => (is_array($f) ? $f : [])];
      return;
    }

    $new = (isset($f['new']) && is_array($f['new'])) ? $f['new'] : [];

    // Rotate: old se descarta, new pasa a old
    $_SESSION['_qfw_flash'] = ['new' => [], 'old' => $new];
  }

  private function flashStoreEnsure(): void
  {
    self::ensureStarted();

    if (!isset($_SESSION['_qfw_flash']) || !is_array($_SESSION['_qfw_flash'])) {
      $_SESSION['_qfw_flash'] = ['new' => [], 'old' => []];
    }
    if (!isset($_SESSION['_qfw_flash']['new']) || !is_array($_SESSION['_qfw_flash']['new'])) {
      $_SESSION['_qfw_flash']['new'] = [];
    }
    if (!isset($_SESSION['_qfw_flash']['old']) || !is_array($_SESSION['_qfw_flash']['old'])) {
      $_SESSION['_qfw_flash']['old'] = [];
    }
  }

  public function flashSet(string $key, $value): void
  {
    $this->flashStoreEnsure();
    $_SESSION['_qfw_flash']['new'][$key] = $value;
  }

  public function flashHas(string $key): bool
  {
    $this->flashStoreEnsure();
    return array_key_exists($key, $_SESSION['_qfw_flash']['old'])
      || array_key_exists($key, $_SESSION['_qfw_flash']['new']);
  }

  public function flashPeek(string $key, $default = null)
  {
    $this->flashStoreEnsure();
    if (array_key_exists($key, $_SESSION['_qfw_flash']['old'])) return $_SESSION['_qfw_flash']['old'][$key];
    if (array_key_exists($key, $_SESSION['_qfw_flash']['new'])) return $_SESSION['_qfw_flash']['new'][$key];
    return $default;
  }

  public function flashPull(string $key, $default = null)
  {
    $this->flashStoreEnsure();

    if (array_key_exists($key, $_SESSION['_qfw_flash']['old'])) {
      $v = $_SESSION['_qfw_flash']['old'][$key];
      unset($_SESSION['_qfw_flash']['old'][$key]);
      return $v;
    }

    // Permitir lectura en el mismo request si recién se seteo (new)
    if (array_key_exists($key, $_SESSION['_qfw_flash']['new'])) {
      $v = $_SESSION['_qfw_flash']['new'][$key];
      unset($_SESSION['_qfw_flash']['new'][$key]);
      return $v;
    }

    return $default;
  }

  public function flashAll(bool $consume = true): array
  {
    $this->flashStoreEnsure();

    $old = $_SESSION['_qfw_flash']['old'] ?? [];
    $new = $_SESSION['_qfw_flash']['new'] ?? [];

    $all = array_merge($old, $new); // new sobreescribe old si hay claves duplicadas

    if ($consume) {
      $_SESSION['_qfw_flash']['old'] = [];
      $_SESSION['_qfw_flash']['new'] = [];
    }

    return $all;
  }

  /**
   * Mantiene mensajes flash por 1 request adicional.
   * - Si $keys es null, mantiene TODOS los que estén en 'old'.
   * - Si $keys es array, mantiene solo esas claves si existen.
   */
  public function flashKeep($keys = null): void
  {
    $this->flashStoreEnsure();
    $old = $_SESSION['_qfw_flash']['old'] ?? [];
    if (!is_array($keys)) $keys = array_keys($old);

    foreach ($keys as $k) {
      if (array_key_exists($k, $old)) {
        // Copiamos a new para que sobreviva al siguiente request
        $_SESSION['_qfw_flash']['new'][$k] = $old[$k];
      }
    }
  }

  /** Mantiene TODO por 1 request adicional (alias de flashKeep()) */
  public function reflash(): void
  {
    $this->flashKeep(null);
  }

  public function flashClear($keys = null): void
  {
    $this->flashStoreEnsure();

    if ($keys === null) {
      $_SESSION['_qfw_flash']['old'] = [];
      $_SESSION['_qfw_flash']['new'] = [];
      return;
    }

    if (!is_array($keys)) $keys = [$keys];

    foreach ($keys as $k) {
      unset($_SESSION['_qfw_flash']['old'][$k]);
      unset($_SESSION['_qfw_flash']['new'][$k]);
    }
  }

  /**
   * Compatibilidad (Q_Framework):
   * - Setter: flash('key','value')
   * - Getter (consume): flash('key')
   */
  public function flash(string $key, $value = null)
  {
    if (func_num_args() === 1) {
      return $this->flashPull($key, null);
    }
    $this->flashSet($key, $value);
    return null;
  }

  /**
   * Regenerar ID de sesión (seguridad) - estilo Q_Framework.
   */
  public function regenerate(bool $destroy = false): void
  {
    self::ensureStarted();
    if (session_status() !== PHP_SESSION_ACTIVE) return;
    @session_regenerate_id($destroy);
  }

  public function destroy(): void
  {
    if (session_status() !== PHP_SESSION_ACTIVE) return;
    $_SESSION = [];
    session_destroy();
    self::$started = false;
    self::$flashTicked = false;
  }
}
