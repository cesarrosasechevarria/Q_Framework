<?php
declare(strict_types=1);

namespace System\Core;

use ReflectionClass;
use ReflectionNamedType;
use ReflectionParameter;

/**
 * DI Container (simple, robusto)
 *
 * - bind(id, factory)
 * - singleton(id, factory)
 * - instance(id, obj)  (set shared instance)
 * - has/forget
 * - make(FQCN) opcional (autowire básico) para extensiones
 *
 * Nota: get() se mantiene "estricto" (si no está bindeado, lanza),
 * para no romper comportamiento. make() es el modo flexible.
 */
final class Container
{
    /** @var array<string, callable> */
    private array $bindings = [];
    /** @var array<string, mixed> */
    private array $instances = [];

    public function bind(string $id, callable $factory): void
    {
        $this->bindings[$id] = $factory;
    }

    public function singleton(string $id, callable $factory): void
    {
        $this->bindings[$id] = function(self $c) use ($factory, $id) {
            if (!isset($this->instances[$id])) {
                $this->instances[$id] = $factory($c);
            }
            return $this->instances[$id];
        };
    }

    /** Registra una instancia compartida directamente. */
    public function instance(string $id, mixed $value): void
    {
        $this->instances[$id] = $value;
    }

    public function has(string $id): bool
    {
        return isset($this->instances[$id]) || isset($this->bindings[$id]);
    }

    public function forget(string $id): void
    {
        unset($this->instances[$id], $this->bindings[$id]);
    }

    /** Obtiene un servicio bindeado (estricto). */
    public function get(string $id): mixed
    {
        if (isset($this->instances[$id])) return $this->instances[$id];
        if (!isset($this->bindings[$id])) {
            throw new \RuntimeException("Service not bound: {$id}");
        }
        return ($this->bindings[$id])($this);
    }

    /** Obtiene o null si no existe. */
    public function getOrNull(string $id): mixed
    {
        try { return $this->has($id) ? $this->get($id) : null; }
        catch (\Throwable) { return null; }
    }

    /**
     * make(): modo flexible
     * - si está bindeado, usa get()
     * - si $id es clase existente, intenta autowire básico
     */
    public function make(string $id, array $params = []): mixed
    {
        if ($this->has($id)) return $this->get($id);
        if (class_exists($id)) return $this->autowire($id, $params);
        throw new \RuntimeException("Service/Class not resolvable: {$id}");
    }

    private function autowire(string $class, array $params = []): object
    {
        $ref = new ReflectionClass($class);
        $ctor = $ref->getConstructor();
        if (!$ctor) return new $class();

        $args = [];
        foreach ($ctor->getParameters() as $p) {
            $args[] = $this->resolveParam($p, $params);
        }
        return $ref->newInstanceArgs($args);
    }

    private function resolveParam(ReflectionParameter $p, array $params): mixed
    {
        $name = $p->getName();
        if (array_key_exists($name, $params)) return $params[$name];

        $t = $p->getType();
        if ($t instanceof ReflectionNamedType && !$t->isBuiltin()) {
            $fqcn = $t->getName();
            // si está registrado como binding/instance, úsalo
            if ($this->has($fqcn)) return $this->get($fqcn);

            // bindings comunes por nombre (compat)
            $lname = strtolower($fqcn);
            if ($this->has($lname)) return $this->get($lname);

            // si es una clase resoluble, autowire recursivo
            if (class_exists($fqcn)) return $this->autowire($fqcn, []);
        }

        if ($p->isDefaultValueAvailable()) return $p->getDefaultValue();
        if ($p->allowsNull()) return null;

        throw new \RuntimeException("Cannot autowire parameter \${$name}");
    }
}
