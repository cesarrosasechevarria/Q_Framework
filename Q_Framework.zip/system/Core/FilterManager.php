<?php
declare(strict_types=1);

namespace System\Core;

final class FilterManager
{
  private array $cfg;

  public function __construct()
  {
    $this->cfg = require base_path('app/Config/Filters.php');
  }

  /**
   * Retorna arrays:
   *  [
   *    'before' => [ ['class'=>FQCN,'args'=>[]], ... ],
   *    'after'  => [ ['class'=>FQCN,'args'=>[]], ... ],
   *  ]
   */
  public function resolve(string $httpMethod, string $path, array $routeDef): array
  {
    $aliases = $this->cfg['aliases'] ?? [];
    $globals = $this->cfg['globals'] ?? ['before'=>[],'after'=>[]];

    $before = array_values($globals['before'] ?? []);
    $after  = array_values($globals['after'] ?? []);

    $patterns = $this->cfg['patterns'] ?? [];
    foreach ($patterns as $pattern => $filters) {
      if ($this->matchPattern((string)$pattern, $path)) {
        foreach ((array)$filters as $f) $before[] = $f;
      }
    }

    // Filters per-route
    if (!empty($routeDef['filters'])) {
      foreach ((array)$routeDef['filters'] as $f) $before[] = $f;
    }

    // Shortcut auth => true
    if (!empty($routeDef['auth'])) {
      $before[] = 'auth';
    }

    // v9: Shortcut guard => array|true
    if (array_key_exists('guard', $routeDef) && !empty($routeDef['guard'])) {
      $before[] = 'guard';
    }

    $before = $this->uniqueKeepOrder($before);
    $after  = $this->uniqueKeepOrder($after);

    // Route redirect option can be passed to auth filter
    $routeRedirect = $routeDef['redirect'] ?? null;
    $routeGuard    = $routeDef['guard'] ?? null;

    $beforeDefs = [];
    foreach ($before as $aliasRaw) {
      [$alias, $args] = $this->parseFilter((string)$aliasRaw);

      // Si route tiene redirect y el filtro es auth, lo pasamos
      if ($alias === 'auth' && is_string($routeRedirect) && $routeRedirect !== '') {
        $args['redirect'] ??= $routeRedirect;
      }

      // v9: si route define guard config, lo pasamos al GuardFilter
      if ($alias === 'guard') {
        // Si guard se activó como boolean true, marcamos implícito.
        if ($routeGuard === true) {
          $args['_implicit'] = true;
        }

        // Si guard es string => require
        if (is_string($routeGuard) && trim($routeGuard) !== '') {
          $args['require'] ??= trim($routeGuard);
        }

        // Si guard es array => merge
        if (is_array($routeGuard)) {
          $args = array_merge($routeGuard, $args); // args explícitos tienen prioridad (por si usas filters "guard:...")
        }

        // redirect desde routeDef['redirect'] si no se especificó en guard
        if (is_string($routeRedirect) && trim($routeRedirect) !== '') {
          $args['redirect'] ??= $routeRedirect;
        }
      }

      if (isset($aliases[$alias])) {
        $beforeDefs[] = ['class' => $aliases[$alias], 'args' => $args];
      }
    }

    $afterDefs = [];
    foreach ($after as $aliasRaw) {
      [$alias, $args] = $this->parseFilter((string)$aliasRaw);
      if (isset($aliases[$alias])) {
        $afterDefs[] = ['class' => $aliases[$alias], 'args' => $args];
      }
    }

    return ['before' => $beforeDefs, 'after' => $afterDefs];
  }

  /**
   * Sintaxis soportada:
   * - "auth" => alias sin args
   * - "auth:/login" => redirect=/login
   * - "auth:@login" => redirect=route_url('login') (resuelve luego)
   */
  private function parseFilter(string $raw): array
  {
    $raw = trim($raw);
    if ($raw === '') return ['', []];

    if (!str_contains($raw, ':')) {
      return [$raw, []];
    }

    [$alias, $argStr] = explode(':', $raw, 2);
    $alias = trim($alias);
    $argStr = trim((string)$argStr);

    $args = [];

    if ($argStr === '') {
      return [$alias, $args];
    }

    // === Sintaxis histórica ===
    // auth:@route.name  -> redirect a route_url('route.name')
    if (str_starts_with($argStr, '@')) {
      $route = substr($argStr, 1);
      $args['redirect'] = route_url($route);
      return [$alias, $args];
    }

    // === Sintaxis PRO (v9.2.2): key=value ===
    // Ej: rate:max=120&decay=60&by=ip
    //     feature:flag=beta;source=session;key=feature_beta;redirect=@home
    if (str_contains($argStr, '=')) {
      $q = str_replace([';', ','], '&', $argStr);
      $parsed = [];
      parse_str($q, $parsed);

      // Normaliza redirect si viene como @route.name
      if (isset($parsed['redirect']) && is_string($parsed['redirect']) && str_starts_with($parsed['redirect'], '@')) {
        $parsed['redirect'] = route_url(substr($parsed['redirect'], 1));
      }

      // Normaliza valores "true/false/null" (solo 1 nivel)
      foreach ($parsed as $k => $v) {
        if (!is_string($v)) continue;
        $vv = strtolower(trim($v));
        if ($vv === 'true') $parsed[$k] = true;
        elseif ($vv === 'false') $parsed[$k] = false;
        elseif ($vv === 'null') $parsed[$k] = null;
        elseif (is_numeric($v) && !preg_match('/^0\d+$/', $v)) {
          $parsed[$k] = $v + 0;
        }
      }

      return [$alias, $parsed];
    }

    // fallback: value único => redirect/path
    $args['redirect'] = $argStr;
    return [$alias, $args];
  }
  private function matchPattern(string $pattern, string $path): bool
  {
    $pattern = rtrim($pattern, '/');
    $path = rtrim($path, '/');
    if ($pattern === '') $pattern = '/';
    if ($path === '') $path = '/';

    if (str_ends_with($pattern, '/*')) {
      $base = substr($pattern, 0, -2);
      return $path === $base || str_starts_with($path, $base . '/');
    }

    return $pattern === $path;
  }

  private function uniqueKeepOrder(array $arr): array
  {
    $seen = [];
    $out = [];
    foreach ($arr as $v) {
      $k = (string)$v;
      if (isset($seen[$k])) continue;
      $seen[$k] = true;
      $out[] = $v;
    }
    return $out;
  }
}
