<?php
declare(strict_types=1);

namespace System\Core;

final class Uri
{
  public function __construct(private string $path, private array $query = [])
  {
    $this->path = $this->normalize($this->path);
  }

  public static function fromGlobals(): self
  {
    $cfg = config('App');

    $protocol = strtoupper((string)($cfg->uriProtocol ?? 'REQUEST_URI'));

    $raw = '/';
    if ($protocol === 'PATH_INFO') {
      $raw = (string)($_SERVER['PATH_INFO'] ?? '/');
    } elseif ($protocol === 'QUERY_STRING') {
      $raw = (string)($_SERVER['QUERY_STRING'] ?? '/');
      // si viene "a=b&c=d", no es path. fallback:
      $raw = '/';
    } else { // REQUEST_URI default
      $raw = (string)($_SERVER['REQUEST_URI'] ?? '/');
    }

    $path = parse_url($raw, PHP_URL_PATH) ?: '/';

    // ==== Soporte "subfolder" + modo "sin /public" ====
// Caso 1 (clásico): URL incluye /public  -> SCRIPT_NAME: /sub/public/index.php y REQUEST_URI: /sub/public/...
// Caso 2 (publicless): URL NO incluye /public pero el front controller está en /public (rewrite raíz -> public/index.php)
$script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
$baseFromScript = str_replace('\\', '/', dirname($script));
$baseFromScript = rtrim($baseFromScript, '/');
if ($baseFromScript === '.' || $baseFromScript === '/') $baseFromScript = '';

// Si el script vive en /public, el "parent" suele ser el subfolder real (ej: /Q_Framework)
$baseParent = $baseFromScript;
if ($baseFromScript !== '' && str_ends_with($baseFromScript, '/public')) {
  $baseParent = substr($baseFromScript, 0, -strlen('/public'));
  $baseParent = rtrim((string)$baseParent, '/');
  if ($baseParent === '') $baseParent = '';
}

// Base desde config baseURL (si está seteado). Ideal para modo sin /public.
$baseFromCfg = (string)(parse_url((string)($cfg->baseURL ?? ''), PHP_URL_PATH) ?: '');
$baseFromCfg = rtrim(str_replace('\\', '/', $baseFromCfg), '/');
if ($baseFromCfg === '/') $baseFromCfg = '';

$pathNorm = rtrim(str_replace('\\', '/', (string)$path), '/');
if ($pathNorm === '') $pathNorm = '/';

$stripBase = function(string $p, string $b): string {
  if ($b === '' || $b === '/') return $p;
  if ($p === $b) return '/';
  if (str_starts_with($p, $b . '/')) {
    $p2 = substr($p, strlen($b));
    if ($p2 === '' || $p2 === false) return '/';
    if ($p2[0] !== '/') $p2 = '/' . $p2;
    return $p2;
  }
  return $p;
};

// Prioridad inteligente:
// 1) Si la URL incluye el directorio real del front-controller (/public), quítalo primero
// 2) Si no, intenta quitar el parent (modo publicless)
// 3) Finalmente, si baseURL configurada coincide con el inicio, quítala
if ($baseFromScript && ($pathNorm === $baseFromScript || str_starts_with($pathNorm, $baseFromScript . '/'))) {
  $pathNorm = $stripBase($pathNorm, $baseFromScript);
} elseif ($baseParent && ($pathNorm === $baseParent || str_starts_with($pathNorm, $baseParent . '/'))) {
  $pathNorm = $stripBase($pathNorm, $baseParent);
} elseif ($baseFromCfg && ($pathNorm === $baseFromCfg || str_starts_with($pathNorm, $baseFromCfg . '/'))) {
  $pathNorm = $stripBase($pathNorm, $baseFromCfg);
}


// ==== Validate permitted URI chars (seguridad compatible) ====
$pChars = (string)($cfg->permittedURIChars ?? '');
if ($pChars !== '') {
  // Validar por segmento (para permitir "/" como separador).
  $trim = trim($pathNorm, '/');
  if ($trim !== '') {
    $segments = explode('/', $trim);
    foreach ($segments as $seg) {
      if ($seg === '') continue;
      if (!preg_match('/\A['.$pChars.']+\z/iu', $seg)) {
        // En vez de echo+exit, lanzamos HttpException para que el handler global renderice (HTML/JSON).
        throw new \System\Core\HttpException(
          400,
          '400 - Bad Request (URI contains disallowed characters)'
        );
      }
    }
  }
}

$q = $_GET ?? [];
    return new self($pathNorm, $q);
  }

  public function path(): string
  {
    return $this->path;
  }

  public function segments(): array
  {
    $p = trim($this->path, '/');
    if ($p === '') return [];
    return explode('/', $p);
  }

  public function segment(int $index, $default = null)
  {
    $segs = $this->segments();
    $i = $index - 1;
    return $segs[$i] ?? $default;
  }

  public function query(?string $key = null, $default = null)
  {
    if ($key === null) return $this->query;
    return $this->query[$key] ?? $default;
  }

  private function normalize(string $p): string
  {
    $p = preg_replace('#/+#', '/', $p);
    return rtrim($p, '/') ?: '/';
  }
}
