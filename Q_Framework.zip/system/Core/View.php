<?php
declare(strict_types=1);

namespace System\Core;

final class View
{
  /**
   * Renderiza una vista.
   *
   * Reglas:
   * - Vistas de la app: app/Views/<name>.php
   * - Vistas del sistema: system/Views/_system/<name_sin_prefijo>.php
   *   Para invocar una vista del sistema usa el prefijo: "_system/"
   *
   * Ej:
   *   View::render('home');                       // app/Views/home.php
   *   View::render('_system/errors/404');         // system/Views/_system/errors/404.php
   *   View::render('_system/pagers/qfw_default'); // system/Views/_system/pagers/qfw_default.php
   */
  public static function render(string $name, array $data = [], ?string $layout = null): string
  {
    $cfg = config('App');
    $layout = $layout ?? ($cfg->defaultLayout ?? null);

    $viewFile = self::resolve($name);
    if (!$viewFile) return "View no encontrada: {$name}";

    extract($data, EXTR_SKIP);

    ob_start();
    include $viewFile;
    $content = (string) ob_get_clean();

    if ($layout) {
      $layoutFile = self::resolve($layout);
      if ($layoutFile) {
        ob_start();
        include $layoutFile;
        return (string) ob_get_clean();
      }
    }

    return $content;
  }

  private static function resolve(string $name): ?string
  {
    $name = trim($name);

    // Sanitización (anti path traversal)
    if ($name === '' || str_contains($name, "\0")) return null;
    if (str_contains($name, '..')) return null;

    $name = ltrim($name, '/\\');
    if (!preg_match('#^[A-Za-z0-9_\-\/\.]+$#', $name)) return null;

    $viewsAppBase = realpath(base_path('app/Views')) ?: base_path('app/Views');
    $viewsSysBase = realpath(base_path('system/Views')) ?: base_path('system/Views');

    // Vistas del sistema (prefijo reservado)
    if (str_starts_with($name, '_system/')) {
      $rel = substr($name, 8);
      $app = base_path("app/Views/_system/{$rel}.php"); // override opcional
      $sys = base_path("system/Views/_system/{$rel}.php");

      $r = realpath($app);
      if ($r && str_starts_with($r, rtrim($viewsAppBase, '/\\') . DIRECTORY_SEPARATOR) && is_file($r)) return $r;

      $r = realpath($sys);
      if ($r && str_starts_with($r, rtrim($viewsSysBase, '/\\') . DIRECTORY_SEPARATOR) && is_file($r)) return $r;

      return null;
    }

    // Vistas del proyecto (NO cae a system)
    $app = base_path("app/Views/{$name}.php");
    $r = realpath($app);
    if ($r && str_starts_with($r, rtrim($viewsAppBase, '/\\') . DIRECTORY_SEPARATOR) && is_file($r)) return $r;

    // v8: buscar en módulos habilitados (con realpath)
    foreach (\System\Core\Modules::viewPaths() as $dir) {
      $base = realpath($dir) ?: $dir;
      $p = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $name) . '.php';
      $rp = realpath($p);
      if ($rp && str_starts_with($rp, rtrim($base, '/\\') . DIRECTORY_SEPARATOR) && is_file($rp)) return $rp;
    }

    return null;
  }
}
