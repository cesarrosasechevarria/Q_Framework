<?php
declare(strict_types=1);

namespace System\Core;

use System\Core\Debug\Profiler;
use ReflectionClass;
use ReflectionNamedType;
use ReflectionParameter;
use Throwable;

final class App
{
  /** Cache de plan de inyección por clase de controller (evita Reflection en cada request). */
  private static array $ctorPlanCache = [];

  private Request $request;
  private Response $response;
  private Router $router;
  private FilterManager $filters;

  public function __construct()
  {
    $this->request  = new Request();
    $this->response = new Response();

    $routesDef = require base_path('app/Config/Routes.php');
    $this->router   = new Router($routesDef);

    $this->filters  = new FilterManager();
  }



/**
 * Crea una instancia de Controller permitiendo __construct() opcional en el controlador hijo.
 *
 * - Asigna Request/Response antes de invocar el constructor.
 * - Carga helpers declarados en la propiedad $helpers (si existe).
 * - Soporta inyección simple por tipo en el constructor del controlador:
 *     Request, Response, Connection, PDO, Session, Encrypter, Datos
 * - Si no puede resolver un parámetro obligatorio, lanza un error claro.
 */
private function makeController(string $class): object
{
  $ref = new ReflectionClass($class);

  // Instancia SIN ejecutar constructor (para setear contexto ANTES)
  $obj = $ref->newInstanceWithoutConstructor();

  // Contexto Request/Response
  if (method_exists($obj, '__qfw_setContext')) {
    $obj->__qfw_setContext($this->request, $this->response);
  }

  // Helpers por controlador (si define propiedad $helpers, incluso protected/private)
  if (property_exists($obj, 'helpers')) {
    try {
      $helpers = null;

      // Leer property aunque sea protected (LazyLoad)
      if ($ref->hasProperty('helpers')) {
        $rp = $ref->getProperty('helpers');
        $rp->setAccessible(true);
        $helpers = $rp->getValue($obj);
      }

      if (is_array($helpers) && !empty($helpers)) {
        helper($helpers);
      }
    } catch (Throwable $e) {
      // silencioso: si está en debug el error handler lo mostrará si esto detona luego
    }
  }

  // Ejecutar constructor del controlador (si existe)
  $ctor = $ref->getConstructor();
  if ($ctor) {
    $plan = $this->buildCtorPlan($class);
    $args = [];
    foreach ($plan as $step) {
      $k = $step['kind'] ?? '';
      if ($k === 'known') {
        $args[] = $this->resolveKnownType((string)($step['type'] ?? ''));
      } elseif ($k === 'default') {
        $args[] = $step['value'] ?? null;
      } elseif ($k === 'null') {
        $args[] = null;
      } else {
        $n = (string)($step['name'] ?? 'param');
        throw new \RuntimeException("No se pudo resolver el parámetro obligatorio \${$n} en el constructor del controlador.");
      }
    }
    $ctor->setAccessible(true);
    $ctor->invokeArgs($obj, $args);
  }

// Hook posterior (BaseController expone __qfw_init)
  if (method_exists($obj, '__qfw_init')) {
    $obj->__qfw_init();
  }

  return $obj;
}


/**
 * Construye (una vez) un plan de resolución del constructor.
 * Cada item es:
 * - ['kind'=>'known','type'=>FQCN]
 * - ['kind'=>'default','value'=>mixed]
 * - ['kind'=>'null']
 * - ['kind'=>'error','name'=>string]
 */
private function buildCtorPlan(string $class): array
{
  if (isset(self::$ctorPlanCache[$class])) {
    return self::$ctorPlanCache[$class];
  }

  $ref = new \ReflectionClass($class);
  $ctor = $ref->getConstructor();
  if (!$ctor) {
    return self::$ctorPlanCache[$class] = [];
  }

  $plan = [];
  foreach ($ctor->getParameters() as $p) {
    $t = $p->getType();

    if ($t instanceof \ReflectionNamedType && !$t->isBuiltin()) {
      $plan[] = ['kind' => 'known', 'type' => $t->getName()];
      continue;
    }

    if ($p->isDefaultValueAvailable()) {
      $plan[] = ['kind' => 'default', 'value' => $p->getDefaultValue()];
      continue;
    }

    if ($t && $t->allowsNull()) {
      $plan[] = ['kind' => 'null'];
      continue;
    }

    $plan[] = ['kind' => 'error', 'name' => $p->getName()];
  }

  return self::$ctorPlanCache[$class] = $plan;
}

private function resolveKnownType(string $name)
{
  if ($name === Request::class)  return $this->request;
  if ($name === Response::class) return $this->response;

  if ($name === \System\Database\Connection::class) return \Config\Services::db();
  if ($name === \PDO::class) return \Config\Services::pdo();

  if ($name === \System\Core\Session::class) return \Config\Services::session();
  if ($name === \System\Services\Encrypter::class) return \Config\Services::encrypter();

  if ($name === \App\Controllers\Miscontrollers\Datos::class) return \Config\Services::datos();

  return null;
}

private function resolveCtorParam(ReflectionParameter $p)
{
  $t = $p->getType();

  if ($t instanceof ReflectionNamedType && !$t->isBuiltin()) {
    $name = $t->getName();

    // Request/Response
    if ($name === Request::class)  return $this->request;
    if ($name === Response::class) return $this->response;

    // DB
    if ($name === \System\Database\Connection::class) return \Config\Services::db();
    if ($name === \PDO::class) return \Config\Services::pdo();

    // Sesión (solo si el dev la pide explícitamente)
    if ($name === \System\Core\Session::class) return \Config\Services::session();

    // Encriptación (objeto Encrypter)
    if ($name === \System\Services\Encrypter::class) return \Config\Services::encrypter();

    // Factory: Datos (si lo usas como capa de datos)
    if ($name === \App\Controllers\Miscontrollers\Datos::class) return \Config\Services::datos();
  }

  // Si tiene valor por defecto, úsalo
  if ($p->isDefaultValueAvailable()) {
    return $p->getDefaultValue();
  }

  // Nullable => null
  if ($t && $t->allowsNull()) {
    return null;
  }

  $n = $p->getName();
  throw new \RuntimeException("No se pudo resolver el parámetro obligatorio \${$n} en el constructor del controlador.");
}

  public function run(): void
  {
    KernelContext::begin($this->request, $this->response, [
      'start'  => microtime(true),
      'tenant' => Tenant::id(),
    ]);

    try {
      Profiler::mark('app_start');

    \System\Core\Events::boot();
    \System\Core\Events::trigger('app.start', ['time'=>microtime(true)]);

        // ===== Hostname allowlist (compatible + tenancy wildcard) =====
    $cfg = config('App');
    $tCfg = config('Tenancy');

    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = preg_replace('/:\\d+$/', '', $host);

    if ($host !== '') {
      // baseHost desde baseURL (si está configurado como URL real)
      $baseHost = '';
      $base = (string)($cfg->baseURL ?? '');
      if ($base && strtolower($base) !== 'auto') {
        $parsed = parse_url($base);
        $baseHost = strtolower((string)($parsed['host'] ?? ''));
      }

      // allowlist explícita (exacta) + patrones simples (*.dominio.com)
      $allowed = array_map('strtolower', (array)($cfg->allowedHostnames ?? []));
      $allowed = array_values(array_filter(array_map('trim', $allowed)));

      $matchPattern = function(string $h, string $pattern): bool {
        $pattern = strtolower(trim($pattern));
        if ($pattern === '') return false;
        if ($pattern === $h) return true;

        // wildcard: *.example.com
        if (str_starts_with($pattern, '*.') && strlen($pattern) > 2) {
          $suffix = substr($pattern, 1); // ".example.com"
          return str_ends_with($h, $suffix) && $h !== ltrim($suffix, '.');
        }
        return false;
      };

      $ok = false;

      // baseHost exacto
      if ($baseHost !== '' && $host === $baseHost) $ok = true;

      // patrones permitidos
      if (!$ok) {
        foreach ($allowed as $p) {
          if ($matchPattern($host, $p)) { $ok = true; break; }
        }
      }

      // Tenancy por subdominio: permitir subdominios de baseDomains o baseHost
      $tenancyEnabled = !empty($tCfg->enabled);
      $strategy = strtolower((string)($tCfg->strategy ?? 'auto'));
      $usesSubdomain = $tenancyEnabled && ($strategy === 'subdomain' || $strategy === 'auto');

      if (!$ok && $usesSubdomain) {
        $baseDomains = array_values(array_filter(array_map('strtolower', (array)($tCfg->baseDomains ?? []))));
        if (!empty($baseDomains)) {
          foreach ($baseDomains as $bd) {
            if ($bd !== '' && ($host === $bd || str_ends_with($host, '.' . $bd))) { $ok = true; break; }
          }
        } elseif ($baseHost !== '') {
          if ($host === $baseHost || str_ends_with($host, '.' . $baseHost)) $ok = true;
        }
      }

      // si no hay baseHost, no rompemos (modo dev/auto), pero se recomienda configurar baseDomains/allowedHostnames en prod
      if (!$ok && $baseHost === '' && empty($allowed)) {
        $ok = true;
      }

      if (!$ok) {
        $this->response->setStatus(400)->html('400 - Bad Request (Host no permitido)')->send();
        return;
      }
    }

    // ===== Tenant inválido (strict tenancy) =====
    if (defined('TENANT_INVALID') && TENANT_INVALID === true) {
      $tCfg = config('Tenancy');
      $action = strtolower(trim((string)($tCfg->unknownTenantAction ?? '404')));

      // Preferir JSON si el cliente lo pidió
      if ($this->request->wantsJson()) {
        $payload = [
          'ok' => false,
          'state' => 'danger',
          'title' => 'Tenant inválido',
          'message' => 'El tenant solicitado no existe o no está habilitado.',
          'tenant' => defined('TENANT_CANDIDATE') ? TENANT_CANDIDATE : null,
        ];
        $this->response->json($payload, 404)->send();
        return;
      }

      if ($action === 'redirect') {
        $target = (string)($tCfg->unknownTenantRedirect ?? '');
        if ($target === '') {
          // fallback: usar baseHost si existe
          $base = (string)(config('App')->baseURL ?? '');
          $parsed = is_string($base) ? parse_url($base) : null;
          $baseHost = strtolower((string)($parsed['host'] ?? ''));
          if ($baseHost !== '') {
            $scheme = $this->request->isSecure() ? 'https' : 'http';
            $target = $scheme . '://' . $baseHost . '/';
          } else {
            $target = '/';
          }
        }
        $this->response->redirect($target, 302)->send();
        return;
      }

      $this->response->setStatus(404)->html('404 - Tenant inválido')->send();
      return;
    }
// ===== Force HTTPS (opcional) =====
    if (!empty($cfg->forceGlobalSecureRequests) && !$this->request->isSecure()) {
      $uri = $_SERVER['REQUEST_URI'] ?? '/';
      $target = 'https://' . ($_SERVER['HTTP_HOST'] ?? '') . $uri;

      $r = $this->response->redirect($target, 302);
      $r->header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
      $r->send();
      return;
    }

    // ===== Resolve route =====
    Profiler::mark('routing_start');
    \System\Core\Events::trigger('routing.start', ['path'=>$this->request->path(),'method'=>$this->request->method()]);
    // Router PRO: también devuelve métodos permitidos si el path existe (405)
    [$routeDef, $params, $allowedMethods] = $this->router->resolve($this->request);
    Profiler::mark('routing_end');
    \System\Core\Events::trigger('routing.end', ['resolved'=> (bool)$routeDef, 'params'=>$params ?? []]);

    if (!$routeDef || empty($routeDef['uses'])) {

      // =========================
      // 405 Method Not Allowed
      // =========================
      if (!empty($allowedMethods)) {
        $this->response
          ->setStatus(405)
          ->header('Allow', implode(', ', $allowedMethods))
          ->html(\System\Core\Errors::methodNotAllowed($allowedMethods))
          ->send();
        Profiler::mark('end');
        return;
      }

      // Scoped AutoRoute (por prefijo): definido desde app/Config/Routes.php con $routes->auto(...)
      // Útil para habilitar AutoRoute solo para una carpeta (p.ej. /funciones/*) y forzar filtros (CSRF, auth, etc.)
      $scopes = method_exists($this->router, 'autoScopes') ? (array)$this->router->autoScopes() : [];
      if ($scopes) {
        $reqPath = $this->request->path();

        foreach ($scopes as $s) {
          if (!is_array($s)) continue;
          $prefix = (string)($s['prefix'] ?? '/');
          $prefix = '/' . trim($prefix, '/');
          if ($prefix === '//') $prefix = '/';

          // match prefix
          $rel = null;
          if ($prefix === '/') {
            $rel = $reqPath;
          } else {
            $p = rtrim($prefix, '/');
            if ($reqPath === $p) {
              $rel = '/';
            } elseif (str_starts_with($reqPath, $p . '/')) {
              $rel = substr($reqPath, strlen($p)) ?: '/';
            }
          }
          if ($rel === null) continue;

          $opts = is_array($s['opts'] ?? null) ? (array)$s['opts'] : [];

          $auto = $this->resolveAutoRoute(
            $rel,
            (array)($s['namespaces'] ?? []),
            (bool)($opts['translateURIDashes'] ?? $cfg->translateURIDashes ?? true),
            (bool)($opts['translateURIDots'] ?? $cfg->translateURIDots ?? false),
            (string)($opts['defaultController'] ?? $cfg->defaultController ?? 'Home'),
            (string)($opts['defaultMethod'] ?? $cfg->defaultMethod ?? 'index'),
            $opts
          );

          if ($auto) {
            [$routeDef, $params] = $auto;

            // Merge opts into routeDef, handling filters additive
            if (isset($opts['filters'])) {
              $routeDef['filters'] = array_values(array_unique(array_merge(
                (array)($routeDef['filters'] ?? []),
                (array)$opts['filters']
              )));
              unset($opts['filters']);
            }
            unset($opts['uses']);
            $routeDef = array_merge($routeDef, $opts);

            $routeDef['auto_scope'] = $prefix;
            if (empty($routeDef['as']) || $routeDef['as'] === 'auto') {
              $key = trim($prefix, '/');
              $routeDef['as'] = $key ? ('auto.' . str_replace('/', '.', $key)) : 'auto';
            }
            break;
          }
        }
      }
      // AutoRoute (global, opcional, compatible)
      if ((!$routeDef || empty($routeDef['uses'])) && !empty($cfg->autoRoute)) {
        $auto = $this->resolveAutoRoute(
          $this->request->path(),
          (array)($cfg->autoRouteNamespaces ?? ['App\Controllers']),
          (bool)($cfg->translateURIDashes ?? true),
          (bool)($cfg->translateURIDots ?? false),
          (string)($cfg->defaultController ?? 'Home'),
          (string)($cfg->defaultMethod ?? 'index'),
          []
        );
        if ($auto) {
          [$routeDef, $params] = $auto;
        }
      }

      if (!$routeDef || empty($routeDef['uses'])) {
        $this->response->setStatus(404)->html(\System\Core\Errors::notFound())->send();
        Profiler::mark('end');
        return;
      }
    }


    $path = $this->request->path();
    $httpMethod = $this->request->method();

    Profiler::setRoute([
      'method' => $httpMethod,
      'path'   => $path,
      'name'   => $routeDef['as'] ?? '',
      'uses'   => $routeDef['uses'] ?? '',
    ]);

    $filterSet = $this->filters->resolve($httpMethod, $path, $routeDef);

    // ===== Before filters =====
    Profiler::mark('before_filters');
    \System\Core\Events::trigger('filters.before', $filterSet);
    foreach ($filterSet['before'] as $item) {
      $class = $item['class'];
      $args  = $item['args'] ?? [];

      $f = new $class();

      if (method_exists($f, 'setArgs')) {
        $f->setArgs(is_array($args) ? $args : []);
      }

      $r = $f->before($this->request, $this->response);
      if ($r instanceof Response) { $r->send(); Profiler::mark('end'); return; }
    }
    Profiler::mark('before_filters_end');

    // ===== Controller =====
    Profiler::mark('controller_start');
    \System\Core\Events::trigger('controller.before', ['uses'=>$routeDef['uses'] ?? '', 'params'=>$params]);
    [$class, $methodName] = explode('@', (string)$routeDef['uses'], 2);

    if (!class_exists($class)) {
      Logger::error("Controller no existe: {$class}");
      $cfg = config('App');
      $env = (string)($cfg->environment ?? 'production');
      $debug = (bool)($cfg->debug ?? false);

      $msg = 'Controller inválido.';
      if ($debug && $env !== 'production') {
        $msg = "Controller no encontrado: {$class}";
      }
      $this->response->setStatus(500)->html(\System\Core\Errors::page(500, ['title'=>'Error interno','message'=>$msg]))->send();
      Profiler::mark('end');
      return;
    }

    $controller = $this->makeController($class);

    if (!method_exists($controller, $methodName)) {
      Logger::error("Método no existe: {$class}@{$methodName}");
      $cfg = config('App');
      $env = (string)($cfg->environment ?? 'production');
      $debug = (bool)($cfg->debug ?? false);

      $msg = 'Método inválido.';
      if ($debug && $env !== 'production') {
        $msg = "Método no encontrado: {$class}@{$methodName}";
      }
      $this->response->setStatus(500)->html(\System\Core\Errors::page(500, ['title'=>'Error interno','message'=>$msg]))->send();
      Profiler::mark('end');
      return;
    }

    // Captura de salida accidental (echo/var_dump) dentro del controller.
    // Esto evita respuestas rotas (especialmente JSON) y muestra un bloque de debug en HTML (dev).
    $capturedOutput = '';
    ob_start();
    try {
      $result = call_user_func_array([$controller, $methodName], array_values($params));
    } finally {
      $capturedOutput = (string)ob_get_clean();
    }

    if ($result instanceof Response) {
      $this->response = $result;
      if (KernelContext::current()) KernelContext::current()->setResponse($this->response);
    } elseif (is_array($result) || is_object($result)) {
      // Content Negotiation: si la ruta es API o Accept JSON => responde JSON.
      if ($this->request->wantsJson()) {
        $payload = $result;
        $status = 200;
        $headers = [];

        if (is_array($result) && array_key_exists('data', $result) && array_key_exists('status', $result)) {
          $payload = $result['data'];
          $status = (int)$result['status'];
          $headers = is_array($result['headers'] ?? null) ? $result['headers'] : [];
        }

        foreach ($headers as $k => $v) {
          if (is_string($k) && (is_string($v) || is_numeric($v))) $this->response->header($k, (string)$v);
        }
        $this->response->json($payload, $status);
      } else {
        // Fallback HTML legible (útil en dev)
        $pretty = htmlspecialchars(json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?: '', ENT_QUOTES, 'UTF-8');
        $this->response->html('<pre style="white-space:pre-wrap">' . $pretty . '</pre>');
      }
    } else {
      $this->response->html((string)$result);
    }

    // Si se capturó salida desde el controller (echo/print/var_dump),
// por defecto la anexamos a la respuesta HTML para permitir construir vistas “a lo PHP”.
// Modo configurable en Config\App::$controllerOutputMode:
//   - 'append_html' (default): si NO es JSON/redirect, antepone la salida capturada al body.
//   - 'debug': NO la muestra, solo agrega bloque de debug en HTML (dev) y headers informativos.
//   - 'ignore': descarta la salida capturada (solo headers informativos).
if ($capturedOutput !== '') {
  $cfg = config('App');
  $env = (string)($cfg->environment ?? 'production');
  $debug = (bool)($cfg->debug ?? false);


  $mode = strtolower((string)($cfg->controllerOutputMode ?? 'append_html'));

  $len = strlen($capturedOutput);
  $this->response->header('X-QFW-Output-Captured', '1');
  $this->response->header('X-QFW-Output-Len', (string)$len);

  $isJson = $this->request->wantsJson()
    || (method_exists($this->response, 'contentType') && str_contains((string)$this->response->contentType(), 'application/json'));

  $isRedirect = method_exists($this->response, 'isRedirect') ? $this->response->isRedirect() : false;

  if (($mode === 'append_html' || $mode === 'append') && !$isRedirect && !$isJson) {
    // Asegura Content-Type HTML si no se definió
    if (method_exists($this->response, 'contentType') && $this->response->contentType() === '') {
      $charset = (string)($cfg->charset ?? 'UTF-8');
      $this->response->header('Content-Type', 'text/html; charset=' . $charset);
    }
    // Mantener orden natural: lo echo sale antes que lo retornado.
    $this->response->setBody($capturedOutput . $this->response->body());

    Logger::info('Salida capturada desde controller (echo/print) y anexada al body.', [
      'uses' => $routeDef['uses'] ?? '',
      'len'  => $len,
      'mode' => $mode,
    ]);
  } else {
    // Mantener comportamiento anterior (debug / ignore): no mezclar con JSON/redirect.
    Logger::warn('Salida capturada desde controller (echo/print/var_dump).', [
      'uses' => $routeDef['uses'] ?? '',
      'len'  => $len,
      'mode' => $mode,
    ]);

    if ($mode === 'debug' && $debug && $env !== 'production' && method_exists($this->response, 'isHtml') && $this->response->isHtml()) {
      $escaped = htmlspecialchars($capturedOutput, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
      $block = "\n<!-- QFW Captured Output -->\n"
        . '<div style="margin:16px 0;padding:12px;border:1px dashed rgba(0,0,0,.35);border-radius:10px;background:rgba(255,255,0,.07)">'
        . '<div style="font:600 13px/1.2 system-ui; margin-bottom:6px">⚠️ Q_Framework capturó salida directa del controller</div>'
        . '<div style="font:12px/1.4 system-ui; opacity:.9">Si deseas que el <code>echo</code> se vea como contenido, usa <code>controllerOutputMode=append_html</code> en Config\App.</div>'
        . '<details style="margin-top:8px"><summary style="cursor:pointer;font:600 12px/1.2 system-ui">Ver salida capturada (' . $len . ' bytes)</summary>'
        . '<pre style="white-space:pre-wrap;overflow:auto;margin:10px 0 0;padding:10px;border-radius:8px;background:rgba(0,0,0,.06)">' . $escaped . '</pre>'
        . '</details></div>\n';

      $this->response->appendBody($block);
    }
  }
}

    Profiler::mark('controller_end');
    \System\Core\Events::trigger('controller.after', ['uses'=>$routeDef['uses'] ?? '', 'result_type'=> is_object($result)? get_class($result) : gettype($result)]);

    // ===== After filters =====
    Profiler::mark('after_filters');
    \System\Core\Events::trigger('filters.after', $filterSet);
    foreach ($filterSet['after'] as $item) {
      $class = $item['class'];
      $args  = $item['args'] ?? [];

      $f = new $class();
      if (method_exists($f, 'setArgs')) {
        $f->setArgs(is_array($args) ? $args : []);
      }

      $r = $f->after($this->request, $this->response);
      if ($r instanceof Response) { $this->response = $r; if (KernelContext::current()) KernelContext::current()->setResponse($this->response); }
    }
    Profiler::mark('after_filters_end');

    \System\Core\Events::trigger('response.before_send', ['status'=>$this->response->status()]);

    $this->response->send();

    \System\Core\Events::trigger('response.after_send', ['status'=>$this->response->status()]);
    Profiler::mark('end');
    } finally {
      KernelContext::end();
    }
  }

  /**
   * AutoRoute compatible:
   * - /home            -> Home::index()
   * - /users/10        -> Users::index(10)
   * - /admin/reports   -> Admin::reports() OR Admin\Reports::index() (si existe)
   * - /admin/reports/x -> Admin\Reports::x() (si existe) o Admin::reports('x')
   */
  private function resolveAutoRoute(
    string $path,
    array $namespaces,
    bool $translateDashes,
    bool $translateDots,
    string $defaultController,
    string $defaultMethod,
    array $opts = []
  ): ?array {
    $path = '/' . trim($path, '/');
    $segments = array_values(array_filter(explode('/', trim($path, '/')), fn($s) => $s !== ''));

    // Opcional: permitir dots como separador (admin.users.edit -> admin/users/edit)
    if ($translateDots && $segments) {
      $out = [];
      foreach ($segments as $seg) {
        // Solo split si el segmento parece "palabra.palabra" (evita casos tipo v1.0)
        if (preg_match('/^[A-Za-z][A-Za-z0-9_-]*(\.[A-Za-z][A-Za-z0-9_-]*)+$/', $seg)) {
          foreach (explode('.', $seg) as $p) {
            if ($p !== '') $out[] = $p;
          }
        } else {
          $out[] = $seg;
        }
      }
      $segments = $out;
    }

    if (!$segments) {
      $segments = [$defaultController];
    }


    // Autoroute aliases (scoped)
    // Ej: ['inicio'=>'Home'] permite /funciones/inicio/login => Home@login
    $aliases = [];
    if (isset($opts['aliases']) && is_array($opts['aliases'])) $aliases = $opts['aliases'];
    if (isset($opts['controllerAliases']) && is_array($opts['controllerAliases'])) $aliases = $opts['controllerAliases'];
    if ($aliases && $segments) {
      $k = (string)$segments[0];
      if (array_key_exists($k, $aliases)) {
        $rep = (string)$aliases[$k];
        // Permite "Admin\\Users" o "admin/users" como alias
        $rep = str_replace(['.','/'], ['\\','\\'], $rep);
        $repSegs = array_values(array_filter(preg_split('/\\\\+/', $rep) ?: []));
        if ($repSegs) {
          $segments = array_merge($repSegs, array_slice($segments, 1));
        }
      }
    }

    // Modo opcional: /prefix/login => defaultController@login (si existe)
    $methodFirst = (bool)($opts['methodFirst'] ?? $opts['defaultControllerMethodFirst'] ?? false);

    // Opciones PRO
    // - maxDepth: cuántos segmentos como máximo se intentan como controller (permite subcarpetas profundas)
    // - methodCase: 'auto' (default), 'snake', 'camel', 'preserve'
    // - fallbackToDefaultMethod: si el método no existe, usa defaultMethod y trata el segmento como param (compat)
    $maxDepth = (int)($opts['maxDepth'] ?? 12);
    if ($maxDepth < 1) $maxDepth = 1;
    if ($maxDepth > 20) $maxDepth = 20;

    $methodCase = (string)($opts['methodCase'] ?? 'auto');
    $fallbackToDefault = (bool)($opts['fallbackToDefaultMethod'] ?? $opts['fallbackToIndex'] ?? true);

    // Normaliza namespaces
    $namespaces = array_values(array_filter(array_map(fn($n) => trim((string)$n, '\\'), $namespaces)));
    if (!$namespaces) $namespaces = ['App\\Controllers'];

    // 0) method-first sobre defaultController (opcional)
    if ($methodFirst && $segments) {
      $candidateMethodSeg = $segments[0] ?? '';
      if ($candidateMethodSeg !== '' && !ctype_digit($candidateMethodSeg)) {
        foreach ($namespaces as $nsRaw) {
          $class = trim((string)$nsRaw, '\\') . '\\' . $this->segToPascal($defaultController);
          if (!class_exists($class)) continue;

          $cands = $this->methodCandidates($candidateMethodSeg, $translateDashes, $methodCase);
          if (!$cands) $cands = [$defaultMethod];

          foreach ($cands as $m) {
            $m = $m ?: $defaultMethod;
            if (!method_exists($class, $m)) continue;
            if (str_starts_with($m, '_')) continue;

            try {
              $ref = new \ReflectionMethod($class, $m);
              if (!$ref->isPublic() || $ref->isStatic() || $ref->isConstructor() || $ref->isDestructor()) continue;
              if ($ref->getDeclaringClass()->getName() !== $class) continue;
              $routeDef = ['as'=>'auto','uses'=>$class.'@'.$m,'auto'=>true];
              $params = array_slice($segments, 1);
              return [$routeDef, $params];
            } catch (\Throwable $e) {
              // ignore
            }
          }
        }
      }
    }

    // Intenta resolver controllers con subfolders: usa el mayor prefijo posible como Controller: usa el mayor prefijo posible como Controller
    foreach ($namespaces as $nsRaw) {
      $ns = $nsRaw; // sin backslash final

      for ($i = min(count($segments), $maxDepth); $i >= 1; $i--) {
        $ctrlSegs = array_slice($segments, 0, $i);
        $ctrlClassPart = implode('\\', array_map([$this, 'segToPascal'], $ctrlSegs));
        if ($ctrlClassPart === '') continue;

        $class = $ns . '\\' . $ctrlClassPart;
        if (!class_exists($class)) continue;

        // method seg
        $methodSeg = $segments[$i] ?? '';
        $rest = array_slice($segments, $i + 1);

        // Si no hay methodSeg, usa default
        if ($methodSeg === '') {
          $method = $defaultMethod;
          $params = [];
        } else {
          // Si methodSeg es numérico, lo tratamos como param y usamos defaultMethod
          if (ctype_digit($methodSeg)) {
            $method = $defaultMethod;
            $params = array_merge([$methodSeg], $rest);
          } else {
            $found = false;
            $method = $defaultMethod;
            $params = [];

            $cands = $this->methodCandidates($methodSeg, $translateDashes, $methodCase);
            // Si no produce candidatos válidos, tratamos el segmento como param
            if ($cands) {
              foreach ($cands as $cand) {
                $cand = $cand ?: $defaultMethod;
                if (!method_exists($class, $cand)) continue;
                if (str_starts_with($cand, '_')) continue;
                try {
                  $ref = new \ReflectionMethod($class, $cand);
                  if (!$ref->isPublic() || $ref->isStatic() || $ref->isConstructor() || $ref->isDestructor()) continue;
                  if ($ref->getDeclaringClass()->getName() !== $class) continue;
                } catch (\Throwable $e) {
                  continue;
                }
                $method = $cand;
                $params = $rest;
                $found = true;
                break;
              }
            }

            if (!$found) {
              if (!$fallbackToDefault) {
                continue;
              }
              // Compat: cae al defaultMethod y trata methodSeg como primer parámetro
              $method = $defaultMethod;
              $params = array_merge([$methodSeg], $rest);
            }
          }
        }

        // Seguridad: debe existir método público declarado en el controller
        if (!method_exists($class, $method)) continue;
        if (str_starts_with($method, '_')) continue;

        try {
          $ref = new \ReflectionMethod($class, $method);
          if (!$ref->isPublic() || $ref->isStatic() || $ref->isConstructor() || $ref->isDestructor()) continue;
          // Bloquea métodos heredados del BaseController (evita exponer helpers internos)
          if ($ref->getDeclaringClass()->getName() !== $class) continue;
        } catch (\Throwable $e) {
          continue;
        }

        $routeDef = [
          'as'   => 'auto',
          'uses' => $class . '@' . $method,
          'auto' => true,
        ];
        return [$routeDef, $params];
      }
    }

    return null;
  }

  private function segToPascal(string $seg): string
  {
    $seg = trim($seg);
    if ($seg === '') return '';
    // elimina chars raros
    $seg = preg_replace('/[^a-zA-Z0-9_\-]/', '', $seg) ?? '';
    $parts = preg_split('/[-_]+/', $seg) ?: [$seg];
    $parts = array_values(array_filter($parts, fn($p) => $p !== ''));
    $parts = array_map(fn($p) => ucfirst(strtolower($p)), $parts);
    return implode('', $parts);
  }

  private function segToCamel(string $seg): string
  {
    $p = $this->segToPascal($seg);
    return $p ? lcfirst($p) : '';
  }

  /**
   * Genera candidatos de método para AutoRoute, soportando nombres mixtos.
   *
   * - URL: obt_files -> intenta obt_files
   * - URL: obt-files (si translateDashes) -> intenta obt_files y obtFiles
   * - URL: obtFiles -> intenta obtFiles
   */
  private function methodCandidates(string $methodSeg, bool $translateDashes, string $mode = 'auto'): array
  {
    $methodSeg = trim($methodSeg);
    if ($methodSeg === '') return [];

    $raw = $methodSeg;

    // Si viene con '.', no se procesa aquí (ya se resolvió translateDots antes)

    $snake = $raw;
    if ($translateDashes) {
      $snake = str_replace('-', '_', $snake);
    }

    $camel = '';
    if ($translateDashes && preg_match('/[-_]/', $raw)) {
      // Solo camelizamos si hay separadores (no tocamos camelCase existente)
      $camel = $this->segToCamel($raw);
    }

    // Sanitiza: método PHP válido
    $isValid = function(string $m): bool {
      if ($m === '') return false;
      return (bool) preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $m);
    };

    $push = function(array &$arr, string $m) use ($isValid): void {
      if (!$isValid($m)) return;
      if (!in_array($m, $arr, true)) $arr[] = $m;
    };

    $out = [];

    $mode = strtolower(trim($mode));
    if ($mode === 'snake') {
      $push($out, $snake);
      return $out;
    }
    if ($mode === 'camel') {
      if ($camel !== '') $push($out, $camel);
      else $push($out, $snake);
      $push($out, $raw);
      return $out;
    }
    if ($mode === 'preserve') {
      // preserve (pero si hay '-', solo tiene sentido si translateDashes lo convierte)
      $push($out, $snake);
      $push($out, $raw);
      return $out;
    }

    // auto (default): snake primero, luego preserve, luego camel
    $push($out, $snake);
    $push($out, $raw);
    if ($camel !== '') $push($out, $camel);
    return $out;
  }

}
