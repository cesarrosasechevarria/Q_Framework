<?php
declare(strict_types=1);

namespace System\Core;

final class Csp
{
  private static ?string $nonce = null;

  public static function nonce(): string
  {
    if (self::$nonce !== null) return self::$nonce;

    $raw = random_bytes(16);
    $b64 = rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');

    self::$nonce = $b64;
    $_SERVER['QFW_CSP_NONCE'] = $b64;

    return $b64;
  }

  public static function attr(): string
  {
    $n = self::nonce();
    return 'nonce="' . htmlspecialchars($n, ENT_QUOTES, 'UTF-8') . '"';
  }
}
