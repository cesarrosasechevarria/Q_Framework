<?php
declare(strict_types=1);

namespace System\Core\Debug;

final class Toolbar
{
  public static function enabled(): bool
  {
    $appCfg = \config('App');
    $env = (string)($appCfg->environment ?? 'production');
    $debug = (bool)($appCfg->debug ?? false);
$cfg = \config('Debug');

    return $debug && $env !== 'production' && !empty($cfg->toolbarEnabled);
  }

  public static function inject(string $html): string
  {
    if (!self::enabled()) return $html;

    $cfg = \config('Debug');
    $sum = Profiler::summary();

    $total = number_format((float)$sum['total_ms'], 2);
    $peak  = number_format((float)$sum['peak_mb'], 2);
    $filesCount = is_array($sum['files']) ? count($sum['files']) : 0;
    $qCount = is_array($sum['queries']) ? count($sum['queries']) : 0;

    $route = $sum['route'] ?? [];
    $routeLine = htmlspecialchars((string)($route['method'] ?? '') . ' ' . (string)($route['path'] ?? ''), ENT_QUOTES,'UTF-8');
    $controller = htmlspecialchars((string)($route['uses'] ?? ''), ENT_QUOTES,'UTF-8');
    $routeName = htmlspecialchars((string)($route['name'] ?? ''), ENT_QUOTES,'UTF-8');

    $marksHtml = '';
    foreach (($sum['marks'] ?? []) as $m) {
      $n = htmlspecialchars((string)$m['name'], ENT_QUOTES,'UTF-8');
      $ms = number_format((float)$m['ms'], 2);
      $marksHtml .= "<tr><td>{$n}</td><td style='text-align:right'>{$ms} ms</td></tr>";
    }

    $queriesHtml = '';
    if (!empty($cfg->collectDb)) {
      foreach (($sum['queries'] ?? []) as $q) {
        $sql = htmlspecialchars((string)$q['sql'], ENT_QUOTES,'UTF-8');
        $ms = number_format((float)$q['ms'], 2);
        $queriesHtml .= "<tr><td><code>{$sql}</code></td><td style='white-space:nowrap;text-align:right'>{$ms} ms</td></tr>";
      }
    } else {
      $queriesHtml = "<tr><td colspan='2'>DB collection desactivado</td></tr>";
    }

    $filesHtml = '';
    if (!empty($cfg->collectFiles)) {
      foreach (($sum['files'] ?? []) as $f) {
        $filesHtml .= "<li><code>" . htmlspecialchars((string)$f, ENT_QUOTES,'UTF-8') . "</code></li>";
      }
    }

    // Vars (sin forzar sesión)
    $varsHtml = '';
    if (!empty($cfg->collectVars)) {
      $get = htmlspecialchars(json_encode($_GET, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?: "{}", ENT_QUOTES,'UTF-8');
      $post = htmlspecialchars(json_encode($_POST, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?: "{}", ENT_QUOTES,'UTF-8');

      $sess = null;
      if (session_status() === PHP_SESSION_ACTIVE) $sess = $_SESSION;
      $sessJson = $sess !== null
        ? htmlspecialchars(json_encode($sess, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?: "{}", ENT_QUOTES,'UTF-8')
        : '(sesión no iniciada: OK si esta ruta no usa sesión)';

      $varsHtml = "<h4>\$_GET</h4><pre>{$get}</pre><h4>\$_POST</h4><pre>{$post}</pre><h4>\$_SESSION</h4><pre>{$sessJson}</pre>";
    }

    $toolbar = <<<HTML
<!-- QFW Debug Toolbar -->
<style>
#qfw-toolbar{position:fixed;left:0;right:0;bottom:0;z-index:2147483646;font:12px/1.4 system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:var(--qfw-toolbar-bg, rgba(17,24,39,.92));color:var(--qfw-toolbar-text,#e6edf3);border-top:1px solid rgba(255,255,255,.10);backdrop-filter:saturate(1.2) blur(10px)}
#qfw-toolbar .bar{display:flex;align-items:center;gap:10px;padding:8px 10px}
#qfw-toolbar .pill{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:999px;background:var(--qfw-toolbar-pill, rgba(255,255,255,.10));cursor:pointer;user-select:none}
#qfw-toolbar .pill:hover{background:var(--qfw-toolbar-pill-hover, rgba(255,255,255,.14))}
#qfw-toolbar .sp{flex:1}
#qfw-toolbar .muted{color:var(--qfw-toolbar-muted, rgba(230,237,243,.65))}
#qfw-toolbar .btn{position:fixed;right:14px;bottom:56px;z-index:2147483647;width:44px;height:44px;border-radius:999px;background:var(--qfw-accent,#ff7a18);color:var(--qfw-accent-contrast,#111);border:none;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center}
#qfw-toolbar .btn:hover{filter:brightness(1.05)}
#qfw-panel{position:fixed;left:12px;right:12px;bottom:56px;max-height:70vh;z-index:2147483646;background:var(--qfw-toolbar-bg, rgba(11,15,20,.96));color:var(--qfw-toolbar-text,#e6edf3);border:1px solid rgba(255,255,255,.12);border-radius:12px;box-shadow:0 30px 80px rgba(0,0,0,.55);display:none;overflow:hidden}
#qfw-panel .head{display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.10)}
#qfw-panel .tabs{display:flex;gap:8px;flex-wrap:wrap}
#qfw-panel .tab{padding:6px 10px;border-radius:10px;background:rgba(255,255,255,.08);cursor:pointer}
#qfw-panel .tab.active{background:rgba(255,255,255,.14)}
#qfw-panel .content{padding:12px;overflow:auto;max-height:calc(70vh - 52px)}
#qfw-panel table{width:100%;border-collapse:collapse}
#qfw-panel td{padding:6px 8px;border-bottom:1px solid rgba(255,255,255,.08);vertical-align:top}
#qfw-panel code{color:#ffd39a}
#qfw-panel pre{background:rgba(255,255,255,.08);padding:10px;border-radius:10px;overflow:auto}
</style>

<div id="qfw-toolbar">
  <button class="btn" id="qfw-toggle" title="QFW Debug">🔥</button>
  <div class="bar">
    <div class="pill" data-tab="perf">⏱ <strong>{$total} ms</strong></div>
    <div class="pill" data-tab="route">🧭 <strong>{$routeName}</strong> <span class="muted">{$routeLine}</span></div>
    <div class="pill" data-tab="files">📦 <strong>{$filesCount}</strong> <span class="muted">files</span></div>
    <div class="pill" data-tab="db">🗄 <strong>{$qCount}</strong> <span class="muted">queries</span></div>
    <div class="sp"></div>
    <div class="muted">Peak: {$peak} MB</div>
  </div>
</div>

<div id="qfw-panel" aria-hidden="true">
  <div class="head">
    <div style="font-weight:700">Q_Framework Debug</div>
    <div class="muted" style="flex:1">{$routeLine} · {$controller}</div>
    <div class="tabs">
      <div class="tab active" data-tab="perf">Performance</div>
      <div class="tab" data-tab="route">Route</div>
      <div class="tab" data-tab="db">DB</div>
      <div class="tab" data-tab="files">Files</div>
      <div class="tab" data-tab="vars">Vars</div>
    </div>
    <div class="tab" id="qfw-close">✕</div>
  </div>

  <div class="content" id="qfw-content-perf">
    <table>{$marksHtml}</table>
  </div>

  <div class="content" id="qfw-content-route" style="display:none">
    <table>
      <tr><td>name</td><td><code>{$routeName}</code></td></tr>
      <tr><td>path</td><td><code>{$routeLine}</code></td></tr>
      <tr><td>uses</td><td><code>{$controller}</code></td></tr>
    </table>
  </div>

  <div class="content" id="qfw-content-db" style="display:none">
    <table>{$queriesHtml}</table>
  </div>

  <div class="content" id="qfw-content-files" style="display:none">
    <p class="muted">Included files: {$filesCount}</p>
    <ul style="margin:0;padding-left:18px">{$filesHtml}</ul>
  </div>

  <div class="content" id="qfw-content-vars" style="display:none">
    {$varsHtml}
  </div>
</div>

<script>
(function(){
  const toggle = document.getElementById('qfw-toggle');
  const panel = document.getElementById('qfw-panel');
  const close = document.getElementById('qfw-close');
  const pills = document.querySelectorAll('#qfw-toolbar .pill');
  const tabs = document.querySelectorAll('#qfw-panel .tab[data-tab]');

  function open(tab){
    panel.style.display='block';
    panel.setAttribute('aria-hidden','false');
    select(tab);
  }
  function hide(){
    panel.style.display='none';
    panel.setAttribute('aria-hidden','true');
  }
  function select(tab){
    tabs.forEach(t=>t.classList.toggle('active', t.dataset.tab===tab));
    ['perf','route','db','files','vars'].forEach(k=>{
      const el=document.getElementById('qfw-content-'+k);
      if (!el) return;
      el.style.display=(k===tab)?'block':'none';
    });
  }

  toggle && toggle.addEventListener('click', ()=> {
    if (panel.style.display==='block') hide(); else open('perf');
  });
  close && close.addEventListener('click', hide);

  pills.forEach(p=>p.addEventListener('click', ()=>open(p.dataset.tab||'perf')));
  tabs.forEach(t=>t.addEventListener('click', ()=>select(t.dataset.tab||'perf')));

  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') hide(); });
})();
</script>
<!-- /QFW Debug Toolbar -->
HTML;

    // Inserta antes de </body> si existe
    if (stripos($html, '</body>') !== false) {
      return preg_replace('/<\/body>/i', $toolbar . '</body>', $html, 1);
    }

    return $html . $toolbar;
  }
}
