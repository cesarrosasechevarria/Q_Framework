<?php
declare(strict_types=1);

namespace System\Core\Debug;

use System\Core\Debug\Profiler;

/**
 * PDOStatement con logging de ejecución (tiempo y SQL).
 * Se activa si Config\Debug::$collectDb y modo debug.
 */
class LoggedStatement extends \PDOStatement
{
  protected function __construct() {}

  public function execute(?array $params = null): bool
  {
    $t0 = microtime(true);
    $ok = parent::execute($params);
    $ms = (microtime(true) - $t0) * 1000;

    Profiler::addQuery($this->queryString ?? '', $ms, $params);

    return $ok;
  }
}
