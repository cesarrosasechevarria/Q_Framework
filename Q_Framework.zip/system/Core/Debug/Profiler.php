<?php
declare(strict_types=1);

namespace System\Core\Debug;

final class Profiler
{
  private static float $start = 0.0;

  /** @var array<string,float> */
  private static array $marks = [];

  /** @var array<string,mixed> */
  private static array $route = [];

  /** @var array<int,array{sql:string,ms:float,params:mixed}> */
  private static array $queries = [];

  public static function init(): void
  {
    if (self::$start > 0) return;
    self::$start = defined('QFW_START') ? (float)QFW_START : microtime(true);
    self::mark('start');
  }

  public static function mark(string $name): void
  {
    self::init();
    self::$marks[$name] = microtime(true);
  }

  public static function setRoute(array $info): void
  {
    self::$route = $info;
  }

  public static function addQuery(string $sql, float $ms, $params = null): void
  {
    self::$queries[] = [
      'sql' => $sql,
      'ms' => $ms,
      'params' => $params,
    ];
  }

  public static function summary(): array
  {
    self::init();
    $now = microtime(true);
    $totalMs = ($now - self::$start) * 1000;

    $marks = self::$marks;
    $marks['end'] = $now;

    // ordena por inserción (ya lo está)
    $pairs = [];
    $prevName = null;
    $prevTime = null;
    foreach ($marks as $n => $t) {
      if ($prevTime !== null) {
        $pairs[] = ['name' => $prevName . ' → ' . $n, 'ms' => ($t - $prevTime) * 1000];
      }
      $prevName = $n;
      $prevTime = $t;
    }

    return [
      'total_ms' => $totalMs,
      'peak_mb'  => memory_get_peak_usage(true) / 1024 / 1024,
      'marks'    => $pairs,
      'route'    => self::$route,
      'queries'  => self::$queries,
      'files'    => get_included_files(),
    ];
  }
}
