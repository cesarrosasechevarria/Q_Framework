<?php
declare(strict_types=1);

namespace System\Core;

use Throwable;

/**
 * KernelContext
 * -------------
 * Contexto por request para procesos persistentes (RoadRunner/Swoole/workers/CLI loops/tests).
 *
 * Evita fugas de estado entre requests (Request/Response/Session/Validator/Locale/etc.).
 *
 * Diseño:
 * - Stack (LIFO) para soportar sub-requests.
 * - Scoped services por request via scopedGetOrSet().
 */
final class KernelContext
{
  /** @var array<int,KernelContext> */
  private static array $stack = [];

  private Request $request;
  private Response $response;

  /** @var array<string,mixed> */
  private array $meta = [];

  /** @var array<string,mixed> */
  private array $scoped = [];

  private static bool $shutdownRegistered = false;

  private function __construct(Request $request, Response $response, array $meta = [])
  {
    $this->request  = $request;
    $this->response = $response;
    $this->meta     = $meta;
  }

  public static function begin(Request $request, Response $response, array $meta = []): void
  {
    // Registrar limpieza por shutdown una sola vez
    if (!self::$shutdownRegistered) {
      self::$shutdownRegistered = true;
      register_shutdown_function([self::class, 'shutdown']);
    }

    self::$stack[] = new self($request, $response, $meta);
  }

  public static function current(): ?self
  {
    $n = count(self::$stack);
    return $n > 0 ? self::$stack[$n - 1] : null;
  }

  public static function end(): void
  {
    // Pop current
    array_pop(self::$stack);

    // Si ya no hay contexto activo, limpiar request-scoped caches.
    if (empty(self::$stack)) {
      // Cerrar sesión para liberar locks en workers persistentes
      if (Session::isStarted()) {
        @session_write_close();
      }

      // Limpieza request-scoped de Services (si existe)
      if (class_exists('\\Config\\Services') && method_exists('\\Config\\Services', 'clearRequestScoped')) {
        try {
          \Config\Services::clearRequestScoped();
        } catch (Throwable $e) {
          // no-op: no interrumpir shutdown/end
        }
      }
    }
  }

  /**
   * Ejecuta un callback dentro de un contexto (útil en CLI/tests).
   * Siempre hace end() en finally.
   */
  public static function run(Request $request, Response $response, callable $fn, array $meta = [])
  {
    self::begin($request, $response, $meta);
    try {
      return $fn();
    } finally {
      self::end();
    }
  }

  /** Limpieza en shutdown (fatals incluidos). */
  public static function shutdown(): void
  {
    // Vaciar stack completo
    if (!empty(self::$stack)) {
      self::$stack = [];
    }
    // Intentar limpieza request-scoped
    if (class_exists('\\Config\\Services') && method_exists('\\Config\\Services', 'clearRequestScoped')) {
      try {
        \Config\Services::clearRequestScoped();
      } catch (Throwable $e) {
        // ignore
      }
    }
    // Liberar locks de sesión si está abierta
    if (Session::isStarted()) {
      @session_write_close();
    }
  }

  public function request(): Request
  {
    return $this->request;
  }

  public function response(): Response
  {
    return $this->response;
  }

  public function setResponse(Response $response): void
  {
    $this->response = $response;
  }

  /**
   * Obtener metadata del contexto (tenant, request_id, etc.).
   */
  public function meta(string $key, $default = null)
  {
    return array_key_exists($key, $this->meta) ? $this->meta[$key] : $default;
  }

  /**
   * Singleton por request.
   * @template T
   * @param string $key
   * @param callable():T $factory
   * @return T
   */
  public function scopedGetOrSet(string $key, callable $factory)
  {
    if (!array_key_exists($key, $this->scoped)) {
      $this->scoped[$key] = $factory();
    }
    return $this->scoped[$key];
  }
}
