<?php
declare(strict_types=1);

namespace System\Core;

/**
 * ServiceProvider base
 *
 * Provee utilidades para que el usuario extienda fácilmente:
 * - bind/singleton en el container
 * - registrar listeners
 * - helper para agregar rutas con prefijo
 */
abstract class ServiceProvider implements ProviderInterface
{
  /** Container global del framework (lazy). */
  protected function container(): Container
  {
    return Providers::container();
  }

  /** Bind factory */
  protected function bind(string $id, callable $factory): void
  {
    $this->container()->bind($id, $factory);
  }

  /** Singleton */
  protected function singleton(string $id, callable $factory): void
  {
    $this->container()->singleton($id, $factory);
  }

  /** Events shortcut */
  protected function on(string $event, callable $fn, int $priority = 0): void
  {
    Events::on($event, $fn, $priority);
  }

  /** Rutas shortcut */
  protected function route(string $name, string $method, string $path, string $uses, array $opts = []): void
  {
    Routes::add($name, $method, $path, $uses, $opts);
  }
}
