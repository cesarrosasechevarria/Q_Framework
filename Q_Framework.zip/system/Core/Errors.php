<?php
declare(strict_types=1);

namespace System\Core;

use Throwable;

final class Errors
{
  private static string $env = 'production';
  private static bool $debug = false;

  /**
   * Heurística estática para determinar si la respuesta debe ser JSON.
   *
   * Errors es un handler global y no siempre tiene una instancia de Request,
   * por eso detecta intención JSON vía headers/URI.
   */
  private static function wantsJson(): bool
  {
    $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
    if ($accept !== '' && (str_contains($accept, 'application/json') || str_contains($accept, '+json'))) {
      return true;
    }

    $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? ''));
    if ($ct !== '' && str_contains($ct, 'json')) {
      return true;
    }

    $xrw = strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''));
    if ($xrw === 'xmlhttprequest') {
      return true;
    }

    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    if ($uri !== '') {
      // /api/* o /v1/*, /v2/*, etc.
      $path = parse_url($uri, PHP_URL_PATH);
      if (is_string($path) && preg_match('#^/(api|v\d+)(/|$)#i', $path)) {
        return true;
      }
      // /algo.json
      if (preg_match('#\.json($|\?)#i', $uri)) {
        return true;
      }
      // ?format=json
      if (preg_match('#[\?&](format|output)=json($|&|\b)#i', $uri)) {
        return true;
      }
    }

    return false;
  }

  public static function register(string $env = 'production', bool $debug = false): void
  {
    self::$env = $env;
    self::$debug = $debug;

    error_reporting(E_ALL);

    ini_set('display_errors', ($debug && $env !== 'production') ? '1' : '0');
    ini_set('display_startup_errors', ($debug && $env !== 'production') ? '1' : '0');

    set_error_handler(function(int $severity, string $message, string $file, int $line) {
      if (!(error_reporting() & $severity)) return false;
      throw new \ErrorException($message, 0, $severity, $file, $line);
    });

    set_exception_handler(function(Throwable $e) {
      self::logThrowable($e);

      // Evita mezclar salida parcial con la vista de error (HTML/JSON)
      self::cleanOutputBuffers();

      $status  = 500;
      $headers = [];
      $payload = null;

      if ($e instanceof \System\Core\HttpException) {
        $status  = $e->status;
        $headers = $e->headers ?? [];
        $payload = $e->payload ?? null;
      }

      http_response_code($status);

      // Headers extra (si aplica)
      foreach ($headers as $hk => $hv) {
        if (is_int($hk)) {
          header((string)$hv);
        } else {
          header($hk . ': ' . (string)$hv);
        }
      }

      // JSON automático para API/AJAX
      if (self::wantsJson()) {
        header('Content-Type: application/json; charset=utf-8');
        $out = [
          'status'  => $status,
          'error'   => true,
          'message' => $e->getMessage(),
        ];
        if (is_array($payload)) $out = array_merge($out, $payload);
        echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return;
      }

      if (self::$debug && self::$env !== 'production') {
        echo self::debugPage($e);
        return;
      }

      echo self::page($status, [
        'title' => ($status >= 500) ? 'Error interno' : 'Error',
        'message' => $e->getMessage() ?: 'Ocurrió un problema inesperado al procesar la solicitud.',
      ]);
    });

    register_shutdown_function(function() {
      $err = error_get_last();
      if (!$err) return;

      if (in_array($err['type'] ?? 0, [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        // Limpia cualquier salida previa (por ejemplo, "Fatal error: ..." impreso por PHP)
        self::cleanOutputBuffers();
        Logger::error("Fatal: " . ($err['message'] ?? 'fatal'), $err);
        http_response_code(500);

        // JSON automático para API/AJAX (también en fatales)
        if (self::wantsJson()) {
          header('Content-Type: application/json; charset=utf-8');
          $msg = (self::$debug && self::$env !== 'production')
            ? (string)($err['message'] ?? 'Fatal error')
            : 'Error interno';
          echo json_encode([
            'status'  => 500,
            'error'   => true,
            'message' => $msg,
          ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
          return;
        }

        if (self::$debug && self::$env !== 'production') {
          $e = new \ErrorException((string)($err['message'] ?? 'Fatal error'), 0, (int)($err['type'] ?? E_ERROR), (string)($err['file'] ?? ''), (int)($err['line'] ?? 0));
          echo self::debugPage($e, $err);
          return;
        }

        echo self::page(500, [
          'title' => 'Error interno',
          'message' => 'Ocurrió un problema inesperado al procesar la solicitud.',
        ]);
      }
    });
  }

  /**
   * Limpia buffers de salida para que una página fatal no quede “encima” de la vista debug.
   * Útil cuando display_errors=1 imprime el error antes del shutdown handler.
   */
  private static function cleanOutputBuffers(): void
  {
    try {
      while (ob_get_level() > 0) {
        @ob_end_clean();
      }
    } catch (\Throwable $ignore) {
      // ignore
    }
  }

  private static function logThrowable(Throwable $e): void
  {
    try {
      Logger::error($e->getMessage(), [
        'type' => get_class($e),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString(),
      ]);
    } catch (Throwable $ignore) {}
  }

  /** Página simple (prod). */
  public static function page(int $code, array $data = []): string
  {
    $title = htmlspecialchars((string)($data['title'] ?? 'Error'), ENT_QUOTES, 'UTF-8');
    $msg   = htmlspecialchars((string)($data['message'] ?? ''), ENT_QUOTES, 'UTF-8');

    return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'.
      '<title>'.$title.'</title>'.
      '<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;display:flex;min-height:100vh;margin:0;background:#0b1220;color:#e8eefc}main{margin:auto;max-width:720px;padding:28px}h1{font-size:22px;margin:0 0 10px}p{opacity:.9;line-height:1.5}code{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:6px}</style>'.
      '</head><body><main><h1>'.$code.' - '.$title.'</h1><p>'.$msg.'</p></main></body></html>';
  }

  /**
   * Página 404 estándar.
   *
   * Se invoca desde el kernel cuando no hay ruta resuelta.
   * Debe existir para evitar errores fatales en entornos dev.
   */
  public static function notFound(?string $message = null): string
  {
    $msg = $message ?: 'La página solicitada no existe o fue movida.';
    return self::page(404, [
      'title'   => 'No encontrado',
      'message' => $msg,
    ]);
  }

  /** Página 405 estándar. */
  public static function methodNotAllowed(array $allowed = [], ?string $message = null): string
  {
    $allowed = array_values(array_filter(array_map('strval', $allowed)));
    $allowStr = $allowed ? ('Métodos permitidos: ' . implode(', ', $allowed) . '.') : '';
    $msg = $message ?: 'El recurso existe, pero el método HTTP usado no está permitido.';
    if ($allowStr) $msg .= ' ' . $allowStr;
    return self::page(405, [
      'title'   => 'Método no permitido',
      'message' => $msg,
    ]);
  }

  /** Página debug (dev) con sugerencias. */
  private static function debugPage(Throwable $e, ?array $fatal = null): string
  {
    $title = htmlspecialchars(get_class($e), ENT_QUOTES, 'UTF-8');
    $message = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    $file = htmlspecialchars($e->getFile(), ENT_QUOTES, 'UTF-8');
    $line = (int)$e->getLine();

    $method = htmlspecialchars($_SERVER['REQUEST_METHOD'] ?? 'CLI', ENT_QUOTES, 'UTF-8');
    $uriStr = htmlspecialchars($_SERVER['REQUEST_URI'] ?? ($_SERVER['argv'][0] ?? 'cli'), ENT_QUOTES, 'UTF-8');
    $uri = $method . ' ' . $uriStr;

    $suggestions = self::suggestionsFromThrowable($e);
    $sugHtml = '';
    if (!empty($suggestions)) {
      $sugHtml .= '<section class="card"><div class="card-h"><h2>Posibles soluciones</h2></div><div class="card-b"><ol class="list">';
      foreach ($suggestions as $s) $sugHtml .= '<li>' . $s . '</li>';
      $sugHtml .= '</ol></div></section>';
    }

    $trace = htmlspecialchars((string)$e, ENT_QUOTES, 'UTF-8');
    $fatalBlock = '';
    if ($fatal) {
      $fType = htmlspecialchars((string)($fatal['type'] ?? ''), ENT_QUOTES, 'UTF-8');
      $fMsg  = htmlspecialchars((string)($fatal['message'] ?? ''), ENT_QUOTES, 'UTF-8');
      $fFile = htmlspecialchars((string)($fatal['file'] ?? ''), ENT_QUOTES, 'UTF-8');
      $fLine = (int)($fatal['line'] ?? 0);
      $fatalBlock = '<section class="card"><div class="card-h"><h2>Fatal</h2></div><div class="card-b"><div class="mono">'.$fType.'</div><div class="mono">'.$fMsg.'</div><div class="muted">'.$fFile.':'.$fLine.'</div></div></section>';
    }

    // Try to extract a small code frame
    $codeFrame = '';
    try {
      if (is_file($e->getFile()) && is_readable($e->getFile())) {
        $lines = @file($e->getFile());
        if (is_array($lines)) {
          $start = max(1, $line - 6);
          $end   = min(count($lines), $line + 6);
          $buf = '';
          for ($i=$start; $i<=$end; $i++) {
            $ln = str_pad((string)$i, 4, ' ', STR_PAD_LEFT);
            $src = rtrim($lines[$i-1], "\r\n");
            $srcEsc = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
            $cls = ($i === $line) ? 'line hit' : 'line';
            $buf .= '<div class="'.$cls.'"><span class="ln">'.$ln.'</span><span class="src">'.$srcEsc.'</span></div>';
          }
          $codeFrame = '<section class="card"><div class="card-h"><h2>Contexto</h2><div class="actions"><button class="btn" type="button" data-copy="#qfw_file">Copiar ruta</button><button class="btn" type="button" data-copy="#qfw_trace">Copiar trace</button></div></div><div class="card-b"><div class="muted mono" id="qfw_file">'.$file.':'.$line.'</div><div class="codeframe">'.$buf.'</div></div></section>';
        }
      }
    } catch (\Throwable $ignore) {}

    $env = htmlspecialchars(self::$env, ENT_QUOTES, 'UTF-8');
    $isDev = (self::$env !== 'production');

    return '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' .
      '<title>Q_Framework Debug</title>' .
      '<style>
        :root{
          color-scheme: light dark;
          --bg1:#0b1220; --bg2:#0f1a2e; --card:#0f1a2e; --card2:rgba(255,255,255,.06);
          --text:#e6edf3; --muted:rgba(230,237,243,.72); --border:rgba(255,255,255,.12);
          --accent:#ff8a3d; --accent2:#8ab4ff;
          --shadow: 0 30px 80px rgba(0,0,0,.45);
          --radius:18px;
          --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        }
        @media (prefers-color-scheme: light){
          :root{ --bg1:#f6f7fb; --bg2:#ffffff; --card:#ffffff; --card2:#f1f2f6; --text:#0b1020; --muted:rgba(11,16,32,.70); --border:rgba(11,16,32,.14); --shadow: 0 10px 30px rgba(0,0,0,.08); --accent:#ff7a18; --accent2:#2b5cff;}
        }
        html[data-theme="dark"]{ --bg1:#0b1220; --bg2:#0f1a2e; --card:#0f1a2e; --card2:rgba(255,255,255,.06); --text:#e6edf3; --muted:rgba(230,237,243,.72); --border:rgba(255,255,255,.12); --shadow: 0 30px 80px rgba(0,0,0,.45); --accent:#ff8a3d; --accent2:#8ab4ff;}
        html[data-theme="light"]{ --bg1:#f6f7fb; --bg2:#ffffff; --card:#ffffff; --card2:#f1f2f6; --text:#0b1020; --muted:rgba(11,16,32,.70); --border:rgba(11,16,32,.14); --shadow: 0 10px 30px rgba(0,0,0,.08); --accent:#ff7a18; --accent2:#2b5cff;}
        *{box-sizing:border-box}
        body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial; background: radial-gradient(1200px 800px at 10% 10%, rgba(255,138,61,.16), transparent 60%), radial-gradient(1200px 800px at 90% 20%, rgba(138,180,255,.14), transparent 55%), linear-gradient(180deg,var(--bg1),var(--bg2)); color:var(--text); min-height:100vh;}
        a{color:var(--accent2); text-decoration:none}
        .wrap{max-width:1100px; margin:0 auto; padding:26px 18px 46px;}
        .topbar{display:flex; align-items:center; justify-content:space-between; gap:14px; padding:14px 16px; background:rgba(0,0,0,.18); border:1px solid var(--border); border-radius:var(--radius); box-shadow:var(--shadow); backdrop-filter: blur(10px);}
        .brand{display:flex; align-items:center; gap:10px;}
        .logo{width:38px;height:38px;border-radius:14px;background:linear-gradient(135deg,var(--accent),#ffd7b5); display:flex;align-items:center;justify-content:center;color:#111;font-weight:900}
        .meta{display:flex; flex-wrap:wrap; gap:10px; align-items:center}
        .pill{font-size:12px; padding:6px 10px; border:1px solid var(--border); border-radius:999px; background:rgba(255,255,255,.06)}
        .btn{cursor:pointer; border:1px solid var(--border); background:rgba(255,255,255,.06); color:var(--text); padding:8px 12px; border-radius:12px; font-weight:700}
        .btn:hover{background:rgba(255,255,255,.10)}
        .grid{display:grid; grid-template-columns: 1.1fr .9fr; gap:16px; margin-top:16px}
        @media (max-width: 980px){ .grid{grid-template-columns:1fr} }
        .card{background:var(--card); border:1px solid var(--border); border-radius:var(--radius); box-shadow:var(--shadow); overflow:hidden}
        .card-h{display:flex; align-items:flex-start; justify-content:space-between; gap:12px; padding:14px 16px; border-bottom:1px solid var(--border); background:linear-gradient(180deg, rgba(255,255,255,.06), transparent)}
        .card-b{padding:14px 16px}
        h1{margin:0; font-size:18px}
        h2{margin:0; font-size:14px; letter-spacing:.2px; text-transform:uppercase; opacity:.9}
        .muted{color:var(--muted)}
        .mono{font-family:var(--mono)}
        .err-title{font-size:20px; font-weight:900; margin:0}
        .err-msg{margin-top:6px; font-size:14px; line-height:1.5}
        .list{margin:0; padding-left:18px}
        .list li{margin:8px 0; line-height:1.45}
        .actions{display:flex; gap:8px; flex-wrap:wrap; justify-content:flex-end}
        pre{margin:0; white-space:pre-wrap; word-break:break-word; font-family:var(--mono); font-size:12.5px; line-height:1.5; background:rgba(0,0,0,.18); border:1px solid var(--border); padding:12px; border-radius:14px}
        details{border:1px solid var(--border); border-radius:14px; overflow:hidden; background:rgba(255,255,255,.04)}
        summary{cursor:pointer; padding:12px 12px; font-weight:800}
        .codeframe{margin-top:10px; border:1px solid var(--border); border-radius:14px; overflow:hidden}
        .line{display:flex; gap:12px; padding:6px 10px; background:rgba(0,0,0,.12); border-bottom:1px solid rgba(255,255,255,.06)}
        .line:last-child{border-bottom:none}
        .line.hit{background:rgba(255,138,61,.14)}
        .ln{width:44px; opacity:.75; font-family:var(--mono)}
        .src{flex:1; font-family:var(--mono); overflow:auto}
        .toast{position:fixed; left:50%; transform:translateX(-50%); bottom:18px; background:rgba(0,0,0,.70); color:white; padding:10px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.15); display:none; z-index:9999}
      </style>' .
      '</head><body><div class="wrap">' .
        '<div class="topbar"><div class="brand"><div class="logo">Q</div><div><div style="font-weight:900">Q_Framework Debug</div><div class="muted" style="font-size:12px">Modo '.($isDev ? 'development' : 'production').' • '.$uri.'</div></div></div>' .
        '<div class="meta"><span class="pill mono">'.$env.'</span><span class="pill mono">'.$method.'</span><button class="btn" type="button" data-theme-toggle title="Tema">🌓 Tema</button></div></div>' .
        '<div class="grid">' .
          '<section class="card"><div class="card-h"><div><h2>Error</h2><div class="err-title">'.$title.'</div><div class="err-msg">'.$message.'</div></div></div>' .
          '<div class="card-b"><div class="muted">Ubicación</div><div class="mono" style="margin-top:6px">'.$file.':'.$line.'</div></div></section>' .
          '<section class="card"><div class="card-h"><h2>Entorno</h2></div><div class="card-b"><div class="muted">Ruta</div><div class="mono" style="margin-top:6px">'.$uri.'</div><div style="height:10px"></div><div class="muted">PHP</div><div class="mono" style="margin-top:6px">'.htmlspecialchars(PHP_VERSION, ENT_QUOTES, 'UTF-8').'</div><div style="height:10px"></div><div class="muted">Debug</div><div class="mono" style="margin-top:6px">'.(self::$debug ? 'true' : 'false').'</div></div></section>' .
        '</div>' .
        $codeFrame .
        $sugHtml .
        '<section class="card"><div class="card-h"><h2>Trace</h2><div class="actions"><button class="btn" type="button" data-copy="#qfw_trace">Copiar</button></div></div><div class="card-b"><details open><summary>Ver stack trace</summary><div style="padding:12px"><pre id="qfw_trace">'.$trace.'</pre></div></details></div></section>' .
        $fatalBlock .
        '<section class="card"><div class="card-h"><h2>Tip</h2></div><div class="card-b"><div class="muted" style="line-height:1.55">Si este error es por <span class="mono">función no definida</span>, normalmente te falta cargar un helper. Ejemplo: <span class="mono">helper(\'url\');</span> o <span class="mono">helper(\'security\');</span> o <span class="mono">helper(\'mi_helper\');</span> en tu <span class="mono">BaseController</span> o en el <span class="mono">__construct()</span> del controller.</div></div></section>' .
      '</div><div class="toast" id="qfw_toast">Copiado</div>' .
      '<script>
        (function(){
          const root=document.documentElement;
          const key="qfw_theme";
          const saved=localStorage.getItem(key);
          if(saved==="light"||saved==="dark") root.setAttribute("data-theme", saved);
          const btn=document.querySelector("[data-theme-toggle]");
          if(btn) btn.addEventListener("click", ()=>{ const cur=root.getAttribute("data-theme")||""; const next=(cur==="dark")?"light":"dark"; root.setAttribute("data-theme", next); localStorage.setItem(key,next); });
          const toast=document.getElementById("qfw_toast");
          function showToast(txt){ if(!toast) return; toast.textContent=txt||"Copiado"; toast.style.display="block"; clearTimeout(toast.__t); toast.__t=setTimeout(()=>toast.style.display="none",1200); }
          document.querySelectorAll("[data-copy]").forEach(el=>{
            el.addEventListener("click", async ()=>{
              const sel=document.querySelector(el.getAttribute("data-copy"));
              const text=sel ? sel.textContent : "";
              try{ await navigator.clipboard.writeText(text); showToast("Copiado ✅"); }catch(e){ showToast("No se pudo copiar"); }
            });
          });
        })();
      </script></body></html>';
  }

  private static function suggestionsFromThrowable(Throwable $e): array
  {
    $msg = $e->getMessage();
    $out = [];

    // Undefined function
    if (preg_match('/Call to undefined function\s+([A-Za-z0-9_\\\\]+)\s*\(/', $msg, $m)) {
      $fn = $m[1];

      $helper = self::helperForFunction($fn);
      if ($helper === '@core') {
        $out[] = 'La función <span class="mono">'.$fn.'()</span> es <strong>core</strong> y debería estar disponible siempre. Revisa que se esté cargando <span class="mono">system/Support/Functions.php</span> (autoload.php / bootstrap).';
      } elseif ($helper) {
        $out[] = 'Carga el helper <span class="mono">'.$helper.'</span>: <span class="mono">helper(\''.$helper.'\');</span>';
        $out[] = 'O en tu controller: <span class="mono">protected array $helpers = [\''.$helper.'\'];</span>';
      } else {
        $out[] = 'Revisa si olvidaste incluir el archivo que define <span class="mono">'.$fn.'()</span>.';
      }
    }

    // Class not found
    if (preg_match('/Class\s+[\"\']([^\"\']+)[\"\']\s+not found/', $msg, $m)) {
      $cls = $m[1];
      $vendorSug = self::vendorSuggestionForClass($cls);
      if ($vendorSug) $out[] = $vendorSug;
      $out[] = 'Si es una librería externa, asegúrate de incluir su autoload manualmente (tu /vendor) o <span class="mono">vendor/autoload.php</span> si lo usas.';
    }

    // Require failed
    if (preg_match('/Failed opening required\s+[\"\']([^\"\']+)[\"\']/', $msg, $m)) {
      $out[] = 'No se encontró el archivo requerido: <span class="mono">'.$m[1].'</span>. Verifica rutas y permisos.';
    }

    return array_values(array_unique($out));
  }

  private static function helperForFunction(string $fn): ?string
  {
    $fn = trim($fn);

    // En archivos con namespace, PHP puede mostrar algo como App\Controllers\base_url; nos quedamos con el nombre real.
    $short = preg_replace('~^.*\\\\~', '', $fn);
    $shortLower = strtolower((string)$short);

    // 1) Mapa central (si existe)
    try {
      $map = \config('FunctionMap'); // namespace Config\FunctionMap
      if (is_object($map)) {
        // Prefijos
        if (property_exists($map, 'prefixToHelper') && is_array($map->prefixToHelper)) {
          foreach ($map->prefixToHelper as $prefix => $helper) {
            if (str_starts_with((string)$short, (string)$prefix) || str_starts_with($shortLower, strtolower((string)$prefix))) {
              return (string)$helper;
            }
          }
        }
        // Funciones exactas
        if (property_exists($map, 'fnToHelper') && is_array($map->fnToHelper)) {
          if (isset($map->fnToHelper[$shortLower])) return (string)$map->fnToHelper[$shortLower];
        }
      }
    } catch (\Throwable $t) {
      // ignore: si config() no está disponible por alguna razón, seguimos con fallback interno
    }
    // 2) Fallback interno (si no existe FunctionMap): reglas mínimas
    $securityFns = ['csrf_field','csrf_token','csrf_meta','csp_nonce','csp_attr'];
    if (in_array($shortLower, $securityFns, true)) return 'security';

    $urlFns = ['base_url','site_url','current_url','redirect','route_url','asset_url','url'];
    if (in_array($shortLower, $urlFns, true)) return 'url';

    $pagFns = ['paginate','pager_links'];
    if (in_array($shortLower, $pagFns, true)) return 'pagination';

    if ($shortLower === 'e') return 'view';

    return null;
  }


  private static function vendorSuggestionForClass(string $cls): ?string
  {
    $cls = ltrim($cls, '\\');

    if (str_starts_with($cls, 'EmailValidation\\')) {
      return 'Para validar emails con validmail: <span class="mono">require_once ROOTPATH.\'vendor/validmail/autoload.php\';</span>';
    }
    if (str_starts_with($cls, 'libphonenumber\\')) {
      return 'Para validar teléfonos con libphonenumber: <span class="mono">require_once ROOTPATH.\'vendor/phonevalid/autoload.php\';</span>';
    }
    return null;
  }
}
