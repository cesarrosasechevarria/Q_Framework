<?php
declare(strict_types=1);

namespace System\Core;

/**
 * PluginManager: resuelve módulos habilitados con estado runtime (por tenant).
 */
final class PluginManager
{
  /**
   * @param array<int,string> $baseEnabled
   * @return array<int,string>
   */
  public static function apply(array $baseEnabled, string $modulesAbsPath, object $cfg): array
  {
    $available = self::discover($modulesAbsPath);

    $enabled = array_values(array_filter(array_map('strval', $baseEnabled)));

    // Si no hay módulos disponibles, retornar base
    if (!$available) return $enabled;

    // runtime state
    $state = ModuleState::load();
    $mode = strtolower((string)($state['mode'] ?? ($cfg->stateMode ?? 'override')));
    if (!in_array($mode, ['override','merge'], true)) $mode = 'override';

    $sEnabled = array_values(array_filter(array_map('strval', (array)($state['enabled'] ?? []))));
    $sDisabled= array_values(array_filter(array_map('strval', (array)($state['disabled'] ?? []))));

    if ($sEnabled || $sDisabled) {
      if ($mode === 'override' && $sEnabled) {
        $enabled = $sEnabled;
      } else {
        $enabled = array_values(array_unique(array_merge($enabled, $sEnabled)));
      }
      if ($sDisabled) {
        $enabled = array_values(array_filter($enabled, fn($m)=>!in_array($m, $sDisabled, true)));
      }
    }

    // filtra a módulos existentes
    $enabled = array_values(array_filter($enabled, fn($m)=>in_array($m, $available, true)));
    return $enabled;
  }

  /** @return array<int,string> */
  public static function discover(string $modulesAbsPath): array
  {
    if (!is_dir($modulesAbsPath)) return [];
    $out = [];
    foreach (scandir($modulesAbsPath) ?: [] as $d) {
      if ($d === '.' || $d === '..') continue;
      if (is_dir($modulesAbsPath . DIRECTORY_SEPARATOR . $d)) {
        $out[] = (string)$d;
      }
    }
    sort($out);
    return $out;
  }
}
