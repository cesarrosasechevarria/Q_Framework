<?php
declare(strict_types=1);

namespace System\Core;

final class RouteCollection
{
  private array $routes = [
    'GET' => [],
    'POST' => [],
    'PUT' => [],
    'PATCH' => [],
    'DELETE' => [],
    'ANY' => [],
  ];

  private array $names = [];
  private array $groupStack = [];

  /**
   * Scoped AutoRoute definitions.
   * Each item:
   *  - prefix: '/funciones'
   *  - namespaces: ['App\\Controllers\\Funciones']
   *  - opts: ['filters'=>['csrf'], ...]
   */
  private array $autoScopes = [];

  /**
   * Define a scoped AutoRoute.
   *
   * Example:
   *   $routes->auto('/funciones', 'App\\Controllers\\Funciones', [
   *     'filters' => ['csrf'],
   *     'defaultController' => 'Home',
   *     'defaultMethod' => 'index',
   *   ]);
   */
  public function auto(string $prefix, string|array $namespaces, array $opts = []): void
  {
    $prefix = '/' . trim($prefix, '/');
    if ($prefix === '//') $prefix = '/';

    // Permite definir AutoRoute dentro de group(): hereda prefijo + opts (filters/guard/etc.)
    // Ej:
    // $routes->group('/funciones', ['filters'=>['csrf']], fn($r)=> $r->auto('/', 'App\\Controllers\\Funciones'));
    foreach ($this->groupStack as $g) {
      $gPrefix = (string)($g['prefix'] ?? '/');
      $gPrefix = '/' . trim($gPrefix, '/');
      if ($gPrefix === '//') $gPrefix = '/';

      // Combina prefijos igual que add()
      $prefix = rtrim($gPrefix, '/') . ($prefix === '/' ? '' : $prefix);
      $prefix = rtrim(preg_replace('#/+#', '/', $prefix), '/') ?: '/';

      // Hereda opts del group (filters/guard)
      $opts = self::mergeOpts((array)($g['opts'] ?? []), $opts);
    }

    $nsList = is_array($namespaces) ? $namespaces : [$namespaces];
    $nsList = array_values(array_filter(array_map(fn($n) => trim((string)$n, '\\'), $nsList)));
    if (!$nsList) $nsList = ['App\\Controllers'];

    $this->autoScopes[] = [
      'prefix' => $prefix,
      'namespaces' => $nsList,
      'opts' => $opts,
    ];
  }

  public function get(string $path, string $uses, array $opts = []): void { $this->add('GET', $path, $uses, $opts); }
  public function post(string $path, string $uses, array $opts = []): void { $this->add('POST', $path, $uses, $opts); }
  public function put(string $path, string $uses, array $opts = []): void { $this->add('PUT', $path, $uses, $opts); }
  public function patch(string $path, string $uses, array $opts = []): void { $this->add('PATCH', $path, $uses, $opts); }
  public function delete(string $path, string $uses, array $opts = []): void { $this->add('DELETE', $path, $uses, $opts); }
  public function any(string $path, string $uses, array $opts = []): void { $this->add('ANY', $path, $uses, $opts); }

  public function group(string $prefix, array $opts, callable $cb): void
  {
    $prefix = '/' . trim($prefix, '/');
    if ($prefix === '//') $prefix = '/';

    $this->groupStack[] = ['prefix' => $prefix, 'opts' => $opts];
    $cb($this);
    array_pop($this->groupStack);
  }

  public function compile(): array
  {
    $out = $this->routes;

    if (!empty($out['ANY'])) {
      foreach (['GET','POST','PUT','PATCH','DELETE'] as $m) {
        foreach ($out['ANY'] as $p => $def) {
          if (!isset($out[$m][$p])) $out[$m][$p] = $def;
        }
      }
    }
    unset($out['ANY']);

    $out['_names'] = $this->names;
    $out['_auto']  = $this->autoScopes;
    return $out;
  }

  private function add(string $method, string $path, string $uses, array $opts): void
  {
    $path = '/' . ltrim($path, '/');
    $path = rtrim(preg_replace('#/+#', '/', $path), '/') ?: '/';

    foreach ($this->groupStack as $g) {
      $path = rtrim($g['prefix'], '/') . ($path === '/' ? '' : $path);

      // v9: merge PRO de opts (filters + guard heredable)
      $opts = self::mergeOpts((array)($g['opts'] ?? []), $opts);
    }

    // Permite shorthand tipo CI: 'carpeta.controller' (controller.method) o 'admin.users.edit' (folder.controller.method)
    $uses = self::normalizeUses($uses);

    $def = array_merge(['uses' => $uses], $opts);
    $this->routes[$method][$path] = $def;

    if (!empty($def['as'])) {
      $this->names[(string)$def['as']] = [$method, $path];
    }
  }

  
  /**
   * Normaliza "uses" para permitir sintaxis corta estilo CI:
   * - 'Home@index' (clásico)
   * - 'Home' -> Home@index
   * - 'carpeta.controller' -> App\Controllers\Carpeta@controller
   * - 'admin.users.edit' -> App\Controllers\Admin\Users@edit
   * - 'Admin\Users@edit' -> App\Controllers\Admin\Users@edit
   */
  private static function normalizeUses(string $uses): string
  {
    $uses = trim($uses);
    if ($uses === '') return $uses;

    $defaultNs = 'App\\Controllers';

    // Si ya viene como Clase@metodo
    if (str_contains($uses, '@')) {
      [$classPart, $methodPart] = explode('@', $uses, 2);
      $classPart  = trim((string)$classPart);
      $methodPart = trim((string)$methodPart);
      $class  = self::normalizeClassPart($classPart, $defaultNs);
      $method = self::normalizeMethodPart($methodPart);
      return $class . '@' . ($method ?: 'index');
    }

    // Si viene como controller.method o folder.controller.method (dots)
    if (str_contains($uses, '.')) {
      $parts = array_values(array_filter(explode('.', $uses), fn($p) => $p !== ''));
      if (count($parts) >= 2) {
        $methodPart = array_pop($parts);
        $classPart  = implode('\\', array_map([self::class, 'toPascal'], $parts));
        $class  = self::normalizeClassPart($classPart, $defaultNs);
        $method = self::normalizeMethodPart((string)$methodPart);
        return $class . '@' . ($method ?: 'index');
      }
    }

    // Solo clase (con o sin namespace)
    $class = self::normalizeClassPart($uses, $defaultNs);
    return $class . '@index';
  }

  private static function normalizeClassPart(string $classPart, string $defaultNs): string
  {
    $classPart = trim($classPart, " \\");
    if ($classPart === '') return $defaultNs . '\\Home';

    // Acepta dots en classPart: Admin.Users -> Admin\Users
    $classPart = str_replace('.', '\\', $classPart);

    // Normaliza segmentos a PascalCase si vienen en minúsculas o con guiones
    $segs = array_values(array_filter(explode('\\', $classPart), fn($s) => $s !== ''));
    $segs = array_map(function($seg){
      $seg = (string)$seg;
      // si tiene '-' '_' o es todo minúscula, lo pasamos a Pascal
      if (preg_match('/[-_]/', $seg) || $seg === strtolower($seg)) {
        return self::toPascal($seg);
      }
      return $seg;
    }, $segs);

    $classPart = implode('\\', $segs);

    // Si ya es fully-qualified (App\..., System\..., Vendor\...)
    if (str_contains($classPart, '\\')) {
      if (str_starts_with($classPart, 'App\\') || str_starts_with($classPart, 'System\\')) {
        return $classPart;
      }
      // Relativo: Admin\Users -> App\Controllers\Admin\Users
      return $defaultNs . '\\' . $classPart;
    }

    // Simple: Home -> App\Controllers\Home
    return $defaultNs . '\\' . self::toPascal($classPart);
  }

  private static function toPascal(string $c): string
  {
    $c = str_replace(['-', '_'], ' ', strtolower(trim($c)));
    $c = str_replace(' ', '', ucwords($c));
    return $c ?: 'Home';
  }

  /**
   * Normaliza el nombre de método en las definiciones de rutas.
   * Reglas:
   * - Si el dev escribe camelCase (tiene mayúsculas), se respeta tal cual.
   * - Si usa kebab-case, se convierte a snake_case ("mi-metodo" -> "mi_metodo").
   * - snake_case se respeta.
   */
  private static function normalizeMethodPart(string $m): string
  {
    $m = trim($m);
    if ($m === '') return 'index';

    // Respeta camelCase explícito
    if (preg_match('/[A-Z]/', $m)) return $m;

    // Convierte kebab-case a snake_case (más natural en PHP)
    if (str_contains($m, '-')) $m = str_replace('-', '_', $m);

    return $m;
  }


/**
   * Merge de opts para group -> route.
   * - filters: se acumulan (unique)
   * - guard: se hereda y se combina (require/any se acumulan, match se mergea)
   * - resto: route override
   */
  private static function mergeOpts(array $group, array $route): array
  {
    $out = array_merge($group, $route);

    // filters: union
    if (!empty($group['filters']) && !empty($route['filters'])) {
      $out['filters'] = array_values(array_unique(array_merge((array)$group['filters'], (array)$route['filters'])));
    }

    // guard: merge semántico
    if (array_key_exists('guard', $group) || array_key_exists('guard', $route)) {
      $g = $group['guard'] ?? null;
      $r = $route['guard'] ?? null;

      // si route define explicitamente guard=false, desactiva herencia
      if ($r === false) {
        $out['guard'] = false;
        return $out;
      }

      // normaliza a array
      $gArr = self::normalizeGuard($g);
      $rArr = self::normalizeGuard($r);

      // boolean true sin config => marca implícita (el filtro asume require=user si no hay config)
      if ($g === true && $gArr === []) $gArr['_implicit'] = true;
      if ($r === true && $rArr === []) $rArr['_implicit'] = true;

      // merge
      $merged = $gArr;

      // require/any: acumula
      foreach (['require','any'] as $k) {
        $a = isset($gArr[$k]) ? (array)$gArr[$k] : [];
        $b = isset($rArr[$k]) ? (array)$rArr[$k] : [];
        $list = array_values(array_unique(array_filter(array_merge($a, $b), fn($x) => is_string($x) && trim($x) !== '')));
        if ($list) $merged[$k] = $list;
      }

      // match: merge (route override)
      if (isset($gArr['match']) || isset($rArr['match'])) {
        $gm = is_array($gArr['match'] ?? null) ? $gArr['match'] : [];
        $rm = is_array($rArr['match'] ?? null) ? $rArr['match'] : [];
        $merged['match'] = array_merge($gm, $rm);
      }

      // otros: route override
      foreach ($rArr as $k => $v) {
        if (in_array($k, ['require','any','match'], true)) continue;
        $merged[$k] = $v;
      }

      // si al final no hay config pero hay implicit, lo dejamos
      $out['guard'] = $merged;
    }

    return $out;
  }

  private static function normalizeGuard(mixed $g): array
  {
    if ($g === null) return [];
    if ($g === true) return [];
    if (is_string($g) && trim($g) !== '') {
      return ['require' => [trim($g)]];
    }
    return is_array($g) ? $g : [];
  }
}
