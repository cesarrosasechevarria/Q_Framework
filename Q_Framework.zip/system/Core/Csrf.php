<?php
declare(strict_types=1);

namespace System\Core;

/**
 * CSRF manager (PRO)
 *
 * Soporta storage:
 * - cookie (recomendado: NO fuerza sesión)
 * - session
 */
final class Csrf
{
  public static function enabled(): bool
  {
    $cfg = \config('Security');
    return !empty($cfg->csrfEnabled);
  }

  public static function key(): string
  {
    $cfg = \config('Security');
    return (string)($cfg->csrfKey ?? '_token');
  }

  public static function rotate(): bool
  {
    $cfg = \config('Security');
    return !empty($cfg->csrfRotate);
  }

  public static function storage(): string
  {
    $cfg = \config('Security');
    $s = strtolower((string)($cfg->csrfStorage ?? 'cookie'));
    return in_array($s, ['cookie','session'], true) ? $s : 'cookie';
  }

  public static function cookieName(): string
  {
    $cfg = \config('Security');
    $name = (string)($cfg->csrfCookieName ?? 'QFW_CSRF');

    // Multi-tenant: evita colisiones de cookies cuando compartes dominio.
    try {
      if (class_exists(\System\Core\Tenant::class)) {
        $tid = \System\Core\Tenant::id();
        if (is_string($tid) && $tid !== '' && $tid !== 'default') {
          $name .= '_' . $tid;
        }
      }
    } catch (\Throwable $e) {
      // ignora
    }

    return $name;
  }

  public static function headerName(): string
  {
    $cfg = \config('Security');
    return (string)($cfg->csrfHeader ?? 'X-CSRF-TOKEN');
  }

  /** Retorna el token actual (crea si no existe). */
  public static function token(): string
  {
    if (!self::enabled()) return '';

    return self::storage() === 'session'
      ? self::sessionToken()
      : self::cookieToken();
  }

  /** Valida un token enviado por el cliente. */
  public static function verify(?string $sent): bool
  {
    if (!self::enabled()) return true;
    $sent = (string)$sent;
    if ($sent === '') return false;
    $cur = self::storage() === 'session' ? self::peekSessionToken() : self::peekCookieToken();
    if ($cur === '') return false;
    return hash_equals($cur, $sent);
  }

  /** Regenera token. */
  public static function regenerate(): string
  {
    if (!self::enabled()) return '';
    return self::storage() === 'session'
      ? self::forceSessionToken()
      : self::forceCookieToken();
  }

  /** Devuelve token enviado por header o post. */
  public static function fromRequest(): string
  {
    $hdr = self::headerName();
    $hkey = 'HTTP_' . strtoupper(str_replace('-', '_', $hdr));
    $v = $_SERVER[$hkey] ?? '';
    if (is_string($v) && $v !== '') return $v;

    $k = self::key();
    $p = $_POST[$k] ?? '';
    return is_string($p) ? $p : '';
  }

  /* =========================
     Storage: Session
  ========================= */
  private static function peekSessionToken(): string
  {
    if (session_status() !== PHP_SESSION_ACTIVE) return '';
    $k = self::key();
    $v = $_SESSION[$k] ?? '';
    return is_string($v) ? $v : '';
  }

  private static function sessionToken(): string
  {
    // Solo aquí inicia sesión si el usuario eligió storage=session
    Session::ensureStarted();
    $cur = self::peekSessionToken();
    if ($cur !== '') return $cur;
    return self::forceSessionToken();
  }

  private static function forceSessionToken(): string
  {
    Session::ensureStarted();
    $k = self::key();
    $t = self::makeToken();
    $_SESSION[$k] = $t;
    return $t;
  }

  /* =========================
     Storage: Cookie
  ========================= */
  private static function peekCookieToken(): string
  {
    $name = self::cookieName();
    $v = $_COOKIE[$name] ?? '';
    return is_string($v) ? $v : '';
  }

  private static function cookieToken(): string
  {
    $cur = self::peekCookieToken();
    if ($cur !== '') return $cur;
    return self::forceCookieToken();
  }

  private static function forceCookieToken(): string
  {
    $t = self::makeToken();
    self::setCookie($t);
    return $t;
  }

  private static function setCookie(string $value): void
  {
    $name = self::cookieName();
    $cfgC = \config('Cookies');
    $cfgS = \config('Security');

    $expire = (int)($cfgS->csrfExpire ?? 0);
    $expTs = $expire > 0 ? (time() + $expire) : 0;

    $secure = isset($cfgS->csrfCookieSecure) ? (bool)$cfgS->csrfCookieSecure : (bool)($cfgC->secure ?? false);
    $httpOnly = isset($cfgS->csrfCookieHttpOnly) ? (bool)$cfgS->csrfCookieHttpOnly : (bool)($cfgC->httpOnly ?? true);
    $sameSite = (string)($cfgS->csrfCookieSameSite ?? ($cfgC->sameSite ?? 'Lax'));

    // PHP 7.3+ array options
    setcookie($name, $value, [
      'expires'  => $expTs,
      'path'     => (string)($cfgC->path ?? '/'),
      'domain'   => (string)($cfgC->domain ?? ''),
      'secure'   => $secure,
      'httponly' => $httpOnly,
      'samesite' => $sameSite,
    ]);

    // disponible inmediatamente en el request actual
    $_COOKIE[$name] = $value;
  }

  private static function makeToken(): string
  {
    $bytes = random_bytes(32);
    return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
  }
}
