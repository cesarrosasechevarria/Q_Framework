<?php
declare(strict_types=1);

namespace System\Core;

final class Cookie
{
  public static function get(string $name, $default = null)
  {
    $cfg = config('Cookies');
    $n = (string)($cfg->prefix ?? '') . $name;
    return $_COOKIE[$n] ?? $default;
  }

  public static function set(string $name, string $value, int $minutes = 0): void
  {
    $cfg = config('Cookies');
    $n = (string)($cfg->prefix ?? '') . $name;

    $expire = $minutes > 0 ? (time() + $minutes * 60) : 0;

    setcookie($n, $value, [
      'expires'  => $expire,
      'path'     => (string)($cfg->path ?? '/'),
      'domain'   => (string)($cfg->domain ?? ''),
      'secure'   => !empty($cfg->secure),
      'httponly' => !empty($cfg->httpOnly),
      'samesite' => (string)($cfg->sameSite ?? 'Lax'),
    ]);

    // disponible en el mismo request
    $_COOKIE[$n] = $value;
  }

  public static function delete(string $name): void
  {
    $cfg = config('Cookies');
    $n = (string)($cfg->prefix ?? '') . $name;

    setcookie($n, '', [
      'expires'  => time() - 3600,
      'path'     => (string)($cfg->path ?? '/'),
      'domain'   => (string)($cfg->domain ?? ''),
      'secure'   => !empty($cfg->secure),
      'httponly' => !empty($cfg->httpOnly),
      'samesite' => (string)($cfg->sameSite ?? 'Lax'),
    ]);

    unset($_COOKIE[$n]);
  }
}
