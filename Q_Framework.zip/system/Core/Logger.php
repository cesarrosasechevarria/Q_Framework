<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Logger simple (archivo) con soporte JSON Lines.
 * - tenant-aware: el bootstrap inicializa el directorio con Tenant::writePath('logs')
 * - observabilidad: si Context está inicializado, se adjunta automáticamente.
 */
final class Logger
{
  private static string $dir = '';
  private static string $format = 'text'; // text|json

  public static function init(string $dir): void
  {
    self::$dir = $dir;
    if (!is_dir(self::$dir)) @mkdir(self::$dir, 0775, true);

    // Format desde config Observability (si existe)
    $fmt = 'text';
    if (function_exists('config')) {
      try {
        $oc = \config('Observability');
        if (is_object($oc) && isset($oc->logFormat)) {
          $fmt = (string)$oc->logFormat;
        }
      } catch (\Throwable $e) {
        // noop
      }
    }
    self::setFormat($fmt);
  }

  public static function setFormat(string $format): void
  {
    $format = strtolower(trim($format));
    self::$format = in_array($format, ['json','text'], true) ? $format : 'text';
  }

  public static function info(string $msg, array $ctx = []): void  { self::write('INFO',  $msg, $ctx); }
  public static function warn(string $msg, array $ctx = []): void  { self::write('WARN',  $msg, $ctx); }
  // Aliases estilo PSR-3 / compatibilidad
  public static function warning(string $msg, array $ctx = []): void { self::write('WARN', $msg, $ctx); }
  public static function debug(string $msg, array $ctx = []): void   { self::write('DEBUG', $msg, $ctx); }
  public static function notice(string $msg, array $ctx = []): void  { self::write('NOTICE', $msg, $ctx); }
  public static function critical(string $msg, array $ctx = []): void{ self::write('CRIT', $msg, $ctx); }
  public static function alert(string $msg, array $ctx = []): void   { self::write('ALERT', $msg, $ctx); }
  public static function emergency(string $msg, array $ctx = []): void{ self::write('EMERG', $msg, $ctx); }
  public static function log(string $level, string $msg, array $ctx = []): void {
    self::write(strtoupper(trim($level)), $msg, $ctx);
  }

  public static function error(string $msg, array $ctx = []): void { self::write('ERROR', $msg, $ctx); }

  private static function write(string $level, string $msg, array $ctx): void
  {
    $date = date('Y-m-d');
    $file = rtrim(self::$dir ?: sys_get_temp_dir(), '/\\') . "/{$date}.log";

    // Adjunta contexto de observabilidad si existe
    $auto = [];
    if (class_exists('System\\Observability\\Context')) {
      try {
        /** @var class-string $c */
        $c = 'System\\Observability\\Context';
        if (method_exists($c, 'toArray')) {
          $auto = (array)$c::toArray();
        }
      } catch (\Throwable $e) {
        $auto = [];
      }
    }

    // ctx explícito gana sobre ctx automático
    $ctx = array_merge($auto, $ctx);

    if (self::$format === 'json') {
      $payload = [
        'ts' => date('c'),
        'level' => $level,
        'msg' => $msg,
      ];
      if (!empty($ctx)) $payload['context'] = $ctx;
      $line = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } else {
      $time = date('H:i:s');
      $line = "[{$date} {$time}] {$level}: {$msg}";
      if (!empty($ctx)) $line .= " | " . json_encode($ctx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    @file_put_contents($file, (string)$line . PHP_EOL, FILE_APPEND);
  }
}
