<?php
declare(strict_types=1);

namespace System\Core;

final class Constants
{
  public static function load(): void
  {
    $cfg = config('Constants');
    $arr = $cfg->constants ?? [];
    if (!is_array($arr)) return;

    foreach ($arr as $k => $v) {
      $name = (string)$k;
      if ($name === '' || defined($name)) continue;
      define($name, $v);
    }
  }
}
