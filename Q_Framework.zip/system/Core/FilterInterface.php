<?php
declare(strict_types=1);

namespace System\Core;

interface FilterInterface
{
  public function before(Request $request, Response $response): ?Response;
  public function after(Request $request, Response $response): ?Response;
}
