<?php
declare(strict_types=1);

namespace System\Core;

final class Routes
{
  private static array $names = [];

  public static function setNames(array $names): void
  {
    self::$names = $names;
  }

  
public static function has(string $name): bool
{
  return isset(self::$names[$name]);
}

/** URL por nombre de ruta (alias) con fallback explícito. */
public static function urlOr(string $name, string $fallback = '/', array $params = []): string
{
  if (!isset(self::$names[$name])) {
      \System\Core\Logger::warning('Route name not found: ' . $name);
    return \url(str_starts_with($fallback, '/') ? $fallback : '/' . $fallback);
  }
  return self::url($name, $params);
}

public static function url(string $name, array $params = []): string
  {
    if (!isset(self::$names[$name])) {
      \System\Core\Logger::warning('Route name not found: ' . $name);
      if (str_starts_with($name, '/')) return \url($name);
      return \url('/');
    }

    [$method, $path] = self::$names[$name];

    foreach ($params as $k => $v) {
      $pattern = '#\{' . preg_quote((string)$k, '#') . '(?:\:[^}]+)?\}#';
      $path = preg_replace($pattern, rawurlencode((string)$v), $path) ?? $path;
    }

    return \url($path);
  }
}