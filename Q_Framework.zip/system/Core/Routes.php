<?php
declare(strict_types=1);

namespace System\Core;

final class Routes
{
  private static array $names = [];

  public static function setNames(array $names): void
  {
    self::$names = $names;
  }

  public static function url(string $name, array $params = []): string
  {
    if (!isset(self::$names[$name])) {
      if (str_starts_with($name, '/')) return \url($name);
      return \url('/');
    }

    [$method, $path] = self::$names[$name];

    foreach ($params as $k => $v) {
      $pattern = '#\{' . preg_quote((string)$k, '#') . '(?:\:[^}]+)?\}#';
      $path = preg_replace($pattern, rawurlencode((string)$v), $path) ?? $path;
    }

    return \url($path);
  }
}
