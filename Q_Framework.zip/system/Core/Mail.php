<?php
declare(strict_types=1);

namespace System\Core;

final class Mail
{
  public static function send(string $to, string $subject, string $html, array $headers = []): bool
  {
    $cfg = config('Mail');

    $from = (string)($cfg->fromEmail ?? 'no-reply@example.com');
    $fromName = (string)($cfg->fromName ?? 'Q_Framework');

    $h = [];
    $h[] = 'MIME-Version: 1.0';
    $h[] = 'Content-type: text/html; charset=UTF-8';
    $h[] = 'From: ' . $fromName . ' <' . $from . '>';

    foreach ($headers as $k => $v) {
      $h[] = $k . ': ' . $v;
    }

    $driver = (string)($cfg->driver ?? 'mail');
    if ($driver !== 'mail') {
      // Placeholder para SMTP (puedes integrar PHPMailer/SwiftMailer luego)
      Logger::error('Mail driver SMTP no implementado aún.');
      return false;
    }

    return mail($to, $subject, $html, implode("\r\n", $h));
  }
}
