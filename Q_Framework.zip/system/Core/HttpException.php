<?php
declare(strict_types=1);

namespace System\Core;

/**
 * HttpException: permite abortar con status HTTP, headers y payload.
 * Usado por abort() y por capas de API.
 */
class HttpException extends \RuntimeException
{
    public int $status;
    public array $headers;
    public mixed $payload;

    public function __construct(int $status = 500, string $message = '', mixed $payload = null, array $headers = [])
    {
        $this->status = $status;
        $this->headers = $headers;
        $this->payload = $payload;
        parent::__construct($message !== '' ? $message : self::defaultMessage($status), $status);
    }

    private static function defaultMessage(int $status): string
    {
        return match ($status) {
            400 => 'Solicitud inválida',
            401 => 'No autorizado',
            403 => 'Prohibido',
            404 => 'No encontrado',
            405 => 'Método no permitido',
            419 => 'Token CSRF inválido',
            422 => 'Validación fallida',
            429 => 'Demasiadas solicitudes',
            default => 'Error interno',
        };
    }
}
