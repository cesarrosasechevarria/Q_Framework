<?php
declare(strict_types=1);

namespace System\Core;

final class Request
{
  private Uri $uri;
  private string $locale;

  public function __construct()
  {
    $this->uri = Uri::fromGlobals();
    $this->locale = $this->resolveLocale();

    // disponible para helpers sin pasar Request
    $GLOBALS['__qfw_locale'] = $this->locale;
  }

  public function uri(): Uri
  {
    return $this->uri;
  }

  public function method(): string
  {
    $m = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    if ($m === 'POST') {
      $spoof = $_POST['_method'] ?? $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? null;
      if (is_string($spoof) && $spoof !== '') {
        $m2 = strtoupper($spoof);
        if (in_array($m2, ['PUT','PATCH','DELETE'], true)) return $m2;
      }
    }
    return $m;
  }

  public function path(): string
  {
    return $this->uri->path();
  }

  public function locale(): string
  {
    return $this->locale;
  }

  /**
   * Fuerza el locale del request en runtime.
   * - Actualiza cache global (para helpers)
   * - Sincroniza el servicio Lang (si está disponible)
   */
  public function setLocale(string $locale): void
  {
    $locale = trim($locale);
    if ($locale === '') return;

    $this->locale = $locale;
    $GLOBALS['__qfw_locale'] = $locale;

    // Mantener I18n sincronizado (evita que lang() traduzca en otro idioma)
    try {
      $lang = \Config\Services::lang();
      if ($lang && method_exists($lang, 'setLocale')) {
        $lang->setLocale($locale);
      }
    } catch (\Throwable) {
      // ignore
    }
  }

  private function resolveLocale(): string
  {
    $cfg = config('App');
    $default = (string)($cfg->defaultLocale ?? 'en');
    $supported = (array)($cfg->supportedLocales ?? [$default]);

    if (empty($cfg->negotiateLocale)) {
      return $default;
    }

    $header = strtolower((string)($this->header('Accept-Language', '') ?? ''));
    if ($header === '') return $default;

    // Parse simple: toma los idiomas en orden, ignora q=, usa match exacto o por prefijo (es-PE -> es)
    $parts = array_map('trim', explode(',', $header));
    foreach ($parts as $p) {
      if ($p === '') continue;
      $lang = trim(explode(';', $p, 2)[0]);
      if ($lang === '') continue;

      // exact
      foreach ($supported as $s) {
        if (strtolower((string)$s) === $lang) return (string)$s;
      }
      // prefix
      $base = explode('-', $lang, 2)[0];
      foreach ($supported as $s) {
        if (strtolower((string)$s) === $base) return (string)$s;
      }
    }

    return $default;
  }

  /**
   * HTTPS real:
   * - true si HTTPS server var está activo
   * - o si (y solo si) el request viene de proxy confiable, confiamos en X-Forwarded-Proto
   */
  public function isSecure(): bool
  {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;

    $cfg = config('App');
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '');

    $trusted = $cfg->trustedProxies ?? [];
    $protoHeader = (string)($cfg->proxyProtoHeader ?? 'X-Forwarded-Proto');

    // Modo nuevo: trusted proxies (IPs o CIDR)
    if (is_array($trusted) && !empty($trusted) && $this->isTrustedProxy($remote, $trusted)) {
      $proto = strtolower((string)($this->header($protoHeader, '') ?? ''));
      return $proto === 'https';
    }

    // Compat: modo antiguo proxyIPs[ip] => header (si REMOTE_ADDR está whitelisted)
    $proxy = $cfg->proxyIPs ?? [];
    if (is_array($proxy) && isset($proxy[$remote])) {
      $proto = strtolower((string)($this->header($protoHeader, '') ?? ''));
      return $proto === 'https';
    }

    return false;
  }

  // Alias por compatibilidad (HTTPS)
  public function isHttps(): bool
  {
    return $this->isSecure();
  }

  public function ip(): string
  {
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    $cfg = config('App');

    // Nuevo modo: trustedProxies (IPs o CIDR)
    $trusted = $cfg->trustedProxies ?? [];
    if (is_array($trusted) && !empty($trusted) && $this->isTrustedProxy($remote, $trusted)) {
      $header = (string)($cfg->proxyIpHeader ?? 'X-Forwarded-For');
      $xff = (string)($this->header($header, '') ?? '');

      $ips = [];
      if ($xff !== '') {
        foreach (explode(',', $xff) as $p) {
          $p = trim($p);
          if ($p === '') continue;

          $p = $this->sanitizeForwardedIp($p);
          if ($p !== '' && filter_var($p, FILTER_VALIDATE_IP)) $ips[] = $p;
        }
      }

      // cadena: [client, proxy1, proxy2, ...]; añadimos REMOTE al final
      $ips[] = $remote;

      // Pelar proxies confiables desde el final
      while (count($ips) > 1) {
        $last = (string)end($ips);
        if ($this->isTrustedProxy($last, $trusted)) array_pop($ips);
        else break;
      }

      return (string)end($ips);
    }

    // Compat: modo antiguo proxyIPs[ip] => header
    $proxy = $cfg->proxyIPs ?? [];
    if (is_array($proxy) && isset($proxy[$remote])) {
      $header = (string)$proxy[$remote];
      $val = (string)($this->header($header, '') ?? '');
      if ($val !== '') {
        $parts = array_map('trim', explode(',', $val));
        if (!empty($parts[0])) {
          $p = $this->sanitizeForwardedIp((string)$parts[0]);
          if ($p !== '' && filter_var($p, FILTER_VALIDATE_IP)) return $p;
        }
      }
    }

    return $remote;
  }

  public function userAgent(): string
  {
    return $_SERVER['HTTP_USER_AGENT'] ?? '';
  }

  public function header(string $key, ?string $default=null): ?string
  {
    $h = 'HTTP_' . strtoupper(str_replace('-', '_', $key));
    return $_SERVER[$h] ?? $default;
  }

  public function isAjax(): bool
  {
    return strtolower((string)$this->header('X-Requested-With', '')) === 'xmlhttprequest';
  }

  public function contentType(): string
  {
    return strtolower((string)($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? ''));
  }

  public function acceptsJson(): bool
  {
    $accept = strtolower((string)($this->header('Accept', '') ?? ''));
    return str_contains($accept, 'application/json') || str_contains($accept, '+json');
  }

  /** Heurística: si el cliente "quiere" JSON (API). */
  public function wantsJson(): bool
  {
    if ($this->acceptsJson()) return true;
    $ct = $this->contentType();
    if ($ct !== '' && str_contains($ct, 'json')) return true;
    if ($this->isAjax()) return true;

    $path = $this->path();
    return (bool)preg_match('#^/(api|v\d+)(/|$)#i', $path);
  }

  public function query(string $key, $default=null)
  {
    return $_GET[$key] ?? $default;
  }

  public function get(string $key, $default=null)
  {
    return $this->query($key, $default);
  }

  public function post(string $key, $default=null)
  {
    return $_POST[$key] ?? $default;
  }

  public function input(string $key, $default=null)
  {
    return $_POST[$key] ?? $_GET[$key] ?? $default;
  }

  // ====== Compat Q_Framework-style ======
  public function getGet(?string $key = null, $default = null)
  {
    if ($key === null) return $_GET ?? [];
    return $_GET[$key] ?? $default;
  }

  public function getPost(?string $key = null, $default = null)
  {
    if ($key === null) return $_POST ?? [];
    return $_POST[$key] ?? $default;
  }

  public function getVar(string $key, $default = null)
  {
    return $this->input($key, $default);
  }

  public function getJSON(bool $assoc = true)
  {
    $raw = file_get_contents('php://input');
    if (!$raw) return $assoc ? [] : null;
    return json_decode($raw, $assoc);
  }

  public function all(): array
  {
    return array_merge($_GET, $_POST);
  }

  public function files(): array
  {
    return $_FILES ?? [];
  }

  public function json(): array
  {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
  }

  public function body(): array
  {
    $ct = $this->contentType();
    if (str_contains($ct, 'application/json')) return $this->json();
    return $this->all();
  }

  // ==========================================================
  // Helpers para trusted proxies
  // ==========================================================
  private function isTrustedProxy(string $ip, array $trusted): bool
  {
    $ip = trim($ip);
    if ($ip === '') return false;

    foreach ($trusted as $rule) {
      $rule = trim((string)$rule);
      if ($rule === '') continue;

      // match exacto
      if ($rule === $ip) return true;

      // CIDR IPv4
      if (str_contains($rule, '/')) {
        if ($this->ipInCidrV4($ip, $rule)) return true;
      }
    }
    return false;
  }

  private function ipInCidrV4(string $ip, string $cidr): bool
  {
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;

    [$net, $bits] = array_pad(explode('/', $cidr, 2), 2, null);
    if (!$net || $bits === null) return false;
    if (!filter_var($net, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;

    $bits = (int)$bits;
    if ($bits < 0 || $bits > 32) return false;

    $ipLong  = ip2long($ip);
    $netLong = ip2long($net);

    $mask = $bits === 0 ? 0 : (~0 << (32 - $bits));
    return (($ipLong & $mask) === ($netLong & $mask));
  }

  /**
   * Normaliza tokens típicos en X-Forwarded-For:
   * - "1.2.3.4:1234" -> "1.2.3.4"
   * - "[2001:db8::1]:443" -> "2001:db8::1"
   */
  private function sanitizeForwardedIp(string $raw): string
  {
    $raw = trim($raw);
    if ($raw === '') return '';

    // [IPv6]:port
    if ($raw[0] === '[') {
      $end = strpos($raw, ']');
      if ($end !== false) {
        return substr($raw, 1, $end - 1);
      }
      return $raw;
    }

    // IPv4:port (heurística: tiene punto y termina en :digits)
    if (str_contains($raw, '.') && preg_match('/:\d+$/', $raw)) {
      return preg_replace('/:\d+$/', '', $raw) ?? $raw;
    }

    return $raw;
  }
}
