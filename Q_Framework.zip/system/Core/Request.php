<?php
declare(strict_types=1);

namespace System\Core;

final class Request
{
  private Uri $uri;
  private string $locale;

  public function __construct()
  {
    $this->uri = Uri::fromGlobals();
    $this->locale = $this->resolveLocale();

    // disponible para helpers sin pasar Request
    $GLOBALS['__qfw_locale'] = $this->locale;
  }

  public function uri(): Uri
  {
    return $this->uri;
  }

  public function method(): string
  {
    $m = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

    if ($m === 'POST') {
      $spoof = $_POST['_method'] ?? $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? null;
      if (is_string($spoof) && $spoof !== '') {
        $m2 = strtoupper($spoof);
        if (in_array($m2, ['PUT','PATCH','DELETE'], true)) return $m2;
      }
    }
    return $m;
  }

  public function path(): string
  {
    return $this->uri->path();
  }

  public function locale(): string
  {
    return $this->locale;
  }

  private function resolveLocale(): string
  {
    $cfg = config('App');
    $default = (string)($cfg->defaultLocale ?? 'en');
    $supported = (array)($cfg->supportedLocales ?? [$default]);

    if (empty($cfg->negotiateLocale)) {
      return $default;
    }

    $header = strtolower((string)($this->header('Accept-Language', '') ?? ''));
    if ($header === '') return $default;

    // Parse simple: toma los idiomas en orden, ignora q=, usa match exacto o por prefijo (es-PE -> es)
    $parts = array_map('trim', explode(',', $header));
    foreach ($parts as $p) {
      if ($p === '') continue;
      $lang = trim(explode(';', $p, 2)[0]);
      if ($lang === '') continue;

      // exact
      foreach ($supported as $s) {
        if (strtolower((string)$s) === $lang) return (string)$s;
      }
      // prefix
      $base = explode('-', $lang, 2)[0];
      foreach ($supported as $s) {
        if (strtolower((string)$s) === $base) return (string)$s;
      }
    }

    return $default;
  }

  public function isSecure(): bool
  {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (($this->header('X-Forwarded-Proto', '') ?? '') === 'https') return true;
    return false;
  }

  public function ip(): string
  {
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');

    $cfg = config('App');
    $proxy = $cfg->proxyIPs ?? [];

    if (is_array($proxy) && isset($proxy[$remote])) {
      $header = (string)$proxy[$remote];
      $val = (string)($this->header($header, '') ?? '');
      if ($val !== '') {
        // X-Forwarded-For puede venir: "client, proxy1, proxy2"
        $parts = array_map('trim', explode(',', $val));
        if (!empty($parts[0])) return $parts[0];
      }
    }

    return $remote;
  }

  public function userAgent(): string
  {
    return $_SERVER['HTTP_USER_AGENT'] ?? '';
  }

  public function header(string $key, ?string $default=null): ?string
  {
    $h = 'HTTP_' . strtoupper(str_replace('-', '_', $key));
    return $_SERVER[$h] ?? $default;
  }

  public function isAjax(): bool
  {
    return strtolower((string)$this->header('X-Requested-With', '')) === 'xmlhttprequest';
  }

  public function contentType(): string
  {
    return strtolower((string)($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? ''));
  }

  public function acceptsJson(): bool
  {
    $accept = strtolower((string)($this->header('Accept', '') ?? ''));
    return str_contains($accept, 'application/json') || str_contains($accept, '+json');
  }

  /** Heurística: si el cliente "quiere" JSON (API). */
  public function wantsJson(): bool
  {
    if ($this->acceptsJson()) return true;
    $ct = $this->contentType();
    if ($ct !== '' && str_contains($ct, 'json')) return true;
    if ($this->isAjax()) return true;

    $path = $this->path();
    return (bool)preg_match('#^/(api|v\d+)(/|$)#i', $path);
  }

  public function query(string $key, $default=null)
  {
    return $_GET[$key] ?? $default;
  }

  public function get(string $key, $default=null)
  {
    return $this->query($key, $default);
  }

  public function post(string $key, $default=null)
  {
    return $_POST[$key] ?? $default;
  }

  public function input(string $key, $default=null)
  {
    return $_POST[$key] ?? $_GET[$key] ?? $default;
  }

  // ====== Compat Q_Framework-style ======
  public function getGet(?string $key = null, $default = null)
  {
    if ($key === null) return $_GET ?? [];
    return $_GET[$key] ?? $default;
  }

  public function getPost(?string $key = null, $default = null)
  {
    if ($key === null) return $_POST ?? [];
    return $_POST[$key] ?? $default;
  }

  public function getVar(string $key, $default = null)
  {
    return $this->input($key, $default);
  }

  public function getJSON(bool $assoc = true)
  {
    $raw = file_get_contents('php://input');
    if (!$raw) return $assoc ? [] : null;
    $data = json_decode($raw, $assoc);
    return $data;
  }


  public function all(): array
  {
    return array_merge($_GET, $_POST);
  }

  public function files(): array
  {
    return $_FILES ?? [];
  }

  public function json(): array
  {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
  }

  public function body(): array
  {
    $ct = $this->contentType();
    if (str_contains($ct, 'application/json')) return $this->json();
    return $this->all();
  }
}
