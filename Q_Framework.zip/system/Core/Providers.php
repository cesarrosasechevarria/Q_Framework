<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Providers manager (PRO)
 *
 * - Carga lista desde app/Config/Providers.php
 * - Ejecuta register() y luego boot()
 * - Expone un Container global para extensiones (sin obligar a usarlo)
 */
final class Providers
{
  private static bool $booted = false;

  /** @var ProviderInterface[] */
  private static array $instances = [];

  private static ?Container $container = null;

  public static function container(): Container
  {
    if (!self::$container) self::$container = new Container();
    return self::$container;
  }

  public static function boot(): void
  {
    if (self::$booted) return;
    self::$booted = true;

    $c = self::container();

    // === Default core bindings (source of truth) ===
    // Estrategia:
    // - Evitar recursión: NO llamamos a \Config\Services::* dentro de los bindings.
    // - Permitir comportamiento request-scoped mediante KernelContext (para CLI/tests).
    // - Tenant-aware en Cache/RateLimiter (instancias por tenant).

    // Request / Response (request-scoped si KernelContext existe)
    $c->singleton('_request_global', fn($c) => new \System\Core\Request());
    $c->bind('request', fn($c) => ($x = \System\Core\KernelContext::current()) ? $x->request() : $c->get('_request_global'));
    $c->bind(\System\Core\Request::class, fn($c) => $c->get('request'));

    $c->singleton('_response_global', fn($c) => new \System\Core\Response());
    $c->bind('response', fn($c) => ($x = \System\Core\KernelContext::current()) ? $x->response() : $c->get('_response_global'));
    $c->bind(\System\Core\Response::class, fn($c) => $c->get('response'));

    // Session (lazy)
    $c->singleton('_session_global', function($c){
      \System\Core\Session::ensureStarted();
      return new \System\Core\Session();
    });
    $c->bind('session', function($c){
      $x = \System\Core\KernelContext::current();
      if ($x) {
        return $x->scopedGetOrSet('session', function(){
          \System\Core\Session::ensureStarted();
          return new \System\Core\Session();
        });
      }
      return $c->get('_session_global');
    });
    $c->bind(\System\Core\Session::class, fn($c) => $c->get('session'));

    // Encrypter
    $c->singleton(\System\Services\Encrypter::class, fn($c) => new \System\Services\Encrypter());
    $c->bind('encrypter', fn($c) => $c->get(\System\Services\Encrypter::class));

    // DB / PDO (default group)
    $c->singleton('db', fn($c) => \System\Core\DB::connect(null));
    $c->bind(\System\Database\Connection::class, fn($c) => $c->get('db'));

    // Extras Presenter (lookup/combo/files/map/json_get)
    if (class_exists(\System\Database\Presenter\ExtrasPresenter::class)) {
      $c->singleton(\System\Database\Presenter\ExtrasPresenter::class, fn($c) =>
        new \System\Database\Presenter\ExtrasPresenter(
          $c->get('db'),
          $c->get('encrypter')
        )
      );
      $c->bind('presenter', fn($c) => $c->get(\System\Database\Presenter\ExtrasPresenter::class));
    }


    $c->singleton('pdo', fn($c) => \System\Core\DB::pdo(null));
    $c->bind(\PDO::class, fn($c) => $c->get('pdo'));

    // Schema (DDL / ensure tables)
    if (class_exists(\System\Database\Schema\Schema::class)) {
      $c->singleton(\System\Database\Schema\Schema::class, fn($c) => new \System\Database\Schema\Schema($c->get('db')));
      $c->bind('schema', fn($c) => $c->get(\System\Database\Schema\Schema::class));
    }

    

// CRUD (PRO) - dinámico por tabla
if (class_exists(\System\Database\Crud\Crud::class)) {
  $c->singleton(\System\Database\Crud\Crud::class, fn($c) => new \System\Database\Crud\Crud($c->get('db')));
  $c->bind('crud', fn($c) => $c->get(\System\Database\Crud\Crud::class));
}

// Cache (tenant-aware) => instancia por tenant: cache:{tenantId}
    $c->bind('cache', function($c){
      $tid = class_exists(\System\Core\Tenant::class) ? \System\Core\Tenant::id() : 'default';
      $id = 'cache:' . $tid;
      if ($c->has($id)) return $c->get($id);

      $cfg = \config('Cache');
      $driver = strtolower((string)($cfg->driver ?? 'file'));

      if ($driver === 'redis') {
        $host = (string)($cfg->redisHost ?? '127.0.0.1');
        $port = (int)($cfg->redisPort ?? 6379);
        $auth = (string)($cfg->redisAuth ?? '');
        $db   = (int)($cfg->redisDb ?? 0);
        $timeout = (float)($cfg->redisTimeout ?? 1.5);
        $persist = !empty($cfg->redisPersistent);

        $prefix = (string)($cfg->prefix ?? 'qfw');
        $prefix = rtrim($prefix, ':') . ':' . $tid . ':';

        $client = new \System\Cache\RedisClient($host, $port, $timeout, $persist, $auth, $db);
        $obj = new \System\Cache\RedisCache($client, $prefix);
      } else {
        $path = (string)($cfg->path ?? 'write/cache');
        $isAbs = str_starts_with($path, '/') || preg_match('/^[A-Za-z]:\\\\/', $path);
        $abs = $isAbs ? $path : base_path($path);
        $abs = rtrim($abs,'/\\\\') . DIRECTORY_SEPARATOR . $tid;
        $obj = new \System\Cache\FileCache($abs);
      }

      $c->instance($id, $obj);
      return $obj;
    });
    $c->bind(\System\Cache\CacheInterface::class, fn($c) => $c->get('cache'));

    // Validator (request-scoped si KernelContext existe)
    $c->singleton('_validator_global', function($c){
      $cfg = \config('Validation');
      return new \System\Validation\Validator((array)($cfg->messages ?? []));
    });
    $c->bind('validator', function($c){
      $x = \System\Core\KernelContext::current();
      if ($x) {
        return $x->scopedGetOrSet('validator', function(){
          $cfg = \config('Validation');
          return new \System\Validation\Validator((array)($cfg->messages ?? []));
        });
      }
      return $c->get('_validator_global');
    });
    $c->bind(\System\Validation\Validator::class, fn($c) => $c->get('validator'));

    // Lang / i18n (request-scoped si KernelContext existe)
    $c->singleton('_lang_global', function($c){
      // Fuente única de verdad: locale del Request (negociado/definido por App).
      // Evita desincronización entre Request->locale() y lang()->locale().
      try {
        $req = $c->get('request');
        if ($req instanceof \System\Core\Request) {
          $loc = (string)$req->locale();
          if ($loc !== '') return new \System\I18n\Lang($loc);
        }
      } catch (\Throwable) {
        // ignore -> fallback a config
      }

      $cfg = \config('I18n');
      $loc = (string)($cfg->defaultLocale ?? 'en');
      return new \System\I18n\Lang($loc);
    });
    $c->bind('lang', function($c){
      $x = \System\Core\KernelContext::current();
      if ($x) {
        return $x->scopedGetOrSet('lang', function() use ($x){
          // Request-scoped: toma el locale real del Request del contexto
          try {
            $req = $x->request();
            if ($req instanceof \System\Core\Request) {
              $loc = (string)$req->locale();
              if ($loc !== '') return new \System\I18n\Lang($loc);
            }
          } catch (\Throwable) {
            // ignore
          }

          $cfg = \config('I18n');
          $loc = (string)($cfg->defaultLocale ?? 'en');
          return new \System\I18n\Lang($loc);
        });
      }
      return $c->get('_lang_global');
    });
    $c->bind(\System\I18n\Lang::class, fn($c) => $c->get('lang'));

    // RateLimiter (tenant-aware)
    $c->bind('ratelimiter', function($c){
      $tid = class_exists(\System\Core\Tenant::class) ? \System\Core\Tenant::id() : 'default';
      $id = 'ratelimiter:' . $tid;
      if ($c->has($id)) return $c->get($id);

      $obj = new \System\Security\RateLimiter($c->get('cache'));
      $c->instance($id, $obj);
      return $obj;
    });
    $c->bind(\System\Security\RateLimiter::class, fn($c) => $c->get('ratelimiter'));

    // Migrator / Seeder (default group)
    $c->singleton('migrator', function($c){
      $cfg = \config('Migrations');

      // rutas base
      $rel = [];
      if (is_array($cfg->paths ?? null) && !empty($cfg->paths)) {
        foreach ($cfg->paths as $rp) {
          if (is_string($rp) && trim($rp) !== '') $rel[] = trim($rp);
        }
      }
      if (!$rel) {
        $p1 = is_string($cfg->path ?? null) ? trim((string)$cfg->path) : '';
        if ($p1 !== '') $rel[] = $p1;
      }

      $abs = [];
      foreach ($rel as $rp) $abs[] = base_path($rp);

      if (!empty($cfg->includeModules)) {
        foreach (\System\Core\Modules::migrationPaths() as $mp) $abs[] = $mp;
      }

      $abs = array_values(array_unique(array_filter($abs, fn($v) => is_string($v) && $v !== '')));
      return new \System\Database\Migrations\Migrator($c->get('db'), $abs);
    });
    $c->bind(\System\Database\Migrations\Migrator::class, fn($c) => $c->get('migrator'));

    $c->singleton('seeder', fn($c) => new \System\Database\Seeds\SeederRunner('default'));
    $c->bind(\System\Database\Seeds\SeederRunner::class, fn($c) => $c->get('seeder'));

    $list = self::loadProviderList();

    if (!$list) return;

    foreach ($list as $fqcn) {
      if (!is_string($fqcn) || trim($fqcn) === '') continue;
      if (!class_exists($fqcn)) {
        Logger::error('Provider class not found', ['provider' => $fqcn]);
        continue;
      }
      try {
        $obj = new $fqcn();
        if ($obj instanceof ProviderInterface) self::$instances[] = $obj;
      } catch (\Throwable $e) {
        Logger::error('Provider instantiation failed', ['provider' => $fqcn, 'err' => $e->getMessage()]);
      }
    }

    // 1) Register
    foreach (self::$instances as $p) {
      try { $p->register(); } catch (\Throwable $e) {
        Logger::error('Provider register failed', ['provider' => get_class($p), 'err' => $e->getMessage()]);
      }
    }

    // 2) Boot
    foreach (self::$instances as $p) {
      try { $p->boot(); } catch (\Throwable $e) {
        Logger::error('Provider boot failed', ['provider' => get_class($p), 'err' => $e->getMessage()]);
      }
    }
  }

  /** @return string[] */
  private static function loadProviderList(): array
  {
    $file = base_path('app/Config/Providers.php');
    if (!is_file($file)) return [];

    // Permite retornar array directamente
    $ret = require $file;
    if (is_array($ret)) return array_values($ret);

    // O clase Config\Providers
    if (class_exists('Config\\Providers')) {
      $cfg = \config('Providers');
      if (is_object($cfg) && isset($cfg->providers) && is_array($cfg->providers)) {
        return array_values($cfg->providers);
      }
    }

    return [];
  }
}
