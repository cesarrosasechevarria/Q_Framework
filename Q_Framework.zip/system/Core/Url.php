<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Url: utilitario CORE (sin helpers).
 * Objetivo: evitar depender de funciones helper (base_url/route_url) en el núcleo.
 *
 * Puedes extender esta clase en App\Support\Url y configurar App::$urlClass / env('URL_CLASS').
 */
class Url
{
  /**
   * Construye una URL absoluta basada en Config\App::$baseURL (o auto) y el request actual.
   * - Soporta modo con /public y modo "publicless" (DocumentRoot -> /public).
   */
  public static function base(string $path = ''): string
  {
    $cfg = \config('App');
    $path = ltrim($path, '/');

    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';

    $script = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
    $scriptDir = rtrim(str_replace('\\', '/', \dirname($script)), '/');
    if ($scriptDir === '/') $scriptDir = '';

    $reqUri  = $_SERVER['REQUEST_URI'] ?? '/';
    $reqPath = (string)(\parse_url($reqUri, PHP_URL_PATH) ?? '/');
    if ($reqPath === '') $reqPath = '/';

    $endsWithPublic = ($scriptDir !== '' && str_ends_with($scriptDir, '/public'));
    $withPublic = $endsWithPublic && ($reqPath === $scriptDir || str_starts_with($reqPath, $scriptDir . '/'));

    $baseCfg = rtrim((string)($cfg->baseURL ?? ''), '/');
    $baseCfgLower = strtolower($baseCfg);
    $base = $baseCfg;

    if ($baseCfg === '' || $baseCfgLower === 'auto') {
      if ($endsWithPublic && !$withPublic) {
        $parent = rtrim(str_replace('\\', '/', \dirname($scriptDir)), '/');
        if ($parent === '') $parent = '';
        $base = $scheme . '://' . $host . $parent;
      } else {
        $base = $scheme . '://' . $host . $scriptDir;
      }
    } else {
      $bPath = (string)(\parse_url($base, PHP_URL_PATH) ?? '');
      $bPath = rtrim($bPath, '/');
      $cfgHasPublic = ($bPath !== '' && str_ends_with($bPath, '/public'));

      if ($withPublic && !$cfgHasPublic) {
        $base = rtrim($base, '/') . '/public';
      }
      if (!$withPublic && $cfgHasPublic) {
        $base = \preg_replace('~/public$~', '', $base) ?: $base;
      }
    }

    $indexPage = trim((string)($cfg->indexPage ?? ''), '/');
    if ($indexPage !== '') {
      $base = rtrim($base, '/') . '/' . $indexPage;
    }

    return rtrim($base, '/') . ($path !== '' ? '/' . $path : '/');
  }

  /** URL por nombre de ruta (alias). */
  public static function route(string $name, array $params = []): string
  {
    return Routes::url($name, $params);
  }
}
