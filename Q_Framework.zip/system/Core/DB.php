<?php
declare(strict_types=1);

namespace System\Core;

use PDO;
use System\Core\Debug\LoggedStatement;
use System\Database\Connection;

final class DB
{
  /** @var array<string, PDO> */
  private static array $pdos = [];

  /** @var array<string, Connection> */
  private static array $conns = [];

  /** Conexión (recomendada) */
  public static function connect(?string $group = null): Connection
  {
    $cfg = config('Database'); /** @var \Config\Database $cfg */
    $group = strtolower(trim((string)($group ?: $cfg->defaultGroup ?: 'default')));
    if ($group === '') $group = 'default';

    if (isset(self::$conns[$group])) return self::$conns[$group];

    $pdo = self::pdo($group);
    self::$conns[$group] = new Connection($group, $pdo);
    return self::$conns[$group];
  }

    

/** Shortcut PRO: Schema (DDL) */
public static function schema(?string $group = null): \System\Database\Schema\Schema
{
  return new \System\Database\Schema\Schema(self::connect($group));
}

/** Shortcut PRO: CRUD dinámico por tabla */
public static function crud(?string $group = null): \System\Database\Crud\Crud
{
  return new \System\Database\Crud\Crud(self::connect($group));
}

/** PDO (compat) */
  public static function pdo(?string $group = null): PDO
  {
    $cfg = config('Database'); /** @var \Config\Database $cfg */
    $group = strtolower(trim((string)($group ?: $cfg->defaultGroup ?: 'default')));
    if ($group === '') $group = 'default';

    if (isset(self::$pdos[$group])) return self::$pdos[$group];

    $c = $cfg->connections[$group] ?? $cfg->connections['default'] ?? null;
    if (!$c || empty($c['dsn'])) {
      throw new \RuntimeException("DB: conexión no configurada para grupo '{$group}'. Define DB_DSN o DB_CONNECTIONS_JSON.");
    }

    $dsn  = (string)$c['dsn'];
    $user = (string)($c['user'] ?? '');
    $pass = (string)($c['pass'] ?? '');

    $options = (array)($c['options'] ?? []);
    // Defaults profesionales (no rompe si ya vienen definidos)
    $options = array_replace([
      PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES   => false,
    ], $options);

    $env   = (string)env('APP_ENV', 'production');
    $debug = env_bool('APP_DEBUG', false);
    $dbgCfg = config('Debug');

    if ($debug && $env !== 'production' && !empty($dbgCfg->collectDb)) {
      $options[PDO::ATTR_STATEMENT_CLASS] = [LoggedStatement::class, []];
    }

    // MySQL: asegura charset por si el DSN no lo incluyó
    $driver = self::dsnDriver($dsn);
    if ($driver === 'mysql' && !str_contains(strtolower($dsn), 'charset=')
        && defined('PDO::MYSQL_ATTR_INIT_COMMAND')) {
      $options[PDO::MYSQL_ATTR_INIT_COMMAND] = "SET NAMES utf8mb4";
    }

    try {
      self::$pdos[$group] = new PDO($dsn, $user, $pass, $options);
      return self::$pdos[$group];
    } catch (\PDOException $ex) {
      // Reintento inteligente (dev): host/puerto común en XAMPP
      $retry = self::maybeRetryPdo($dsn, $user, $pass, $options, $ex);
      if ($retry instanceof PDO) {
        self::$pdos[$group] = $retry;
        return self::$pdos[$group];
      }
      throw self::wrapPdoException($ex, $group, $dsn, $user, $env, $debug);
    }
  }



  // =========================
  // Helpers de conexión PRO
  // =========================

  private static function dsnDriver(string $dsn): string
  {
    $p = strpos($dsn, ':');
    if ($p === false) return '';
    return strtolower(substr($dsn, 0, $p));
  }

  /** Parse simple para DSN mysql (host, port, dbname, charset, unix_socket, etc.) */
  private static function parseMysqlDsn(string $dsn): array
  {
    $p = strpos($dsn, ':');
    if ($p === false) return [];
    $rest = substr($dsn, $p + 1);
    $out = [];
    foreach (explode(';', $rest) as $seg) {
      $seg = trim($seg);
      if ($seg === '') continue;
      $kv = explode('=', $seg, 2);
      if (count($kv) !== 2) continue;
      $k = strtolower(trim((string)$kv[0]));
      $v = trim((string)$kv[1]);
      if ($k !== '') $out[$k] = $v;
    }
    return $out;
  }

  private static function buildMysqlDsn(array $parts, ?string $host = null, ?int $port = null): string
  {
    $p = $parts;
    if ($host !== null && $host !== '') $p['host'] = $host;
    if ($port !== null && $port > 0) $p['port'] = (string)$port;

    // Orden recomendado (más legible)
    $order = ['unix_socket','host','port','dbname','charset'];
    $segs = [];

    foreach ($order as $k) {
      if (isset($p[$k]) && (string)$p[$k] !== '') {
        $segs[] = $k . '=' . $p[$k];
      }
      unset($p[$k]);
    }

    // Conserva cualquier parámetro extra del DSN original
    foreach ($p as $k => $v) {
      $k = (string)$k;
      $v = (string)$v;
      if ($k === '' || $v === '') continue;
      $segs[] = $k . '=' . $v;
    }

    return 'mysql:' . implode(';', $segs);
  }

  private static function sanitizeDsn(string $dsn): string
  {
    // DSN normalmente no trae pass, pero por si acaso
    return preg_replace('/(password=)[^;]*/i', '$1***', $dsn) ?: $dsn;
  }

  /** Reintento inteligente en entorno dev (XAMPP / puertos comunes). */
  private static function maybeRetryPdo(string $dsn, string $user, string $pass, array $options, \PDOException $ex): ?PDO
  {
    $driver = self::dsnDriver($dsn);
    if ($driver !== 'mysql') return null;

    $msg = $ex->getMessage();
    $code = (string)$ex->getCode();
    $is2002 = (str_contains($msg, '[2002]') || $code === '2002' || $code === 'HY000');

    // Solo reintenta si parece "connection refused/failed"
    if (!$is2002) return null;

    $parts = self::parseMysqlDsn($dsn);
    $host  = $parts['host'] ?? null;
    $hasPort = isset($parts['port']) && (string)$parts['port'] !== '';

    $ports = [];
    $envPort = env('DB_PORT', '');
    if ((string)$envPort !== '') $ports[] = (int)$envPort;

    foreach ([3306, 3307, 3308] as $p) {
      if (!in_array($p, $ports, true)) $ports[] = $p;
    }

    $attempts = [];
    $altHost = null;
    if ($host === '127.0.0.1') $altHost = 'localhost';
    if ($host === 'localhost') $altHost = '127.0.0.1';

    // 1) Si no hay port en DSN, prueba puertos comunes
    if (!$hasPort && $host) {
      foreach ($ports as $p) $attempts[] = [$host, $p];
      if ($altHost) foreach ($ports as $p) $attempts[] = [$altHost, $p];
    }

    // 2) Si hay port, prueba host alterno
    if ($hasPort && $host && $altHost) {
      $attempts[] = [$altHost, (int)$parts['port']];
    }

    // 3) Si no hay host, prueba localhost/127 con puertos comunes
    if (!$host) {
      foreach (['127.0.0.1','localhost'] as $h) {
        foreach ($ports as $p) $attempts[] = [$h, $p];
      }
    }

    $tried = [];
    foreach ($attempts as $a) {
      [$h, $p] = $a;
      $key = $h . ':' . $p;
      if (isset($tried[$key])) continue;
      $tried[$key] = true;

      $dsn2 = self::buildMysqlDsn($parts, $h, (int)$p);
      try {
        return new PDO($dsn2, $user, $pass, $options);
      } catch (\PDOException $e2) {
        // sigue probando
      }
    }

    return null;
  }

  /** Envuelve PDOException con diagnóstico y tips (dev). */
  private static function wrapPdoException(\PDOException $ex, string $group, string $dsn, string $user, string $env, bool $debug): \RuntimeException
  {
    $driver = self::dsnDriver($dsn);
    $dsnSafe = self::sanitizeDsn($dsn);

    $tips = [];
    if ($driver === 'mysql') {
      $tips[] = "• Asegúrate de iniciar MySQL/MariaDB en XAMPP (panel de control).";
      $tips[] = "• Verifica el puerto: 3306 (default) o 3307 (común en XAMPP si 3306 está ocupado).";
      $tips[] = "  - Opción A: agrega ;port=3307 en DB_DSN.";
      $tips[] = "  - Opción B: define DB_PORT=3307 en .env (el framework intentará usarlo).";
      $tips[] = "• Prueba host=localhost en lugar de 127.0.0.1 (o viceversa).";
      $tips[] = "• Confirma DB_USER/DB_PASS (root a veces tiene password).";
    }

    $base = "DB: no se pudo conectar (grupo '{$group}', driver '{$driver}'). DSN='{$dsnSafe}'.";
    $detail = $ex->getMessage();

    if ($debug && $env !== 'production') {
      $msg = $base . " " . $detail . "\n\nSugerencias:\n" . implode("\n", $tips);
    } else {
      $msg = $base . " " . $detail;
    }

    return new \RuntimeException($msg, 0, $ex);
  }

  /** Helper rápido: devuelve rows (array assoc) */
  public static function query(string $sql, array $params = []): array
  {
    return self::connect()->query($sql, $params)->getResultArray();
  }

  /**
   * Resetea conexiones/PDOS cacheadas (todo o un grupo específico).
   * Útil para multi-tenant (CLI) cuando se cambia de tenant en runtime.
   */
  public static function reset(?string $group = null): void
  {
    if ($group === null) {
      self::$pdos  = [];
      self::$conns = [];
      return;
    }
    $g = strtolower(trim($group));
    unset(self::$pdos[$g], self::$conns[$g]);
  }
}
