<?php
declare(strict_types=1);

namespace System\Core;

/**
 * Paginación simple (standalone).
 *
 * Útil cuando:
 * - Estás paginando arreglos/listas (sin QueryBuilder)
 * - Ya tienes el total y solo necesitas links
 *
 * Ejemplo:
 *   $p = paginate($total, 20, (int)($_GET['page'] ?? 1), base_url('/posts?page=(:num)'));
 *   echo $p->links();
 *
 * Personalización (estilo CI/Bootstrap):
 *   echo $p->links(2, ['preset' => 'bootstrap']);
 */
final class Paginator
{
  public function __construct(
    private int $total,
    private int $perPage,
    private int $page,
    private string $pattern
  ) {
    $this->perPage = max(1, $this->perPage);
    $this->page = max(1, $this->page);
  }

  public function total(): int { return $this->total; }
  public function perPage(): int { return $this->perPage; }
  public function page(): int { return $this->page; }

  public function pages(): int
  {
    return (int)max(1, ceil($this->total / $this->perPage));
  }

  public function offset(): int
  {
    return ($this->page - 1) * $this->perPage;
  }

  public function url(int $page): string
  {
    $page = max(1, min($this->pages(), $page));
    return str_replace('(:num)', (string)$page, $this->pattern);
  }

  /**
   * Links como array (para render custom).
   * Cada item: ['page'=>int,'url'=>string,'current'=>bool]
   */
  public function linksArray(int $window = 2): array
  {
    $pages = $this->pages();
    $cur = $this->page();

    $window = max(0, $window);
    $start = max(1, $cur - $window);
    $end = min($pages, $cur + $window);

    // Bloque razonable al inicio/fin
    if ($cur <= 1 + $window) {
      $end = min($pages, 1 + ($window * 2));
    } elseif ($cur >= $pages - $window) {
      $start = max(1, $pages - ($window * 2));
    }

    $out = [];
    for ($p = $start; $p <= $end; $p++) {
      $out[] = [
        'page' => $p,
        'url' => $this->url($p),
        'current' => ($p === $cur),
      ];
    }
    return $out;
  }

  /**
   * Render links HTML.
   *
   * - Si NO envías $opts, mantiene el HTML inline anterior (compatibilidad).
   * - Si envías preset/clases, genera HTML "templatable" (Bootstrap/CI).
   *
   * Opciones principales:
   * - preset: 'bootstrap' (ul/li/a con clases) | null
   * - ariaLabel
   * - showFirstLast (bool)
   * - labels: labelFirst,labelPrev,labelNext,labelLast
   * - wrapperTag, wrapperClass, wrapperStyle
   * - containerTag (ej: 'ul'), containerClass, containerStyle
   * - itemTag (ej: 'li'), itemClass
   * - linkClass
   * - activeItemClass, activeLinkClass
   * - disabledItemClass, disabledLinkClass
   */
  public function links(int $window = 2, array $opts = []): string
  {
    if ($this->pages() <= 1) return '';

    // ===== Presets =====
    if (!empty($opts['preset'])) {
      $preset = strtolower((string)$opts['preset']);
      if ($preset === 'bootstrap' || $preset === 'ci' || $preset === 'ci4') {
        $opts = array_merge([
          'wrapperTag' => 'nav',
          'ariaLabel' => 'Paginación',
          'containerTag' => 'ul',
          'containerClass' => 'pagination',
          'itemTag' => 'li',
          'itemClass' => 'page-item',
          'linkClass' => 'page-link',
          'activeItemClass' => 'active',
          'disabledItemClass' => 'disabled',
          // Bootstrap suele usar span para disabled/active
          'useSpanForDisabled' => true,
          'useSpanForActive' => true,
          'wrapperClass' => '',
          'wrapperStyle' => '',
          'containerStyle' => '',
        ], $opts);
      }
    }

    // Si no hay config, usa compat (inline)
    if (empty($opts)) {
      return $this->linksCompat($window);
    }

    $pages = $this->pages();
    $cur = $this->page();

    $aria = (string)($opts['ariaLabel'] ?? 'Paginación');
    $showFirstLast = (bool)($opts['showFirstLast'] ?? true);

    $labelFirst = (string)($opts['labelFirst'] ?? '«');
    $labelPrev  = (string)($opts['labelPrev']  ?? '‹');
    $labelNext  = (string)($opts['labelNext']  ?? '›');
    $labelLast  = (string)($opts['labelLast']  ?? '»');

    $wTag = (string)($opts['wrapperTag'] ?? 'nav');
    $wCls = (string)($opts['wrapperClass'] ?? 'qfw-pager');
    $wSty = (string)($opts['wrapperStyle'] ?? '');

    $cTag = (string)($opts['containerTag'] ?? '');
    $cCls = (string)($opts['containerClass'] ?? '');
    $cSty = (string)($opts['containerStyle'] ?? '');

    $iTag = (string)($opts['itemTag'] ?? '');
    $iCls = (string)($opts['itemClass'] ?? '');

    $aCls = (string)($opts['linkClass'] ?? '');
    $aSty = (string)($opts['linkStyle'] ?? '');

    $activeI = (string)($opts['activeItemClass'] ?? '');
    $activeA = (string)($opts['activeLinkClass'] ?? '');
    $disI = (string)($opts['disabledItemClass'] ?? '');
    $disA = (string)($opts['disabledLinkClass'] ?? '');

    $spanDisabled = !empty($opts['useSpanForDisabled']);
    $spanActive   = !empty($opts['useSpanForActive']);

    $html = '';
    $html .= '<' . $this->h($wTag);
    if ($wCls !== '') $html .= ' class="' . $this->h($wCls) . '"';
    if ($wSty !== '') $html .= ' style="' . $this->h($wSty) . '"';
    $html .= ' aria-label="' . $this->h($aria) . '">';

    $openContainer = function() use (&$html, $cTag, $cCls, $cSty) {
      if ($cTag === '') return;
      $html .= '<' . $this->h($cTag);
      if ($cCls !== '') $html .= ' class="' . $this->h($cCls) . '"';
      if ($cSty !== '') $html .= ' style="' . $this->h($cSty) . '"';
      $html .= '>';
    };
    $closeContainer = function() use (&$html, $cTag) {
      if ($cTag === '') return;
      $html .= '</' . $this->h($cTag) . '>';
    };

    $openContainer();

    if ($showFirstLast) {
      $html .= $this->item(
        label: $labelFirst,
        url: $this->url(1),
        disabled: ($cur === 1),
        active: false,
        itemTag: $iTag,
        itemClass: $iCls,
        linkClass: $aCls,
        linkStyle: $aSty,
        activeItemClass: $activeI,
        activeLinkClass: $activeA,
        disabledItemClass: $disI,
        disabledLinkClass: $disA,
        useSpanWhenDisabled: $spanDisabled,
        useSpanWhenActive: $spanActive,
        ariaCurrent: false,
      );
    }

    $html .= $this->item(
      label: $labelPrev,
      url: $this->url($cur - 1),
      disabled: ($cur === 1),
      active: false,
      itemTag: $iTag,
      itemClass: $iCls,
      linkClass: $aCls,
      linkStyle: $aSty,
      activeItemClass: $activeI,
      activeLinkClass: $activeA,
      disabledItemClass: $disI,
      disabledLinkClass: $disA,
      useSpanWhenDisabled: $spanDisabled,
      useSpanWhenActive: $spanActive,
      ariaCurrent: false,
    );

    foreach ($this->linksArray($window) as $it) {
      $html .= $this->item(
        label: (string)$it['page'],
        url: (string)$it['url'],
        disabled: false,
        active: (bool)$it['current'],
        itemTag: $iTag,
        itemClass: $iCls,
        linkClass: $aCls,
        linkStyle: $aSty,
        activeItemClass: $activeI,
        activeLinkClass: $activeA,
        disabledItemClass: $disI,
        disabledLinkClass: $disA,
        useSpanWhenDisabled: $spanDisabled,
        useSpanWhenActive: $spanActive,
        ariaCurrent: true,
      );
    }

    $html .= $this->item(
      label: $labelNext,
      url: $this->url($cur + 1),
      disabled: ($cur === $pages),
      active: false,
      itemTag: $iTag,
      itemClass: $iCls,
      linkClass: $aCls,
      linkStyle: $aSty,
      activeItemClass: $activeI,
      activeLinkClass: $activeA,
      disabledItemClass: $disI,
      disabledLinkClass: $disA,
      useSpanWhenDisabled: $spanDisabled,
      useSpanWhenActive: $spanActive,
      ariaCurrent: false,
    );

    if ($showFirstLast) {
      $html .= $this->item(
        label: $labelLast,
        url: $this->url($pages),
        disabled: ($cur === $pages),
        active: false,
        itemTag: $iTag,
        itemClass: $iCls,
        linkClass: $aCls,
        linkStyle: $aSty,
        activeItemClass: $activeI,
        activeLinkClass: $activeA,
        disabledItemClass: $disI,
        disabledLinkClass: $disA,
        useSpanWhenDisabled: $spanDisabled,
        useSpanWhenActive: $spanActive,
        ariaCurrent: false,
      );
    }

    $closeContainer();
    $html .= '</' . $this->h($wTag) . '>';

    return $html;
  }

  /** Render anterior (inline) para no romper proyectos. */
  private function linksCompat(int $window = 2): string
  {
    $pages = $this->pages();
    $cur = $this->page();

    $window = max(0, $window);
    $start = max(1, $cur - $window);
    $end = min($pages, $cur + $window);

    $html = '<nav class="qfw-pager" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:12px">';
    $html .= $this->linkCompat('«', 1, $cur == 1);
    $html .= $this->linkCompat('‹', $cur - 1, $cur == 1);

    for ($i = $start; $i <= $end; $i++) {
      $active = ($i == $cur);
      $html .= $this->linkCompat((string)$i, $i, false, $active);
    }

    $html .= $this->linkCompat('›', $cur + 1, $cur == $pages);
    $html .= $this->linkCompat('»', $pages, $cur == $pages);
    $html .= '</nav>';
    return $html;
  }

  private function linkCompat(string $label, int $page, bool $disabled, bool $active=false): string
  {
    $style = 'padding:8px 12px;border-radius:10px;border:1px solid #e7e7ef;background:#fff;text-decoration:none;';
    if ($active) $style .= 'font-weight:700;';
    if ($disabled) return '<span style="'.$this->h($style).'opacity:.5">'.$this->h($label).'</span>';
    return '<a style="'.$this->h($style).'" href="'.$this->h($this->url($page)).'">'.$this->h($label).'</a>';
  }

  private function item(
    string $label,
    string $url,
    bool $disabled,
    bool $active,
    string $itemTag,
    string $itemClass,
    string $linkClass,
    string $linkStyle,
    string $activeItemClass,
    string $activeLinkClass,
    string $disabledItemClass,
    string $disabledLinkClass,
    bool $useSpanWhenDisabled,
    bool $useSpanWhenActive,
    bool $ariaCurrent
  ): string {
    $wrap = ($itemTag !== '');
    $out = '';

    $wrapCls = $itemClass;
    if ($active && $activeItemClass !== '') $wrapCls = trim($wrapCls . ' ' . $activeItemClass);
    if ($disabled && $disabledItemClass !== '') $wrapCls = trim($wrapCls . ' ' . $disabledItemClass);

    if ($wrap) {
      $out .= '<' . $this->h($itemTag);
      if ($wrapCls !== '') $out .= ' class="' . $this->h($wrapCls) . '"';
      $out .= '>';
    }

    $tag = 'a';
    if (($disabled && $useSpanWhenDisabled) || ($active && $useSpanWhenActive)) {
      $tag = 'span';
    }

    $aClsFinal = $linkClass;
    if ($active && $activeLinkClass !== '') $aClsFinal = trim($aClsFinal . ' ' . $activeLinkClass);
    if ($disabled && $disabledLinkClass !== '') $aClsFinal = trim($aClsFinal . ' ' . $disabledLinkClass);

    $out .= '<' . $this->h($tag);
    if ($aClsFinal !== '') $out .= ' class="' . $this->h($aClsFinal) . '"';
    if ($linkStyle !== '') $out .= ' style="' . $this->h($linkStyle) . '"';
    if ($tag === 'a') $out .= ' href="' . $this->h($disabled ? '#' : $url) . '"';
    if ($active && $ariaCurrent) $out .= ' aria-current="page"';
    $out .= '>' . $this->h($label) . '</' . $this->h($tag) . '>';

    if ($wrap) $out .= '</' . $this->h($itemTag) . '>';
    return $out;
  }

  private function h(string $s): string
  {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
  }
}
