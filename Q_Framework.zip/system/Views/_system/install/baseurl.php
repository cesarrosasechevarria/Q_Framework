<?php
declare(strict_types=1);

ob_start();

/** Installer state */
$data = $data ?? [];
$base = (string)($data['baseURL'] ?? 'auto');
$idx  = (string)($data['indexPage'] ?? '');
?>
<h2 style="margin:0 0 6px">Base URL</h2>
<p class="qfw-muted" style="margin-top:0">
  Configura cómo se construyen tus enlaces. Recomendado:
  <code>auto</code> (funciona tanto si entras con <code>/public</code> como si ya configuraste URLs limpias).
</p>

<form method="post" style="margin-top:12px">
  <div class="qfw-form">
    <label class="qfw-label">baseURL</label>
    <input class="qfw-input" name="baseURL" value="<?= htmlspecialchars($base) ?>"
           placeholder="auto (recomendado) / https://example.com/ / http://localhost/proyecto/" />
    <div class="qfw-muted" style="margin-top:8px">
      <strong>Tip:</strong> si ahora ves <code>/public</code> en tu barra (ej: <code>/Q_Framework/public/</code>), deja <code>auto</code>.
      Cuando actives URLs limpias, Q_Framework se adapta automáticamente.
    </div>
  </div>

  <div class="qfw-form" style="margin-top:14px">
    <label class="qfw-label">indexPage</label>
    <input class="qfw-input" name="indexPage" value="<?= htmlspecialchars($idx) ?>"
           placeholder="(vacío para URLs limpias) / index.php" />
    <div class="qfw-muted" style="margin-top:8px">
      Déjalo vacío para URLs limpias. Si tu servidor no soporta reescritura, usa <code>index.php</code>.
    </div>
  </div>

  <div class="qfw-actions" style="margin-top:14px">
    <a class="qfw-btn ghost" href="<?= htmlspecialchars(base_url('install/requirements')) ?>">← Atrás</a>
    <button class="qfw-btn primary" type="submit">Guardar y continuar ➜</button>
  </div>
</form>

<div class="qfw-muted" style="margin-top:14px">
  ¿Quieres que tu dominio quede <strong>sin</strong> <code>/public</code>? Mira la guía:
  <a href="<?= htmlspecialchars(base_url('setup/publicless')) ?>">Setup · URLs limpias</a>.
</div>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
