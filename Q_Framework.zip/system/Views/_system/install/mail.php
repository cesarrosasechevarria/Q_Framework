<?php
ob_start();
?>
<h2 style="margin:0 0 6px">Mail</h2>
<p class="qfw-muted" style="margin-top:0">Por ahora incluye <code>mail()</code> y placeholders para SMTP (puedes implementarlo después).</p>

<form method="post">
  <div class="qfw-split">
    <div>
      <label>MAIL_DRIVER</label>
      <select name="MAIL_DRIVER">
        <option value="mail" <?= (($data['MAIL_DRIVER'] ?? 'mail')==='mail') ? 'selected' : '' ?>>mail()</option>
        <option value="smtp" <?= (($data['MAIL_DRIVER'] ?? 'mail')==='smtp') ? 'selected' : '' ?>>SMTP (placeholder)</option>
      </select>
    </div>
    <div>
      <label>MAIL_FROM</label>
      <input name="MAIL_FROM" value="<?= htmlspecialchars($data['MAIL_FROM'] ?? 'no-reply@example.com') ?>">
    </div>
  </div>

  <label>MAIL_FROM_NAME</label>
  <input name="MAIL_FROM_NAME" value="<?= htmlspecialchars($data['MAIL_FROM_NAME'] ?? 'Q_Framework') ?>">

  <div class="qfw-split">
    <div>
      <label>MAIL_HOST</label>
      <input name="MAIL_HOST" value="<?= htmlspecialchars($data['MAIL_HOST'] ?? '') ?>">
    </div>
    <div>
      <label>MAIL_PORT</label>
      <input name="MAIL_PORT" value="<?= htmlspecialchars($data['MAIL_PORT'] ?? '587') ?>">
    </div>
  </div>

  <div class="qfw-split">
    <div>
      <label>MAIL_USER</label>
      <input name="MAIL_USER" value="<?= htmlspecialchars($data['MAIL_USER'] ?? '') ?>">
    </div>
    <div>
      <label>MAIL_PASS</label>
      <input name="MAIL_PASS" value="<?= htmlspecialchars($data['MAIL_PASS'] ?? '') ?>">
    </div>
  </div>

  <label>MAIL_ENCRYPTION</label>
  <input name="MAIL_ENCRYPTION" value="<?= htmlspecialchars($data['MAIL_ENCRYPTION'] ?? 'tls') ?>">

  <div style="margin-top:14px">
    <button class="qfw-btn primary" type="submit">Guardar y continuar ➜</button>
  </div>
</form>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
