<?php
ob_start();
?>
<h2 style="margin:0 0 6px">Bienvenido</h2>
<p class="qfw-muted" style="margin-top:0">
  Este asistente configura tu Q_Framework: <code>baseURL</code>, <code>APP_KEY</code>, CSRF, BD, Mail y crea el archivo <code>write/install.lock</code>.
</p>

<div class="qfw-card" style="margin-top:12px">
  <div style="font-weight:900">Modo PRO recomendado: sin <code>/public</code></div>
  <div class="qfw-muted" style="margin-top:6px">
    Para que tu app se vea como <code>dominio.com/</code> (y no <code>dominio.com/public</code>),
    configura tu servidor para que el <strong>DocumentRoot</strong> apunte a <code>public/</code>.
  </div>
  <div style="margin-top:10px;display:flex;gap:10px;flex-wrap:wrap">
    <a class="qfw-btn" href="<?= route_url('docs.publicless') ?>">Ver guía sin /public</a>
    <a class="qfw-btn" href="<?= base_url('_health.php') ?>">Health</a>
  </div>
</div>

<form method="post" style="margin-top:14px">
  <button class="qfw-btn primary" type="submit">Empezar ➜</button>
</form>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
