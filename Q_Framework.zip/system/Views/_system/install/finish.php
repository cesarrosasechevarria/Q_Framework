<?php
declare(strict_types=1);

/**
 * Step: finish
 * - IMPORTANTE: este step muestra un botón que hace POST para "finalizar".
 * - En el POST, Install::handlePost() escribe:
 *     - INSTALL_WIZARD=0 en .env
 *     - write/install.lock
 *   y luego redirige a /?installed=1
 */

ob_start();

$title = 'Instalación finalizada';

/** Installer state */
$data = $data ?? [];

$siteWithPublic = rtrim(base_url('/'), '/');
$siteNoPublic   = preg_replace('~/public$~', '', $siteWithPublic) ?: $siteWithPublic;
$same = (rtrim($siteWithPublic,'/') === rtrim($siteNoPublic,'/'));
?>
<div class="qfw-card">
  <div class="qfw-row" style="align-items:center; gap:12px;">
    <div style="font-size:38px; line-height:1;">🎉</div>
    <div>
      <h2 style="margin:0">¡Listo! Revisa y finaliza la instalación</h2>
      <div class="qfw-muted" style="margin-top:4px">
        Al finalizar, se desactiva el instalador (<code>INSTALL_WIZARD=0</code>) y se crea <code>write/install.lock</code>.
      </div>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="qfw-grid-2">
    <div class="qfw-panel">
      <div style="font-weight:700; margin-bottom:6px">URL actual (con <code>/public</code>)</div>
      <div class="qfw-muted"><?= htmlspecialchars($siteWithPublic) ?></div>
    </div>

    <div class="qfw-panel">
      <div style="font-weight:700; margin-bottom:6px">URL limpia (sin <code>/public</code>)</div>
      <div class="qfw-muted"><?= htmlspecialchars($siteNoPublic) ?></div>
      <?php if (!$same): ?>
        <div class="qfw-muted" style="margin-top:8px">
          Requiere <code>DocumentRoot</code> a <code>public/</code> o rewrite en la raíz.
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div style="height:14px"></div>

  <form method="post" action="<?= htmlspecialchars(base_url('install/finish')) ?>">
    <input type="hidden" name="_finalize" value="1">
    <button class="qfw-btn primary" type="submit">Finalizar e ir al Inicio</button>
    <a class="qfw-btn" href="<?= htmlspecialchars(base_url('setup/publicless')) ?>">Setup · URLs limpias</a>
    <a class="qfw-btn" href="<?= htmlspecialchars(base_url('docs/capabilities')) ?>">Ver guía / capacidades</a>
  </form>

  <?php if (!$same): ?>
    <div class="qfw-alert" style="margin-top:14px">
      <strong>Nota:</strong> Si “URL limpia” muestra 404, habilita <code>mod_rewrite</code> y <code>AllowOverride All</code>,
      o configura un VirtualHost apuntando a <code>public/</code>.
    </div>
  <?php endif; ?>
</div>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
