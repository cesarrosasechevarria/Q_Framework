<?php
ob_start();
?>
<h2 style="margin:0 0 6px"><?= htmlspecialchars($title ?? 'Info') ?></h2>
<div class="qfw-muted" style="margin-top:0"><?= $body ?? '' ?></div>
<div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
  <?= $linksHtml ?? '' ?>
  <a class="qfw-btn" href="<?= htmlspecialchars(base_url('install')) ?>">Abrir instalador</a>
</div>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
