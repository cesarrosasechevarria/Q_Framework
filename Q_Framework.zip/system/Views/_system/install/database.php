<?php
ob_start();
?>
<h2 style="margin:0 0 6px">Base de datos</h2>
<p class="qfw-muted" style="margin-top:0">Opcional. Si no usas BD aún, puedes dejarlo vacío.</p>

<form method="post">
  <label>DB_DSN</label>
  <input name="DB_DSN" value="<?= htmlspecialchars($data['DB_DSN'] ?? 'mysql:host=127.0.0.1;dbname=test;charset=utf8mb4') ?>">

  <div class="qfw-split">
    <div>
      <label>DB_USER</label>
      <input name="DB_USER" value="<?= htmlspecialchars($data['DB_USER'] ?? 'root') ?>">
    </div>
    <div>
      <label>DB_PASS</label>
      <input name="DB_PASS" value="<?= htmlspecialchars($data['DB_PASS'] ?? '') ?>">
    </div>
  </div>

  <div style="margin-top:14px">
    <button class="qfw-btn primary" type="submit">Guardar y continuar ➜</button>
  </div>
</form>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
