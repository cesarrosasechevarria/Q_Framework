<?php
function step_active(string $s, string $cur): string { return $s === $cur ? 'active' : ''; }
$steps = [
  'welcome'       => 'Inicio',
  'requirements'  => 'Requisitos',
  'baseurl'       => 'Base URL',
  'security'      => 'Seguridad',
  'database'      => 'BD',
  'mail'          => 'Mail',
  'finish'        => 'Final'
];
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Q_Framework Installer</title>
  <link rel="stylesheet" href="<?= base_url('assets/qfw.css') ?>">
  <script defer src="<?= base_url('assets/qfw.js') ?>"></script>
</head>
<body>
  <div class="qfw-wrap">
    <div class="qfw-top">
      <div class="qfw-row" style="gap:10px">
        <div class="qfw-badge">Q</div>
        <div style="font-weight:900">Q_Framework Installer</div>
      </div>
      <div class="qfw-row">
        <div class="qfw-muted">Config guiada · genera <code>.env</code> · crea <code>install.lock</code></div>
        <button class="qfw-btn icon" type="button" data-qfw-theme-toggle title="Tema">🌓</button>
      </div>
    </div>

    <div class="qfw-card">
      <div class="qfw-steps">
        <?php foreach ($steps as $k => $t): ?>
          <div class="qfw-step <?= step_active($k, (string)($step ?? 'welcome')) ?>"><?= htmlspecialchars($t) ?></div>
        <?php endforeach; ?>
      </div>

      <?php if (!empty($error)): ?>
        <div class="qfw-card" style="border-color:rgba(224,82,82,.55);margin-bottom:14px">
          <div style="font-weight:800;margin-bottom:6px">⚠️ Atención</div>
          <div class="qfw-muted"><?= htmlspecialchars((string)$error) ?></div>
        </div>
      <?php endif; ?>

      <?= $content ?? '' ?>
    </div>

    <p class="qfw-muted" style="margin-top:14px">Tip: cuando termines, borra o desactiva el instalador poniendo <code>INSTALL_WIZARD=0</code> o eliminando la ruta /install.</p>
  </div>
</body>
</html>
