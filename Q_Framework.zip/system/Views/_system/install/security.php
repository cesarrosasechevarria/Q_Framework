<?php
ob_start();
?>
<h2 style="margin:0 0 6px">Seguridad</h2>
<p class="qfw-muted" style="margin-top:0">Genera <code>APP_KEY</code> y configura CSRF.</p>

<form method="post">
  <label>APP_KEY (si lo dejas vacío, se genera automáticamente)</label>
  <input name="appKey" value="<?= htmlspecialchars($data['APP_KEY'] ?? '') ?>" placeholder="base64:...">

  <div class="qfw-split">
    <div>
      <label>CSRF Enabled</label>
      <select name="csrfEnabled">
        <option value="1" <?= (($data['CSRF_ENABLED'] ?? '1')==='1') ? 'selected' : '' ?>>Sí</option>
        <option value="0" <?= (($data['CSRF_ENABLED'] ?? '1')==='0') ? 'selected' : '' ?>>No</option>
      </select>
    </div>
    <div>
      <label>CSRF Key</label>
      <input name="csrfKey" value="<?= htmlspecialchars($data['CSRF_KEY'] ?? '_token') ?>">
    </div>
  </div>

  <label>CSRF Rotate (rota token)</label>
  <select name="csrfRotate">
    <option value="0" <?= (($data['CSRF_ROTATE'] ?? '0')==='0') ? 'selected' : '' ?>>No</option>
    <option value="1" <?= (($data['CSRF_ROTATE'] ?? '0')==='1') ? 'selected' : '' ?>>Sí</option>
  </select>

  <div style="margin-top:14px">
    <button class="qfw-btn primary" type="submit">Guardar y continuar ➜</button>
  </div>
</form>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
