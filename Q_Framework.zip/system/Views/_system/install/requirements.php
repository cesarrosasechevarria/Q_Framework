<?php
ob_start();
?>
<h2 style="margin:0 0 6px">Requisitos</h2>
<p class="qfw-muted" style="margin-top:0">Asegúrate de que todo lo <strong>requerido</strong> esté en verde antes de continuar.</p>

<table style="margin-top:12px">
  <?php foreach(($checks ?? []) as $c): ?>
    <tr>
      <td style="width:36px"><?= !empty($c['ok']) ? '<span class="qfw-ok">✔</span>' : '<span class="qfw-bad">✖</span>' ?></td>
      <td>
        <?= htmlspecialchars((string)$c['name']) ?>
        <?php if (!empty($c['required'])): ?>
          <span class="qfw-muted" style="margin-left:6px">(requerido)</span>
        <?php else: ?>
          <span class="qfw-muted" style="margin-left:6px">(opcional)</span>
        <?php endif; ?>
      </td>
      <td class="qfw-muted" style="width:200px"><?= htmlspecialchars((string)($c['detail'] ?? '')) ?></td>
    </tr>
  <?php endforeach; ?>
</table>

<div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
  <form method="post" style="margin:0">
    <button class="qfw-btn primary" type="submit" <?= !empty($reqOk) ? '' : 'disabled' ?>>Continuar ➜</button>
  </form>
  <a class="qfw-btn" href="<?= htmlspecialchars(base_url('install/requirements')) ?>">Refrescar</a>
  <a class="qfw-btn" href="<?= htmlspecialchars(base_url('_health.php')) ?>">Ver Health</a>
  <?php if (empty($reqOk)): ?>
    <span class="qfw-muted">Corrige los elementos en rojo (permisos/extensiones) para continuar.</span>
  <?php endif; ?>
</div>
<?php
$content = (string)ob_get_clean();
include __DIR__.'/_layout.php';
