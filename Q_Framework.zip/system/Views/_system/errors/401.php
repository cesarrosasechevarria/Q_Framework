<?php
declare(strict_types=1);

/** @var int $code */
/** @var string $title */
/** @var string $message */
/** @var string $traceId */
$code = $code ?? 401;
$title = $title ?? "No autorizado";
$message = $message ?? "Debes autenticarte para acceder a este recurso.";
$traceId = $traceId ?? '';
$home = function_exists('base_url') ? base_url('/') : '/';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars((string)$code) ?> · <?= htmlspecialchars((string)$title) ?></title>
  <style>
    :root {
      --bg: #0b1220;
      --card: rgba(255,255,255,.06);
      --muted: rgba(255,255,255,.72);
      --text: rgba(255,255,255,.92);
      --border: rgba(255,255,255,.12);
      --accent: #7c3aed;
      --accent2: #22c55e;
      --shadow: 0 18px 50px rgba(0,0,0,.40);
    }
    @media (prefers-color-scheme: light) {
      :root {
        --bg: #f5f7fb;
        --card: rgba(255,255,255,.86);
        --muted: rgba(17,24,39,.65);
        --text: rgba(17,24,39,.92);
        --border: rgba(17,24,39,.12);
        --accent: #5b21b6;
        --accent2: #16a34a;
        --shadow: 0 18px 50px rgba(17,24,39,.12);
      }
    }
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, "Noto Sans", "Liberation Sans", sans-serif;
      background: radial-gradient(1200px 800px at 20% 10%, rgba(124,58,237,.25), transparent 60%),
                  radial-gradient(900px 700px at 90% 30%, rgba(34,197,94,.18), transparent 55%),
                  var(--bg);
      color: var(--text);
      min-height: 100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      padding: 28px;
    }
    .wrap{width: min(980px, 100%);}
    .card{
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 18px;
      padding: 22px;
      box-shadow: var(--shadow);
      overflow:hidden;
    }
    .top{display:flex;gap:14px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap}
    .badge{
      width: 44px; height: 44px;
      border-radius: 14px;
      display:flex; align-items:center; justify-content:center;
      background: linear-gradient(135deg, var(--accent), #0ea5e9);
      color: white;
      font-weight: 900;
      letter-spacing:.5px;
      flex: 0 0 auto;
    }
    .h1{font-size: 26px; line-height: 1.2; margin: 0 0 6px 0; font-weight: 900}
    .muted{color: var(--muted)}
    .meta{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}
    .pill{
      border: 1px solid var(--border);
      padding: 6px 10px;
      border-radius: 999px;
      font-size: 12px;
      color: var(--muted);
      background: rgba(0,0,0,.06);
    }
    @media (prefers-color-scheme: light){ .pill{background: rgba(255,255,255,.55);} }
    .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top: 16px}
    a.btn{
      display:inline-flex;align-items:center;gap:8px;
      padding: 10px 14px;
      border-radius: 12px;
      border: 1px solid var(--border);
      text-decoration:none;
      color: var(--text);
      font-weight: 700;
      background: rgba(0,0,0,.08);
    }
    @media (prefers-color-scheme: light){ a.btn{background: rgba(255,255,255,.65);} }
    a.btn.primary{
      border-color: rgba(124,58,237,.35);
      background: linear-gradient(135deg, rgba(124,58,237,.30), rgba(14,165,233,.18));
    }
    .hr{height:1px;background: var(--border);margin:16px 0}
    .hint{font-size: 13px; line-height: 1.5}
    code{font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <div class="top">
        <div style="display:flex;gap:14px;align-items:flex-start">
          <div class="badge">Q</div>
          <div>
            <h1 class="h1"><?= htmlspecialchars((string)$code) ?> · <?= htmlspecialchars((string)$title) ?></h1>
            <div class="muted"><?= htmlspecialchars((string)$message) ?></div>
            <div class="meta">
              <span class="pill">Trace: <?= htmlspecialchars((string)$traceId) ?></span>
              <span class="pill">PHP <?= htmlspecialchars(PHP_VERSION) ?></span>
            </div>
          </div>
        </div>

        <div class="actions">
          <a class="btn primary" href="<?= htmlspecialchars((string)$home) ?>">🏠 Ir al inicio</a>
          <a class="btn" href="javascript:history.back()">↩️ Volver</a>
        </div>
      </div>

      <div class="hr"></div>
      <div class="hint muted">
        Si este error ocurre en desarrollo, activa <code>APP_DEBUG=1</code> en tu <code>.env</code> para ver detalles.
        En producción, revisa <code>write/logs/</code> usando el <code>Trace</code> mostrado arriba.
      </div>
    </div>
  </div>
</body>
</html>
