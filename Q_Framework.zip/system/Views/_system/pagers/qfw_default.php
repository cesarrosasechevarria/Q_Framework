<?php
/**
 * Pager template (core)
 *
 * Puedes sobreescribir este archivo copiándolo a:
 *   app/Views/pagers/qfw_default.php
 *
 * Variables disponibles:
 * - $pager     : \System\Database\Pager
 * - $pagerCfg  : Config\Pager
 */

/** @var \System\Database\Pager $pager */
/** @var object $pagerCfg */

$totalPages = $pager->totalPages();
if ($totalPages <= 1) return;

$cfg = $pagerCfg ?? config('Pager');

$navClass    = $cfg->navClass ?? 'qfw-pager';
$rowClass    = $cfg->rowClass ?? 'qfw-row';
$btnClass    = $cfg->btnClass ?? 'qfw-btn';
$activeClass = $cfg->activeBtnClass ?? 'qfw-btn primary';
$disabledCls = $cfg->disabledClass ?? 'qfw-btn';
$disabledSty = $cfg->disabledStyle ?? 'opacity:.45; pointer-events:none';
$summaryCls  = $cfg->summaryClass ?? 'qfw-muted';

$showFirstLast = !empty($cfg->showFirstLast);
$showSummary   = !empty($cfg->showSummary);

$labelFirst = (string)($cfg->labelFirst ?? '«');
$labelPrev  = (string)($cfg->labelPrev  ?? '‹');
$labelNext  = (string)($cfg->labelNext  ?? '›');
$labelLast  = (string)($cfg->labelLast  ?? '»');

$btn = function(string $label, ?string $url, bool $enabled, string $title) use ($btnClass, $disabledCls, $disabledSty): string {
  if (!$enabled || !$url) {
    return '<span class="'.e($disabledCls).'" style="'.e($disabledSty).'" title="'.e($title).'">'.e($label).'</span>';
  }
  return '<a class="'.e($btnClass).'" href="'.e($url).'" title="'.e($title).'">'.e($label).'</a>';
};
?>

<nav class="<?= e((string)$navClass) ?>" aria-label="Paginación">
  <div class="<?= e((string)$rowClass) ?>" style="gap:8px; flex-wrap:wrap">

    <?php if ($showFirstLast): ?>
      <?= $btn($labelFirst, $pager->firstUrl(), $pager->hasPrev(), 'Primera') ?>
    <?php endif; ?>

    <?= $btn($labelPrev, $pager->prevUrl(), $pager->hasPrev(), 'Anterior') ?>

    <?php foreach ($pager->linksArray() as $it): ?>
      <?php $cls = $it['current'] ? $activeClass : $btnClass; ?>
      <a class="<?= e((string)$cls) ?>" href="<?= e((string)$it['url']) ?>"><?= (int)$it['page'] ?></a>
    <?php endforeach; ?>

    <?= $btn($labelNext, $pager->nextUrl(), $pager->hasNext(), 'Siguiente') ?>

    <?php if ($showFirstLast): ?>
      <?= $btn($labelLast, $pager->lastUrl(), $pager->hasNext(), 'Última') ?>
    <?php endif; ?>

  </div>

  <?php if ($showSummary): ?>
    <div class="<?= e((string)$summaryCls) ?>" style="margin-top:8px">
      Página <?= (int)$pager->currentPage() ?> de <?= (int)$pager->totalPages() ?> · <?= (int)$pager->totalRows() ?> registros
    </div>
  <?php endif; ?>
</nav>
