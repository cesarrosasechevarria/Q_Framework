<?php
declare(strict_types=1);

namespace System\I18n;

/**
 * Lang loader
 *
 * Estructura:
 * app/Language/es/app.php retorna ['welcome' => '...']
 *
 * Uso:
 *   lang('app.welcome');          // archivo 'app' -> key 'welcome'
 *   lang('auth.invalid');         // archivo 'auth' -> key 'invalid'
 */
final class Lang
{
  /** @var array<string, array<string,mixed>> */
  private array $loaded = [];

  public function __construct(private string $locale)
  {
    $this->locale = trim($this->locale) ?: 'en';
  }

  public function locale(): string
  {
    return $this->locale;
  }

  public function setLocale(string $locale): void
  {
    $locale = trim($locale);
    if ($locale === '') return;
    $this->locale = $locale;
  }

  public function get(string $key, array $params = []): string
  {
    $key = trim($key);
    if ($key === '') return '';

    // file.key
    $file = $key;
    $k = $key;
    if (str_contains($key, '.')) {
      [$file, $k] = explode('.', $key, 2);
    }

    $arr = $this->loadFile($file);
    $val = $arr[$k] ?? $key;

    if (!is_string($val)) return (string)$val;

    foreach ($params as $pKey => $pVal) {
      $val = str_replace('{' . $pKey . '}', (string)$pVal, $val);
    }

    return $val;
  }

  private function loadFile(string $file): array
  {
    $file = trim($file);
    if ($file === '') return [];

    $cacheKey = $this->locale . ':' . $file;
    if (isset($this->loaded[$cacheKey])) return $this->loaded[$cacheKey];

    $path = base_path('app/Language/' . $this->locale . '/' . $file . '.php');
    if (!is_file($path)) {
      $this->loaded[$cacheKey] = [];
      return [];
    }

    $arr = require $path;
    $this->loaded[$cacheKey] = is_array($arr) ? $arr : [];
    return $this->loaded[$cacheKey];
  }
}
