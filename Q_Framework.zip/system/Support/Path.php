<?php
declare(strict_types=1);

namespace System\Support;

/**
 * Path (Q_Framework)
 *
 * Utilidades de rutas para Windows/Linux/Mac.
 *
 * Principios:
 * - Internamente normalizamos a formato UNIX (/) para procesar y comparar.
 * - Luego puedes convertir a formato nativo (DIRECTORY_SEPARATOR) para operaciones con filesystem.
 * - resolveUnder() está pensado para inputs de usuario (POST/GET): evita que '..' escape de una base.
 */
final class Path
{
    private function __construct() {}

    public static function isWindows(): bool
    {
        return (defined('PHP_OS_FAMILY') && PHP_OS_FAMILY === 'Windows') || DIRECTORY_SEPARATOR === '\\';
    }

    /** Normaliza separadores a UNIX (/) y elimina bytes nulos. */
    public static function toUnix(string $path): string
    {
        $p = str_replace("\0", '', $path);
        $p = trim($p);
        $p = str_replace('\\', '/', $p);

        // Colapsar múltiples slashes, preservando UNC inicial //
        if (str_starts_with($p, '//')) {
            $p = '//' . preg_replace('#/+#', '/', substr($p, 2));
        } else {
            $p = preg_replace('#/+#', '/', $p);
        }
        return $p ?? '';
    }

    /** Convierte a separador nativo del SO. */
    public static function toNative(string $path): string
    {
        $u = self::toUnix($path);
        return DIRECTORY_SEPARATOR === '/' ? $u : str_replace('/', DIRECTORY_SEPARATOR, $u);
    }

    /**
     * Indica si la ruta es absoluta.
     * - Unix: /...
     * - Windows: C:\... o C:/...
     * - UNC: \\server\share o //server/share
     */
    public static function isAbsolute(string $path): bool
    {
        $p = self::toUnix($path);
        if ($p === '') return false;

        if (str_starts_with($p, '/')) return true;
        if (str_starts_with($p, '//')) return true; // UNC
        return (bool)preg_match('#^[A-Za-z]:/#', $p); // drive absolute
    }

    /**
     * Colapsa '.' y '..' en una ruta (UNIX).
     * - Absoluta: no deja escapar del root.
     * - Relativa: preserva .. extra.
     */
    public static function collapseDots(string $path, bool $keepTrailingSlash = false): string
    {
        $p = self::toUnix($path);
        if ($p === '') return '';

        $trailing = ($keepTrailingSlash && str_ends_with($p, '/') && $p !== '/');

        $root = '';
        $segments = [];

        // UNC: //server/share/...
        if (str_starts_with($p, '//')) {
            $rest = substr($p, 2);
            $parts = explode('/', $rest);
            $server = $parts[0] ?? '';
            $share  = $parts[1] ?? '';
            if ($server !== '' && $share !== '') {
                $root = '//' . $server . '/' . $share;
                $segments = array_slice($parts, 2);
            } else {
                $root = '//';
                $segments = array_values(array_filter($parts, fn($x)=>$x!=='' ));
            }
        }
        // Drive: C:/...
        elseif (preg_match('#^([A-Za-z]:)(/.*)?$#', $p, $m)) {
            $drive = $m[1];
            $rest = $m[2] ?? '';
            if ($rest !== '' && str_starts_with($rest, '/')) {
                $root = $drive . '/';
                $segments = explode('/', ltrim($rest, '/'));
            } else {
                $root = $drive; // C: (relativo)
                $segments = $rest !== '' ? explode('/', ltrim($rest, '/')) : [];
            }
        }
        // Unix abs
        elseif (str_starts_with($p, '/')) {
            $root = '/';
            $segments = explode('/', ltrim($p, '/'));
        }
        // Relative
        else {
            $root = '';
            $segments = explode('/', $p);
        }

        $stack = [];
        foreach ($segments as $seg) {
            if ($seg === '' || $seg === '.') continue;
            if ($seg === '..') {
                if (!empty($stack) && end($stack) !== '..') {
                    array_pop($stack);
                    continue;
                }
                if ($root === '' || (bool)preg_match('#^[A-Za-z]:$#', $root)) {
                    $stack[] = '..';
                }
                continue; // absoluto: ignora .. extra
            }
            $stack[] = $seg;
        }

        if ($root === '/') {
            $out = '/' . implode('/', $stack);
            if ($out === '') $out = '/';
        } elseif (str_starts_with($root, '//') && $root !== '//') {
            $out = $root . (empty($stack) ? '' : '/' . implode('/', $stack));
        } elseif (preg_match('#^[A-Za-z]:/$#', $root)) {
            $out = $root . implode('/', $stack);
        } elseif (preg_match('#^[A-Za-z]:$#', $root)) {
            $out = $root . (empty($stack) ? '' : '/' . implode('/', $stack));
        } else {
            $out = implode('/', $stack);
        }

        if ($trailing && $out !== '' && !str_ends_with($out, '/')) $out .= '/';
        return $out;
    }

    /** Une segmentos y normaliza. Si alguno es absoluto, reinicia desde ese segmento. */
    public static function join(string $base, string ...$parts): string
    {
        $buf = self::toUnix($base);
        foreach ($parts as $p) {
            $p = self::toUnix((string)$p);
            if ($p === '') continue;

            if (self::isAbsolute($p)) {
                $buf = $p;
                continue;
            }
            $buf = rtrim($buf, '/') . '/' . ltrim($p, '/');
        }
        return self::collapseDots($buf);
    }

    /**
     * Resuelve un input dentro de una base, evitando escape.
     * Retorna ruta ABSOLUTA (nativa) o null.
     */
    public static function resolveUnder(string $input, string $base, bool $mustExist = false): ?string
    {
        $baseU = self::collapseDots(self::toUnix($base));
        if ($baseU === '') return null;

        $baseReal = realpath(self::toNative($baseU)) ?: self::toNative($baseU);
        $baseU = self::collapseDots(self::toUnix($baseReal));

        $in = trim(self::toUnix($input));
        if ($in === '' || $in === '.' || $in === './' || $in === '/') {
            return self::toNative($baseU);
        }

        $candidateU = self::isAbsolute($in)
            ? self::collapseDots($in)
            : self::collapseDots(self::join($baseU, $in));

        if (!self::withinUnix($candidateU, $baseU)) return null;

        if ($mustExist) {
            $rp = realpath(self::toNative($candidateU));
            if (!$rp) return null;
            $rpU = self::collapseDots(self::toUnix($rp));
            if (!self::withinUnix($rpU, $baseU)) return null;
            return self::toNative($rpU);
        }
        return self::toNative($candidateU);
    }

    public static function within(string $path, string $base): bool
    {
        $pU = self::collapseDots(self::toUnix(realpath($path) ?: $path));
        $bU = self::collapseDots(self::toUnix(realpath($base) ?: $base));
        return self::withinUnix($pU, $bU);
    }

    private static function withinUnix(string $pathU, string $baseU): bool
    {
        $b = rtrim($baseU, '/');
        $p = rtrim($pathU, '/');

        $bKey = self::isWindows() ? strtolower($b) : $b;
        $pKey = self::isWindows() ? strtolower($p) : $p;

        if ($pKey === $bKey) return true;
        return str_starts_with($pKey, $bKey . '/');
    }

    public static function relativize(string $path, string $base): string
    {
        $pU = self::collapseDots(self::toUnix(realpath($path) ?: $path));
        $bU = self::collapseDots(self::toUnix(realpath($base) ?: $base));

        $b = rtrim($bU, '/');
        $p = rtrim($pU, '/');

        $bKey = self::isWindows() ? strtolower($b) : $b;
        $pKey = self::isWindows() ? strtolower($p) : $p;

        if ($pKey === $bKey) return '';
        if (str_starts_with($pKey, $bKey . '/')) {
            return ltrim(substr($p, strlen($b) + 1), '/');
        }
        return $pU;
    }

    public static function toUrlPath(string $path): string
    {
        $u = self::toUnix($path);
        $u = preg_replace('#^\\./#', '', $u) ?? $u;
        return ltrim($u, '/');
    }
}
