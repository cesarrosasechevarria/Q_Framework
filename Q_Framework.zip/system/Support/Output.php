<?php
declare(strict_types=1);

namespace System\Support;

use System\Database\DbResult;

/**
 * Output presenter / normalizer
 * - Permite controlar cuánto detalle exponer en respuestas (minimal|api|debug|full)
 * - Protege contra exposición de SQL/params en producción (APP_DEBUG=0)
 */
final class Output
{
  /** Perfiles soportados */
  public const PROFILES = ['minimal','api','debug','full'];

  /**
   * Presenta $value según perfil.
   *
   * @param mixed $value
   * @param string|null $profile  minimal|api|debug|full (si null, se resuelve por config/env/request)
   * @param array $opts
   *   - hidePublic (bool): pasa a DbResult->safeArray()
   *   - hide (array|string): pasa a DbResult->safeArray()
   *   - includeSql/includeParams (bool): forzar (solo se respeta en debug y perfil full)
   *   - drop (array|string): keys a eliminar del array final
   *   - keep (array|string): whitelist (si se define, solo se conservan esas keys)
   */
  public static function present(mixed $value, ?string $profile = null, array $opts = []): mixed
  {
    $cfg = null;
    if (function_exists('config')) {
      try { $cfg = config('Output'); } catch (\Throwable $e) { $cfg = null; }
    }

    $debug = self::isDebug();
    $profile = self::resolveProfile($profile, $opts, $cfg, $debug);

    // Producción: nunca permitir debug/full (aunque lo pidan)
    if (!$debug && ($profile === 'debug' || $profile === 'full')) {
      $profile = 'api';
    }

    // DbResult -> array seguro según perfil
    if ($value instanceof DbResult) {
      return self::presentDbResult($value, $profile, $opts, $cfg, $debug);
    }

    // Throwable -> DbResult fail -> presentar
    if ($value instanceof \Throwable && class_exists(DbResult::class)) {
      $r = DbResult::failFromThrowable($value);
      return self::presentDbResult($r, $profile, $opts, $cfg, $debug);
    }

    // Si es array, aplicar reglas opcionales keep/drop
    if (is_array($value)) {
      return self::applyKeepDrop($value, $opts);
    }

    // Objetos: si tienen toArray(), úsalo para normalizar
    if (is_object($value) && method_exists($value, 'toArray')) {
      try {
        $arr = $value->toArray();
        if (is_array($arr)) return self::applyKeepDrop($arr, $opts);
      } catch (\Throwable $e) {
        // fallback: devolver el objeto tal cual
      }
    }

    return $value;
  }

  private static function presentDbResult(DbResult $r, string $profile, array $opts, $cfg, bool $debug): array
  {
    // Opciones base: safeArray ya NO incluye sql/params por defecto.
    $safeOpts = $opts;
    $safeOpts['includeSql'] = false;
    $safeOpts['includeParams'] = false;

    // Solo permitir sql/params cuando:
    // - APP_DEBUG=1
    // - profile = full
    // - y el dev lo pide (por config o por opts)
    $wantSql = (bool)($opts['includeSql'] ?? ($cfg->includeSqlInFull ?? true));
    $wantParams = (bool)($opts['includeParams'] ?? ($cfg->includeParamsInFull ?? true));

    if ($debug && $profile === 'full') {
      $safeOpts['includeSql'] = $wantSql;
      $safeOpts['includeParams'] = $wantParams;
    }

    $out = $r->safeArray($safeOpts);

    // Recorte por perfil
    if ($profile === 'minimal') {
      $keep = [
        'ok','state','code','error','trace_id',
        'rowCount','insertId','data'
      ];
      // action puede ser útil y no es sensible
      if (!empty($cfg->minimalIncludeAction)) $keep[] = 'action';
      $out = self::keepOnly($out, $keep);
    }
    elseif ($profile === 'api') {
      $drop = $cfg->dropApi ?? ['table','meta','time_ms','sql','params'];
      $out = self::dropKeys($out, $drop);
    }
    elseif ($profile === 'debug') {
      // Mantén meta/time_ms/table pero sin sql/params
      $drop = $cfg->dropDebug ?? ['sql','params'];
      $out = self::dropKeys($out, $drop);
    }
    else { // full
      // full ya trae sql/params (solo debug). Aun así permite drop adicional.
      $drop = $cfg->dropFull ?? [];
      $out = self::dropKeys($out, $drop);
    }

    // Forzar ocultar trace_id si config lo pide
    if (isset($cfg->includeTraceId) && !$cfg->includeTraceId) {
      unset($out['trace_id']);
    }

    return self::applyKeepDrop($out, $opts);
  }

  private static function resolveProfile(?string $profile, array $opts, $cfg, bool $debug): string
  {
    $p = $profile ?: ($opts['profile'] ?? null);

    // Si no se especifica, intenta override por request (solo si está permitido)
    if (!$p && $debug) {
      $allow = (bool)($cfg->allowOverride ?? true);
      if ($allow && function_exists('service')) {
        try {
          $req = service('request');
          if ($req) {
            $qKey = (string)($cfg->overrideQueryKey ?? 'out');
            $hKey = (string)($cfg->overrideHeader ?? 'X-Q-Output');
            $q = $req->getGet($qKey, null);
            $h = $req->header($hKey, null);

            if (is_string($q) && trim($q) !== '') $p = $q;
            elseif (is_string($h) && trim($h) !== '') $p = $h;
          }
        } catch (\Throwable $e) {
          // ignore
        }
      }
    }

    // Si aún no hay, default config/env
    if (!$p) {
      $p = (string)($cfg->defaultProfile ?? 'api');
      if (function_exists('env')) {
        $p = (string)(env('OUTPUT_PROFILE', $p));
      }
    }

    $p = strtolower(trim((string)$p));
    if (!in_array($p, self::PROFILES, true)) $p = (string)($cfg->defaultProfile ?? 'api');
    if ($p === '') $p = 'api';
    return $p;
  }

  private static function isDebug(): bool
  {
    if (function_exists('env_bool')) return env_bool('APP_DEBUG', false);
    $v = $_ENV['APP_DEBUG'] ?? $_SERVER['APP_DEBUG'] ?? null;
    if ($v === null) return false;
    $v = strtolower((string)$v);
    return in_array($v, ['1','true','yes','on'], true);
  }

  private static function applyKeepDrop(array $arr, array $opts): array
  {
    // keep (whitelist) tiene prioridad
    if (isset($opts['keep'])) {
      $keep = $opts['keep'];
      if (is_string($keep)) $keep = array_map('trim', explode(',', $keep));
      if (is_array($keep) && $keep) {
        return self::keepOnly($arr, $keep);
      }
    }

    if (isset($opts['drop'])) {
      $drop = $opts['drop'];
      if (is_string($drop)) $drop = array_map('trim', explode(',', $drop));
      if (is_array($drop) && $drop) {
        return self::dropKeys($arr, $drop);
      }
    }

    return $arr;
  }

  private static function keepOnly(array $arr, array $keep): array
  {
    $set = [];
    foreach ($keep as $k) {
      if (!is_string($k) && !is_numeric($k)) continue;
      $s = trim((string)$k);
      if ($s === '') continue;
      $set[$s] = true;
    }
    $out = [];
    foreach ($arr as $k => $v) {
      if (isset($set[(string)$k])) $out[$k] = $v;
    }
    return $out;
  }

  private static function dropKeys(array $arr, array $drop): array
  {
    foreach ($drop as $k) {
      if (!is_string($k) && !is_numeric($k)) continue;
      $s = trim((string)$k);
      if ($s === '') continue;
      if (array_key_exists($s, $arr)) unset($arr[$s]);
    }
    return $arr;
  }
}
