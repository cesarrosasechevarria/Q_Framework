<?php
declare(strict_types=1);

/**
 * Q_Framework fallback autoloader (sin Composer).
 * - Registra PSR-4 básico para Config\, App\ y System\
 * - Útil cuando NO existe /vendor/autoload.php
 */
function qfw_register_autoloader(string $rootPath): void
{
  $rootPath = rtrim($rootPath, '/\\');

  spl_autoload_register(function(string $class) use ($rootPath) {
    $map = [
      'Config\\' => $rootPath . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'Config' . DIRECTORY_SEPARATOR,
      'Modules\\' => $rootPath . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'Modules' . DIRECTORY_SEPARATOR,
      'App\\'    => $rootPath . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR,
      'System\\' => $rootPath . DIRECTORY_SEPARATOR . 'system' . DIRECTORY_SEPARATOR,
    ];

    foreach ($map as $prefix => $baseDir) {
      if (strncmp($class, $prefix, strlen($prefix)) !== 0) continue;

      $rel = substr($class, strlen($prefix));
      $file = $baseDir . str_replace('\\', DIRECTORY_SEPARATOR, $rel) . '.php';

      if (is_file($file)) {
        require_once $file;
      }
      return;
    }
  });
}
