<?php
declare(strict_types=1);

// Prevent double-load (e.g., manual include + Composer autoload.files)
//
// Importante: si una copia antigua de este archivo se cargó primero (y definió la constante),
// aquí agregamos helpers NUEVOS de forma incremental (sin redeclare), y salimos.
if (defined('QFW_SUPPORT_FUNCTIONS_LOADED')) {

  // Helpers nuevos (pueden no existir en copias antiguas)
  if (!function_exists('q_out')) {
    function q_out(mixed $value, ?string $profile = null, array $opts = []): mixed
    {
      if (class_exists('\System\Support\Output')) {
        return \System\Support\Output::present($value, $profile, $opts);
      }
      // Fallback mínimo: si es DbResult, safeArray() sin sql/params
      if ($value instanceof \System\Database\DbResult) {
        $a = $value->safeArray($opts + ['includeSql' => false, 'includeParams' => false]);
        unset($a['sql'], $a['params']);
        return $a;
      }
      return $value;
    }
  }

  if (!function_exists('q_json_out')) {
    function q_json_out(mixed $value, ?string $profile = null, int $status = 200, array $opts = []): \System\Core\Response
    {
      return service('response')->json(q_out($value, $profile, $opts), $status);
    }
  }

  // Helper core: response()
  // Importante: se define aquí también por si el archivo se cargó antes en una copia antigua.
  if (!function_exists('response')) {
    function response(): \System\Core\Response
    {
      return \Config\Services::response();
    }
  }

  return;
}
define('QFW_SUPPORT_FUNCTIONS_LOADED', 1);

function base_path(string $path = ''): string
{
  $root = dirname(__DIR__, 2);
  return rtrim($root, '/\\') . ($path ? DIRECTORY_SEPARATOR . ltrim($path, '/\\') : '');
}

function env(string $key, $default = null)
{
  return $_ENV[$key] ?? $default;
}

function env_bool(string $key, bool $default = false): bool
{
  $v = env($key, null);
  if ($v === null) return $default;
  $v = strtolower((string)$v);
  return in_array($v, ['1','true','yes','on'], true);
}

function env_int(string $key, int $default = 0): int
{
  $v = env($key, null);
  if ($v === null || $v === '') return $default;
  return (int)$v;
}

/**
 * Lee JSON desde .env (array/object). Retorna $default si falla.
 */
function env_json(string $key, $default = null)
{
  $v = env($key, null);
  if (!is_string($v) || trim($v) === '') return $default;
  $d = json_decode($v, true);
  return (json_last_error() === JSON_ERROR_NONE) ? $d : $default;
}

/**
 * Carga Config como objeto (tipo Q_Framework).
 * Ej:
 *   $app = config('App');  // instancia Config\App
 */
function config(string $name): object
{
  // Cache global reseteable (útil para multi-tenant / CLI)
  if (!isset($GLOBALS['__qfw_config_cache']) || !is_array($GLOBALS['__qfw_config_cache'])) {
    $GLOBALS['__qfw_config_cache'] = [];
  }

  // Scope por tenant si existe
  $scope = 'default';
  if (class_exists('\\System\\Core\\Tenant')) {
    $scope = \System\Core\Tenant::id();
  } elseif (defined('TENANT_ID')) {
    $scope = (string) TENANT_ID;
  }

  if (!isset($GLOBALS['__qfw_config_cache'][$scope]) || !is_array($GLOBALS['__qfw_config_cache'][$scope])) {
    $GLOBALS['__qfw_config_cache'][$scope] = [];
  }

  $cache =& $GLOBALS['__qfw_config_cache'][$scope];

  if (isset($cache[$name])) return $cache[$name];

  $fqcn = "Config\\{$name}";
  if (class_exists($fqcn)) {
    $cache[$name] = new $fqcn();
    return $cache[$name];
  }

  // Fallback por si existe el archivo pero no está autoloaded
  $file = base_path("app/Config/{$name}.php");
  if (is_file($file)) {
    $val = require $file;
    if (is_array($val)) $val = (object)$val;
    $cache[$name] = is_object($val) ? $val : (object)[];
    return $cache[$name];
  }

  $cache[$name] = (object)[];
  return $cache[$name];
}


/**
 * Limpia la caché de config() (todo o un nombre específico).
 */
function config_clear_cache(?string $name = null, ?string $scope = null): void
{
  if (!isset($GLOBALS['__qfw_config_cache']) || !is_array($GLOBALS['__qfw_config_cache'])) return;

  // Scope actual por tenant (default)
  if ($scope === null) {
    $scope = (class_exists('\\System\\Core\\Tenant')) ? \System\Core\Tenant::id() : 'default';
  }

  // '*' => limpiar todos los scopes
  if ($scope === '*') {
    if ($name === null) { $GLOBALS['__qfw_config_cache'] = []; return; }
    foreach ($GLOBALS['__qfw_config_cache'] as $s => $_) {
      unset($GLOBALS['__qfw_config_cache'][$s][$name]);
    }
    return;
  }

  if (!isset($GLOBALS['__qfw_config_cache'][$scope]) || !is_array($GLOBALS['__qfw_config_cache'][$scope])) return;

  if ($name === null) {
    $GLOBALS['__qfw_config_cache'][$scope] = [];
    return;
  }
  unset($GLOBALS['__qfw_config_cache'][$scope][$name]);
}


/**
 * Inicia sesión SOLO cuando se llama explícitamente session()
 */

/**
 * Carga helpers (estilo Q_Framework)
 * Ej:
 *   helper('form');
 *   helper(['url','security']);
 */
function helper(string|array $names): void
{
  $list = is_array($names) ? $names : [$names];
  foreach ($list as $n) {
    $n = trim((string)$n);
    if ($n === '') continue;
    System\Core\Helper::load($n);
  }
}

/**
 * Service locator (estilo Q_Framework)
 * Ej:
 *   $pdo = service('db');
 *   $sess = service('session');
 */
function service(string $name)
{
  return \Config\Services::get($name);
}

/** Response helper (estilo frameworks: response()->json()/html()/redirect()). */
if (!function_exists('response')) {
  function response(): \System\Core\Response
  {
    return \Config\Services::response();
  }
}

/** Cache (file cache por defecto) */
function cache(): \System\Cache\CacheInterface
{
  return \Config\Services::cache();
}

/** Valida data: retorna [ok, errors] */

/**
 * =========================
 * URL helpers CORE (sin helpers)
 * =========================
 * Nota: Se definen aquí porque son extremadamente usados y deben estar disponibles incluso en Lazy Load.
 * Puedes extender la clase URL y apuntarla en Config\App::$urlClass o env('URL_CLASS').
 */
if (!function_exists('url_class')) {
  function url_class(): string
  {
    $cfg = \config('App');
    $cls = $cfg->urlClass ?? \System\Core\Url::class;
    $cls = is_string($cls) && $cls !== '' ? $cls : \System\Core\Url::class;
    return class_exists($cls) ? $cls : \System\Core\Url::class;
  }
}

if (!function_exists('url')) {
  function url(string $path = ''): string
  {
    $cls = url_class();
    /** @var class-string $cls */
    return $cls::base($path);
  }
}

if (!function_exists('base_url')) {
  function base_url(string $path = ''): string
  {
    return url($path);
  }
}

if (!function_exists('route')) {
  function route(string $name, array $params = []): string
  {
    return \System\Core\Routes::url($name, $params);
  }
}

if (!function_exists('route_url')) {
  function route_url(string $name, array $params = []): string
  {
    return route($name, $params);
  }
}


/**
 * =========================
 * View / Session helpers CORE
 * =========================
 * - view() es extremadamente usado; lo exponemos como helper core.
 * - flash() permite leer sin iniciar sesión si no existe cookie.
 */
if (!function_exists('view')) {
  function view(string $name, array $data = [], ?string $layout = null): string
  {
    return \System\Core\View::render($name, $data, $layout);
  }
}

if (!function_exists('flash')) {
  /**
   * flash('key') => lee y consume el flash si hay sesión activa.
   * flash('key', $value) => setea flash (inicia sesión).
   */
  function flash(string $key, $value = null)
  {
    if (func_num_args() === 1) {
      $s = session_optional();
      if (!$s) return null;
      return $s->flash($key);
    }
    $s = session();
    return $s->flash($key, $value);
  }
}

/**
 * =========================
 * HTTP / Validation helpers CORE
 * =========================
 */
if (!function_exists('abort')) {
  function abort(int $status = 500, string $message = '', mixed $payload = null, array $headers = []): never
  {
    throw new \System\Core\HttpException($status, $message, $payload, $headers);
  }
}

if (!function_exists('validate_or_fail')) {
  function validate_or_fail(array $data, array $rules, array $messages = [], array $labels = []): array
  {
    $v = \Config\Services::validator();
    if (method_exists($v, 'setLabels') && $labels) $v->setLabels($labels);
    $ok = $v->passes($data, $rules, $messages);
    if (!$ok) {
      throw new \System\Validation\ValidationException($v->errors());
    }
    return [$ok, []];
  }
}

/**
 * =========================
 * Output helpers CORE
 * =========================
 *
 * q_out(): normaliza salida según perfil (minimal|api|debug|full).
 * q_json_out(): responde JSON usando el perfil.
 */
if (!function_exists('q_out')) {
  function q_out(mixed $value, ?string $profile = null, array $opts = []): mixed
  {
    return \System\Support\Output::present($value, $profile, $opts);
  }
}

if (!function_exists('q_json_out')) {
  function q_json_out(mixed $value, ?string $profile = null, int $status = 200, array $opts = []): \System\Core\Response
  {
    return service('response')->json(q_out($value, $profile, $opts), $status);
  }
}

function validate(array $data, array $rules, array $messages = []): array
{
  $v = \Config\Services::validator();
  $ok = $v->passes($data, $rules, $messages);
  return [$ok, $v->errors()];
}

/** Lang: obtiene string por key (file.key) */
function lang(string $key, array $params = []): string
{
  return \Config\Services::lang()->get($key, $params);
}

/** Events: registra listener */
function on_event(string $event, callable $fn, int $priority = 0): void
{
  \System\Core\Events::on($event, $fn, $priority);
}

/** Events: dispara evento */
function trigger_event(string $event, mixed $payload = null): void
{
  \System\Core\Events::trigger($event, $payload);
}

function session(): System\Core\Session
{
  return \Config\Services::session();
}

/**
 * Retorna sesión SOLO si ya existe cookie (sin iniciar sesión para usuarios nuevos).
 * Útil para que Home/Layout no cree sesión "por defecto".
 */
function session_optional(): ?System\Core\Session
{
  if (!System\Core\Session::hasCookie()) return null;
  return session();
}

function dd(...$vars): void
{
  header('Content-Type: text/plain; charset=UTF-8');
  foreach ($vars as $v) var_dump($v);
  exit;
}

/**
 * Escape seguro para views (similar a CI4 esc()).
 * Contextos soportados: html, attr, js, css, url.
 */
if (!function_exists('esc')) {
  function esc(mixed $value, string $context = 'html', bool $doubleEncode = true): string
  {
    if ($value === null) return '';
    // arrays/objects -> json (para evitar "Array")
    if (is_array($value) || is_object($value)) {
      $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }
    $str = (string)$value;

    $ctx = strtolower(trim($context));
    switch ($ctx) {
      case 'url':
        // no encodes '/' to keep paths readable
        return str_replace('%2F','/', rawurlencode($str));
      case 'js':
        // JSON encoding safest for JS contexts
        return json_encode($str, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
      case 'css':
        // conservative: strip control chars
        $str = preg_replace('/[\x00-\x1F\x7F]/u', '', $str) ?? '';
        return $str;
      case 'attr':
      case 'html':
      default:
        return htmlspecialchars($str, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', $doubleEncode);
    }
  }
}

/** Alias corto para escapar HTML en vistas: <?= e($var) ?> */
if (!function_exists('e')) {
  function e(mixed $value): string
  {
    return esc($value, 'html', true);
  }
}


/* =========================
   Vendor utilities (core)
   =========================
   Objetivo: incluir autoloads/librerías opcionales desde /vendor sin fatales,
   con nombres claros y reutilizables en helpers y módulos.
*/

if (!function_exists('qfw_vendor_path')) {
  /**
   * Devuelve la ruta absoluta a un archivo/carpeta dentro de /vendor.
   * Ej: qfw_vendor_path('validmail/autoload.php')
   */
  function qfw_vendor_path(string $relative = ''): string
  {
    $relative = ltrim(str_replace('\\', '/', $relative), '/');
    return base_path('vendor' . ($relative !== '' ? '/' . $relative : ''));
  }
}

if (!function_exists('qfw_vendor_include_once')) {
  /**
   * Incluye un archivo desde /vendor si existe. Retorna true si se incluyó.
   * Ej: qfw_vendor_include_once('autoload.php')
   */
  function qfw_vendor_include_once(string $relativeFile): bool
  {
    $file = qfw_vendor_path($relativeFile);
    if (is_file($file)) {
      require_once $file;
      return true;
    }
    return false;
  }
}

if (!function_exists('qfw_vendor_require_once')) {
  /**
   * Requiere un archivo desde /vendor. Lanza RuntimeException si no existe.
   */
  function qfw_vendor_require_once(string $relativeFile): void
  {
    $file = qfw_vendor_path($relativeFile);
    if (!is_file($file)) {
      throw new RuntimeException("Vendor file not found: {$relativeFile}");
    }
    require_once $file;
  }
}

if (!function_exists('qfw_vendor_try_autoload')) {
  /**
   * Intenta cargar vendor/autoload.php (Composer) y autoloads adicionales.
   *
   * @param array $extraAutoloadFiles Lista de rutas relativas dentro de /vendor.
   * @param bool $includeComposer Si true, intenta primero 'autoload.php'.
   */
  function qfw_vendor_try_autoload(array $extraAutoloadFiles = [], bool $includeComposer = true): void
  {
    if ($includeComposer) {
      qfw_vendor_include_once('autoload.php');
    }
    foreach ($extraAutoloadFiles as $rel) {
      if (!is_string($rel) || $rel === '') continue;
      qfw_vendor_include_once($rel);
    }
  }
}