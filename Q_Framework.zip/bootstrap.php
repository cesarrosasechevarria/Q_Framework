<?php
declare(strict_types=1);

// === Autoload safety (en caso bootstrap se invoque sin public/index.php) ===
//
// Nota importante:
// - composer.json tiene "autoload.files": ["system/Support/Functions.php"]
// - Si Functions.php se carga antes que vendor/autoload.php, Composer puede volver a cargarlo
//   y provocar "Cannot redeclare base_path()/env()".
//
// Solución: incluir vendor/autoload.php primero y luego cargar Functions.php solo si hace falta.

// Incluir vendor/autoload.php si existe (opcional) - PRIMERO
$composerAutoload = __DIR__ . '/vendor/autoload.php';
$useVendor = defined('QFW_USE_VENDOR_AUTOLOAD') ? (bool)QFW_USE_VENDOR_AUTOLOAD : true;
if ($useVendor && is_file($composerAutoload)) {
  require_once $composerAutoload;
}

// Core functions (solo si no existen)
if (!function_exists('base_path')) {
  require_once __DIR__ . '/system/Support/Functions.php';
}

// Autoloader propio (fallback)
if (!function_exists('qfw_register_autoloader')) {
  require_once __DIR__ . '/system/Support/Autoload.php';
}
qfw_register_autoloader(__DIR__);

use System\Core\Constants;
use System\Core\Errors;
use System\Core\Helper;
use System\Core\Logger;
use System\Core\Session;
use System\Core\Tenant;

// Define paths for CLI / non-public entry points
if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);
if (!defined('ROOTPATH'))  define('ROOTPATH', rtrim(base_path(''), '/\\') . DS);
if (!defined('APPPATH'))   define('APPPATH', ROOTPATH . 'app' . DS);
if (!defined('SYSTEMPATH'))define('SYSTEMPATH', ROOTPATH . 'system' . DS);
if (!defined('WRITEPATH')) define('WRITEPATH', ROOTPATH . 'write' . DS);
if (!defined('PUBLICPATH'))define('PUBLICPATH', ROOTPATH . 'public' . DS);

System\Core\Env::load(base_path('.env'));

// Boot tenant (multi-tenant) lo más temprano posible
Tenant::boot();

// Carga config App (puede verse afectada por .env del tenant)
$appCfg = config('App');

// Constantes globales (APP_NAME, etc.)
Constants::load();

// Logger (tenant-aware)
$logDir = Tenant::writePath('logs');
Logger::init($logDir);

// Registro de errores (usa Logger)
Errors::register(
  env('APP_ENV', 'production'),
  env_bool('APP_DEBUG', false)
);

// Sesión lazy (tenant-aware)
$sesCfg = config('Session');
$baseName = $sesCfg->name ?? env('SESSION_NAME', 'QFWSESSID');
$name = $baseName . '_' . Tenant::id();
Session::configure([
  'name' => $name,
  'save_path' => Tenant::writePath('sessions'),
]);

$appCfg = config('App');
if (!empty($appCfg->autoloadGlobalHelpers)) {
  Helper::loadGlobals();
}


// v7: Boot events
// v8: Boot providers (extensiones de app)
\System\Core\Providers::boot();

// v7: Boot events (Config/Events.php)
\System\Core\Events::boot();

// v7: Locale negotiation (opcional)
$i18n = config('I18n');
if (!empty($i18n->negotiateLocale)) {
  $hdr = (string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '');
  $pref = strtolower(substr($hdr, 0, 2));
  $supported = array_map(fn($x)=>strtolower(substr((string)$x,0,2)), (array)($i18n->supportedLocales ?? []));
  if ($pref && in_array($pref, $supported, true)) {
    \Config\Services::lang()->setLocale($pref);
  }
}

