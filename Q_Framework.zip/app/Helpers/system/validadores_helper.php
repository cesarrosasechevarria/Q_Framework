<?php declare(strict_types=1);

/**
 * ==========================================================
 * Q_Framework - Módulo Avanzado de Validación (PRO)
 * ==========================================================
 * 
 * Sistema de validación robusto y extensible para formularios y datos
 * con soporte para validadores personalizados, transformaciones en cadena
 * e integración con librerías externas.
 * 
 * CARACTERÍSTICAS PRINCIPALES:
 * ✅ Motor de validación dinámico y extensible
 * ✅ Validadores con 1, 2 o 3 parámetros (sin ArgumentCountError)
 * ✅ Mensajes configurables con placeholders {0}, {1}, ...
 * ✅ Integración con libphonenumber y validadores personalizados
 * ✅ Reglas "email" y "phone" con soporte PRO
 * ✅ Validación JSON robusta (acepta "null" como JSON válido)
 * ✅ Transformadores en cadena (trim, lower, upper, etc.)
 * ✅ Sistema de caché con Redis integrado
 * 
 * USO BÁSICO:
 *   helper('validadores');
 *   $resultado = validador_rules($email, 'required|email|max:80');
 *   if(!$resultado['ok']) { echo $resultado['error']; }
 */

/* ==========================================================
 * EJEMPLOS DE USO PRÁCTICO - COPIAR Y PEGAR EN TU CÓDIGO
 * ==========================================================
 * 
 * DESPUÉS DE CARGAR EL HELPER: helper('validadores');
 * 
 * NIVEL 1 - USO DIRECTO DE VALIDADORES ESPECÍFICOS
 * ----------------------------------------------------------
 * // Validar email directamente
 * [$ok_email, $msg_email, $extra_email] = validador_email('usuario@gmail.com');
 * 
 * // Validar teléfono con región
 * [$ok_phone, $msg_phone, $extra_phone] = validador_phone('+51 999 999 999', 'PE');
 * 
 * NIVEL 2 - USO DE VALIDADORES INDIVIDUALES
 * ----------------------------------------------------------
 * // Validar un campo con un validador específico
 * $resultado = validador_run('email', 'usuario@gmail.com');
 * if($resultado['ok']) { /* pasa *\/ } else { echo $resultado['error']; }
 * 
 * NIVEL 3 - CADENAS DE REGLAS (RECOMENDADO PARA FORMULARIOS)
 * ----------------------------------------------------------
 * // Validación simple
 * $r = validador_rules($email, 'required|email|max:80');
 * 
 * // Validación con transformadores
 * $r = validador_rules($nombre, 'required|trim|lower|min:3|max:50');
 * 
 * // Validación de teléfono con región específica
 * $r = validador_rules($telefono, 'required|phone:PE|max:15');
 * 
 * // Validación de JSON
 * $r = validador_rules($json_string, 'required|json');
 * 
 * // Validación numérica
 * $r = validador_rules($edad, 'required|int|min:18|max:99');
 * 
 * NIVEL 4 - ARRAYS DE REGLAS (PARA REGLAS DINÁMICAS)
 * ----------------------------------------------------------
 * $reglas = [
 *     ['required'],
 *     ['trim'],
 *     ['lower'],
 *     ['min', '3'],
 *     ['max', '50']
 * ];
 * $resultado = validador_apply($valor, $reglas);
 * 
 * EJEMPLOS COMPLETOS EN CONTROLADORES
 * ----------------------------------------------------------
 * 
 * // Ejemplo 1: Validar formulario de registro
 * public function registrar() {
 *     helper('validadores');
 *     
 *     $datos = $this->request->getPost();
 *     $errores = [];
 *     
 *     $errores['email'] = validador_rules($datos['email'], 'required|email|max:80');
 *     $errores['password'] = validador_rules($datos['password'], 'required|min:8');
 *     $errores['telefono'] = validador_rules($datos['telefono'], 'required|phone:PE|max:15');
 *     $errores['edad'] = validador_rules($datos['edad'], 'required|int|min:18');
 *     
 *     // Verificar si hay errores
 *     foreach($errores as $campo => $resultado) {
 *         if(!$resultado['ok']) {
 *             echo "Error en $campo: " . $resultado['error'];
 *         }
 *     }
 * }
 * 
 * // Ejemplo 2: Crear validador personalizado
 * validador_register('dni', function($value) {
 *     // DNI peruano: 8 dígitos
 *     if(!preg_match('/^\d{8}$/', $value)) {
 *         return 'DNI debe tener 8 dígitos';
 *     }
 *     return true;
 * });
 * 
 * // Ahora lo puedes usar como:
 * $resultado = validador_rules($dni, 'required|dni');
 * 
 * // Ejemplo 3: Validador con parámetros
 * validador_register('rango', function($value, $params) {
 *     $min = $params[0] ?? 0;
 *     $max = $params[1] ?? PHP_INT_MAX;
 *     return $value >= $min && $value <= $max;
 * });
 * 
 * validador_message('rango', 'Debe estar entre {0} y {1}');
 * 
 * // Uso: "rango:18,65"
 * $resultado = validador_rules($edad, 'required|rango:18,65');
 * 
 * // Ejemplo 4: Transformador personalizado
 * validador_register('slug', function($value) {
 *     // Convertir a slug: "Hola Mundo" -> "hola-mundo"
 *     $slug = strtolower(preg_replace('/[^A-Za-z0-9]+/', '-', $value));
 *     return trim($slug, '-');
 * });
 * 
 * // Uso: obtienes el valor transformado
 * $resultado = validador_rules('Texto a Slug', 'required|slug');
 * echo $resultado['value']; // "texto-a-slug"
 * 
 * USO CON FORMULARIOS HTML
 * ----------------------------------------------------------
 * <!-- En tu vista HTML -->
 * <form method="post">
 *     <input type="email" name="email" value="<?= old('email') ?>">
 *     <?php if(isset($errores['email'])): ?>
 *         <span class="error"><?= $errores['email']['error'] ?></span>
 *     <?php endif; ?>
 *     
 *     <input type="password" name="password">
 *     <?php if(isset($errores['password'])): ?>
 *         <span class="error"><?= $errores['password']['error'] ?></span>
 *     <?php endif; ?>
 *     
 *     <button type="submit">Enviar</button>
 * </form>
 * 
 * DEBUG Y HERRAMIENTAS
 * ----------------------------------------------------------
 * // Verificar si un validador está registrado
 * if(validador_has('email')) { echo 'El validador email está disponible'; }
 * 
 * // Ver todos los validadores registrados
 * $todos = validador_store();
 * print_r(array_keys($todos)); // ['required', 'email', 'min', 'max', ...]
 * 
 * // Probar validación rápida
 * var_dump(validador_rules('test@example.com', 'required|email|max:80'));
 * 
 * INTEGRACIÓN CON BASE DE DATOS
 * ----------------------------------------------------------
 * // Ejemplo: Validador único para email en base de datos
 * validador_register('unique_email', function($value, $params, $ctx) {
 *     $db = validador_db();
 *     $tabla = $params[0] ?? 'usuarios';
 *     
 *     $existe = $db->table($tabla)
 *                  ->where('email', $value)
 *                  ->countAllResults();
 *                  
 *     return $existe === 0 ? true : 'El email ya está registrado';
 * });
 * 
 * // Uso en registro de usuario
 * $resultado = validador_rules($email, 'required|email|unique_email:usuarios');
 * 
 * CACHÉ CON REDIS
 * ----------------------------------------------------------
 * // Usar cache en validaciones costosas
 * $datos_costosos = validador_cache('clave_cache', function() {
 *     // Operación costosa
 *     return obtener_datos_desde_api();
 * }, 300); // 5 minutos de cache
 * 
 * NOTAS FINALES
 * ----------------------------------------------------------
 * 1. Las reglas se ejecutan en orden de izquierda a derecha
 * 2. Los transformadores (trim, lower, upper, slug) modifican el valor
 * 3. La regla 'nullable' detiene validación si el valor está vacío
 * 4. Puedes crear tantos validadores personalizados como necesites
 * 5. Los mensajes de error son configurables con validador_message()
 * 
 * PARA MÁS INFORMACIÓN:
 * - Ver documentación de Q_Framework
 * - Revisar ejemplos en tests/validadores_test.php
 * - Consultar el código fuente en system/helpers/validadores_helper.php
 */


/* ==========================================================
 * Gestor de Rutas Vendor (Seguro)
 * ========================================================== */

/**
 * Obtiene la ruta raíz del proyecto de forma segura
 * 
 * Esta función determina y retorna la ruta absoluta del directorio raíz
 * del proyecto, asegurando un formato consistente con separador de directorio.
 * 
 * @return string Ruta absoluta del proyecto con separador al final
 * 
 * @example
 * $ruta = validador_rootpath(); // "/var/www/proyecto/"
 */
function validador_rootpath(): string
{
    if (defined('ROOTPATH')) return rtrim((string) ROOTPATH, '/\\') . DIRECTORY_SEPARATOR;
    return rtrim(dirname(__DIR__, 3), '/\\') . DIRECTORY_SEPARATOR;
}

/**
 * Construye ruta absoluta a un archivo dentro de vendor
 * 
 * Genera la ruta completa a cualquier archivo dentro del directorio vendor,
 * manejando automáticamente los separadores de directorio según el sistema.
 * 
 * @param string $rel Ruta relativa dentro de vendor (ej: "autoload.php")
 * @return string Ruta absoluta al archivo solicitado
 * 
 * @example
 * $path = validador_vendor_path('vendor/paquete/archivo.php');
 */
function validador_vendor_path(string $rel): string
{
    $rel = ltrim($rel, '/\\');
    return validador_rootpath() . 'vendor' . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $rel);
}

/**
 * Incluye un archivo de vendor solo una vez si existe
 * 
 * Realiza un require_once seguro de archivos dentro del directorio vendor,
 * retornando estado de éxito o fracaso sin lanzar excepciones.
 * 
 * @param string $rel Ruta relativa al archivo dentro de vendor
 * @return bool true si el archivo fue incluido, false si no existe
 * 
 * @example
 * $cargado = validador_vendor_include_once('phpmailer/autoload.php');
 */
function validador_vendor_include_once(string $rel): bool
{
    $path = validador_vendor_path($rel);
    if (is_file($path)) {
        require_once $path;
        return true;
    }
    return false;
}

/**
 * Carga el autoload de Composer y archivos adicionales
 * 
 * Sistema robusto de carga de dependencias que primero intenta delegar
 * al sistema central del framework, y si no existe, carga directamente
 * los archivos necesarios de vendor.
 * 
 * @param array<int, string> $extraAutoloadFiles Lista de autoloads adicionales
 * @param bool $includeComposer Incluir vendor/autoload.php de Composer
 * @return void
 * 
 * @note Se ejecuta una sola vez por petición para optimizar rendimiento
 */
function validador_vendor_try_autoload(array $extraAutoloadFiles = [], bool $includeComposer = true): void
{
    if (function_exists('qfw_vendor_try_autoload')) {
        qfw_vendor_try_autoload($extraAutoloadFiles, $includeComposer);
        return;
    }

    static $done = false;
    if ($done) return;
    $done = true;

    if ($includeComposer) {
        $composer = validador_vendor_path('autoload.php');
        if (is_file($composer)) require_once $composer;
    }

    foreach ($extraAutoloadFiles as $rel) {
        validador_vendor_include_once((string) $rel);
    }
}

/**
 * Carga automática de librerías específicas para validadores
 * 
 * Carga las dependencias necesarias para funcionalidades avanzadas
 * como validación de emails y teléfonos con librerías externas.
 * 
 * @return void
 * 
 * @internal Usado internamente por validador_email() y validador_phone()
 */
function validador_try_autoload_libs(): void
{
    validador_vendor_try_autoload([
        'validmail/autoload.php',
        'phonevalid/autoload.php',
    ], true);
}

/* ==========================================================
 * Validadores Directos (API de Bajo Nivel)
 * ========================================================== */

/**
 * Validador profesional de direcciones de correo electrónico
 * 
 * Implementa validación robusta de emails utilizando FILTER_VALIDATE_EMAIL
 * y carga automática de librerías externas si están disponibles.
 * 
 * @param ?string $mail Dirección de email a validar
 * @return array{0:bool,1:string,2:array|null}
 *              0: Éxito de validación
 *              1: Mensaje descriptivo ("OK" o error)
 *              2: Datos adicionales (null en esta implementación)
 * 
 * @example
 * [$valido, $mensaje, $extra] = validador_email('usuario@dominio.com');
 */
function validador_email(?string $mail = null): array
{
    $mail = trim((string) $mail);
    if ($mail === '') return [false, 'Email vacío.', null];

    validador_try_autoload_libs();

    $ok = filter_var($mail, FILTER_VALIDATE_EMAIL) !== false;
    return [$ok, $ok ? 'OK' : 'Email inválido.', null];
}

/**
 * Validador avanzado de números telefónicos con soporte internacional
 * 
 * Valida números de teléfono utilizando libphonenumber (si disponible)
 * o implementa un fallback básico por longitud de dígitos.
 * 
 * @param ?string $phone Número telefónico a validar
 * @param string $cod Código de región (ej: 'PE' para Perú)
 * @return array{0:bool,1:string,2:array|null}
 *              0: Éxito de validación
 *              1: Mensaje descriptivo
 *              2: Datos enriquecidos (formato E164, nacional, región)
 * 
 * @example
 * [$valido, $mensaje, $extra] = validador_phone('+51987654321', 'PE');
 */
function validador_phone(?string $phone = null, string $cod = 'PE'): array
{
    $phone = trim((string) $phone);
    if ($phone === '') return [false, 'Teléfono vacío.', null];

    validador_try_autoload_libs();

    if (class_exists('\libphonenumber\PhoneNumberUtil')) {
        try {
            $util  = \libphonenumber\PhoneNumberUtil::getInstance();
            $proto = $util->parse($phone, $cod);
            $ok    = $util->isValidNumber($proto);

            $extra = null;
            if (class_exists('\libphonenumber\PhoneNumberFormat')) {
                $extra = [
                    'e164'     => $util->format($proto, \libphonenumber\PhoneNumberFormat::E164),
                    'national' => $util->format($proto, \libphonenumber\PhoneNumberFormat::NATIONAL),
                    'region'   => $cod,
                ];
            }

            return [$ok, $ok ? 'OK' : 'Teléfono inválido.', $extra];

        } catch (\libphonenumber\NumberParseException $e) {
            return [false, 'Teléfono inválido: ' . $e->getMessage(), null];
        } catch (\Throwable $e) {
            return [false, 'Error validando teléfono: ' . $e->getMessage(), null];
        }
    }

    // Fallback para entornos sin libphonenumber
    $digits = preg_replace('/\D+/', '', $phone);
    $ok = is_string($digits) && strlen($digits) >= 7 && strlen($digits) <= 15;
    return [$ok, $ok ? 'OK' : 'Teléfono inválido.', null];
}

/**
 * Detector de contenido inapropiado en texto
 * 
 * Escanea texto en busca de palabras o frases consideradas inapropiadas
 * según una lista predefinida (configurable internamente).
 * 
 * @param mixed $string Texto a analizar
 * @return false|string false si no se encuentra contenido inapropiado,
 *                     string con la palabra detectada si se encuentra
 * 
 * @example
 * $detectado = validador_frase('texto con contenido ofensivo');
 * if($detectado !== false) echo "Palabra inapropiada: $detectado";
 */
function validador_frase($string)
{
    $texto = strtoupper((string) $string);

    $msgarray = [
        'MIERDA','CHUPAR','PORQUERIA','SUCIO','SEXO','PORNO','DILDO','PENE','VAGINA','COCHINADA',
        'CHUCHA','PINCHO','HUEVADA','JODAS','JODER','PUTA','JODA','BASURA','COJUDO','ASQUEROSO',
        'ASCO','CUCARACHA','MOSCA','SANGRE','DEMONIO','DIABLO','GAY','MARICON'
    ];

    foreach ($msgarray as $palabra) {
        if (strpos($texto, $palabra) !== false) return $palabra;
    }
    return false;
}

/* ==========================================================
 * Motor Central de Validación (Núcleo del Sistema)
 * ========================================================== */

/**
 * Obtiene referencia al registro global de validadores
 * 
 * Retorna el almacén central donde se registran todos los validadores
 * disponibles en el sistema, inicializándolo si es necesario.
 * 
 * @return array<string, callable> Array asociativo [nombre => callable]
 * 
 * @internal Para uso interno del motor de validación
 */
function &validador_store(): array
{
    if (!isset($GLOBALS['__QFW_VALIDADORES']) || !is_array($GLOBALS['__QFW_VALIDADORES'])) {
        $GLOBALS['__QFW_VALIDADORES'] = [];
    }
    return $GLOBALS['__QFW_VALIDADORES'];
}

/**
 * Obtiene referencia al registro global de mensajes de error
 * 
 * Retorna el almacén de mensajes personalizados para cada validador,
 * soportando placeholders {0}, {1}, etc. para parámetros dinámicos.
 * 
 * @return array<string, string> Array asociativo [nombre => mensaje]
 * 
 * @internal Para uso interno del sistema de mensajes
 */
function &validador_messages_store(): array
{
    if (!isset($GLOBALS['__QFW_VALIDADORES_MSG']) || !is_array($GLOBALS['__QFW_VALIDADORES_MSG'])) {
        $GLOBALS['__QFW_VALIDADORES_MSG'] = [];
    }
    return $GLOBALS['__QFW_VALIDADORES_MSG'];
}

/**
 * Verifica si un validador específico está registrado en el sistema
 * 
 * @param string $name Nombre del validador a verificar
 * @return bool true si el validador existe, false en caso contrario
 * 
 * @example
 * if(validador_has('dni')) { // Validador personalizado disponible }
 */
function validador_has(string $name): bool
{
    $s = validador_store();
    return array_key_exists($name, $s);
}

/**
 * Registra un nuevo validador personalizado en el sistema
 * 
 * Extiende las capacidades del motor de validación permitiendo
 * agregar reglas personalizadas con lógica específica.
 * 
 * @param string $name Nombre único del validador (ej: "dni", "ruc")
 * @param callable $fn Función de validación que retorna bool|string|array
 * @param bool $override Permitir sobrescribir validadores existentes
 * @return void
 * 
 * @note El callable puede aceptar 1-3 parámetros: ($valor, $params, $contexto)
 * 
 * @example
 * validador_register('mayor_de_edad', function($edad) {
 *     return $edad >= 18 ? true : 'Debe ser mayor de edad';
 * });
 */
function validador_register(string $name, callable $fn, bool $override = true): void
{
    $name = trim($name);
    if ($name === '') return;

    $s = &validador_store();
    if (!$override && array_key_exists($name, $s)) return;

    $s[$name] = $fn;
}

/**
 * Define mensaje personalizado para un validador específico
 * 
 * Establece un mensaje de error amigable para un validador,
 * soportando placeholders {0}, {1} para valores dinámicos.
 * 
 * @param string $name Nombre del validador
 * @param string $message Mensaje de error personalizado
 * @return void
 * 
 * @example
 * validador_message('min', 'El valor debe tener al menos {0} caracteres');
 */
function validador_message(string $name, string $message): void
{
    $name = trim($name);
    if ($name === '') return;

    $m = &validador_messages_store();
    $m[$name] = $message;
}

/**
 * Formatea mensaje reemplazando placeholders con valores reales
 * 
 * Sustituye marcadores como {0}, {1}, etc. con los valores
 * proporcionados en el array de parámetros.
 * 
 * @param string $tpl Plantilla del mensaje con placeholders
 * @param array<int, mixed> $params Valores para sustitución
 * @return string Mensaje formateado
 * 
 * @internal Usado internamente para generar mensajes de error dinámicos
 */
function validador_format_message(string $tpl, array $params = []): string
{
    return preg_replace_callback('/\{(\d+)\}/', function ($m) use ($params) {
        $i = (int) $m[1];
        return array_key_exists($i, $params) ? (string) $params[$i] : $m[0];
    }, $tpl) ?? $tpl;
}

/**
 * Ejecuta un callable respetando su firma original
 * 
 * Invoca funciones de validación adaptándose automáticamente
 * al número de parámetros que esperan recibir.
 * 
 * @param callable $fn Función a ejecutar
 * @param mixed $value Valor a validar
 * @param array<int, mixed> $params Parámetros adicionales de la regla
 * @param array<string, mixed> $ctx Contexto adicional (ej: datos del formulario)
 * @return mixed Resultado de la ejecución del validador
 * 
 * @note Previene ArgumentCountError adaptándose a la aridad de la función
 */
function validador_call(callable $fn, $value, array $params, array $ctx)
{
    try {
        $closure = ($fn instanceof \Closure) ? $fn : \Closure::fromCallable($fn);
        $rf = new \ReflectionFunction($closure);
        $n = $rf->getNumberOfParameters();

        if ($n <= 1) return $closure($value);
        if ($n === 2) return $closure($value, $params);
        return $closure($value, $params, $ctx);

    } catch (\Throwable $e) {
        // Fallback seguro si Reflection falla
        return $fn($value, $params, $ctx);
    }
}

/**
 * Ejecuta una regla de validación específica sobre un valor
 * 
 * Núcleo del motor de validación: localiza y ejecuta un validador
 * registrado, interpretando diferentes formatos de retorno.
 * 
 * @param string $name Nombre de la regla a ejecutar
 * @param mixed $value Valor a validar/transformar
 * @param array<int, mixed> $params Parámetros adicionales para la regla
 * @param array<string, mixed> $ctx Contexto opcional (datos completos)
 * @return array{ok:bool,value:mixed,error:?string,name:string}
 *         ok: Estado de la validación
 *         value: Valor original o transformado
 *         error: Mensaje de error (null si ok=true)
 *         name: Nombre de la regla ejecutada
 * 
 * @throws \Throwable Propaga excepciones no controladas
 * 
 * @example
 * $resultado = validador_run('min', 'texto', ['5']);
 */
function validador_run(string $name, $value, array $params = [], array $ctx = []): array
{
    $s = validador_store();
    $fn = $s[$name] ?? null;

    if (!$fn) {
        return ['ok' => false, 'value' => $value, 'error' => "Validador no registrado: {$name}", 'name' => $name];
    }

    try {
        $res = validador_call($fn, $value, $params, $ctx);

        // Retorno completo estilo array
        if (is_array($res) && array_key_exists('ok', $res)) {
            return [
                'ok'    => (bool) ($res['ok'] ?? false),
                'value' => array_key_exists('value', $res) ? $res['value'] : $value,
                'error' => $res['error'] ?? null,
                'name'  => $name,
            ];
        }

        // String no vacío = mensaje de error personalizado
        if (is_string($res) && $res !== '' && $res !== 'OK') {
            return ['ok' => false, 'value' => $value, 'error' => $res, 'name' => $name];
        }

        // Boolean simple
        if ($res === true)  return ['ok' => true,  'value' => $value, 'error' => null, 'name' => $name];
        if ($res === false) {
            $msgs = validador_messages_store();
            $tpl = $msgs[$name] ?? "Validación {$name} fallida.";
            return ['ok' => false, 'value' => $value, 'error' => validador_format_message($tpl, $params), 'name' => $name];
        }

        // Transformación: cualquier otro valor se considera el nuevo valor
        return ['ok' => true, 'value' => $res, 'error' => null, 'name' => $name];

    } catch (\Throwable $e) {
        return ['ok' => false, 'value' => $value, 'error' => $e->getMessage(), 'name' => $name];
    }
}

/**
 * Aplica múltiples reglas de validación en secuencia
 * 
 * Procesa una lista de reglas sobre un valor, aplicando transformaciones
 * y validaciones en el orden especificado.
 * 
 * @param mixed $value Valor inicial a procesar
 * @param array<int, array<int, mixed>> $rules Array de reglas [[nombre, ...params], ...]
 * @param array<string, mixed> $ctx Contexto adicional para validadores
 * @return array{ok:bool,value:mixed,error:?string,name?:string}
 *         ok: Éxito de toda la cadena de validación
 *         value: Valor final después de transformaciones
 *         error: Primer mensaje de error encontrado
 * 
 * @note La regla especial "nullable" corta la validación si el valor está vacío
 * 
 * @example
 * $reglas = [['required'], ['trim'], ['min', '3']];
 * $resultado = validador_apply($valor, $reglas);
 */
function validador_apply($value, array $rules, array $ctx = []): array
{
    $current = $value;

    foreach ($rules as $rule) {
        if (!is_array($rule) || count($rule) === 0) continue;

        $name   = (string) $rule[0];
        $params = array_slice($rule, 1);

        // Manejo especial de regla nullable
        if ($name === 'nullable') {
            if ($current === null || $current === '') return ['ok' => true, 'value' => $current, 'error' => null];
            continue;
        }

        $r = validador_run($name, $current, $params, $ctx);
        if (!$r['ok']) return $r;

        $current = $r['value'];
    }

    return ['ok' => true, 'value' => $current, 'error' => null];
}

/**
 * Aplica reglas de validación desde string con sintaxis simple
 * 
 * Interpreta cadenas de texto con formato "regla1|regla2:param|regla3"
 * y las convierte en validaciones secuenciales.
 * 
 * @param mixed $value Valor a validar
 * @param string $rules Cadena de reglas separadas por pipe
 * @param array<string, mixed> $ctx Contexto adicional
 * @return array{ok:bool,value:mixed,error:?string,name?:string}
 * 
 * @syntax regla[:param1,param2,...]
 * @separator |
 * 
 * @example
 * $resultado = validador_rules($email, 'required|email|max:80');
 */
function validador_rules($value, string $rules, array $ctx = []): array
{
    $rules = trim($rules);
    if ($rules === '') return ['ok' => true, 'value' => $value, 'error' => null];

    $parts = array_filter(array_map('trim', explode('|', $rules)));
    $arr = [];

    foreach ($parts as $p) {
        $seg = explode(':', $p, 2);
        $name = trim($seg[0]);
        if ($name === '') continue;

        $params = [];
        if (isset($seg[1])) $params = array_map('trim', explode(',', $seg[1]));

        $arr[] = array_merge([$name], $params);
    }

    return validador_apply($value, $arr, $ctx);
}

/* ==========================================================
 * Integración con Servicios del Framework
 * ========================================================== */

/**
 * Obtiene instancia del servicio Redis si está disponible
 * 
 * @return mixed Instancia de Redis o null si no está disponible
 * 
 * @example
 * $redis = validador_redis();
 * if($redis) $redis->set('clave', 'valor');
 */
function validador_redis()
{
    return (class_exists('Config\\Services') && method_exists('Config\\Services', 'redis'))
        ? \Config\Services::redis()
        : null;
}

/**
 * Obtiene instancia del servicio Q_Pair para operaciones emparejadas
 * 
 * @return mixed|null Instancia de Q_Pair o null si no existe
 * 
 * @internal Para integración específica con Q_Framework
 */
function validador_pair()
{
    if (class_exists('Q_Pair') && method_exists('Q_Pair', 'instance')) return \Q_Pair::instance();
    if (class_exists('Config\\Services') && method_exists('Config\\Services', 'pair')) return \Config\Services::pair();
    return null;
}

/**
 * Obtiene conexión a base de datos del framework
 * 
 * @param ?string $group Nombre del grupo de conexión (null para default)
 * @return mixed Conexión a base de datos o null si no está disponible
 * 
 * @example
 * $db = validador_db();
 * $usuarios = $db->table('usuarios')->get()->getResult();
 */
function validador_db(?string $group = null)
{
    return (class_exists('Config\\Services') && method_exists('Config\\Services', 'db'))
        ? \Config\Services::db($group)
        : null;
}

/**
 * Sistema de caché con Redis para operaciones costosas
 * 
 * Almacena y recupera resultados de funciones costosas en Redis,
 * con fallback a ejecución directa si Redis no está disponible.
 * 
 * @param string $key Clave única para el cache
 * @param callable $fn Función que genera el valor a cachear
 * @param int $ttl Tiempo de vida en segundos (default: 60)
 * @return mixed Valor cacheado o resultado de la función
 * 
 * @example
 * $datos = validador_cache('usuarios_activos', function() {
 *     return obtener_usuarios_activos(); // Operación costosa
 * }, 300);
 */
function validador_cache(string $key, callable $fn, int $ttl = 60)
{
    $r = validador_redis();
    if (!$r) return $fn();

    try {
        $hit = method_exists($r, 'get') ? $r->get($key) : null;

        if ($hit !== null && $hit !== false && $hit !== '') {
            $j = json_decode((string) $hit, true);
            if (json_last_error() === JSON_ERROR_NONE) return $j;
            return $hit;
        }

        $val = $fn();
        $payload = is_string($val) ? $val : json_encode($val, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

        if (method_exists($r, 'setex')) $r->setex($key, $ttl, (string)$payload);
        elseif (method_exists($r, 'set')) $r->set($key, (string)$payload);

        return $val;

    } catch (\Throwable $e) {
        return $fn();
    }
}

/* ==========================================================
 * Validadores Predefinidos (Built-in)
 * ========================================================== */

/**
 * Inicializa los validadores predefinidos del sistema
 * 
 * Registra todas las reglas básicas y sus mensajes por defecto
 * una sola vez durante la ejecución del script.
 * 
 * @return void
 * 
 * @note No sobrescribe validadores personalizados ya registrados
 */
function validador_boot_defaults(): void
{
    static $booted = false;
    if ($booted) return;
    $booted = true;

    // Mensajes por defecto para validadores básicos
    validador_message('required',     'Campo requerido.');
    validador_message('email',        'Email inválido.');
    validador_message('email_basic',  'Email inválido.');
    validador_message('min',          'Debe tener mínimo {0} caracteres.');
    validador_message('max',          'Debe tener máximo {0} caracteres.');
    validador_message('int',          'Debe ser un entero.');
    validador_message('float',        'Debe ser un número.');
    validador_message('json',         'JSON inválido.');
    validador_message('phone',        'Teléfono inválido.');
    validador_message('phone_basic',  'Teléfono inválido.');

    // Transformadores (modifican el valor)
    validador_register('trim',  fn($v) => is_string($v) ? trim($v) : $v, false);
    validador_register('lower', fn($v) => is_string($v) ? mb_strtolower($v) : $v, false);
    validador_register('upper', fn($v) => is_string($v) ? mb_strtoupper($v) : $v, false);

    // Validadores básicos
    validador_register('required', fn($v) => !($v === null || $v === '' || (is_array($v) && empty($v))), false);

    // Validador email PRO (usa validador_email interno)
    validador_register('email', function ($v) {
        return validador_email((string)$v)[0];
    }, false);

    // Validador email básico (filter_var)
    validador_register('email_basic', fn($v) => filter_var($v, FILTER_VALIDATE_EMAIL) !== false, false);

    validador_register('min', fn($v, $p) => mb_strlen((string) $v) >= (int) ($p[0] ?? 0), false);
    validador_register('max', fn($v, $p) => mb_strlen((string) $v) <= (int) ($p[0] ?? PHP_INT_MAX), false);

    validador_register('int',   fn($v) => filter_var($v, FILTER_VALIDATE_INT) !== false, false);
    validador_register('float', fn($v) => filter_var($v, FILTER_VALIDATE_FLOAT) !== false, false);

    // Validador JSON robusto (acepta null)
    validador_register('json', function ($v) {
        json_decode((string)$v, true);
        return json_last_error() === JSON_ERROR_NONE;
    }, false);

    // Validador phone PRO con región opcional
    validador_register('phone', function ($v, $p) {
        $region = (string)($p[0] ?? 'PE');
        return validador_phone((string)$v, $region)[0];
    }, false);

    // Validador phone básico (solo longitud)
    validador_register('phone_basic', function ($v) {
        $digits = preg_replace('/\D+/', '', (string)$v);
        return is_string($digits) && strlen($digits) >= 7 && strlen($digits) <= 15;
    }, false);

    // "nullable" se maneja en validador_apply, no necesita registro
}

// Inicializar validadores predefinidos al cargar el helper
validador_boot_defaults();

/* ==========================================================
 * Sistema de Encriptación Compatible
 * ========================================================== */

/**
 * Encripta datos con soporte para expiración y metadatos
 * 
 * Sistema de encriptación robusto que soporta:
 * - Encriptación con AES-GCM (si está disponible)
 * - Metadatos embebidos (fecha creación, expiración)
 * - Additional Authenticated Data (AAD)
 * - Fallback a base64 para compatibilidad
 * 
 * @param mixed $dato Datos a encriptar (string, array, objeto)
 * @param int $horas Horas hasta expiración (0 = sin expiración)
 * @param bool $confecha Incluir timestamp de creación
 * @param array $aad Additional Authenticated Data para AES-GCM
 * @return string Token encriptado o codificado
 * 
 * @example
 * $token = validador_encriptar(['id' => 123, 'rol' => 'admin'], 24, true);
 */
function validador_encriptar($dato, int $horas = 0, bool $confecha = true, array $aad = []): string
{
    // Legacy: función global personalizada
    if (function_exists('encriptar')) {
        return (string) encriptar($dato, $horas, $confecha);
    }

    $payload = $dato;

    // Agregar metadatos si es necesario
    if ($confecha || $horas > 0) {
        $wrap = [
            '_qfw' => 1,
            'iat'  => time(),
            'data' => $payload,
        ];
        if ($horas > 0) $wrap['exp'] = time() + ($horas * 3600);
        $payload = $wrap;
    }

    $plain = is_string($payload)
        ? $payload
        : json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if ($plain === false || $plain === null) $plain = (string) $payload;

    // Encriptación con Crypt del framework (si existe)
    if (class_exists('System\\Core\\Crypt')) {
        $c = 'System\\Core\\Crypt';
        if (method_exists($c, 'encrypt')) {
            return (string) $c::encrypt((string)$plain, $aad);
        }
    }

    // Fallback a base64 (sin encriptación real)
    return base64_encode((string)$plain);
}

/**
 * Desencripta tokens generados por validador_encriptar
 * 
 * @param string $token Token a desencriptar
 * @param bool $json Decodificar JSON automáticamente
 * @param bool $array Retornar como array asociativo
 * @param array $aad Additional Authenticated Data (debe coincidir)
 * @return mixed Datos originales o estructura decodificada
 * 
 * @note Si el token ha expirado, retorna array vacío o null
 * 
 * @example
 * $datos = validador_desencriptar($token, true, true);
 */
function validador_desencriptar(string $token, bool $json = true, bool $array = true, array $aad = [])
{
    $token = trim($token);
    if ($token === '') return $json ? ($array ? [] : null) : '';

    // Legacy: función global personalizada
    if (function_exists('desencriptar')) {
        return desencriptar($token, $json, $array);
    }

    $raw = null;

    // Desencriptación con Crypt del framework
    if (class_exists('System\\Core\\Crypt')) {
        $c = 'System\\Core\\Crypt';
        if (method_exists($c, 'decrypt')) {
            try {
                $raw = (string) $c::decrypt($token, $aad);
            } catch (\Throwable $e) {
                return $json ? ($array ? [] : null) : '';
            }
        }
    }

    // Fallback: decodificación base64
    if ($raw === null) {
        $b = base64_decode($token, true);
        if ($b === false) return $json ? ($array ? [] : null) : $token;
        $raw = $b;
    }

    if (!$json) return $raw;

    $decoded = json_decode($raw, $array);
    if (json_last_error() !== JSON_ERROR_NONE) return $raw;

    // Extraer datos si hay metadatos embebidos
    $hasMeta = (is_array($decoded) && isset($decoded['_qfw'])) || (is_object($decoded) && isset($decoded->_qfw));
    if ($hasMeta) {
        $exp = is_array($decoded) ? ($decoded['exp'] ?? null) : ($decoded->exp ?? null);
        if ($exp && is_numeric($exp) && time() > (int) $exp) {
            return $array ? [] : null;
        }

        $data = is_array($decoded) ? ($decoded['data'] ?? null) : ($decoded->data ?? null);
        return $data;
    }

    return $decoded;
}

/* ==========================================================
 * Utilidades de Validación (Funciones Auxiliares)
 * ========================================================== */

/**
 * Verifica si un string es codificación base64 válida
 * 
 * @param mixed $str String a verificar
 * @return bool true si es base64 válido y reversible
 * 
 * @example
 * $esBase64 = validador_base64('SGVsbG8gV29ybGQ='); // true
 */
function validador_base64($str): bool
{
    return base64_encode(base64_decode((string)$str, true)) === (string)$str;
}

/**
 * Calcula diferencia en días entre dos fechas
 * 
 * @param mixed $date1 Primera fecha (string convertible por strtotime)
 * @param mixed $date2 Segunda fecha (string convertible por strtotime)
 * @return int Diferencia en días (redondeado)
 * 
 * @example
 * $dias = validador_dias2fechas('2024-01-01', '2024-01-10'); // 9
 */
function validador_dias2fechas($date1, $date2): int
{
    $diff = strtotime((string)$date2) - strtotime((string)$date1);
    return (int) round($diff / 86400);
}

/**
 * Verifica si un string es JSON válido
 * 
 * @param mixed $string String a verificar
 * @return bool true si es JSON válido (acepta null como JSON)
 * 
 * @note Utiliza json_last_error() para detección precisa
 */
function validador_isjson($string): bool
{
    if (!is_string($string)) return false;
    json_decode($string);
    return json_last_error() === JSON_ERROR_NONE;
}

/**
 * Búsqueda case-insensitive de substring en string
 * 
 * @param string $quecosa Texto a buscar
 * @param string $donde Texto donde buscar
 * @return bool true si se encuentra (ignorando mayúsculas/minúsculas)
 * 
 * @example
 * $encontrado = validador_existeenstring('hola', 'Hola Mundo'); // true
 */
function validador_existeenstring(string $quecosa, string $donde): bool
{
    return (strpos(mb_strtolower($donde), mb_strtolower($quecosa)) !== false);
}

/**
 * Oculta parte central de un string para mostrar solo extremos
 * 
 * @param ?string $string Texto original
 * @return ?string Texto con caracteres centrales ocultos
 * 
 * @example
 * $oculto = validador_ocultarletras('ABCDEFGHIJ'); // "AB****IJ"
 */
function validador_ocultarletras(?string $string = null): ?string
{
    if (!$string) return null;

    $length = strlen($string);
    $visibleCount = (int) round($length / 4);
    $hiddenCount  = $length - ($visibleCount * 2);

    return substr($string, 0, $visibleCount)
        . str_repeat('*', $hiddenCount)
        . substr($string, ($visibleCount * -1), $visibleCount);
}

/**
 * Busca valores en string separado por delimitador
 * 
 * @param mixed $string String con valores separados
 * @param mixed $bscr Valor o array de valores a buscar
 * @param string $separador Delimitador (default: ',')
 * @return bool true si encuentra al menos un valor
 * 
 * @example
 * $encontrado = validador_buscarstring('a,b,c', 'b'); // true
 */
function validador_buscarstring($string, $bscr, $separador = ','): bool
{
    $arr = explode((string)$separador, (string)$string);
    $arr = array_map('trim', $arr);

    if (is_array($bscr)) {
        foreach ($bscr as $value) {
            if (in_array((string)$value, $arr, true)) return true;
        }
        return false;
    }

    return in_array((string)$bscr, $arr, true);
}

/**
 * Verifica accesibilidad HTTP de una URL
 * 
 * Realiza petición HEAD para determinar si la URL responde
 * con códigos HTTP 2xx-4xx (considerados accesibles).
 * 
 * @param mixed $url URL a verificar
 * @return ?bool true si responde, null si falla o timeout
 * 
 * @timeout 5 segundos máximo
 */
function validador_urlexiste($url): ?bool
{
    $url = (string)$url;
    if ($url === '') return null;

    $ch = curl_init($url);
    if (!$ch) return null;

    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);

    curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ($httpCode >= 200 && $httpCode <= 400) ? true : null;
}

/**
 * Detecta si una URL apunta a una imagen válida
 * 
 * @param string $url URL a verificar
 * @return ?bool true si es imagen, null si no o error
 * 
 * @note Utiliza getimagesize() para detección precisa
 */
function validador_esimagenURL($url = ""): ?bool
{
    $url = (string)$url;
    if ($url === '') return null;

    try {
        if (validador_urlexiste($url)) {
            $info = @getimagesize($url);
            return $info ? true : null;
        }
    } catch (\Throwable $e) {
        return null;
    }

    return null;
}

/**
 * Verifica existencia y legibilidad de URL (especializada en imágenes)
 * 
 * @param mixed $url URL a verificar
 * @return ?bool true si es legible, null si no
 * 
 * @deprecated Usar validador_urlexiste() o validador_esimagenURL()
 */
function validador_urlexist($url): ?bool
{
    if (!validador_esimagenURL((string)$url)) return null;

    $ok = @file_get_contents((string)$url, false, null, 0, 1);
    return ($ok !== false) ? true : null;
}

/**
 * Valida formato de URL con FILTER_VALIDATE_URL
 * 
 * @param mixed $url URL a validar
 * @return ?bool true si es URL válida, null si no
 * 
 * @example
 * $esUrl = validador_isurl('https://ejemplo.com'); // true
 */
function validador_isurl($url): ?bool
{
    return (!filter_var((string)$url, FILTER_VALIDATE_URL) === false) ? true : null;
}

/**
 * Detecta si un MIME type corresponde a imagen
 * 
 * @param mixed $mime MIME type a verificar
 * @return ?bool true si comienza con "image/", null si no
 */
function validador_esimagen($mime): ?bool
{
    return (strstr((string)$mime, "image/") !== false) ? true : null;
}

/**
 * Detecta imágenes por extensión de archivo
 * 
 * @param string $filename Nombre de archivo o ruta
 * @return bool true si la extensión es de imagen conocida
 * 
 * @note Soporta: jpg, jpeg, png, gif, bmp, webp, svg, tiff, tif, ico, avif
 */
function validador_imagen_por_extension(string $filename): bool
{
    $extensionesImagen = ['jpg','jpeg','png','gif','bmp','webp','svg','tiff','tif','ico','avif'];
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, $extensionesImagen, true);
}

/**
 * Elimina tildes y diacríticos de texto
 * 
 * @param string $str Texto a normalizar
 * @return string Texto sin tildes ni caracteres especiales
 * 
 * @example
 * $normalizado = validador_sintildes('café año'); // "cafe ano"
 */
function validador_sintildes($str = ""): string
{
    $trns = [
        'à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a','å'=>'a','æ'=>'a',
        'À'=>'A','Á'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A','Å'=>'A','Æ'=>'A',
        'ç'=>'c','Ç'=>'C',
        'è'=>'e','é'=>'e','ê'=>'e','ë'=>'e',
        'È'=>'E','É'=>'E','Ê'=>'E','Ë'=>'E',
        'ì'=>'i','í'=>'i','î'=>'i','ï'=>'i',
        'Ì'=>'I','Í'=>'I','Î'=>'I','Ï'=>'I',
        'ñ'=>'n','Ñ'=>'N',
        'ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o','ö'=>'o',
        'Ò'=>'O','Ó'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O',
        'ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u',
        'Ù'=>'U','Ú'=>'U','Û'=>'U','Ü'=>'U',
        'ý'=>'y','Ý'=>'Y',
        'ž'=>'z','Ž'=>'Z'
    ];

    return strtr((string)$str, $trns);
}

/**
 * Valida que todos los valores en string separado existan en array
 * 
 * @param mixed $string String con valores separados por coma
 * @param array $array_comparador Array con valores permitidos
 * @return bool true si todos los valores están permitidos
 * 
 * @example
 * $valido = validador_verificarValores("a,b", ["a","b","c"]); // true
 */
function validador_verificarValores($string, $array_comparador): bool
{
    $valores = array_map('trim', explode(',', (string)$string));
    foreach ($valores as $valor) {
        if (!in_array($valor, $array_comparador, true)) return false;
    }
    return true;
}

/**
 * Minificador de código para PHP, JS, HTML y CSS
 * 
 * Elimina comentarios y espacios innecesarios manteniendo
 * funcionalidad. No es 100% parser-safe para casos extremos.
 * 
 * @param mixed $codigo Código fuente a minificar
 * @param mixed $tipo Tipo de código: 'php', 'js', 'html', 'css'
 * @return string Código minificado
 * @throws \Exception Si el tipo no es soportado
 * 
 * @warning Para producción, considerar herramientas profesionales como UglifyJS
 */
function validador_minificar($codigo, $tipo): string
{
    $tipo = strtolower((string) $tipo);
    $codigo = (string)$codigo;

    switch ($tipo) {
        case 'php':
        case 'js':
            $codigo = preg_replace_callback(
                '/("(?:\\\\.|[^"\\\\])*"|\'(?:\\\\.|[^\'\\\\])*\'|`(?:\\\\.|[^`\\\\])*`|\/\*[\s\S]*?\*\/|\/\/[^\n\r]*)/',
                function ($matches) {
                    return (strpos($matches[0], '/*') === 0 || strpos($matches[0], '//') === 0) ? '' : $matches[0];
                },
                $codigo
            ) ?? $codigo;

            $codigo = preg_replace('/\s*([{}();,:])\s*/', '$1', $codigo) ?? $codigo;
            break;

        case 'html':
            $codigo = preg_replace('/<!--[\s\S]*?-->/', '', $codigo) ?? $codigo;
            $codigo = preg_replace('/>\s+</', '><', $codigo) ?? $codigo;
            break;

        case 'css':
            $codigo = preg_replace_callback(
                '/\/\*[\s\S]*?\*\//',
                function ($matches) {
                    return strpos($matches[0], 'url(') === false ? '' : $matches[0];
                },
                $codigo
            ) ?? $codigo;

            $codigo = preg_replace('/\s*([{}:;,])\s*/', '$1', $codigo) ?? $codigo;
            break;

        default:
            throw new \Exception("Tipo de código no soportado: $tipo");
    }

    return trim($codigo);
}

/**
 * Minificador específico para HTML
 * 
 * @param mixed $html Código HTML a minificar
 * @return string HTML minificado
 * 
 * @note Más simple que validador_minificar() para HTML
 */
function validador_minificarHTML($html): string
{
    $html = (string)$html;

    $search = [
        '/\>[^\S ]+/s',
        '/[^\S ]+\</s',
        '/(\s)+/s'
    ];

    $replace = [
        '>',
        '<',
        '\\1'
    ];

    return preg_replace($search, $replace, $html) ?? $html;
}

/**
 * Detecta si el cliente es dispositivo móvil
 * 
 * Analiza el User-Agent para detectar dispositivos móviles
 * comunes (Android, iPhone, iPad, Windows Phone).
 * 
 * @return bool true si es dispositivo móvil
 * 
 * @note Basado en simple string matching, no es 100% preciso
 */
function validador_DispMobil(): bool
{
    $mobileDevices = ['Android', 'iPhone', 'iPad', 'Windows Phone'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    foreach ($mobileDevices as $device) {
        if (strpos($userAgent, $device) !== false) return true;
    }

    return false;
}