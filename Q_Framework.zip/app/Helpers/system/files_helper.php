<?php

    require_once(ROOTPATH.'vendor/resizeimage/autoload.php');
    use \Gumlet\ImageResize;

    /**
     * Configura los headers iniciales para la descarga de un archivo
     *
     * @param string $tipo Tipo MIME del archivo
     * @param string $nombre Nombre del archivo a descargar
     */
    function files_DescInicio($tipo,$nombre)
    {
        header('Content-Type:'.$tipo); 
        header("Content-Disposition: attachment; filename=".$nombre);
        header('Cache-Control: max-age=0'); 
        ob_end_clean();
    }
    
    /**
     * Finaliza el proceso de descarga de archivo
     */
    function files_Descfin()
    {
        exit;
    }
    
    /**
     * Obtiene la extensión de un archivo
     *
     * @param mixed $file Puede ser array $_FILES o string con ruta
     * @return string Extensión del archivo
     */
    function files_getExtention($file)
    {
        
        if (is_array($file) && isset($file['name'])) 
        {
            $filename = $file['name'];
        }
        else 
        {
            $filename = basename($file);
        }
        
        return pathinfo($filename, PATHINFO_EXTENSION);;
    }
    
    /**
     * Convierte una imagen a formato WebP usando Imagick
     *
     * @param mixed $fileIGM Puede ser objeto Imagick, array $_FILES o URL
     * @return mixed Imagen WebP en formato binario o el archivo original si falla
     */
    function files_img2webp($fileIGM)
    {
        
        if (extension_loaded('imagick')) 
        {
            
            $imagick = new Imagick();
    
            if ($fileIGM instanceof Imagick) 
            {
                $imagick = $fileIGM;
            } 
            elseif (is_array($fileIGM) && is_uploaded_file($fileIGM['tmp_name'])) 
            {
                $imagick->readImage($fileIGM['tmp_name']);
            } 
            elseif (filter_var($fileIGM, FILTER_VALIDATE_URL)) 
            {
                $imagick->readImage($fileIGM);
            } 
            else 
            {
                return false;
            }
            
            // Convertir la imagen a formato WebP
            $imagick->setImageFormat('webp');
            $webpImage = $imagick->getImageBlob();
    
            // Liberar memoria
            $imagick->clear();
            $imagick->destroy();
    
            return $webpImage;
            
        }
        else 
        {
            return $fileIGM;
        }
    }

    /**
    * Adapta la salida de files_img2webp() a un array tipo $_FILES.
    * - $result puede ser: string (blob webp), false, o array (si no hubo conversión).
    * - $original es el $_FILES original para rescatar nombre/mime si hace falta.
    */
    function files_img2webp_normalize($result, array $original)
    {
        // Si falló la conversión
        if ($result === false) {
            return false;
        }

        // Si la función devolvió un string → es el blob WEBP. Creamos un tmp file y normalizamos.
        if (is_string($result)) {
            $origName   = $original['name'] ?? 'archivo';
            $baseName   = preg_replace('/\.[^.]+$/', '', $origName);
            $finalName  = $baseName . '.webp';

            $tmpBase = tempnam(sys_get_temp_dir(), 'webp_');
            $tmpWebp = $tmpBase . '.webp';
            @unlink($tmpBase);

            // Guardar blob a disco
            file_put_contents($tmpWebp, $result);

            return [
                'tmp_name'      => $tmpWebp,
                'name'          => $finalName,         // nombre final .webp
                'type'          => 'image/webp',
                'size'          => filesize($tmpWebp) ?: 0,
                'name_original' => $origName,          // conserva nombre original
            ];
        }

        // Si devolvió un array (ej. no hubo conversión porque no hay Imagick) → normaliza campos mínimos
        if (is_array($result)) {
            // Asegurar name_original para tus búsquedas
            if (empty($result['name_original']) && !empty($result['name'])) {
                $result['name_original'] = $result['name'];
            }
            return $result;
        }

        // Cualquier otro caso
        return false;
    }
    
    /**
     * Redimensiona una imagen manteniendo o no la proporción
     *
     * @param mixed $fileIMG Imagen a redimensionar
     * @param int $width Ancho deseado
     * @param int $height Alto deseado
     * @param bool $respectRatio Mantener proporción
     * @return mixed Imagen redimensionada o false si falla
     */
    function files_resizeimagen($fileIMG, $width, $height,$respectRatio=false)
    {
        if (extension_loaded('imagick'))
        {
            $image = new Imagick();
        
            if (is_uploaded_file($fileIMG['tmp_name'])) 
            {
                $image->readImage($fileIMG['tmp_name']);
            } 
            elseif (filter_var($fileIMG, FILTER_VALIDATE_URL)) 
            {
                $image->readImage($fileIMG);
            } 
            else 
            {
                $image->readImageBlob($fileIMG);
            }
        }
    }
            
    /**
     * Recorta una imagen a las dimensiones especificadas
     *
     * @param mixed $fileIMG Imagen a recortar
     * @param int $ancho Ancho deseado
     * @param int $alto Alto deseado
     * @param string $proporcion Tipo de proporción ('ancho'|'alto'|'')
     * @return mixed Imagen recortada o false si falla
     */
    function files_cropImage($fileIMG, $ancho, $alto, $proporcion = '') 
    {
        if (extension_loaded('imagick')) 
        {
            $imagen = new Imagick();
    
            if ($fileIMG instanceof Imagick) 
            {
                $imagen = $fileIMG;
            } 
            elseif (is_array($fileIMG) && is_uploaded_file($fileIMG['tmp_name'])) 
            {
                $imagen->readImage($fileIMG['tmp_name']);
            } 
            elseif (filter_var($fileIMG, FILTER_VALIDATE_URL)) 
            {
                $imagen->readImage($fileIMG);
            } 
            else 
            {
                echo "Error, no se pudo leer el archivo";
                return false;
            }
    
            // Obtener dimensiones originales
            $anchoOriginal = $imagen->getImageWidth();
            $altoOriginal = $imagen->getImageHeight();
    
            // Calcular nuevas dimensiones según proporción
            if ($proporcion == 'ancho') 
            {
                $nuevoAncho = $ancho;
                $nuevoAlto = ($altoOriginal / $anchoOriginal) * $ancho;
            } 
            elseif ($proporcion == 'alto') 
            {
                $nuevoAncho = ($anchoOriginal / $altoOriginal) * $alto;
                $nuevoAlto = $alto;
            } 
            else 
            {
                $nuevoAncho = $ancho;
                $nuevoAlto = $alto;
            }
    
            $imagen->resizeImage($nuevoAncho, $nuevoAlto, Imagick::FILTER_LANCZOS, 1);
    
            // Crear imagen final
            $imagenFinal = new Imagick();
            $imagenFinal->newImage($ancho, $alto, 'white', 'jpeg');
    
            // Posicionar imagen redimensionada
            $posicionX = ($ancho - $nuevoAncho) / 2;
            $posicionY = ($alto - $nuevoAlto) / 2;
    
            $imagenFinal->compositeImage($imagen, Imagick::COMPOSITE_OVER, $posicionX, $posicionY);
            $imagenFinal->setImageFormat('jpeg');
    
            return $imagenFinal;
        } 
        elseif (extension_loaded('gd')) 
        {
            // Usar GD si Imagick no está disponible
            if (is_array($fileIMG) && is_uploaded_file($fileIMG['tmp_name'])) 
            {
                $fileIMG = $fileIMG['tmp_name'];
            } 
            elseif (!file_exists($fileIMG)) 
            {
                echo "Error, no se pudo leer el archivo";
                return false;
            }
    
            $imagen = @imagecreatefromstring(file_get_contents($fileIMG));
            
            if (!$imagen) 
            {
                return $fileIMG;
            }
    
            $anchoOriginal = imagesx($imagen);
            $altoOriginal = imagesy($imagen);
    
            if ($proporcion == 'ancho') 
            {
                $nuevoAncho = $ancho;
                $nuevoAlto = ($altoOriginal / $anchoOriginal) * $ancho;
            } 
            elseif ($proporcion == 'alto') 
            {
                $nuevoAncho = ($anchoOriginal / $altoOriginal) * $alto;
                $nuevoAlto = $alto;
            } 
            else 
            {
                $nuevoAncho = $ancho;
                $nuevoAlto = $alto;
            }
    
            $imagenRedimensionada = imagecreatetruecolor($nuevoAncho, $nuevoAlto);
            imagecopyresampled($imagenRedimensionada, $imagen, 0, 0, 0, 0, $nuevoAncho, $nuevoAlto, $anchoOriginal, $altoOriginal);
    
            $imagenFinal = imagecreatetruecolor($ancho, $alto);
            $blanco = imagecolorallocate($imagenFinal, 255, 255, 255);
            imagefill($imagenFinal, 0, 0, $blanco);
    
            $posicionX = ($ancho - $nuevoAncho) / 2;
            $posicionY = ($alto - $nuevoAlto) / 2;
    
            imagecopy($imagenFinal, $imagenRedimensionada, $posicionX, $posicionY, 0, 0, $nuevoAncho, $nuevoAlto);
    
            ob_start();
            imagejpeg($imagenFinal);
            $output = ob_get_clean();
    
            imagedestroy($imagen);
            imagedestroy($imagenRedimensionada);
            imagedestroy($imagenFinal);
    
            return $output;
        } 
        else 
        {
            return $fileIMG;
        }
    }
        
    /**
    * Guarda un archivo en destino a partir de:
    * - array tipo $_FILES (usa ['tmp_name'] o ['content'])
    * - ruta a archivo (string)
    * - blob de datos (string binario)
    *
    * Compatibilidad:
    * - Firma original: files_guardararchivo($data, $destination)
    * - Opcional: files_guardararchivo($data, $destination, $opts)
    *
    * @param mixed  $data         Array $_FILES / ruta / blob
    * @param string $destination  Ruta final (archivo) o carpeta (si termina con / o es dir)
    * @param array  $opts         Opciones:
    *   - overwrite   (bool)  Default true   : permite sobrescribir
    *   - atomic      (bool)  Default true   : escribe usando tmp+rename
    *   - chmod       (int)   Default 0644   : permisos al final (si se puede)
    *   - ensure_ext  (bool)  Default false  : si destino es carpeta o sin extensión, agrega según mime
    *   - mime        (null|string)          : mime esperado; si null intenta detectar
    *   - return      ('bool'|'array')       : 'bool' (default) o info detallada
    *
    * @return bool|array  true/false o ['path','bytes','mime','existed']
    *
    * @throws Exception
    */
    function files_guardararchivo($data, $destination, array $opts = [])
    {
        $opts = array_merge([
            'overwrite'  => true,
            'atomic'     => true,
            'chmod'      => 0644,
            'ensure_ext' => false,
            'mime'       => null,
            'return'     => 'bool',
        ], $opts);

        // 1) Obtener binario + nombre sugerido + mime
        $bin       = null;
        $srcName   = 'archivo';
        $srcMime   = $opts['mime']; // si viene forzado
        $isFileArr = false;

        if (is_array($data)) {
            // Puede venir de $_FILES o del adaptador (tmp_name ya convertido)
            $isFileArr = true;
            $srcName   = $data['name'] ?? $srcName;

            if (!empty($data['tmp_name']) && is_readable($data['tmp_name'])) {
                // NO exigimos is_uploaded_file, para soportar “modo directo”
                $bin = @file_get_contents($data['tmp_name']);
                // Intenta tomar mime del array si existe
                if (!$srcMime && !empty($data['type'])) {
                    $srcMime = $data['type'];
                }
            } elseif (!empty($data['content']) && is_string($data['content'])) {
                $bin = $data['content'];
                if (!$srcMime && !empty($data['type'])) {
                    $srcMime = $data['type'];
                }
            } else {
                throw new Exception('El array no contiene tmp_name legible ni content.');
            }
        } elseif (is_string($data)) {
            if (is_file($data) && is_readable($data)) {
                $bin     = @file_get_contents($data);
                $srcName = basename($data);
            } else {
                // lo tratamos como blob/string
                $bin = $data;
            }
        } else {
            throw new Exception('Tipo de dato no soportado para $data.');
        }

        if ($bin === null) {
            throw new Exception('No se pudo obtener el contenido binario del archivo.');
        }

        // 2) Detectar MIME si no se proporcionó
        if (!$srcMime) {
            // Si tenemos un archivo temporal, finfo directo; si no, usa finfo de buffer
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $srcMime = $finfo->buffer($bin) ?: 'application/octet-stream';
        }

        // 3) Resolver ruta final (acepta carpeta o archivo completo)
        $destination = rtrim($destination, DIRECTORY_SEPARATOR);
        $destIsDir   = (substr($destination, -1) === DIRECTORY_SEPARATOR) || (is_dir($destination));

        if ($destIsDir) {
            // Si es carpeta, usamos nombre fuente
            $fileName = $srcName ?: 'archivo';
            $filePath = $destination . DIRECTORY_SEPARATOR . $fileName;
        } else {
            $filePath = $destination;
        }

        // 3.1) Asegurar extensión si se pide y no la tiene (útil al guardar WEBP)
        if ($opts['ensure_ext']) {
            $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
            if ($ext === '') {
                // map mínimo mime->ext
                $map = [
                    'image/webp'       => 'webp',
                    'image/jpeg'       => 'jpg',
                    'image/png'        => 'png',
                    'image/gif'        => 'gif',
                    'application/pdf'  => 'pdf',
                    'text/plain'       => 'txt',
                ];
                $useExt = $map[$srcMime] ?? null;
                if ($useExt) {
                    $filePath .= '.' . $useExt;
                }
            }
        }

        // 4) Crear carpeta destino
        $directory = dirname($filePath);
        if (!is_dir($directory)) {
            if (!@mkdir($directory, 0777, true) && !is_dir($directory)) {
                throw new Exception('No se pudo crear el directorio destino: ' . $directory);
            }
        }

        // 5) Overwrite / existencia
        $alreadyExisted = is_file($filePath);
        if ($alreadyExisted && !$opts['overwrite']) {
            throw new Exception('El archivo ya existe y overwrite=false: ' . $filePath);
        }

        // 6) Escritura (atómica opcional)
        $bytes = 0;
        if ($opts['atomic']) {
            // Escribir a un tmp en el mismo directorio y renombrar
            $tmp = tempnam($directory, 'wrt_');
            if ($tmp === false) {
                throw new Exception('No se pudo crear archivo temporal para escritura atómica.');
            }
            $bytes = @file_put_contents($tmp, $bin, LOCK_EX);
            if ($bytes === false) {
                @unlink($tmp);
                throw new Exception('Error escribiendo al archivo temporal.');
            }
            // Renombrar (reemplaza si existe)
            if (!@rename($tmp, $filePath)) {
                @unlink($tmp);
                throw new Exception('No se pudo mover el temporal al destino final.');
            }
        } else {
            $bytes = @file_put_contents($filePath, $bin, LOCK_EX);
            if ($bytes === false) {
                throw new Exception('No se pudo escribir el archivo destino.');
            }
        }

        // 7) Permisos
        if (is_int($opts['chmod'])) {
            @chmod($filePath, $opts['chmod']);
        }

        // 8) Limpieza de temporales de entrada (solo si proviene de array y tmp_name “propio”)
        // OJO: si tmp_name es nuestro (p. ej., el adaptador lo generó), normalmente PHP lo borra al final del request,
        // pero si quieres limpiar ya, puedes hacerlo aquí de forma opcional.

        // 9) Retorno
        if ($opts['return'] === 'array') {
            return [
                'path'    => $filePath,
                'bytes'   => (int)$bytes,
                'mime'    => $srcMime,
                'existed' => $alreadyExisted,
            ];
        }

        return $bytes !== false;
    }

    
    /**
     * Obtiene el tamaño y extensión de un archivo
     *
     * @param string $filePath Ruta del archivo
     * @return array|bool Array con size y extension, o false si no existe
     */
    function files_tamext($filePath)
    {
        if (file_exists($filePath)) 
        {
            return 
            [
                'size' => filesize($filePath),
                'extension' => pathinfo($filePath, PATHINFO_EXTENSION)
            ];
        } 
        else 
        {
            return false;
        }
    }
    
    /**
     * Obtiene un archivo desde la base de datos
     *
     * @param object $Datos Objeto de conexión a BD
     * @param int $id ID del archivo
     * @param bool $urldata Si true devuelve URL, si false contenido
     * @return mixed URL, contenido o null si no existe
     */
	function files_fileFromarchivos($Datos,$id,$urldata=true)
	{
	    $archivo=$Datos->datos_select("select * from app_archivos where arch_id='".$id."'");
	    
	    if ($archivo)
	    {
	        $fila=json_decode($archivo[0]['arch_documento'],TRUE);

	        if ($urldata)
	        {
	            return "/public/uploads/archivos/".$archivo[0]['arch_tabla']."/".$archivo[0]['arch_columna']."/".$fila['doc_nombre'];
	        }
	        else 
	        {
	            return file_get_contents(ROOTPATH."/public/uploads/archivos/".$archivo[0]['arch_tabla']."/".$archivo[0]['arch_columna']."/".$fila['doc_nombre']);
	        }
	    }
	    else 
	    {
	        return null;
	    }
	}
	
	/**
	 * Agrega marca de agua a una imagen
	 *
	 * @param mixed $fileIMG Imagen a marcar
	 * @param string $marcaurl Ruta de la marca de agua
	 * @return mixed Imagen con marca o original si falla
	 */
	function files_ponermarcadeagua($fileIMG,$marcaurl="/public/imagenes/sistema/agua.png")
	{
	    if (extension_loaded('imagick'))
	    {
            $image = new Imagick();
        
            if (is_uploaded_file($fileIMG['tmp_name'])) 
            {
                $image->readImage($fileIMG['tmp_name']);
            } 
            elseif (filter_var($fileIMG, FILTER_VALIDATE_URL)) 
            {
                $image->readImage($fileIMG);
            } 
            else 
            {
                $image->readImageBlob($fileIMG);
            }
    
            $marca = new Imagick();
            $marca->readImage(ROOTPATH.$marcaurl);
            $image->compositeImage($marca, \imagick::COMPOSITE_MATHEMATICS,0, 0);
    
            return $image;
	    }
	    else 
	    {
	        return $fileIMG;
	    }
	}
	
    /**
     * Elimina un archivo del sistema
     *
     * @param string $rutaArchivo Ruta del archivo a eliminar
     * @return bool True si se eliminó correctamente
     */
    function files_borrarArchivo($rutaArchivo) 
    {
        if (file_exists($rutaArchivo)) 
        {
            return unlink($rutaArchivo);
        } 
        else 
        {
            return false;
        }
    }

    /**
     * Verifica si un archivo existe en el servidor
     *
     * @param string $url Ruta relativa del archivo
     * @return bool True si existe, false si no
     */
    function files_verificarFile($url)
    {
        return file_exists($_SERVER['DOCUMENT_ROOT'].$url);
    }
	
	/**
	 * Genera HTML para subir imágenes
	 *
	 * @return string HTML del control de subida
	 */
	function files_subirimagenes()
	{
	    return "<div class='m_subeimagen'></div>";
	}
	
    /**
     * Obtiene el valor de una variable desde un archivo PHP
     *
     * @param string $archivo Nombre del archivo (sin extensión)
     * @param string $nombreVariable Nombre de la variable a obtener
     * @return mixed Valor de la variable o mensaje de error
     */
    function files_ObtVariable($archivo, $nombreVariable) 
    {
        if (file_exists(APPPATH .$archivo.".php")) 
        {
            include APPPATH .$archivo.".php";
        
            if (isset($$nombreVariable)) 
            {
                return $$nombreVariable;
            }
            else 
            {
                return 'La variable '.$nombreVariable.' no existe en el archivo.';
            }
        } 
        else 
        {
            return "El archivo '$archivo' no existe.";
        }
    }
        
    /**
    * Lista recursivamente todos los archivos en uno o varios directorios.
    *
    * @param string|array $rutas   Ruta(s) a escanear (absolutas o relativas)
    * @param bool         $detallado  false = devuelve solo array de URLs (compatible)
    *                                  true  = devuelve estructura con archivos, errores, etc.
    * @return array
    */
    function files_FilesFolderLista($rutas, bool $detallado = false)
    {
        // --- Helpers de entorno (protocolo y host) ---
        $proto = 'http';
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
            $proto = 'https';
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
            // Soporte para proxies / load balancers
            $proto = explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0];
        } elseif (!empty($_SERVER['REQUEST_SCHEME'])) {
            $proto = $_SERVER['REQUEST_SCHEME'];
        }

        $host    = $_SERVER['HTTP_HOST']       ?? 'localhost';
        $docroot = $_SERVER['DOCUMENT_ROOT']   ?? getcwd();
        $docroot = rtrim(str_replace('\\', '/', $docroot), '/');

        $toArray = function($val) {
            if ($val === null || $val === '') return [];
            return is_array($val) ? array_values($val) : [$val];
        };

        $normalize = function($path) {
            $p = str_replace('\\', '/', (string)$path);
            // Resolver relativas respecto a DOCUMENT_ROOT (o cwd)
            if ($p === '') return '';
            // ¿Es absoluta? (Unix / Windows)
            $isAbs = ($p[0] === '/') || preg_match('#^[A-Za-z]:/#', $p);
            if (!$isAbs) {
                global $docroot;
                $p = $docroot . '/' . ltrim($p, '/');
            }
            // Quitar trailing slash
            return rtrim($p, '/');
        };

        $toUrl = function($absPath) use ($docroot, $host, $proto) {
            $abs = str_replace('\\', '/', $absPath);
            if ($docroot && strpos($abs, $docroot) === 0) {
                $rel = substr($abs, strlen($docroot));
                if ($rel === '' || $rel[0] !== '/') $rel = '/'.$rel;
                return $proto . '://' . $host . $rel;
            }
            return null; // No se puede construir URL (fuera de docroot)
        };

        $urls      = [];
        $errores   = [];
        $faltantes = [];
        $scanDirs  = 0;

        $rutasLista = $toArray($rutas);
        if (empty($rutasLista)) {
            $msg = 'No se proporcionaron rutas.';
            return $detallado
                ? ['estado' => false, 'mensaje' => $msg, 'archivos' => [], 'errores' => [$msg], 'rutas_inexistentes' => [], 'directorios_escaneados' => 0]
                : [];
        }

        // Evitar bucles por symlinks
        $visited = [];

        $recurse = function($path) use (&$recurse, &$urls, &$errores, &$faltantes, &$scanDirs, &$visited, $normalize, $toUrl) {
            $path = $normalize($path);
            if ($path === '' || !file_exists($path)) {
                $faltantes[] = $path ?: '(ruta vacía)';
                return;
            }

            // Si es archivo directo
            if (is_file($path)) {
                $u = $toUrl($path);
                if ($u) $urls[] = $u; else $errores[] = "No se puede construir URL (fuera de DOCUMENT_ROOT): $path";
                return;
            }

            // Directorio
            if (!is_dir($path)) {
                $errores[] = "Ruta no válida (ni archivo ni directorio): $path";
                return;
            }
            if (!is_readable($path)) {
                $errores[] = "Sin permisos de lectura: $path";
                return;
            }

            // Evitar repetir el mismo dir (por symlinks)
            $real = @realpath($path) ?: $path;
            if (isset($visited[$real])) return;
            $visited[$real] = true;

            $scanDirs++;
            $list = @scandir($path);
            if ($list === false) {
                $errores[] = "No se pudo escanear el directorio: $path";
                return;
            }

            foreach ($list as $entry) {
                if ($entry === '.' || $entry === '..') continue;
                // Si no quieres omitir ocultos, comenta la siguiente línea:
                if ($entry[0] === '.') continue;

                $full = $path . '/' . $entry;
                if (is_link($full)) {
                    // Evita posibles bucles
                    continue;
                }

                if (is_dir($full)) {
                    $recurse($full);
                } elseif (is_file($full)) {
                    $u = $toUrl($full);
                    if ($u) $urls[] = $u; else $errores[] = "No se puede construir URL (fuera de DOCUMENT_ROOT): $full";
                }
            }
        };

        foreach ($rutasLista as $r) { $recurse($r); }

        // Eliminar duplicados y reindexar
        $urls = array_values(array_unique($urls));

        if ($detallado) {
            $ok  = !empty($urls);
            $msg = $ok
                ? 'Archivos listados correctamente.'
                : ( (!empty($faltantes) || !empty($errores)) ? 'Se encontraron problemas al listar.' : 'No se encontraron archivos.' );

            return [
                'estado'                 => $ok,
                'mensaje'                => $msg,
                'archivos'               => $urls,
                'errores'                => $errores,
                'rutas_inexistentes'     => $faltantes,
                'directorios_escaneados' => $scanDirs,
            ];
        }

        return $urls;
    }

?>