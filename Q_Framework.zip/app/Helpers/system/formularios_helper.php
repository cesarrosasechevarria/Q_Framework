<?php
    
    /**
     * Lee un formulario desde un archivo y lo devuelve como array o HTML
     *
     * @param string $formulario Nombre del archivo del formulario (sin extensión)
     * @param array|null $datosForm Datos para poblar el formulario (opcional)
     * @param bool $html Si es true devuelve HTML, si es false devuelve array
     * @return array|string Array con componentes o HTML del formulario
     */
    function Form_LeerDesdeArchivo($formulario,$datosForm=null,$html=false)
    {
        
        $include=include_once APPPATH.'Formularios/' . $formulario . '.php';

        if ($html)
        {
            
            $mhtml =Form_generarIncludes($includes);
            $mhtml.=validador_minificarHTML($html);
            $mhtml.="<script>".validador_minificar($javascript)."</script>";
            
            return $mhtml;
            
        }
        else 
        {
            
            return array
            (
                rand(),
                isset($html) ? validador_minificarHTML($html) : "",
                isset($javascript) ? validador_minificar($javascript) : "",
                isset($includes) ? $includes :  "",
            );

        }

    }
    
    /**
     * Genera etiquetas HTML para incluir archivos CSS y JS
     *
     * @param array $includes Array de rutas de archivos a incluir
     * @return string HTML con las etiquetas link/script generadas
     */
    function Form_generarIncludes($includes) 
    {
        $html = '';
        
        foreach ($includes as $include) 
        {
            // Divide la cadena en base al carácter '?'
            $parts = explode('?', $include);
            
            // Obtiene el nombre del archivo y la extensión
            $fileInfo = pathinfo($parts[0]);
            $extension = $fileInfo['extension'];
            
            // Obtén la versión si está presente
            $version = (isset($parts[1])) ? '?' . $parts[1] : '';
            
            // Genera el elemento HTML
            if ($extension == 'css') 
            {
                $html .= '<link rel="stylesheet" type="text/css" href="' . $include . '">';
            } 
            elseif ($extension == 'js') 
            {
                $html .= '<script src="' . $include . '"></script>';
            } 
            else 
            {
                $html .= '<!-- Otro tipo de include: ' . $include . ' -->';
            }
        }
        
        return $html;
    }
                
    /**
     * Asigna valores a los inputs de un formulario según su tipo
     *
     * @param array $datos Datos a asignar
     * @param string $key Clave del campo
     * @param array &$input Referencia al control del formulario
     */
    function Form_valor_a_imput($datos, $key, &$input)
    {
        $tipo = $input['campos']['type'] ?? '';

        if ($tipo === "textarea") 
        {
            $input['valor'] = $datos[$key] ?? "";
        } 
        elseif ($tipo === "search") 
        {
            $input['campos']['value'] = $datos[$key]['texto'] ?? "";
            $input['valor'] = $datos[$key]['valor'] ?? "";
        } 
        elseif ($tipo === "password") 
        {
            $input['campos']['value'] = "";
        } 
        elseif ($tipo === "q_select") 
        {
            $input['valores'] = $datos[$key] ?? "";
        } 
        elseif ($tipo === "q_map") 
        {
            // Para q_map, cargamos los valores de latitud y longitud
            $latKey = $key . '_latitud';
            $lonKey = $key . '_longitud';
            
            $input['valor_lat'] = $datos[$latKey] ?? "";
            $input['valor_lon'] = $datos[$lonKey] ?? "";
            
            // También asignar a campos para compatibilidad
            $input['campos']['data-lat'] = $input['valor_lat'];
            $input['campos']['data-lon'] = $input['valor_lon'];
        }
        elseif ($tipo === "q_pair") 
        {
            // Para q_pair, cargamos los datos como array o JSON
            if (isset($datos[$key])) {
                if (is_array($datos[$key])) {
                    $input['valor'] = $datos[$key];
                } else {
                    // Intentar decodificar si es JSON string
                    $decoded = json_decode($datos[$key], true);
                    $input['valor'] = ($decoded !== null) ? $decoded : [];
                }
            } else {
                $input['valor'] = [];
            }
            
            // También asignar a campos para inicialización
            $input['campos']['data-initial-data'] = json_encode($input['valor']);
        }
        else 
        {
            $input['campos']['value'] = $datos[$key] ?? "";
        }
    }
        
    /**
     * Asigna valores a los controles de un formulario en base a los datos proporcionados.
     *
     * Esta función recorre todos los elementos del arreglo `$Forulario` (representando los controles del formulario)
     * y les asigna valores correspondientes extraídos del arreglo `$datos`, utilizando la función `Form_valor_a_control`.
     *
     * @param array $datos Arreglo asociativo que contiene los valores a asignar a los controles del formulario.
     * @param array &$Forulario Arreglo que representa el formulario, donde cada clave es el nombre del control
     *                          y el valor es la definición del control (por referencia).
     *
     * @return void
     */
    function Form_valor_a_form($datos, &$Formulario)
    {
        foreach ($Formulario as $key => &$input) 
        {
            // Si es un grupo de campos
            if (is_string($key) && substr($key, 0, 6) === 'grupo_' && is_array($input)) 
            {
                foreach ($input as $subkey => &$subinput) 
                {
                    Form_valor_a_imput($datos, $subkey, $subinput);
                }
            } 
            else 
            {
                Form_valor_a_imput($datos, $key, $input);
            }
        }
    }


        
    /**
     * Convierte campos de base de datos a controles de formulario
     *
     * @param array $campos Array de campos de BD
     * @return array Controles de formulario generados
     */
    function Form_bd2Inputs($campos) 
    {
        
        $controles = array(); // Array para almacenar las características de los campos
        
        foreach ($campos as $campo) 
        {
            $nombreCampo        = $campo['columnName'];         // Nombre del campo
            $tipoCampo          = $campo['tipoCampo'];          // Tipo de dato del campo
            $limiteCaracteres   = $campo['limiteCaracteres'];   // Límite de caracteres del campo (si aplica)
            $defaultValue       = $campo['defaultValue'];       // Límite de caracteres del campo (si aplica)
            $comentario         = $campo['comment'];            // Límite de caracteres del campo (si aplica)
            $class              = "";
            $style              = "";
            
            if (strpos($tipoCampo, 'int') !== false || strpos($tipoCampo, 'tinyint') !== false || strpos($tipoCampo, 'smallint') !== false || strpos($tipoCampo, 'mediumint') !== false || strpos($tipoCampo, 'bigint') !== false || strpos($tipoCampo, 'float') !== false || strpos($tipoCampo, 'double') !== false || strpos($tipoCampo, 'decimal') !== false) 
            {
                $tipoInput = 'number';
                $class     = "uk-input curba5px";
            } 
            elseif ($tipoCampo === 'date')
            {
                $tipoInput = 'date';
                $class     = "uk-input curba5px";
            } 
            elseif ($tipoCampo === 'time')
            {
                $tipoInput = 'time';
                $class     = "uk-input curba5px";
            } 
            elseif ($tipoCampo === 'datetime' || $tipoCampo === 'timestamp')
            {
                $tipoInput = 'datetime-local';
                $class     = "uk-input curba5px";
            } 
            elseif (strpos($tipoCampo, 'text') !== false || strpos($tipoCampo, 'tinytext') !== false)
            {
                $tipoInput = 'textarea';
                $class     = "uk-textarea curba5px";
            } 
            elseif (strpos($tipoCampo, 'bool') !== false)
            {
                $tipoInput = 'checkbox';
                $class     = "uk-input curba5px";
            } 
            else 
            {
                $tipoInput = 'text'; // Tipo de input genérico para cualquier otro tipo de campo
                $class     = "uk-input curba5px";
            }
            
            if (intval($limiteCaracteres)>0){$class.=" q_charcount";}
            //if ($tipoCampo=='tinytext'){$limiteCaracteres=255;$class.=" q_contador";}
            
            // Agregar las características del campo al array
            $controles[$nombreCampo]['id']      = $campo['columnName'];
            $controles[$nombreCampo]['nombre']  = $campo['columnName'];
            $controles[$nombreCampo]['tooltip'] = $campo['comment'];
            $controles[$nombreCampo]['campos']  = array('type' => $tipoInput,'maxlength' => 50,'value' => $defaultValue,'placeholder' => $comentario,'class'=>$class,'style'=>$style);
            
        }
        
        return $controles; // Devolver el array con las características de los campos
    }
                                
    function Form_renderAddonItem(array $it): string 
    {
        $cls = htmlspecialchars(trim($it['class'] ?? 'addon'), ENT_QUOTES, 'UTF-8');
        $attrs = '';
        
        // Agregar atributos específicos para cada tipo
        if (!empty($it['action'])) {
            $attrs .= ' data-action="' . htmlspecialchars($it['action'], ENT_QUOTES, 'UTF-8') . '"';
        }
        if (!empty($it['tooltip'])) {
            $attrs .= ' title="' . htmlspecialchars($it['tooltip'], ENT_QUOTES, 'UTF-8') . '"';
        }
        if (!empty($it['theme'])) {
            $cls .= ' addon-' . htmlspecialchars($it['theme'], ENT_QUOTES, 'UTF-8');
        }
        if (!empty($it['size'])) {
            $cls .= ' addon-' . htmlspecialchars($it['size'], ENT_QUOTES, 'UTF-8');
        }

        // Atributos adicionales
        if (!empty($it['attrs']) && is_array($it['attrs'])) 
        {
            foreach ($it['attrs'] as $k=>$v) 
            {
                $attrs .= ' '.htmlspecialchars($k,ENT_QUOTES,'UTF-8').'="'.htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8').'"';
            }
        }
        
        $type = strtolower($it['type'] ?? 'text');

        if ($type === 'button') 
        {
            $buttonType = $it['buttonType'] ?? 'button';
            $label = '';
            
            // Icono del botón
            if (!empty($it['icon'])) {
                $iconName = preg_replace('/[^a-z0-9_-]/i','', $it['icon'] ?? 'circle');
                $label .= "<span class='q_icon' data-icon='{$iconName}'></span>";
            }
            
            // Texto del botón
            if (!empty($it['text'])) {
                $label .= "<span class='addon-text'>" . htmlspecialchars($it['text'], ENT_QUOTES, 'UTF-8') . "</span>";
            }
            
            // Solo icono (sin texto)
            $onlyIcon = (!empty($it['icon']) && empty($it['text'])) ? ' only-icon' : '';
            
            return "<button type='{$buttonType}' class='{$cls} addon-button{$onlyIcon}'{$attrs}>{$label}</button>";
        }

        if ($type === 'icon') 
        {
            $name  = preg_replace('/[^a-z0-9_-]/i','', $it['name'] ?? $it['icon'] ?? 'info');
            $size  = isset($it['size']) ? ' data-size="'.htmlspecialchars($it['size'],ENT_QUOTES,'UTF-8').'"' : '';
            
            // Si tiene acción, hacerlo clickeable
            if (!empty($it['action'])) {
                $cls .= ' clickable';
            }
            
            return "<span class='q_icon {$cls}' data-icon='{$name}'{$size}{$attrs}></span>";
        }

        if ($type === 'html') 
        {
            // OJO: solo usa 'html' con contenido confiable
            return "<span class='{$cls}'{$attrs}>".($it['html'] ?? '')."</span>";
        }

        if ($type === 'badge') 
        {
            $text = htmlspecialchars($it['text'] ?? '', ENT_QUOTES, 'UTF-8');
            $theme = isset($it['theme']) ? ' badge-' . htmlspecialchars($it['theme'], ENT_QUOTES, 'UTF-8') : '';
            return "<span class='badge {$cls}{$theme}'{$attrs}>{$text}</span>";
        }

        if ($type === 'text') 
        {
            $text = htmlspecialchars($it['text'] ?? '', ENT_QUOTES, 'UTF-8');
            return "<span class='{$cls} addon-text'{$attrs}>{$text}</span>";
        }

        if ($type === 'file') 
        {
            $name  = preg_replace('/[^a-z0-9_-]/i','', $it['icon'] ?? 'file');
            $label = '';
            
            if (!empty($it['icon'])) {
                $label .= "<span class='q_icon' data-icon='{$name}'></span>";
            }
            
            return "<button type='button' class='{$cls} addon-button only-icon'{$attrs}>{$label}</button>";
        }

        if ($type === 'link') 
        {
            $href = $it['href'] ?? '#';
            $target = !empty($it['target']) ? ' target="' . htmlspecialchars($it['target'], ENT_QUOTES, 'UTF-8') . '"' : '';
            $label = '';
            
            // Icono del link
            if (!empty($it['icon'])) {
                $iconName = preg_replace('/[^a-z0-9_-]/i','', $it['icon'] ?? 'link');
                $label .= "<span class='q_icon' data-icon='{$iconName}'></span>";
            }
            
            // Texto del link
            if (!empty($it['text'])) {
                $label .= "<span class='addon-text'>" . htmlspecialchars($it['text'], ENT_QUOTES, 'UTF-8') . "</span>";
            }
            
            return "<a href='{$href}'{$target} class='{$cls} addon-link'{$attrs}>{$label}</a>";
        }

        // default: text (fallback)
        $text = htmlspecialchars($it['text'] ?? '', ENT_QUOTES, 'UTF-8');
        return "<span class='{$cls}'{$attrs}>{$text}</span>";
    }

    function Form_renderAddons(array $items): string {
        $out = '';
        foreach ($items as $it) { $out .= Form_renderAddonItem((array)$it); }
        return $out;
    }



    /**
     * Genera el HTML de un control de formulario
     *
     * @param string $key_id ID del control
     * @param array $control Configuración del control
     * @return string HTML del control generado
     */
    function Form_inputHtml($key_id, $control)
    {
        $propiedades = [];
        
        // Definir clases específicas por tipo de input
        $inputClasses = [
            'text' => 'input', 'email' => 'input', 'password' => 'input',
            'number' => 'input', 'tel' => 'input', 'q_search' => 'q_search q_width-full',
            'url' => 'input', 'date' => 'input', 'datetime-local' => 'input',
            'month' => 'input', 'time' => 'input', 'week' => 'input',
            'q_file' => 'input', 'file' => 'q_upload', 'color' => 'input',
            'range' => 'input', 'textarea' => 'textarea',
            'checkbox' => 'checkbox', 'radio' => 'radio',
            'select' => 'select', 'opcion' => 'select',
            'q_select' => 'q_select', 'q_rich' => 'input q_rich'
        ];
        
        $inputType = $control['campos']['type'] ?? '';
        
        // Inicializar class si no está y corresponde según el tipo
        if (!isset($control['campos']['class']) && isset($inputClasses[$inputType])) {
            $control['campos']['class'] = $inputClasses[$inputType];
        }
        
        // Procesar propiedades
        $propiedades = [];
        
        foreach ($control['campos'] as $key => $value) {
            // Manejar diferentes tipos de valores
            if (is_array($value)) {
                // Para arrays específicos como initialData, mantenerlos como JSON
                $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            } elseif (is_bool($value)) {
                // Para booleanos, convertirlos a string "true"/"false" o 1/0 según necesites
                $value = $value ? 'true' : 'false';
            } elseif (is_numeric($value)) {
                // Para números, mantener como string numérico
                $value = (string)$value;
            } else {
                // Para strings, hacer trim
                $value = trim((string)$value);
            }
            
            // Solo procesar si no está vacío
            if (!empty($value) && $value !== '""' && $value !== '[]') 
            {
                if ($key === 'class') 
                {
                    // Asegurarse de que sea string para procesar clases
                    $value = (string)$value;
                    
                    // Si el valor empieza con [ (es JSON de array), procesarlo
                    if (strpos($value, '[') === 0) {
                        $arrayValue = json_decode($value, true);
                        if (json_last_error() === JSON_ERROR_NONE && is_array($arrayValue)) {
                            $value = implode(' ', $arrayValue);
                        }
                    }
                    
                    // Separar clases existentes
                    $classList = preg_split('/\s+/', $value, -1, PREG_SPLIT_NO_EMPTY);
                
                    // Añadir required si requerido
                    if (!empty($control['campos']['required']) && $control['campos']['required'] == true && !in_array('required', $classList)) 
                    {
                        $classList[] = 'required';
                    }

                    // Añadir clase correspondiente al tipo si no existe ya
                    if (isset($inputClasses[$inputType])) 
                    {
                        $requiredClasses = preg_split('/\s+/', $inputClasses[$inputType], -1, PREG_SPLIT_NO_EMPTY);
                        foreach ($requiredClasses as $cls) 
                        {
                            if (!in_array($cls, $classList)) 
                            {
                                $classList[] = $cls;
                            }
                        }
                    }

                    // Reconstruir el valor de class limpio
                    $value = implode(' ', array_unique($classList));
                }

                // Para atributos que son arrays (como data-initial), usar data-* attributes
                if (is_array($control['campos'][$key]) && $key !== 'class') {
                    $propiedades[] = 'data-' . $key . '="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"';
                } else {
                    $propiedades[] = $key . '="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"';
                }
            }
        }
        
        if (isset($control['prms']))
        {
            $propiedades[]='data-prms='.validador_encriptar($control['prms']);
        }

        $propiedades = implode(" ", $propiedades);
        
        $iconContenedor = "";
        $iconLeft       = "";
        
        if (isset($control['icono'])) 
        {
            $name  = preg_replace('/[^a-z0-9_-]/i', '', $control['icono']); // sanitiza
            $size  = isset($control['icono_tam'])   ? ' data-size="'.htmlspecialchars($control['icono_tam'], ENT_QUOTES, 'UTF-8').'"' : '';
            $label = isset($control['icono_label']) ? ' data-label="'.htmlspecialchars($control['icono_label'], ENT_QUOTES, 'UTF-8').'"' : '';
            $color = isset($control['icono_color']) ? ' style="color:'.htmlspecialchars($control['icono_color'], ENT_QUOTES, 'UTF-8').'"' : '';
            $stroke= isset($control['icono_stroke'])? ' data-stroke="'.htmlspecialchars($control['icono_stroke'], ENT_QUOTES, 'UTF-8').'"' : '';
        
            $iconLeft = "<span class='q_icon' data-icon='{$name}'{$size}{$label}{$stroke}{$color}></span>";
            $iconContenedor = 'icon-left';
        }

        $addonsConf  = isset($control['addons']) && is_array($control['addons']) ? $control['addons'] : null;
        $hasAddons   = $addonsConf && ( !empty($addonsConf['start']) || !empty($addonsConf['end']) );
        $compactCls  = ($hasAddons && !empty($addonsConf['compact'])) ? ' compact' : '';
        $addonsStart = ($hasAddons && !empty($addonsConf['start'])) ? "<div class='addons start'>".Form_renderAddons($addonsConf['start'])."</div>" : '';
        $addonsEnd   = ($hasAddons && !empty($addonsConf['end']))   ? "<div class='addons end'>".Form_renderAddons($addonsConf['end'])."</div>"   : '';
        $wrapBaseCls = "input-container ".$iconContenedor.($hasAddons ? " has-addons{$compactCls}" : "");

        
        $input = "";
    
        if ($control['campos']['type'] == "textarea") 
        {
            $input = "<div class='{$wrapBaseCls}'>{$addonsStart}{$iconLeft}<textarea id='{$key_id}' name='{$key_id}' {$propiedades}>".($control['valor'] ?? "")."</textarea>{$addonsEnd}</div>";
        } 
        elseif ($control['campos']['type'] == 'checkbox') 
        {
            $control['campos']['value'] = isset($control['campos']['value']) && ($control['campos']['value'] == 1) ? 'checked' : '';
            $input = "<div class='q_form-group'><label class='q_form-checkbox-label'><input id='" . $key_id . "' name='" . $key_id . "' " . $propiedades . " " . $control['campos']['value'] . "> " . $control['nombre'] . "</label></div>";
        } 
        elseif(($control['campos']['type']=='q_select')||($control['campos']['type']=='opcion')||($control['campos']['type']=='select'))
        {
            $opstring = '';
            if (!empty($control['opciones'])) 
            {
                $curr = (string)($control['campos']['value'] ?? '');
                foreach ($control['opciones'] as $k => $v) 
                {
                    $key   = htmlspecialchars((string)$k, ENT_QUOTES, 'UTF-8');
                    $label = htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
                    $sel   = ((string)$k === $curr) ? ' selected="selected"' : '';
                    $opstring .= "<option value=\"{$key}\"{$sel}>{$label}</option>";
                }
            }
			
			$prms = isset($control['parametros']) && (is_array($control['parametros'])) ? " data-prms='".validador_encriptar($control['parametros'])."'" : '';
            
            $attrs = [];
            
            // Condicional a data-multiple
            if (!empty($control['campos']['data-multiple']) && $control['campos']['data-multiple'] === true) 
            {
                $attrs[] = 'multiple';
            }
            
            // Condicional a valores
            if (!empty($control['valores'])) 
            {
                $attrs[] = "data-valores='" . base64_encode(json_encode($control['valores'])) . "'";
            }
            
            // Concatenamos todo
            $vlrs = $attrs ? ' ' . implode(' ', $attrs) : '';
			
            $input= "<div class='input-container'>".$iconLeft."<select id='".$key_id."' name='".$key_id."' ".$propiedades." ".$prms." ".$vlrs.">".$opstring."</select></div>";
        }
        elseif($control['campos']['type']=="file")
        {
            $defaultFilesAttr = '';
            if (isset($control['campos']['data-default-files'])) 
            {
                $defaultFilesAttr = ' data-default-files="' . htmlspecialchars($control['campos']['data-default-files'], ENT_QUOTES, 'UTF-8') . '"';
            }
            
            $input = "<div class='q_upload' id='".$key_id."' ".$propiedades.$defaultFilesAttr."></div>";
        }
		elseif($control['campos']['type']=="q_rich")
		{
			$valor = (isset($control['valor']) && strlen(trim($control['valor'])) > 0) ? "data-content='" . base64_encode($control['valor']) . "'" : '';
            $input = "<div class='input-container ".$iconContenedor."'>" . $iconLeft . "<div id='" . $key_id . "' name='" . $key_id . "' " . $propiedades . " q_rich-height='100' ".$valor."></div></div>";
		}
		elseif($control['campos']['type']=="q_search")
		{
			
			$search_prms = 
			[
				'tipo' => 'filtrar',
				'prms' => 
				[
					'query' => 'select id,nombre,descripcion from prueba_datos',
					'colum' => 'nombre', 
					'detalle' => 'descripcion',
					'respu' => 'id'
				]
			];
			
			$valor="";
            $input = "<div class='input-container ".$iconContenedor."'>" . $iconLeft . "<div id='" . $key_id . "' name='" . $key_id . "' " . $propiedades . " q_prms='".validador_encriptar($control['parametros'])."'  ".$valor."></div></div>";
		}
        elseif($control['campos']['type']=="q_pair")
        {
            // =============================
            // Q_PAIR (Q_Pair.js) - dataset config
            // Soporta modo value-only mediante:
            //   - campos.mode = "value"  o
            //   - campos.valueOnly = true
            // =============================

            // Helper para leer config en orden: campos[key] -> control[key] -> default
            $getConfig = function($key, $default = null) use ($control) {
                if (isset($control['campos'][$key])) return $control['campos'][$key];
                if (isset($control[$key])) return $control[$key];
                return $default;
            };

            // Config base
            $separator       = $getConfig('separator', '=>');
            $typeSeparator   = $getConfig('typeSeparator', '::');
            $allowEmptyValues= (bool)$getConfig('allowEmptyValues', false);
            $allowDuplicates = (bool)$getConfig('allowDuplicates', false);
            $maxEntries      = $getConfig('maxEntries', null);
            $types           = $getConfig('types', ['text','value','template','option']);
            $defaultType     = $getConfig('defaultType', 'text');
            $showTypeColumn  = (bool)$getConfig('showTypeColumn', true);
            $readonly        = (bool)$getConfig('readonly', false);

            // NUEVO: modo / valueOnly
            // Nota: Si tu form usa mode interno (ej: "table-edit"), usa mejor: campos.qMode = "value"
            $mode            = $getConfig('qMode', $getConfig('mode', null));
            $valueOnly       = $getConfig('qValueOnly', $getConfig('valueOnly', null));

            // Normalizar types
            if (is_string($types)) {
                $types = json_decode($types, true) ?: explode(',', $types);
            }
            if (!is_array($types)) {
                $types = ['text','value','template','option'];
            }

            // Procesar datos iniciales
            $initialData = [];
            $valor = $getConfig('valor', null);

            if ($valor) {
                if (is_string($valor)) {
                    $decoded = json_decode($valor, true);
                    if ($decoded !== null) $initialData = $decoded;
                } elseif (is_array($valor)) {
                    $initialData = $valor;
                }
            } elseif ($getConfig('initialData', null) !== null) {
                $initData = $getConfig('initialData', []);
                if (is_string($initData)) {
                    $decoded = json_decode($initData, true);
                    if ($decoded !== null) $initialData = $decoded;
                } elseif (is_array($initData)) {
                    $initialData = $initData;
                }
            }

            // Hidden input (JSON)
            $hiddenValue = json_encode($initialData);
            $hiddenInput = "<input type='hidden' id='{$key_id}' name='{$key_id}' value='" . htmlspecialchars($hiddenValue, ENT_QUOTES) . "' />";

            // Atributos data-* para Q_Pair.autoInit()
            $attrs = [];
            $attrs[] = "data-q-pair=\"true\"";
            $attrs[] = "data-hidden-input-id=\"" . htmlspecialchars($key_id, ENT_QUOTES) . "\"";

            $attrs[] = "data-kv-separator=\"" . htmlspecialchars($separator, ENT_QUOTES) . "\"";
            $attrs[] = "data-kv-type-separator=\"" . htmlspecialchars($typeSeparator, ENT_QUOTES) . "\"";
            $attrs[] = "data-kv-allow-empty=\"" . ($allowEmptyValues ? 'true' : 'false') . "\"";
            $attrs[] = "data-kv-allow-duplicates=\"" . ($allowDuplicates ? 'true' : 'false') . "\"";
            if ($maxEntries) {
                $attrs[] = "data-kv-max-entries=\"" . htmlspecialchars((string)$maxEntries, ENT_QUOTES) . "\"";
            }
            $attrs[] = "data-kv-types=\"" . htmlspecialchars(json_encode($types), ENT_QUOTES) . "\"";
            $attrs[] = "data-kv-default-type=\"" . htmlspecialchars((string)$defaultType, ENT_QUOTES) . "\"";
            $attrs[] = "data-kv-show-types=\"" . ($showTypeColumn ? 'true' : 'false') . "\"";
            $attrs[] = "data-kv-initial-data=\"" . htmlspecialchars(json_encode($initialData), ENT_QUOTES) . "\"";
            $attrs[] = "data-kv-readonly=\"" . ($readonly ? 'true' : 'false') . "\"";

            // NUEVO: enviar modo/valueOnly al dataset (Q_Pair.js lo lee como dataset.kvMode / dataset.kvValueOnly)
            if ($mode !== null && $mode !== '') {
                $attrs[] = "data-kv-mode=\"" . htmlspecialchars((string)$mode, ENT_QUOTES) . "\"";
            }
            if ($valueOnly !== null) {
                $attrs[] = "data-kv-value-only=\"" . ((is_bool($valueOnly) ? ($valueOnly ? 'true' : 'false') : htmlspecialchars((string)$valueOnly, ENT_QUOTES))) . "\"";
            }

            // Opcionales (si los usas)
            $optionalAttrs = [
                'placeholder' => 'data-kv-placeholder',
                'enableSearch' => 'data-kv-enable-search',
                'highlightSearch' => 'data-kv-highlight-search',
                'valueRows' => 'data-kv-value-rows',
                'keyMaxLen' => 'data-kv-key-max-len',
                'valueMaxLen' => 'data-kv-value-max-len',
                'debounceSearchMs' => 'data-kv-debounce-search-ms'
            ];

            foreach ($optionalAttrs as $k => $attr) {
                $v = $getConfig($k, null);
                if ($v === null) continue;
                if (is_bool($v)) {
                    $attrs[] = $attr . "=\"" . ($v ? 'true' : 'false') . "\"";
                } else {
                    $attrs[] = $attr . "=\"" . htmlspecialchars((string)$v, ENT_QUOTES) . "\"";
                }
            }

            // Button meta (opcional)
            if (isset($control['campos']['buttonMeta']) && is_array($control['campos']['buttonMeta'])) {
                $attrs[] = "data-kv-button-meta=\"" . htmlspecialchars(json_encode($control['campos']['buttonMeta']), ENT_QUOTES) . "\"";
            }

            $attrsString = implode(' ', $attrs);
            $containerId = $key_id . '_container';

            $input = "
            <div class='input-container q_pair-wrapper' style='width: 100%;'>
                {$hiddenInput}
                <div id='{$containerId}' class='q_width-1-1 q_pair-container' {$attrsString}></div>
            </div>";
        }
        else 
        {
            $input = "<div class='{$wrapBaseCls}'>{$addonsStart}{$iconLeft}<input id='{$key_id}' name='{$key_id}' {$propiedades}>{$addonsEnd}</div>";


        }
    
        return $input;
    }


    /**
     * Convierte un array de controles a HTML de formulario
     *
     * @param array $controles Array de controles de formulario
     * @return string HTML del formulario generado
     */
    function Form_form3html($controles)
    {
        $inputHTML="";
        foreach ($controles as $key_id=>$control) 
        {
            $inputHTML=$inputHTML.Form_inputHtml($key_id,$control);
        }
        
        return $inputHTML;
    }
                    
function Form_qfila($key, $control, $fila = true)
{
    // Tooltip
    $tooltip = '';
    if (!empty($control['tooltip'])) {
        $text  = htmlspecialchars($control['tooltip'], ENT_QUOTES, 'UTF-8');
        $color = $control['tooltip_color'] ?? 'dark';
        $pos   = $control['tooltip_position'] ?? 'top';
        $tooltip = " <span class='q_tooltip q_icon sm' data-icon='toltip' data-tooltip=\"text: {$text}; color: {$color}; pos: {$pos};\">";
    }
    $control['nombre'] = isset($control['nombre']) ? $control['nombre'] . $tooltip : $tooltip;

    // selectorform
    if (isset($control['selectorform'])) {
        $control['campos']['selectorform'] = htmlspecialchars(json_encode($control['selectorform']), ENT_QUOTES, 'UTF-8');
        $control['campos']['class'] = trim(($control['campos']['class'] ?? '') . " q_selectorform");
    }

    // === MÁSCARA / FORMATO / VALIDACIÓN (mapeo correcto) ===

    // 1) Máscara -> data-mask (string) + opcionales
    if (!empty($control['mascara'])) {
        $m = $control['mascara'];

        // Acepta string o array
        if (is_array($m)) {
            if (!empty($m['pattern']) && empty($control['campos']['data-mask'])) {
                $control['campos']['data-mask'] = $m['pattern']; // <-- SOLO la máscara
            }
            if (!empty($m['leading']) && empty($control['campos']['data-leading'])) {
                $control['campos']['data-leading'] = $m['leading']; // 'lazy' | 'full'
            }
            if (!empty($m['normalize']) && empty($control['campos']['data-normalize'])) {
                $control['campos']['data-normalize'] = $m['normalize']; // p.ej. 'digits'
            }
            if (!empty($m['placeholder']) && empty($control['campos']['placeholder'])) {
                $control['campos']['placeholder'] = $m['placeholder'];
            }
            // Si defines una regex aparte para validar la máscara:
            if (!empty($m['regex']) && empty($control['campos']['data-pattern'])) {
                $control['campos']['data-pattern'] = $m['regex'];
            }
        } else {
            // Si te pasan la máscara directa como string
            if (empty($control['campos']['data-mask'])) {
                $control['campos']['data-mask'] = (string)$m;
            }
        }
    }

    // 2) Formato/normalización
    if (!empty($control['formato'])) {
        $f = $control['formato'];

        // Moneda
        if (!empty($f['type']) && in_array($f['type'], ['moneda','currency'], true)) {
            $control['campos']['data-format'] = 'currency';
            if (isset($f['decimales'])) $control['campos']['data-decimals'] = (int)$f['decimales'];
            if (!empty($f['locale']))    $control['campos']['data-locale']   = $f['locale'];
            if (!empty($f['currency']))  $control['campos']['data-currency'] = $f['currency'];
        }

        // Número “limpio” (solo dígitos). No uses JSON en data-format.
        if (!empty($f['type']) && in_array($f['type'], ['numero','number'], true)) {
            if (empty($control['campos']['data-normalize'])) {
                $control['campos']['data-normalize'] = 'digits';
            }
        }

        // Upper/lower/trim si los usas como filtros simples
        if (!empty($f['normalize']) && empty($control['campos']['data-normalize'])) {
            $control['campos']['data-normalize'] = $f['normalize']; // 'digits' | 'letters' | 'alnum'
        }
    }

    // 3) Validación nativa y mensaje (¡sin tocar placeholder!)
    if (!empty($control['validacion'])) {
        $v = $control['validacion'];

        if (!empty($v['pattern']) && empty($control['campos']['pattern'])) {
            $control['campos']['pattern'] = $v['pattern']; // HTML5
            // Q_Form también puede usar data-pattern; si prefieres:
            if (empty($control['campos']['data-pattern'])) {
                $control['campos']['data-pattern'] = $v['pattern'];
            }
        }
        if (isset($v['min'])  && $v['min']  !== '' && empty($control['campos']['min']))  $control['campos']['min']  = $v['min'];
        if (isset($v['max'])  && $v['max']  !== '' && empty($control['campos']['max']))  $control['campos']['max']  = $v['max'];
        if (isset($v['step']) && $v['step'] !== '' && empty($control['campos']['step'])) $control['campos']['step'] = $v['step'];
        if (!empty($v['required']) && empty($control['campos']['required'])) $control['campos']['required'] = true;
        if (!empty($v['mensaje']) && empty($control['campos']['data-validate-msg'])) {
            $control['campos']['data-validate-msg'] = htmlspecialchars($v['mensaje'], ENT_QUOTES, 'UTF-8');
        }
    }

    // 4) NUNCA autollenes placeholder con regex
    if (empty($control['campos']['placeholder'])) {

        // 1) si la máscara trae placeholder, úsalo
        if (!empty($control['mascara']['placeholder'])) {
            $control['campos']['placeholder'] = $control['mascara']['placeholder'];

        // 2) si hay máscara (pattern tipo #### o 0000), genera ejemplo
        } elseif (!empty($control['campos']['data-mask']) || !empty($control['mascara']['pattern'])) {
            $mask = $control['campos']['data-mask'] ?? $control['mascara']['pattern'];
            // normaliza tokens a los que entiende Form_textodePatron (0 y -)
            $maskNorm = strtr((string)$mask, ['#' => '0', '9' => '0']);
            $control['campos']['placeholder'] = Form_textodePatron($maskNorm);

        // 3) si hay "pattern" pero es estilo máscara (no regex), genera ejemplo
        } elseif (!empty($control['campos']['pattern'])) {
            $p = (string)$control['campos']['pattern'];
            $pareceRegex = preg_match('/[\^\$\[\]\(\)\{\}\|\+\?\\\\]/', $p); // caracteres de regex
            $pareceMask  = preg_match('/[0#9A\*]/', $p);                     // tokens de máscara
            if (!$pareceRegex && $pareceMask) {
                $pNorm = strtr($p, ['#' => '0', '9' => '0']);
                $control['campos']['placeholder'] = Form_textodePatron($pNorm);
            }
            // si es regex, NO seteamos placeholder
        }
    }

    // ---------------- LÓGICA DE CONTADOR POR DEFECTO ----------------
    $type = strtolower($control['campos']['type'] ?? 'text');
    $soportaContador = in_array($type, ['text','textarea','email','password','search','tel','url']);
        
    if ($soportaContador)
    {
        // Alias "max" -> data-max (si no hay maxlength)
        if (!empty($control['max']) && empty($control['campos']['maxlength']) && empty($control['campos']['data-max'])) {
            $control['campos']['data-max'] = (int)$control['max'];
        }
    
        $cls = ' '.($control['campos']['class'] ?? '').' ';
        $hayMax = isset($control['campos']['maxlength'])
               || isset($control['campos']['data-max'])
               || preg_match('/\bq_limit-\d+\b/', $cls);
    
        if ($hayMax)
        {
            // Modo "restantes/total" si lo piden
            if (($control['count_mode'] ?? null) === 'remain') {
                $control['campos']['data-count'] = 'remain';
            }
    
            // DEFAULT: warn al 85% (salvo que lo sobrescriban)
            if (!isset($control['campos']['data-warn'])) {
                $warn = isset($control['warn']) ? (float)$control['warn'] : 0.85;
                // clamp simple para evitar valores fuera de 0..1
                if ($warn <= 0 || $warn >= 1) $warn = 0.85;
                $control['campos']['data-warn'] = $warn;
            }
    
            // Límite duro sólo si lo piden
            if (!isset($control['campos']['data-hard']) && !empty($control['hard'])) {
                $control['campos']['data-hard'] = '1';
            }
        }
        elseif (!empty($control['count']))
        {
            // Sin máximo pero quieren contador de usados
            if (strpos($cls, ' q_count ') === false) {
                $control['campos']['class'] = trim(($control['campos']['class'] ?? '').' q_count');
            }
        }
    }

    // ----------------------------------------------------------------
    // Atributos extras para fila/columna (NUEVO)
    $attrsRow = '';
    if (!empty($control['fila_attr']) && is_array($control['fila_attr'])) {
        $attrsRow = ' ' . Form_crearPropiedades($control['fila_attr']); // data-* al wrapper .row
    }
    $attrsCol = '';
    if (!empty($control['col_attr']) && is_array($control['col_attr'])) {
        $attrsCol = ' ' . Form_crearPropiedades($control['col_attr']);  // data-* al div .col
    }

    // Render
    $style = $control['style'] ?? "";
    $resp = $fila ? "<div class='row mb-md'{$attrsRow} style='{$style}'>" : "";

    if (($control['campos']['type'] ?? '') !== 'checkbox') {
        $resp .= "<div class='col'{$attrsCol}>"
              .  (strlen($control['nombre']) ? "<div class='label-container'><label>{$control['nombre']}</label></div>" : "")
              .  Form_inputHtml($key, $control)
              .  "</div>";
    } else {
        $resp .= "<div class='col'{$attrsCol}>" . Form_inputHtml($key, $control) . "</div>";
    }

    $resp .= $fila ? "</div>" : "";
    return $resp;
}


    /**
     * Renderiza un formulario tipo JSON usando Form_qfila, permitiendo excluir campos.
     *
     * @param array $formulario Array del formulario JSON decodificado.
     * @param array $excluir Claves de campos a excluir.
     * @return string HTML del formulario renderizado.
     */
    function Form_renderForm(array $formulario, array $excluir = []): string
    {
        $html = "";
    
        foreach ($formulario as $key => $control) 
        {
            // Si es un grupo
            if (is_string($key) && substr($key, 0, 6) === 'grupo_' && is_array($control)) 
            {
                // Filtrar subcampos visibles
                $visibles = array_filter($control, function($subcontrol_key) use ($excluir) {
                    return !in_array($subcontrol_key, $excluir);
                }, ARRAY_FILTER_USE_KEY);
    
                // Si el grupo no tiene campos visibles, saltar todo
                if (empty($visibles)) continue;
    
                $html .= "<div class='grid cols-" . min(count($visibles), 5) . " gap-md mb-md'>";
                foreach ($visibles as $subkey => $subcontrol) 
                {
                    $html .= Form_qfila($subkey, $subcontrol, false);
                }
                $html .= "</div>";
            } 
            else 
            {
                // Campo individual (si no está excluido)
                if (in_array($key, $excluir)) continue;
    
                $style = $control['style'] ?? '';
                $html .= "<div class='row mb-md' style='{$style}'>";
                $html .= Form_qfila($key, $control, false);
                $html .= "</div>";
            }
        }
    
        return $html;
    }


    /**
     * Convierte valores de controles de formulario a array asociativo
     *
     * @param array $campos Array de controles de formulario
     * @return array Array con los valores de los campos
     */
    function Form_input2json($campos)
    {
        $controles = array(); // Array para almacenar las características de los campos
        
        foreach ($campos as $key=>$campo) 
        {
             
            if (($campo['campos']['type']<>"textarea") and ($campo['campos']['type']<>"file2"))
            {
                $controles[$key] = $campo['campos']['value'] ?? "";
            }
            else 
            {
                $controles[$key] = $campo['valor'] ?? "";
            }

        }
        
        return $controles; // Devolver el array con las características de los campos
    }
    
    /**
     * Agrega un valor a elementos de un array que coincidan con un filtro
     *
     * @param array &$array Array de referencia a modificar
     * @param mixed $filter Valor o condición para filtrar
     * @param mixed $value Valor a agregar
     * @param string|null $column Columna donde agregar (opcional)
     */
    function addValueToArray(&$array, $filter, $value, $column = null) 
    {
        foreach ($array as $key => &$item) 
        {
            if (Listar_ContieneClave(array($key => $item),$filter))
            {
                Listar_modifarray($item, $value, $column);

            }
        }
    }

    /**
     * Genera un texto de ejemplo basado en un patrón
     *
     * @param string $patron Patrón con formato (0 para dígitos, - para guiones)
     * @return string Texto de ejemplo generado
     */
    function Form_textodePatron($patron)
    {
        $ejemplo = '';
        $longitud = strlen($patron);
        
        for ($i = 0; $i < $longitud; $i++) {
            switch ($patron[$i]) {
                case '0':
                    $ejemplo .= rand(0, 9); // Agrega un dígito aleatorio
                    break;
                case '-':
                    $ejemplo .= '-'; // Agrega un guión
                    break;
                default:
                    $ejemplo .= $patron[$i]; // Conserva cualquier otro carácter literal
                    break;
            }
        }
        
        return $ejemplo;
    }

    /**
     * Genera la cabecera de un formulario con estilos UIkit
     *
     * @param array $camarray Configuración de la cabecera
     * @return string HTML de la cabecera generada
     */
    function Form_cabecera($camarray)
    {
        $cabecera="";
        
   		$cabecera=$cabecera. "<div class='uk-container uk-container-expand'><div class=' ".$camarray['class']."' ><div class='uk-width-1-1 uk-form '>";
    		
    		foreach ($camarray['CONTENIDO'] as $contenido)
    		{
                $cabecera=$cabecera. "<div class='uk-grid-small ".($contenido['class']??"")."' uk-grid>";
                foreach ($contenido['conte'] as $id_input=>$input)
                {
                    
                	$cabecera=$cabecera. "<div class='uk-width-1-1@m'>";   
                	$cabecera=$cabecera.Form_inputHtml($id_input,$input);	 
                	$cabecera=$cabecera. "</div>";
                    
                }
                $cabecera=$cabecera. "</div>";
    		}
    		$cabecera=$cabecera. "</div></div></div>";

    		return $cabecera;
    		
    }
    
    /**
     * Agrega clases CSS a controles de formulario que coincidan con un filtro
     *
     * @param array $filtro IDs de controles a modificar
     * @param array $formulario Formulario completo
     * @param string $nombre Nombre de la propiedad (ej: 'class')
     * @param string $clase Clase CSS a agregar
     * @param string $propiedad Propiedad a comparar (por defecto 'id')
     * @return array Formulario modificado
     */
    function Form_addclases($filtro, $formulario, $nombre, $clase,$propiedad="id")
    {
        
        foreach ($formulario as $key => $control) 
        {
            if(is_array($control))
            {
                if (array_key_exists($propiedad, $control)) 
                {
                    if (in_array($control[$propiedad], $filtro)) 
                    {
                        if (!array_key_exists($nombre, $formulario[$key])) 
                        {
                            $formulario[$key][$nombre] = $clase;
                        } 
                        else 
                        {
                            $formulario[$key][$nombre] .= " " . $clase;
                        }
                    }
                } 
                elseif (is_array($control)) 
                {
                    $formulario[$key] = Form_addclases($filtro, $control, $nombre, $clase);
                }
            }
        }
        
        return $formulario;
        
    }
    
    
    /**
     * Agrega una propiedad a controles específicos de un formulario
     *
     * @param array $filtro IDs de controles a modificar
     * @param array $formulario Formulario completo
     * @param string $nombre Nombre de la propiedad
     * @param mixed $valor Valor a asignar
     * @return array Formulario modificado
     */
    function Form_add2array($filtro,$formulario,$nombre,$valor)
    {
        $nform=$formulario;
        
        foreach ($nform as $key=>$control) 
        {
            if(array_key_exists('id', $control))
            {
                if (in_array($control['id'],$filtro))
                {
                    $nform[$key][$nombre]=$valor;
                }
            }
        }
        
        return $nform;
    }
    
    /**
     * Crea string de propiedades HTML a partir de un array
     *
     * @param array $datos Array de propiedades
     * @return string String de propiedades HTML
     */
    function Form_crearPropiedades($datos)
    {
        $propiedades="";
        foreach ($datos as $clave => $valor) 
        {
            if (($clave !== 'type') and ($clave !== 'icono') )
            {
                $propiedades .= ' ' . $clave . '="' . $valor . '"';
            }
        }
        return $propiedades;
    }

    /**
     * Reemplaza placeholders en una plantilla con valores de un array
     *
     * @param string $plantilla Plantilla con placeholders
     * @param array $arrayvalores Valores para reemplazar
     * @return string Plantilla con valores reemplazados
     */
    function Form_RempPlantilla($plantilla,$arrayvalores)
    {
        foreach ($arrayvalores as $id => $valor) 
        {
            $html = str_replace("{$id}", $valor, $plantilla);
        }
        return $html;
    }

    /**
     * Muestra o devuelve el texto de un estado según su valor
     *
     * @param mixed $valor Valor del estado
     * @param array $estados Array de estados posibles
     * @param bool $limpiar Si es true devuelve solo texto, si es false devuelve HTML
     * @return string Texto o HTML del estado
     */
	function Form_estado($valor,$estados,$limpiar=false)
	{
	    if ($limpiar)
	    {
	        return $estados[$valor];
	    }
	    else 
	    {
	        return "<span class='uk-text-nowrap'>$estados[$valor]</span>";
	    }
	}
	
	/**
	 * Crea array de títulos cortos a partir de nombres de campos
	 *
	 * @param array $formulario Array de controles de formulario
	 * @return array Array de títulos truncados
	 */
	function Form_creartitulos($formulario)
	{

        $titulos = array();
        
        foreach ($formulario as $campo) 
        {
            $nombre = $campo['nombre'];
            $titulos[] = substr($nombre, 0, 12);
        }
        
        return $titulos;

	}
    

    // -----------------------------------------------------------------------------
    // CSRF propio (Form_) - evita duplicidad y funciona con myfetch/qFetch (FormData)
    // Uso recomendado:
    //   1) En tu layout <head>:  echo Form_csrfMeta();   (crea meta name+token)
    //   2) (Opcional) Dentro de cada <form>: echo Form_csrfField();
    //   3) En endpoints de escritura (Registrar/Borrar): validar con Form_csrfCheck($this->request)
    // -----------------------------------------------------------------------------

        /**
     * Nombre de campo CSRF real (según configuración del framework).
     */
    function Form_csrfName(): string
    {
        // Nombre real que usa el CSRF nativo del framework (Security::$csrfKey)
        if (function_exists('csrf_key')) return csrf_key();
        if (class_exists(\System\Core\Csrf::class)) return \System\Core\Csrf::key();

        $sec = function_exists('config') ? config('Security') : null;
        return (is_object($sec) && isset($sec->csrfKey)) ? (string)$sec->csrfKey : '_token';
    }

    /**
     * Obtiene token CSRF desde sesión (y lo crea si falta o expira).
     * $rotate=true fuerza regeneración.
     */
        /**
     * Token CSRF real del framework.
     * $rotate=true fuerza regeneración.
     *
     * Nota: $ttlSeconds se conserva por compatibilidad del helper,
     *       pero el TTL real lo controla Security::$csrfExpire (cookie) o sesión.
     */
    function Form_csrfToken(bool $rotate = false, int $ttlSeconds = 7200): string
    {
        if (class_exists(\System\Core\Csrf::class)) {
            if ($rotate) return \System\Core\Csrf::regenerate();
            return \System\Core\Csrf::token();
        }
        return '';
    }


    /**
     * Imprime metas para que JS (myfetch/qFetch) pueda adjuntar CSRF automáticamente.
     */
        /**
     * Imprime metas para que JS (myfetch/qFetch) pueda adjuntar CSRF automáticamente.
     * Incluye metas estándar (csrf-*) y legacy (Form_csrf_*).
     */
    function Form_csrfMeta(?string $name = null): string
    {
        $name = $name ?: Form_csrfName();
        $tok  = Form_csrfToken(false);

        // Header real (configurable) para fetch/AJAX
        $hdr = 'X-CSRF-TOKEN';
        if (function_exists('csrf_header')) $hdr = csrf_header();
        elseif (class_exists(\System\Core\Csrf::class)) $hdr = \System\Core\Csrf::headerName();

        $n = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $t = htmlspecialchars($tok, ENT_QUOTES, 'UTF-8');
        $h = htmlspecialchars($hdr, ENT_QUOTES, 'UTF-8');

        // Primero: metas estándar del framework (si existen)
        $std = '';
        if (function_exists('csrf_meta')) {
            $std = csrf_meta();
        } else {
            $std = "<meta name=\"csrf-key\" content=\"{$n}\">\n"
                 . "<meta name=\"csrf-token\" content=\"{$t}\">\n"
                 . "<meta name=\"csrf-header\" content=\"{$h}\">\n";
        }

        // Luego: metas legacy para compatibilidad (tu JS actual)
        $legacy = "<meta name=\"Form_csrf_name\" content=\"{$n}\">\n"
                . "<meta name=\"Form_csrf_token\" content=\"{$t}\">\n"
                . "<meta name=\"Form_csrf_header\" content=\"{$h}\">\n";

        return $std . $legacy;
    }


    /**
     * Hidden input para forms tradicionales (también útil como fallback).
     */
        /**
     * Campo hidden CSRF para formularios.
     */
    function Form_csrfField(?string $name = null): string
    {
        // Usa directamente el helper del framework (recomendado)
        if (function_exists('csrf_field')) return csrf_field();

        $name = $name ?: Form_csrfName();
        $tok  = Form_csrfToken(false);

        $n = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
        $t = htmlspecialchars($tok, ENT_QUOTES, 'UTF-8');

        return "<input type=\"hidden\" name=\"{$n}\" value=\"{$t}\">";
    }


    /**
     * Valida CSRF leyendo el token desde:
     *  - POST (FormData) con name = Form_csrfName()
     *  - Header: X-Form-CSRF (fallback)
     * Retorna array [ok(bool), message(?string), tokenActual(string)]
     */
        /**
     * Validación CSRF manual (compatibilidad).
     * Retorna: [ok(bool), message(?string), token(string)]
     *
     * Recomendación: en rutas POST/PUT/PATCH/DELETE usa el filtro 'csrf' del framework.
     */
    function Form_csrfCheck($request = null, ?string $name = null, int $ttlSeconds = 7200): array
    {
        $name = $name ?: Form_csrfName();

        if (!class_exists(\System\Core\Csrf::class)) {
            return [false, 'CSRF no disponible (System\\Core\\Csrf no encontrado).', ''];
        }

        $hdr = \System\Core\Csrf::headerName();

        $posted = null;
        $header = null;

        // Si te pasan un Request (estilo CI4 o QFW), intentamos leer de ahí
        if ($request && is_object($request)) {
            if (method_exists($request, 'getPost')) {
                $posted = $request->getPost($name);
            } elseif (method_exists($request, 'post')) {
                $posted = $request->post($name);
            }

            if (method_exists($request, 'getHeaderLine')) {
                $header = $request->getHeaderLine($hdr) ?: $request->getHeaderLine('X-Form-CSRF');
            } elseif (method_exists($request, 'header')) {
                $header = $request->header($hdr) ?: $request->header('X-Form-CSRF');
            }
        }

        // Fallback superglobals / core extractor
        $incoming = (string)($posted ?: $header ?: \System\Core\Csrf::fromRequest()
            ?: ($_SERVER['HTTP_X_FORM_CSRF'] ?? '')
            ?: ($_SERVER['HTTP_X_Q_CSRF'] ?? '')
        );

        $ok = ($incoming !== '' && \System\Core\Csrf::verify($incoming));

        if (!$ok) {
            $newTok = \System\Core\Csrf::regenerate();
            return [false, 'CSRF inválido o sesión/cookie caducado. Actualiza el token e intenta nuevamente.', $newTok];
        }

        return [true, null, \System\Core\Csrf::token()];
    }



