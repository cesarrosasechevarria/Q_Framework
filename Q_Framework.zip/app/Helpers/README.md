# app/Helpers

Esta carpeta es para **helpers personalizados del proyecto** (creados por el desarrollador).

- Un helper es un archivo `*_helper.php` con funciones globales.
- Ejemplo: `app/Helpers/mi_helper.php` (cargar con `helper('mi')`).

> Los helpers base del framework vienen en `system/Helpers/`.
