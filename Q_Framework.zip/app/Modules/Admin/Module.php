<?php
declare(strict_types=1);

namespace Modules\Admin;

final class Module
{
  public const NAME = 'Admin';
  public const VERSION = '1.0.0';
  public const DESCRIPTION = 'Panel base (dashboard) protegido por AuthFilter.';
}
