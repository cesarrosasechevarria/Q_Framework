<?php
declare(strict_types=1);

namespace Modules\Admin\Controllers;

use App\Controllers\BaseController;

final class Dashboard extends BaseController
{
  protected array $helpers = ['url','security'];

  public function index()
  {
    $u = auth_user();
    return view('admin/dashboard', [
      'title' => 'Dashboard',
      'user' => $u,
    ]);
  }

  public function profile()
  {
    $u = auth_user();
    return view('admin/profile', [
      'title' => 'Perfil',
      'user' => $u,
    ]);
  }

  /**
   * Ejemplo: ruta pública dentro de /admin (guard=false en la ruta)
   */
  public function publicInfo()
  {
    return view('admin/public_info', [
      'title' => 'Info pública',
    ]);
  }
}
