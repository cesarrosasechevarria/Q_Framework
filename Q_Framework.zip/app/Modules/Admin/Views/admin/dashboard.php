<div class="qfw-card">
  <h1 style="margin:0 0 6px">📊 <?= e($title ?? 'Dashboard') ?></h1>
  <p class="qfw-muted" style="margin-top:0">Bienvenido/a <?= e(($user['name'] ?? '')) ?> (<code><?= e(($user['email'] ?? '')) ?></code>)</p>

  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
    <a class="qfw-btn" href="<?= route_url('admin.profile') ?>">👤 Perfil</a>
    <a class="qfw-btn" href="<?= route_url('files.index') ?>">📁 Archivos</a>
    <a class="qfw-btn" href="<?= route_url('blog.index') ?>">📝 Blog</a>
    <a class="qfw-btn" href="<?= route_url('api.status') ?>">🔌 API status</a>
    <form method="post" action="<?= route_url('auth.logout') ?>" style="display:inline">
      <?= csrf_field() ?>
      <button class="qfw-btn" type="submit">🚪 Salir</button>
    </form>
  </div>
</div>
