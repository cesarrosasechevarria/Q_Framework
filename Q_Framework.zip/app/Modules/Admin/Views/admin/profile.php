<div class="qfw-card" style="max-width:820px">
  <h1 style="margin:0 0 6px">👤 <?= e($title ?? 'Perfil') ?></h1>
  <p class="qfw-muted" style="margin-top:0">Datos en sesión (demo).</p>

  <pre style="background:rgba(255,255,255,.06);padding:12px;border-radius:12px;border:1px solid var(--qfw-border)"><?= e(json_encode($user ?? [], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) ?: '') ?></pre>

  <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
    <a class="qfw-btn" href="<?= route_url('admin.dashboard') ?>">← Volver</a>
  </div>
</div>
