<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){

  // =========================
  // Admin (PRO)
  // =========================
  // Protegido por GuardFilter (role-based), para NO repetir "if(!auth)" en cada controller.
  //
  // Requisitos:
  //  - session('user') existe
  //  - session('user')['role'] == 'admin'
  //
  // Si no cumple:
  //  - recuerda intended URL (por defecto)
  //  - redirige a @auth.login
  //
  $routes->group('/admin', [
    'guard' => [
      'require'  => 'user',
      'match'    => ['user.role' => ['admin','superadmin']],
      'redirect' => '@auth.login',
      'remember' => true,
    ],
  ], function(RouteCollection $r){

    // ✅ Ruta pública dentro del group (desactiva guard SOLO aquí)
    $r->get('/public-info', 'Modules\\Admin\\Controllers\\Dashboard@publicInfo', [
      'as' => 'admin.public_info',
      'guard' => false,
    ]);

    $r->get('/', 'Modules\\Admin\\Controllers\\Dashboard@index', ['as' => 'admin.dashboard']);
    $r->get('/profile', 'Modules\\Admin\\Controllers\\Dashboard@profile', ['as' => 'admin.profile']);
  });
};
