<?php
declare(strict_types=1);

namespace Modules\Blog\Models;

use System\Database\Model;

final class PostModel extends Model
{
  protected string $table = 'blog_posts';
  protected string $primaryKey = 'id';
  protected array $allowedFields = ['title','slug','content','author_id','created_at','updated_at'];

  public function byId(int $id): ?array
  {
    return $this->where(['id'=>$id])->first();
  }

  public function latest(int $limit = 20): array
  {
    return $this->orderBy('id','DESC')->findAll($limit);
  }

  public function slugExists(string $slug, ?int $ignoreId = null): bool
  {
    $qb = $this->where(['slug'=>$slug]);
    if ($ignoreId) $qb->whereNotIn('id', [$ignoreId]);
    return (bool)$qb->first();
  }
}
