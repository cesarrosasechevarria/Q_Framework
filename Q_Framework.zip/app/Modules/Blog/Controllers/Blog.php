<?php
declare(strict_types=1);

namespace Modules\Blog\Controllers;

use App\Controllers\BaseController;
use Modules\Blog\Models\PostModel;

final class Blog extends BaseController
{
  protected array $helpers = ['url','security'];

  private PostModel $posts;

  public function __construct()
  {
    $this->posts = new PostModel();
  }

  public function index(): string
  {
    $items = $this->posts->latest(50);
    return $this->view('blog/index', [
      'title' => 'Blog',
      'items' => $items,
      'user'  => auth_user(),
      'msg'   => flash('msg'),
      'err'   => flash('err'),
    ]);
  }

  public function show(string $id): string
  {
    $idInt = (int)$id;
    $post = $this->posts->byId($idInt);
    if (!$post) {
      return $this->view('blog/show', [
        'title' => 'No encontrado',
        'notFound' => true,
        'user' => auth_user(),
      ]);
    }
    return $this->view('blog/show', [
      'title' => (string)$post['title'],
      'post' => $post,
      'user' => auth_user(),
    ]);
  }

  public function new(): string
  {
    return $this->view('blog/form', [
      'title' => 'Nuevo post',
      'mode'  => 'create',
      'post'  => [
        'title' => flash('old_title') ?? '',
        'content' => flash('old_content') ?? '',
      ],
      'err' => flash('err'),
      'user' => auth_user(),
    ]);
  }

  public function create()
  {
    $title = trim((string)$this->request->post('title',''));
    $content = trim((string)$this->request->post('content',''));

    [$ok, $errs] = validate(['title'=>$title,'content'=>$content], [
      'title' => 'required|min:3|max:140',
      'content' => 'required|min:5|max:60000',
    ]);

    if (!$ok) {
      flash('err', 'Revisa los campos.');
      flash('old_title', $title);
      flash('old_content', $content);
      return $this->redirect(route_url('blog.new'));
    }

    $slug = $this->makeSlug($title);
    $slug = $this->uniqueSlug($slug);

    $u = auth_user();
    $authorId = is_array($u) ? (int)($u['id'] ?? 0) : 0;

    $id = $this->posts->insert([
      'title' => $title,
      'slug' => $slug,
      'content' => $content,
      'author_id' => $authorId ?: null,
      'created_at' => date('Y-m-d H:i:s'),
      'updated_at' => date('Y-m-d H:i:s'),
    ]);

    if (!$id) {
      flash('err', 'No se pudo crear el post.');
      return $this->redirect(route_url('blog.new'));
    }

    flash('msg', 'Post creado.');
    return $this->redirect(route_url('blog.show', ['id'=>$id]));
  }

  public function edit(string $id): string
  {
    $idInt = (int)$id;
    $post = $this->posts->byId($idInt);
    if (!$post) {
      flash('err', 'Post no encontrado.');
      return $this->redirect(route_url('blog.index'));
    }

    return $this->view('blog/form', [
      'title' => 'Editar post',
      'mode'  => 'edit',
      'post'  => $post,
      'err' => flash('err'),
      'user' => auth_user(),
    ]);
  }

  public function update(string $id)
  {
    $idInt = (int)$id;
    $post = $this->posts->byId($idInt);
    if (!$post) {
      flash('err', 'Post no encontrado.');
      return $this->redirect(route_url('blog.index'));
    }

    $title = trim((string)$this->request->post('title',''));
    $content = trim((string)$this->request->post('content',''));

    [$ok, $errs] = validate(['title'=>$title,'content'=>$content], [
      'title' => 'required|min:3|max:140',
      'content' => 'required|min:5|max:60000',
    ]);

    if (!$ok) {
      flash('err', 'Revisa los campos.');
      return $this->redirect(route_url('blog.edit', ['id'=>$idInt]));
    }

    // Mantener slug, pero si cambia el título podrías regenerar (aquí lo mantenemos)
    $ok = $this->posts->update($idInt, [
      'title' => $title,
      'content' => $content,
      'updated_at' => date('Y-m-d H:i:s'),
    ]);

    if (!$ok) {
      flash('err', 'No se pudo actualizar.');
      return $this->redirect(route_url('blog.edit', ['id'=>$idInt]));
    }

    flash('msg', 'Post actualizado.');
    return $this->redirect(route_url('blog.show', ['id'=>$idInt]));
  }

  public function delete(string $id)
  {
    $idInt = (int)$id;
    $post = $this->posts->byId($idInt);
    if (!$post) {
      flash('err', 'Post no encontrado.');
      return $this->redirect(route_url('blog.index'));
    }

    $this->posts->delete($idInt);
    flash('msg', 'Post eliminado.');
    return $this->redirect(route_url('blog.index'));
  }

  private function makeSlug(string $title): string
  {
    $s = mb_strtolower($title, 'UTF-8');
    $s = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s) ?: $s;
    $s = preg_replace('/[^a-z0-9]+/i', '-', $s) ?: '';
    $s = trim($s, '-');
    return $s !== '' ? $s : 'post';
  }

  private function uniqueSlug(string $base): string
  {
    $slug = $base;
    $i = 2;
    while ($this->posts->slugExists($slug)) {
      $slug = $base . '-' . $i;
      $i++;
      if ($i > 500) break;
    }
    return $slug;
  }
}
