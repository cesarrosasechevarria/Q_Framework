<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){
  $routes->group('/blog', [], function(RouteCollection $r){
    // Público
    $r->get('/', 'Modules\\Blog\\Controllers\\Blog@index', ['as'=>'blog.index']);
    $r->get('/{id}', 'Modules\\Blog\\Controllers\\Blog@show', ['as'=>'blog.show']);

    // Protegido (requiere login)
    $r->get('/new', 'Modules\\Blog\\Controllers\\Blog@new', ['as'=>'blog.new','filters'=>['auth:@auth.login']]);
    $r->post('/create', 'Modules\\Blog\\Controllers\\Blog@create', ['as'=>'blog.create','filters'=>['csrf','auth:@auth.login']]);

    $r->get('/{id}/edit', 'Modules\\Blog\\Controllers\\Blog@edit', ['as'=>'blog.edit','filters'=>['auth:@auth.login']]);
    $r->post('/{id}/update', 'Modules\\Blog\\Controllers\\Blog@update', ['as'=>'blog.update','filters'=>['csrf','auth:@auth.login']]);
    $r->post('/{id}/delete', 'Modules\\Blog\\Controllers\\Blog@delete', ['as'=>'blog.delete','filters'=>['csrf','auth:@auth.login']]);
  });
};
