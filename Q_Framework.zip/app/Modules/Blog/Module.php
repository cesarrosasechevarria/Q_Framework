<?php
declare(strict_types=1);

namespace Modules\Blog;

final class Module
{
  public const NAME = 'Blog';
  public const VERSION = '1.0.0';
  public const DESCRIPTION = 'Mini-blog CRUD (con ejemplos de rutas, filtros, validación, ...).';
}
