<div class="qfw-card">
  <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:10px; flex-wrap:wrap">
    <div>
      <h1 style="margin:0">Blog</h1>
      <div class="qfw-muted" style="margin-top:6px">Ejemplo CRUD con rutas, filtros, validación y módulos.</div>
    </div>
    <div style="display:flex; gap:10px; flex-wrap:wrap">
      <a class="qfw-btn" href="<?= base_url('/') ?>">🏠 Inicio</a>
      <?php if (!empty($user['id'])): ?>
        <a class="qfw-btn primary" href="<?= route_url('blog.new') ?>">➕ Nuevo post</a>
        <form method="post" action="<?= route_url('auth.logout') ?>" style="margin:0">
          <?= csrf_field() ?>
          <button class="qfw-btn" type="submit">🚪 Salir</button>
        </form>
      <?php else: ?>
        <a class="qfw-btn primary" href="<?= route_url('auth.login') ?>">🔑 Entrar</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if (!empty($msg)): ?>
    <div class="qfw-alert ok" style="margin-top:12px"><?= e((string)$msg) ?></div>
  <?php endif; ?>
  <?php if (!empty($err)): ?>
    <div class="qfw-alert" style="margin-top:12px"><?= e((string)$err) ?></div>
  <?php endif; ?>

  <div style="margin-top:16px; display:grid; gap:10px">
    <?php foreach (($items ?? []) as $it): ?>
      <div class="qfw-card" style="padding:14px">
        <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap">
          <div>
            <div style="font-weight:900; font-size:18px">
              <a href="<?= route_url('blog.show', ['id'=>$it['id']]) ?>" style="text-decoration:none">
                <?= e((string)($it['title'] ?? '')) ?>
              </a>
            </div>
            <div class="qfw-muted" style="margin-top:6px">
              <code>#<?= e((string)($it['id'] ?? '')) ?></code>
              <?php if (!empty($it['slug'])): ?> · <code><?= e((string)$it['slug']) ?></code><?php endif; ?>
            </div>
          </div>
          <div class="qfw-muted">
            <?= e((string)($it['updated_at'] ?? $it['created_at'] ?? '')) ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>

    <?php if (empty($items)): ?>
      <div class="qfw-muted" style="padding:10px 0">Aún no hay posts. <?= !empty($user['id']) ? 'Crea uno con “Nuevo post”.' : 'Inicia sesión para crear.' ?></div>
    <?php endif; ?>
  </div>
</div>
