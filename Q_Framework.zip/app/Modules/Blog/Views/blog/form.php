<?php $isEdit = ($mode ?? '') === 'edit'; ?>
<div class="qfw-card">
  <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap">
    <div>
      <a class="qfw-btn" href="<?= route_url('blog.index') ?>">← Volver</a>
    </div>
    <a class="qfw-btn" href="<?= base_url('/') ?>">🏠 Inicio</a>
  </div>

  <h1 style="margin-top:12px"><?= e($isEdit ? 'Editar post' : 'Nuevo post') ?></h1>
  <div class="qfw-muted">Ejemplo de formulario con CSRF y validación.</div>

  <?php if (!empty($err)): ?>
    <div class="qfw-alert" style="margin-top:12px"><?= e((string)$err) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= $isEdit ? route_url('blog.update', ['id'=>$post['id']]) : route_url('blog.create') ?>" style="margin-top:16px; display:grid; gap:12px">
    <?= csrf_field() ?>

    <label style="display:grid; gap:6px">
      <div style="font-weight:800">Título</div>
      <input name="title" value="<?= e((string)($post['title'] ?? '')) ?>" maxlength="140" required
        style="padding:10px 12px; border-radius:12px; border:1px solid var(--qfw-border); background:rgba(255,255,255,.06); color:inherit" />
    </label>

    <label style="display:grid; gap:6px">
      <div style="font-weight:800">Contenido</div>
      <textarea name="content" rows="10" required
        style="padding:10px 12px; border-radius:12px; border:1px solid var(--qfw-border); background:rgba(255,255,255,.06); color:inherit"><?= e((string)($post['content'] ?? '')) ?></textarea>
    </label>

    <div style="display:flex; gap:10px; flex-wrap:wrap">
      <button class="qfw-btn primary" type="submit">💾 Guardar</button>
      <a class="qfw-btn" href="<?= route_url('blog.index') ?>">Cancelar</a>
    </div>
  </form>
</div>
