<div class="qfw-card">
  <div style="display:flex; justify-content:space-between; gap:10px; flex-wrap:wrap">
    <div>
      <a class="qfw-btn" href="<?= route_url('blog.index') ?>">← Volver</a>
    </div>
    <div style="display:flex; gap:10px; flex-wrap:wrap">
      <?php if (!empty($user['id']) && !empty($post['id'])): ?>
        <a class="qfw-btn" href="<?= route_url('blog.edit', ['id'=>$post['id']]) ?>">✏️ Editar</a>
        <form method="post" action="<?= route_url('blog.delete', ['id'=>$post['id']]) ?>" style="margin:0" onsubmit="return confirm('¿Eliminar este post?');">
          <?= csrf_field() ?>
          <button class="qfw-btn" type="submit">🗑️ Eliminar</button>
        </form>
      <?php endif; ?>
      <a class="qfw-btn" href="<?= base_url('/') ?>">🏠 Inicio</a>
    </div>
  </div>

  <?php if (!empty($notFound)): ?>
    <h1 style="margin-top:12px">No encontrado</h1>
    <p class="qfw-muted">El post no existe.</p>
  <?php else: ?>
    <h1 style="margin-top:12px"><?= e((string)($post['title'] ?? '')) ?></h1>
    <div class="qfw-muted" style="margin-top:6px">
      <code>#<?= e((string)($post['id'] ?? '')) ?></code>
      <?php if (!empty($post['slug'])): ?> · <code><?= e((string)$post['slug']) ?></code><?php endif; ?>
      <?php if (!empty($post['updated_at'])): ?> · <?= e((string)$post['updated_at']) ?><?php endif; ?>
    </div>

    <div class="qfw-card" style="margin-top:16px; padding:16px">
      <div style="white-space:pre-wrap"><?= e((string)($post['content'] ?? '')) ?></div>
    </div>
  <?php endif; ?>
</div>
