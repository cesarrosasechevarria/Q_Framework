<?php
declare(strict_types=1);

use System\Database\Connection;
use System\Database\Migrations\MigrationInterface;

return new class implements MigrationInterface {
  public function up(Connection $db): void
  {
    $db->query("CREATE TABLE IF NOT EXISTS blog_posts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(140) NOT NULL,
      slug VARCHAR(180) NOT NULL,
      content LONGTEXT NOT NULL,
      author_id INT NULL,
      created_at DATETIME NULL,
      updated_at DATETIME NULL,
      UNIQUE KEY uq_blog_slug (slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  public function down(Connection $db): void
  {
    $db->query('DROP TABLE IF EXISTS blog_posts');
  }
};
