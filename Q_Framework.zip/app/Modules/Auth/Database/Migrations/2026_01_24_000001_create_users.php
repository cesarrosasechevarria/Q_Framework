<?php
declare(strict_types=1);

use System\Database\Connection;
use System\Database\Migrations\MigrationInterface;

return new class implements MigrationInterface {
  public function up(Connection $db): void
  {
    // Nota: para portabilidad MySQL, definimos UNIQUE dentro del CREATE TABLE.
    $db->query("CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(80) NOT NULL,
      email VARCHAR(120) NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role VARCHAR(30) NOT NULL DEFAULT 'user',
      created_at DATETIME NULL,
      updated_at DATETIME NULL,
      UNIQUE KEY uq_users_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  public function down(Connection $db): void
  {
    $db->query('DROP TABLE IF EXISTS users');
  }
};
