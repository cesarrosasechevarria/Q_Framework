<?php
declare(strict_types=1);

namespace Modules\Auth\Support;

use System\Core\Session;

/**
 * Auth helper (módulo)
 *
 * Convención:
 * - Guarda el usuario autenticado en session('user')
 */
final class Auth
{
  /** Retorna true si hay usuario autenticado (inicia sesión si se llama). */
  public static function check(): bool
  {
    Session::ensureStarted();
    return !empty($_SESSION['user']);
  }

  /** Retorna el array user o null (inicia sesión si se llama). */
  public static function user(): ?array
  {
    Session::ensureStarted();
    $u = $_SESSION['user'] ?? null;
    return is_array($u) ? $u : null;
  }

  /** Cierra sesión (regenera id para evitar fixation). */
  public static function logout(): void
  {
    Session::ensureStarted();
    unset($_SESSION['user']);
    @session_regenerate_id(true);
  }

  /**
   * Marca un usuario en sesión.
   * - Firma PRO: login(array $user)
   * - Compat:    login(int $id, array $user)
   *
   * Guarda un payload seguro (sin password_hash).
   */
  public static function login(int|array $idOrUser, ?array $user = null): void
  {
    Session::ensureStarted();

    if (is_array($idOrUser)) {
      $user = $idOrUser;
    } else {
      $user = $user ?? ['id' => $idOrUser];
      $user['id'] = (int)$idOrUser;
    }

    // Sanitiza: no guardar hashes/secretos en sesión
    unset($user['password_hash'], $user['password']);

    // Normaliza
    if (isset($user['email'])) $user['email'] = strtolower(trim((string)$user['email']));
    if (isset($user['role']))  $user['role']  = strtolower(trim((string)$user['role']));

    $_SESSION['user'] = $user;
    @session_regenerate_id(true);
  }

  /** Id del usuario autenticado o null. */
  public static function id(): ?int
  {
    $u = self::user();
    if (!$u) return null;
    return isset($u['id']) ? (int)$u['id'] : null;
  }

  /** Requiere rol (ejemplo). */
  public static function hasRole(string $role): bool
  {
    $u = self::user();
    if (!$u) return false;
    return strtolower((string)($u['role'] ?? '')) === strtolower($role);
  }
}
