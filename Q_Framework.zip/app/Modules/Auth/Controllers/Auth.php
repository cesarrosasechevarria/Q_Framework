<?php
declare(strict_types=1);

namespace Modules\Auth\Controllers;

use App\Controllers\BaseController;
use Modules\Auth\Models\UserModel;
use Modules\Auth\Support\Auth as AuthSupport;
use System\Core\Errors;

/**
 * Auth Controller (PRO)
 * - Login con rate limiting
 * - Registro opcional (configurable)
 * - Intended redirect (GuardFilter)
 */
final class Auth extends BaseController
{
  protected array $helpers = ['url','security'];

  private UserModel $users;

  public function __construct()
  {
    $this->users = new UserModel();
  }

  /** GET /auth/login */
  public function login()
  {
    // Si ya está logueado, redirige (intended o destino por rol)
    if (AuthSupport::check()) {
      return $this->redirect($this->consumeIntendedOrDefault());
    }

    return view('auth/login', [
      'title'    => 'Iniciar sesión',
      'error'    => flash('error'),
      'oldEmail' => flash('old_email'),
    ]);
  }

  /** POST /auth/login */
  public function loginPost()
  {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass  = (string)($_POST['password'] ?? '');

    if ($email === '' || $pass === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      return $this->failAuth('Email/clave inválidos.', 422, $email);
    }

    // === Rate limiting (PRO) ===
    $sec = config('Security');
    $key = (string)($sec->loginRatePrefix ?? 'rl:login') . ':' . $this->request->ip() . ':' . $email;

    $lim = service('ratelimiter');
    $st  = $lim->attempt($key, (int)($sec->loginMaxAttempts ?? 8), (int)($sec->loginDecaySeconds ?? 600));

    if (!$st['ok']) {
      if ($this->request->wantsJson()) {
        return $this->response->json([
          'status'      => 429,
          'error'       => true,
          'message'     => 'Demasiados intentos. Intenta nuevamente en ' . $st['wait'] . 's.',
          'retry_after' => $st['wait'],
        ], 429);
      }
      flash('error', 'Demasiados intentos. Intenta nuevamente en ' . $st['wait'] . 's.');
      flash('old_email', $email);
      return $this->redirect(route_url('auth.login'));
    }

    // Busca usuario
    $row = $this->users->where(['email' => $email])->first();

    if (!$row || empty($row['password_hash']) || !verify_password($pass, (string)$row['password_hash'])) {
      return $this->failAuth('Credenciales incorrectas.', 401, $email);
    }

    // Login: guarda un payload seguro (sin password_hash)
    AuthSupport::login([
      'id'    => (int)$row['id'],
      'name'  => (string)($row['name'] ?? ''),
      'email' => (string)($row['email'] ?? ''),
      'role'  => (string)($row['role'] ?? 'user'),
      'active'=> (int)($row['active'] ?? 1),
    ]);

    // Limpia rate limit al éxito
    $lim->clear($key);

    return $this->redirect($this->consumeIntendedOrDefault());
  }

  /** GET /auth/register */
  public function register()
  {
    if (!$this->registrationEnabled()) {
      return $this->disabledResponse('Registro deshabilitado.');
    }

    if (AuthSupport::check()) {
      return $this->redirect($this->consumeIntendedOrDefault());
    }

    return view('auth/register', [
      'title'    => 'Crear cuenta',
      'error'    => flash('error'),
      'oldName'  => flash('old_name'),
      'oldEmail' => flash('old_email'),
    ]);
  }

  /** POST /auth/register */
  public function registerPost()
  {
    if (!$this->registrationEnabled()) {
      return $this->disabledResponse('Registro deshabilitado.');
    }

    $name  = trim((string)($_POST['name'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass  = (string)($_POST['password'] ?? '');

    // Validaciones PRO (simples pero reales)
    if (mb_strlen($name) < 2 || mb_strlen($name) > 80) {
      return $this->failRegister('Nombre inválido (2 a 80 caracteres).', $name, $email);
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      return $this->failRegister('Correo inválido.', $name, $email);
    }
    if (strlen($pass) < 8) {
      return $this->failRegister('La contraseña debe tener al menos 8 caracteres.', $name, $email);
    }
    // Componente básico de complejidad (mejor que nada)
    if (!preg_match('/[A-Za-z]/', $pass) || !preg_match('/\d/', $pass)) {
      return $this->failRegister('La contraseña debe incluir letras y números.', $name, $email);
    }

    // Email único
    $exists = $this->users->where(['email' => $email])->first();
    if ($exists) {
      return $this->failRegister('Ese correo ya está registrado.', $name, $email);
    }

    $id = $this->users->insert([
      'name'          => $name,
      'email'         => $email,
      'password_hash' => hash_password($pass),
      'role'          => $this->defaultRegisterRole(),
    ], true);

    // Algunos drivers pueden devolver insertId=0 aunque el INSERT haya sido OK.
    // Por eso validamos con === false, y como fallback buscamos por email.
    if ($id === false) {
      return $this->failRegister('No se pudo crear el usuario. Intenta nuevamente.', $name, $email);
    }

    if ($id === 0 || $id === '0') {
      $created = $this->users->where(['email' => $email])->first();
      if ($created && isset($created['id'])) {
        $id = (int)$created['id'];
      }
    }

    if (!$id) {
      return $this->failRegister('No se pudo determinar el ID del usuario creado. Verifica tu conexión a la BD.', $name, $email);
    }

// Auto-login (DX PRO para demo)
    AuthSupport::login([
      'id'    => (int)$id,
      'name'  => $name,
      'email' => $email,
      'role'  => $this->defaultRegisterRole(),
      'active'=> 1,
    ]);

    return $this->redirect($this->consumeIntendedOrDefault());
  }

  /** POST /auth/logout */
  public function logout()
  {
    AuthSupport::logout();
    return $this->redirect(route_url('home'));
  }

  /* =========================
   * Helpers internos
   * ========================= */

  private function registrationEnabled(): bool
  {
    $cfg = config('Auth');
    // Por defecto: enabled en development, deshabilitado en production si no se define
    $env = (string) env('APP_ENV', 'development');
    if (property_exists($cfg, 'registrationEnabled')) {
      return (bool) $cfg->registrationEnabled;
    }
    return $env !== 'production';
  }

  private function defaultRegisterRole(): string
  {
    $cfg = config('Auth');
    if (property_exists($cfg, 'defaultRole') && is_string($cfg->defaultRole) && $cfg->defaultRole !== '') {
      return strtolower(trim($cfg->defaultRole));
    }
    return 'user';
  }

  /** Consumir intended o ir a destino por rol (PRO, evita loops). */
  private function consumeIntendedOrDefault(): string
  {
    $sec = config('Security');
    $intendedKey = (string)($sec->intendedKey ?? '_qfw_intended');
    $intended = (string)(session_optional()?->get($intendedKey) ?? '');
    if ($intended !== '') {
      session()->remove($intendedKey);
      return $intended;
    }

    $u = AuthSupport::user();
    $role = strtolower((string)($u['role'] ?? ''));
    if (in_array($role, ['admin','superadmin'], true)) {
      return route_url('admin.dashboard');
    }
    // Para usuarios normales, manda a Blog (si existe), sino Home.
    return route_url('platform.dashboard');
  }

  private function failAuth(string $msg, int $status, string $email)
  {
    if ($this->request->wantsJson()) {
      return $this->response->json([
        'status'  => $status,
        'error'   => true,
        'message' => $msg,
      ], $status);
    }

    // Renderiza directamente para que el error sea visible sin depender de flash/session.
    return view('auth/login', [
      'title'    => 'Iniciar sesión',
      'error'    => $msg,
      'oldEmail' => $email,
    ]);
  }

  private function failRegister(string $msg, string $name, string $email)
  {
    // Renderiza directamente (sin PRG) para que el error sea visible incluso si no hay sesión/flash.
    // En producción puedes volver a PRG si lo deseas.
    return view('auth/register', [
      'title'    => 'Crear cuenta',
      'error'    => $msg,
      'oldName'  => $name,
      'oldEmail' => $email,
    ]);
  }

  private function disabledResponse(string $msg)
  {
    if ($this->request->wantsJson()) {
      return $this->response->json([
        'status'  => 404,
        'error'   => true,
        'message' => $msg,
      ], 404);
    }
    return $this->response
      ->setStatus(404)
      ->html(Errors::page(404, ['title' => 'No disponible', 'message' => $msg]));
  }
}