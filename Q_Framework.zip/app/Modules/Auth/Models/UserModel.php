<?php
declare(strict_types=1);

namespace Modules\Auth\Models;

use System\Database\Model;

final class UserModel extends Model
{
  protected string $table = 'users';
  protected string $primaryKey = 'id';

  protected array $allowedFields = [
    'name', 'email', 'password_hash', 'role',
    'created_at', 'updated_at'
  ];

  protected bool $useSoftDeletes = false;
}
