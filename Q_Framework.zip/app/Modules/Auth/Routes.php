<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){
  $routes->group('/auth', [], function(RouteCollection $r){

    $r->get('/login',    'Modules\\Auth\\Controllers\\Auth@login',       ['as' => 'auth.login']);
    $r->post('/login',   'Modules\\Auth\\Controllers\\Auth@loginPost',   ['as' => 'auth.login.post', 'filters' => ['csrf']]);

    $r->get('/register', 'Modules\\Auth\\Controllers\\Auth@register',    ['as' => 'auth.register']);
    $r->post('/register','Modules\\Auth\\Controllers\\Auth@registerPost',['as' => 'auth.register.post', 'filters' => ['csrf']]);

    // Logout por POST (recomendado)
    $r->post('/logout',  'Modules\\Auth\\Controllers\\Auth@logout',      ['as' => 'auth.logout', 'filters' => ['csrf','auth:@auth.login']]);
  });
};
