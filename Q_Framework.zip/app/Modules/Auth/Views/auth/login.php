<?php $title = $title ?? 'Login'; ?>
<div class="qfw-card" style="max-width:520px;margin:0 auto">
  <h1 style="margin:0 0 6px">🔐 <?= e($title) ?></h1>
  <p class="qfw-muted" style="margin:0 0 16px">Ingresa tus credenciales para acceder.</p>

  <?php if (!empty($error)): ?>
    <div class="qfw-card" style="border-color:rgba(224,82,82,.55); margin:10px 0">
      <strong>⚠️</strong> <?= e($error) ?>
    </div>
  <?php endif; ?>

  <form method="post" action="<?= route_url('auth.login.post') ?>" autocomplete="on">
    <?= csrf_field() ?>

    <label style="display:block;margin:10px 0 6px">Correo</label>
    <input name="email" type="email" required value="<?= e($oldEmail ?? '') ?>" style="width:100%;padding:10px 12px;border-radius:12px;border:1px solid var(--qfw-border);background:rgba(255,255,255,.06);color:inherit">

    <label style="display:block;margin:10px 0 6px">Contraseña</label>
    <input name="password" type="password" required style="width:100%;padding:10px 12px;border-radius:12px;border:1px solid var(--qfw-border);background:rgba(255,255,255,.06);color:inherit">

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
      <button class="qfw-btn primary" type="submit">Entrar</button>
      <a class="qfw-btn" href="<?= route_url('auth.register') ?>">Crear cuenta</a>
      <a class="qfw-btn" href="<?= route_url('home') ?>">Inicio</a>
    </div>
  </form>

  <p class="qfw-muted" style="margin-top:16px">
    Demo: primero ejecuta migraciones (<code>php bin/console migrate</code>) para crear la tabla <code>users</code>.
  </p>
</div>
