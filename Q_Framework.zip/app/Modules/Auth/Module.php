<?php
declare(strict_types=1);

namespace Modules\Auth;

final class Module
{
  public const NAME = 'Auth';
  public const VERSION = '1.0.0';
  public const DESCRIPTION = 'Autenticación básica (login, registro, logout) con sesión lazy y CSRF.';
}
