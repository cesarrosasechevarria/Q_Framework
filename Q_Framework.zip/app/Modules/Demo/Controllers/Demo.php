<?php
declare(strict_types=1);

namespace Modules\Demo\Controllers;

use System\Core\Controller;
use System\Core\Session;

class Demo extends Controller
{
  public function index()
  {
    return view('demo/index', [
      'title' => 'Demo PRO',
    ]);
  }

  public function beta()
  {
    return view('demo/beta', [
      'title' => 'Demo: Feature beta',
    ]);
  }

  public function enableBeta()
  {
    Session::ensureStarted();
    $_SESSION['feature_beta'] = true;
    return $this->response->redirect(route_url('demo.beta'));
  }

  public function secure()
  {
    return view('demo/secure', [
      'title' => 'Demo: Guard por ruta',
      'user' => auth_user(),
    ]);
  }
}
