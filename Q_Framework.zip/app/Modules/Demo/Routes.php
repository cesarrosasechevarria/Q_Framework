<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){

  $routes->group('/demo', [], function(RouteCollection $r){

    $r->get('/', 'Modules\\Demo\\Controllers\\Demo@index', ['as'=>'demo.public']);

    // Ejemplo: filtro configurable por ruta (FeatureFlagFilter)
    $r->get('/beta', 'Modules\\Demo\\Controllers\\Demo@beta', [
      'as' => 'demo.beta',
      'filters' => [
        'feature:flag=beta&source=session&key=feature_beta&redirect=@demo.public',
      ],
    ]);

    // Helper de demo: habilita feature_beta en la sesión
    $r->get('/enable-beta', 'Modules\\Demo\\Controllers\\Demo@enableBeta', [
      'as' => 'demo.enable_beta',
      'guard' => ['require'=>'user', 'redirect'=>'@auth.login', 'remember'=>true],
    ]);

    // Ejemplo: guard por ruta (sin group) - requiere sesión user, sin role
    $r->get('/secure', 'Modules\\Demo\\Controllers\\Demo@secure', [
      'as' => 'demo.secure',
      'guard' => ['require'=>'user', 'redirect'=>'@auth.login', 'remember'=>true],
    ]);
  });

};
