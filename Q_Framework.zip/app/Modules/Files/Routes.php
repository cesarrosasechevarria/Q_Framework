<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){
  $routes->group('/files', ['filters' => ['auth:@auth.login']], function(RouteCollection $r){
    $r->get('/', 'Modules\\Files\\Controllers\\Files@index', ['as'=>'files.index']);
    $r->post('/upload', 'Modules\\Files\\Controllers\\Files@upload', ['as'=>'files.upload','filters'=>['csrf','auth:@auth.login']]);
  });
};
