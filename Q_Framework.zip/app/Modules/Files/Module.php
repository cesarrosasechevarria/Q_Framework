<?php
declare(strict_types=1);

namespace Modules\Files;

final class Module
{
  public const NAME = 'Files';
  public const VERSION = '1.0.0';
  public const DESCRIPTION = 'Upload / listado de archivos (demo) protegido por AuthFilter.';
}
