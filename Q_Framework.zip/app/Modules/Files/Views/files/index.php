<div class="qfw-card">
  <h1 style="margin:0 0 6px">📁 <?= e($title ?? 'Archivos') ?></h1>
  <p class="qfw-muted" style="margin-top:0">Demo de upload (se guarda en <code>write/uploads</code>).</p>

  <?php if (!empty($msg)): ?>
    <div class="qfw-card" style="border-color:rgba(31,191,91,.45);margin:10px 0">✅ <?= e($msg) ?></div>
  <?php endif; ?>
  <?php if (!empty($err)): ?>
    <div class="qfw-card" style="border-color:rgba(224,82,82,.55);margin:10px 0">⚠️ <?= e($err) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= route_url('files.upload') ?>" enctype="multipart/form-data" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
    <?= csrf_field() ?>
    <input type="file" name="file" required>
    <button class="qfw-btn primary" type="submit">Subir</button>
    <a class="qfw-btn" href="<?= route_url('admin.dashboard') ?>">← Dashboard</a>
  </form>

  <h2 style="margin:18px 0 10px">Listado</h2>
  <div style="overflow:auto">
    <table style="width:100%;border-collapse:collapse">
      <thead>
        <tr>
          <th style="text-align:left;padding:10px;border-bottom:1px solid var(--qfw-border)">Archivo</th>
          <th style="text-align:right;padding:10px;border-bottom:1px solid var(--qfw-border)">Tamaño</th>
          <th style="text-align:right;padding:10px;border-bottom:1px solid var(--qfw-border)">Modificado</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach (($items ?? []) as $it): ?>
        <tr>
          <td style="padding:10px;border-bottom:1px solid var(--qfw-border)"><code><?= e($it['name'] ?? '') ?></code></td>
          <td style="padding:10px;border-bottom:1px solid var(--qfw-border);text-align:right"><?= e(number_format((float)(($it['size'] ?? 0)/1024), 2)) ?> KB</td>
          <td style="padding:10px;border-bottom:1px solid var(--qfw-border);text-align:right"><?= e(date('Y-m-d H:i:s', (int)($it['mtime'] ?? 0))) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($items)): ?>
        <tr><td colspan="3" style="padding:10px" class="qfw-muted">Sin archivos todavía.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
