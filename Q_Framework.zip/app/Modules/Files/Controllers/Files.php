<?php
declare(strict_types=1);

namespace Modules\Files\Controllers;

use App\Controllers\BaseController;

final class Files extends BaseController
{
  protected array $helpers = ['url','security'];

  private string $uploadDir;

  public function __construct()
  {
    $this->uploadDir = base_path('write/uploads');
    if (!is_dir($this->uploadDir)) @mkdir($this->uploadDir, 0775, true);
  }

  public function index()
  {
    $items = [];
    foreach (glob($this->uploadDir . '/*') ?: [] as $f) {
      if (!is_file($f)) continue;
      $items[] = [
        'name' => basename($f),
        'size' => filesize($f) ?: 0,
        'mtime' => filemtime($f) ?: 0,
      ];
    }

    usort($items, fn($a,$b) => ($b['mtime']<=>$a['mtime']));

    return view('files/index', [
      'title' => 'Archivos',
      'items' => $items,
      'msg' => flash('msg'),
      'err' => flash('err'),
    ]);
  }

  public function upload()
  {
    if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
      flash('err', 'No se recibió archivo.');
      return $this->redirect(route_url('files.index'));
    }

    $f = $_FILES['file'];

    if (!empty($f['error'])) {
      flash('err', 'Error de upload: ' . (string)$f['error']);
      return $this->redirect(route_url('files.index'));
    }

    $name = basename((string)($f['name'] ?? 'file'));
    $name = preg_replace('/[^A-Za-z0-9_\-.]+/', '_', $name);
    if ($name === '' || $name === '_' ) $name = 'file_' . date('Ymd_His');

    // Límite (ejemplo): 10 MB
    $size = (int)($f['size'] ?? 0);
    if ($size > 10 * 1024 * 1024) {
      flash('err', 'Archivo demasiado grande (máx 10MB).');
      return $this->redirect(route_url('files.index'));
    }

    $tmp = (string)($f['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
      flash('err', 'Upload inválido.');
      return $this->redirect(route_url('files.index'));
    }

    $dest = $this->uploadDir . DIRECTORY_SEPARATOR . date('Ymd_His') . '_' . $name;
    if (!move_uploaded_file($tmp, $dest)) {
      flash('err', 'No se pudo guardar el archivo.');
      return $this->redirect(route_url('files.index'));
    }

    flash('msg', 'Archivo subido: ' . basename($dest));
    return $this->redirect(route_url('files.index'));
  }
}
