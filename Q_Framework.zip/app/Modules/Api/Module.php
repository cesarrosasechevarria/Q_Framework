<?php
declare(strict_types=1);

namespace Modules\Api;

final class Module
{
  public const NAME = 'Api';
  public const VERSION = '1.0.0';
  public const DESCRIPTION = 'Endpoints JSON de ejemplo (content negotiation)';
}
