<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){

  // =========================
  // API (session-based) - ejemplo simple
  // =========================
  $routes->group('/api', [], function(RouteCollection $r){
    $r->get('/status', 'Modules\\Api\\Controllers\\Status@index', ['as'=>'api.status']);
    $r->get('/me', 'Modules\\Api\\Controllers\\Status@me', ['as'=>'api.me', 'filters'=>['auth:@auth.login']]);
  });

  // =========================
  // API v1 (PRO): token + rate limit
  // =========================
  // Requiere:
  //  - .env -> API_TOKENS=demo_token
  //  - header Authorization: Bearer demo_token
  $routes->group('/api/v1', [
    'filters' => [
      'api', // ApiTokenFilter
      'rate:max=120&decay=60&by=ip&prefix=rl:api', // RateLimitFilter (429)
    ],
  ], function(RouteCollection $r){
    $r->get('/ping', 'Modules\\Api\\Controllers\\V1\\Ping@index', ['as'=>'api.v1.ping']);
    $r->get('/posts', 'Modules\\Api\\Controllers\\V1\\Posts@index', ['as'=>'api.v1.posts']);
  });

};
