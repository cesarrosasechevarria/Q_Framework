<?php
declare(strict_types=1);

namespace Modules\Api\Controllers;

use App\Controllers\BaseController;

final class Status extends BaseController
{
  protected array $helpers = ['url'];

  public function index()
  {
    return $this->json([
      'ok' => true,
      'app' => 'Q_Framework',
      'env' => (string)env('APP_ENV','production'),
      'time' => date('c'),
      'base_url' => base_url('/'),
    ]);
  }

  public function me()
  {
    // Requiere auth filter
    $u = auth_user();
    return $this->json([
      'ok' => true,
      'user' => $u,
    ]);
  }
}
