<?php
declare(strict_types=1);

namespace Modules\Api\Controllers\V1;

use System\Core\Controller;

class Ping extends Controller
{
  public function index()
  {
    return $this->json([
      'ok' => true,
      'service' => 'Q_Framework API',
      'version' => (string) env('APP_VERSION', '9.2.7'),
      'time' => date('c'),
    ]);
  }
}
