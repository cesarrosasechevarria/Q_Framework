<?php
declare(strict_types=1);

namespace Modules\Api\Controllers\V1;

use System\Core\Controller;
use Modules\Blog\Models\PostModel;

class Posts extends Controller
{
  public function index()
  {
    $perPage = (int)($this->request->query('limit', 20) ?? 20);
    $page    = (int)($this->request->query('page', 1) ?? 1);

    if ($perPage < 1) $perPage = 20;
    if ($perPage > 100) $perPage = 100;
    if ($page < 1) $page = 1;

    $m = new PostModel();

    $rows = $m->orderBy('id', 'DESC')
      ->paginate($perPage, $page, 'page', base_url('/api/v1/posts'));

    $pager = $m->pager();

    return $this->json([
      'ok' => true,
      'data' => $rows,
      'meta' => [
        'page' => $pager->page(),
        'perPage' => $pager->perPage(),
        'total' => $pager->total(),
        'pages' => $pager->pages(),
        'next' => $pager->next(),
        'prev' => $pager->prev(),
      ],
    ]);
  }
}
