<?php
declare(strict_types=1);

namespace App\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;
use System\Core\Session;

/**
 * FeatureFlagFilter (Ejemplo PRO)
 *
 * Demuestra un middleware/filter configurable por ruta.
 *
 * Uso:
 *   ['filters' => ['feature:flag=beta&source=session&key=feature_beta&redirect=@demo.public']]
 *
 * Parámetros:
 *  - flag     : nombre lógico (solo informativo)
 *  - source   : session|query|header (default: session)
 *  - key      : clave a leer (default: feature_{flag})
 *  - value    : valor esperado (default: true)
 *  - redirect : URL o @route.name (default: base_url('/'))
 */
final class FeatureFlagFilter implements FilterInterface
{
  private array $args = [];

  public function setArgs(array $args): void { $this->args = $args; }

  public function before(Request $request, Response $response): ?Response
  {
    $flag = (string)($this->args['flag'] ?? '');
    $src  = strtolower((string)($this->args['source'] ?? 'session'));
    $key  = (string)($this->args['key'] ?? ($flag !== '' ? 'feature_' . $flag : 'feature_flag'));
    $expected = $this->args['value'] ?? true;

    $val = null;

    if ($src === 'query') {
      $val = $request->query($key, null);
    } elseif ($src === 'header') {
      $val = $request->header($key, null);
    } else {
      // session
      if (!Session::hasCookie()) {
        $val = null;
      } else {
        Session::ensureStarted();
        $val = $_SESSION[$key] ?? null;
      }
    }

    $ok = ($val == $expected);
    if ($ok) return null;

    $msg = $flag !== '' ? ("Feature '{$flag}' no habilitada.") : "Feature no habilitada.";

    if ($request->wantsJson()) {
      return $response->json([
        'status' => 403,
        'error' => true,
        'message' => $msg,
      ], 403);
    }

    $to = (string)($this->args['redirect'] ?? base_url('/'));
    return $response->redirect($to, 302);
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }
}
