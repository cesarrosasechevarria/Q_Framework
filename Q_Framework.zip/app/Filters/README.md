# Filters (middleware) de tu proyecto

Crea aquí tus filtros personalizados y regístralos en `app/Config/Filters.php`.
