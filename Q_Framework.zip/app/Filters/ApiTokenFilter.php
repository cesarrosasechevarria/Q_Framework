<?php
declare(strict_types=1);

namespace App\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;

/**
 * ApiTokenFilter (PRO)
 *
 * Protege endpoints de API con token (simple, sin BD).
 *
 * Token sources:
 *  1) Authorization: Bearer <token>
 *  2) Header X-API-KEY
 *  3) Query ?api_token=...
 *
 * Config en .env:
 *   API_TOKENS=demo_token,otro_token
 *
 * Uso en rutas:
 *   ['filters' => ['api']]
 *   ['filters' => ['api', 'rate:max=120&decay=60&by=ip']]
 *
 * Parámetros (opcionales):
 *   - header: nombre del header (default: Authorization)
 *   - query : nombre del query param (default: api_token)
 *   - redirect: URL de redirección (web). Si no se indica, usa base_url('/')
 *   - allow_empty: true|false (default: false). Si true, deja pasar sin token (útil para dev/demos)
 */
final class ApiTokenFilter implements FilterInterface
{
  private array $args = [];

  public function setArgs(array $args): void { $this->args = $args; }

  public function before(Request $request, Response $response): ?Response
  {
    $sec = config('Security');

    $headerName = (string)($this->args['header'] ?? ($sec->apiTokenHeader ?? 'Authorization'));
    $queryKey   = (string)($this->args['query']  ?? ($sec->apiTokenQuery ?? 'api_token'));
    $allowEmpty = (bool)($this->args['allow_empty'] ?? false);

    $token = $this->extractToken($request, $headerName, $queryKey);

    if ($token === '' && $allowEmpty) return null;

    $tokens = (array)($sec->apiTokens ?? []);
    $tokens = array_values(array_filter(array_map('strval', $tokens), fn($t) => trim($t) !== ''));

    if (!$tokens) {
      $msg = "API_TOKENS no está configurado. Define API_TOKENS en .env (ej: API_TOKENS=demo_token).";
      if ($request->wantsJson()) {
        return $response->json(['status'=>500,'error'=>true,'message'=>$msg], 500);
      }
      return $response->setStatus(500)->html('<h1>Error de configuración</h1><p>' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</p>');
    }

    if ($token === '' || !in_array($token, $tokens, true)) {
      $response->header('WWW-Authenticate', 'Bearer realm="Q_Framework API"');

      $hint = '';
      if ((string)env('APP_ENV','production') !== 'production') {
        $hint = ' (dev) Usa Authorization: Bearer <token> o ?' . $queryKey . '=...';
      }

      if ($request->wantsJson()) {
        return $response->json([
          'status' => 401,
          'error' => true,
          'message' => 'Unauthorized: token inválido o faltante.' . $hint,
        ], 401);
      }

      $to = (string)($this->args['redirect'] ?? base_url('/'));
      return $response->redirect($to, 302);
    }

    $_SERVER['QFW_API_TOKEN'] = $token;
    return null;
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }

  private function extractToken(Request $request, string $headerName, string $queryKey): string
  {
    $auth = (string)($request->header($headerName, '') ?? '');
    if ($auth !== '') {
      if (preg_match('/^\s*Bearer\s+(.+)$/i', $auth, $m)) {
        return trim((string)$m[1]);
      }
      if (!str_contains($auth, ' ') && strlen($auth) >= 8) {
        return trim($auth);
      }
    }

    $x = (string)($request->header('X-API-KEY', '') ?? '');
    if ($x !== '') return trim($x);

    $q = (string)($request->query($queryKey, '') ?? '');
    return trim($q);
  }
}
