<?php
declare(strict_types=1);

namespace App\Filters;

use System\Core\Request;
use System\Core\Response;

/**
 * LocaleFilter
 *
 * Objetivo:
 * - Definir el idioma por request de forma consistente (Request + Lang)
 * - Soporta selección por:
 *   1) args del filtro: locale:es  / locale:en
 *   2) query: ?lang=es o ?locale=es
 *   3) cookie: lang=es
 *   4) sesión: $_SESSION['lang'] (si la sesión existe)
 *   5) fallback: Accept-Language (si App->negotiateLocale=true) o defaultLocale
 *
 * Uso recomendado:
 *   $routes->group('/admin', ['filters' => ['guard:admin', 'locale:es']], fn($r) => ...);
 *   $routes->group('/cliente', ['filters' => ['guard:client', 'locale']], fn($r) => ...);
 */
final class LocaleFilter implements \System\Core\FilterInterface
{
  /** @var string[] */
  private array $args = [];

  public function setArgs(array $args): void
  {
    $this->args = $args;
  }

  public function before(Request $request, Response $response): ?Response
  {
    $cfg = \config('App');
    $supported = (array)($cfg->supportedLocales ?? []);
    if (!$supported) $supported = [(string)($cfg->defaultLocale ?? 'en')];

    // 1) args: locale:es
    $candidate = '';
    if (!empty($this->args)) {
      $candidate = (string)($this->args[0] ?? '');
    }

    // 2) query params
    if ($candidate === '') {
      $candidate = (string)($request->query('lang', '') ?? '');
      if ($candidate === '') $candidate = (string)($request->query('locale', '') ?? '');
    }

    // 3) cookie
    if ($candidate === '') {
      $candidate = (string)($_COOKIE['lang'] ?? '');
    }

    // 4) sesión (solo si ya existe cookie de sesión)
    if ($candidate === '' && class_exists(\System\Core\Session::class) && \System\Core\Session::hasCookie()) {
      try {
        $sess = \Config\Services::session();
        $v = $sess->get('lang');
        if (is_string($v) && trim($v) !== '') $candidate = $v;
      } catch (\Throwable) {
        // ignore
      }
    }

    $candidate = strtolower(trim($candidate));
    if ($candidate !== '') {
      // match exact o por prefijo (es-PE -> es)
      $pick = '';
      foreach ($supported as $s) {
        $s2 = strtolower((string)$s);
        if ($s2 === $candidate) { $pick = (string)$s; break; }
      }
      if ($pick === '') {
        $base = explode('-', $candidate, 2)[0];
        foreach ($supported as $s) {
          $s2 = strtolower((string)$s);
          if ($s2 === $base) { $pick = (string)$s; break; }
        }
      }

      if ($pick !== '') {
        // setLocale() ya sincroniza Request + Lang
        if (method_exists($request, 'setLocale')) {
          $request->setLocale($pick);
        }
      }
    }

    return null;
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }
}
