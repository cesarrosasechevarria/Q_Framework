<?php
declare(strict_types=1);

namespace App\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;
use System\Core\Session;

/**
 * AuthFilter (lazy-session)
 *
 * - Solo inicia sesión cuando se ejecuta este filtro.
 * - Por defecto busca session('user') creado por Modules\Auth\Support\Auth.
 * - Si no hay usuario, redirige a route 'auth.login' o al redirect indicado.
 */
final class AuthFilter implements FilterInterface
{
  private array $args = [];

  public function setArgs(array $args): void
  {
    $this->args = $args;
  }

  public function before(Request $request, Response $response): ?Response
  {
    // 🔒 Este filtro es "opt-in". Si lo usas, se permite iniciar sesión.
    Session::ensureStarted();
    $s = new Session();

    $u = $s->get('user');
    if (is_array($u) && !empty($u['id'])) {
      return null;
    }

    $redir = $this->args['redirect'] ?? null;
    if (!is_string($redir) || trim($redir) === '') {
      // si existe route auth.login, úsala; sino home.
      try {
        $redir = route_url('auth.login');
      } catch (\Throwable $e) {
        $redir = route_url('home');
      }
    }

    return $response->redirect((string)$redir, 302);
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }
}
