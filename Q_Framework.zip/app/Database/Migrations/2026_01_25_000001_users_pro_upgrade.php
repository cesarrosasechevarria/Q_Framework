<?php
declare(strict_types=1);

use System\Database\Migrations\MigrationInterface;
use System\Database\Connection;

/**
 * Users table (PRO)
 * - Compatible con esquemas antiguos (username/email/active) y lo normaliza a:
 *   users(id, name, email, password_hash, role, active, created_at, updated_at)
 */
return new class implements MigrationInterface {

  /** @return array<string,bool> */
  private function cols(Connection $db, string $table): array
  {
    $out = [];
    foreach ($db->getFieldData($table) as $c) {
      $n = strtolower((string)($c['name'] ?? ''));
      if ($n !== '') $out[$n] = true;
    }
    return $out;
  }

  private function hasIndex(Connection $db, string $table, string $indexName): bool
  {
    try {
      $rows = $db->query("SHOW INDEX FROM `{$table}`")->all();
      foreach ($rows as $r) {
        if (strtolower((string)($r['Key_name'] ?? '')) === strtolower($indexName)) return true;
      }
      return false;
    } catch (\Throwable $e) {
      return false;
    }
  }

  public function up(Connection $db): void
  {
    if (!$db->tableExists('users')) {
      $db->query("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(120) NOT NULL,
        email VARCHAR(190) NOT NULL,
        password_hash VARCHAR(255) NULL,
        role VARCHAR(30) NOT NULL DEFAULT 'user',
        active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NULL,
        updated_at DATETIME NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $db->query("CREATE UNIQUE INDEX ux_users_email ON users (email)");
      return;
    }

    $cols = $this->cols($db, 'users');

    // Renombra username -> name si aplica
    if (isset($cols['username']) && !isset($cols['name'])) {
      $db->query("ALTER TABLE users CHANGE `username` `name` VARCHAR(120) NOT NULL");
      $cols = $this->cols($db, 'users');
    }

    // Si no existe name, lo añade (NULL para compat si hay data)
    if (!isset($cols['name'])) {
      $db->query("ALTER TABLE users ADD COLUMN `name` VARCHAR(120) NULL");
      $cols = $this->cols($db, 'users');
      // Intento best-effort: si había username y no se renombró, copia
      if (isset($cols['username'])) {
        $db->query("UPDATE users SET name = username WHERE name IS NULL");
      }
      // lo deja NOT NULL solo si no hay filas (evita fallas)
      $cnt = (int)($db->query("SELECT COUNT(*) c FROM users")->first()['c'] ?? 0);
      if ($cnt === 0) {
        $db->query("ALTER TABLE users MODIFY `name` VARCHAR(120) NOT NULL");
      }
    }

    if (!isset($cols['email'])) {
      $db->query("ALTER TABLE users ADD COLUMN `email` VARCHAR(190) NULL");
    }

    if (!isset($cols['password_hash'])) {
      $db->query("ALTER TABLE users ADD COLUMN `password_hash` VARCHAR(255) NULL");
    }

    if (!isset($cols['role'])) {
      $db->query("ALTER TABLE users ADD COLUMN `role` VARCHAR(30) NOT NULL DEFAULT 'user'");
    }

    if (!isset($cols['active'])) {
      $db->query("ALTER TABLE users ADD COLUMN `active` TINYINT(1) NOT NULL DEFAULT 1");
    }

    if (!isset($cols['created_at'])) {
      $db->query("ALTER TABLE users ADD COLUMN `created_at` DATETIME NULL");
    }

    if (!isset($cols['updated_at'])) {
      $db->query("ALTER TABLE users ADD COLUMN `updated_at` DATETIME NULL");
    }

    // Índice único email (si ya existe con otro nombre, no lo duplicamos)
    if (!$this->hasIndex($db, 'users', 'ux_users_email')) {
      // Si existe alguna llave única en email, detecta y omite
      $hasAnyUniqueEmail = false;
      try {
        $idx = $db->query("SHOW INDEX FROM `users`")->all();
        foreach ($idx as $r) {
          $col = strtolower((string)($r['Column_name'] ?? ''));
          $nonUnique = (string)($r['Non_unique'] ?? '');
          if ($col === 'email' && $nonUnique === '0') { $hasAnyUniqueEmail = true; break; }
        }
      } catch (\Throwable $e) {}

      if (!$hasAnyUniqueEmail) {
        // Limpia duplicados de email si existen (best-effort) -> conserva el menor id
        try {
          $db->query("DELETE u1 FROM users u1
            INNER JOIN users u2
              ON u1.email = u2.email AND u1.id > u2.id
            WHERE u1.email IS NOT NULL AND u1.email <> ''");
        } catch (\Throwable $e) {}
        $db->query("CREATE UNIQUE INDEX ux_users_email ON users (email)");
      }
    }
  }

  public function down(Connection $db): void
  {
    $db->query("DROP TABLE IF EXISTS users");
  }
};
