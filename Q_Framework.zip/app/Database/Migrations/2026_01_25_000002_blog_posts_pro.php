<?php
declare(strict_types=1);

use System\Database\Migrations\MigrationInterface;
use System\Database\Connection;

/**
 * blog_posts table (PRO examples)
 * - Esquema final:
 *   blog_posts(id, title, slug, content, author_id, created_at, updated_at)
 * - Compatible con esquemas alternativos (body/user_id) y los normaliza.
 */
return new class implements MigrationInterface {

  /** @return array<string,bool> */
  private function cols(Connection $db, string $table): array
  {
    $out = [];
    foreach ($db->getFieldData($table) as $c) {
      $n = strtolower((string)($c['name'] ?? ''));
      if ($n !== '') $out[$n] = true;
    }
    return $out;
  }

  private function hasIndex(Connection $db, string $table, string $indexName): bool
  {
    try {
      $rows = $db->query("SHOW INDEX FROM `{$table}`")->all();
      foreach ($rows as $r) {
        if (strtolower((string)($r['Key_name'] ?? '')) === strtolower($indexName)) return true;
      }
      return false;
    } catch (\Throwable $e) {
      return false;
    }
  }

  public function up(Connection $db): void
  {
    if (!$db->tableExists('blog_posts')) {
      $db->query("CREATE TABLE IF NOT EXISTS blog_posts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(140) NOT NULL,
        slug VARCHAR(190) NOT NULL,
        content LONGTEXT NULL,
        author_id INT NULL,
        created_at DATETIME NULL,
        updated_at DATETIME NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $db->query("CREATE UNIQUE INDEX ux_blog_posts_slug ON blog_posts (slug)");
      $db->query("CREATE INDEX ix_blog_posts_author ON blog_posts (author_id)");
      return;
    }

    $cols = $this->cols($db, 'blog_posts');

    // body -> content
    if (isset($cols['body']) && !isset($cols['content'])) {
      $db->query("ALTER TABLE blog_posts CHANGE `body` `content` LONGTEXT NULL");
      $cols = $this->cols($db, 'blog_posts');
    }

    // user_id -> author_id
    if (isset($cols['user_id']) && !isset($cols['author_id'])) {
      $db->query("ALTER TABLE blog_posts CHANGE `user_id` `author_id` INT NULL");
      $cols = $this->cols($db, 'blog_posts');
    }

    if (!isset($cols['title'])) {
      $db->query("ALTER TABLE blog_posts ADD COLUMN `title` VARCHAR(140) NULL");
    }
    if (!isset($cols['slug'])) {
      $db->query("ALTER TABLE blog_posts ADD COLUMN `slug` VARCHAR(190) NULL");
    }
    if (!isset($cols['content'])) {
      $db->query("ALTER TABLE blog_posts ADD COLUMN `content` LONGTEXT NULL");
    }
    if (!isset($cols['author_id'])) {
      $db->query("ALTER TABLE blog_posts ADD COLUMN `author_id` INT NULL");
    }
    if (!isset($cols['created_at'])) {
      $db->query("ALTER TABLE blog_posts ADD COLUMN `created_at` DATETIME NULL");
    }
    if (!isset($cols['updated_at'])) {
      $db->query("ALTER TABLE blog_posts ADD COLUMN `updated_at` DATETIME NULL");
    }

    if (!$this->hasIndex($db, 'blog_posts', 'ux_blog_posts_slug')) {
      // Si ya hay unique en slug con otro nombre, no lo duplicamos
      $hasAnyUniqueSlug = false;
      try {
        $idx = $db->query("SHOW INDEX FROM `blog_posts`")->all();
        foreach ($idx as $r) {
          $col = strtolower((string)($r['Column_name'] ?? ''));
          $nonUnique = (string)($r['Non_unique'] ?? '');
          if ($col === 'slug' && $nonUnique === '0') { $hasAnyUniqueSlug = true; break; }
        }
      } catch (\Throwable $e) {}

      if (!$hasAnyUniqueSlug) {
        // best-effort: elimina duplicados de slug
        try {
          $db->query("DELETE p1 FROM blog_posts p1
            INNER JOIN blog_posts p2
              ON p1.slug = p2.slug AND p1.id > p2.id
            WHERE p1.slug IS NOT NULL AND p1.slug <> ''");
        } catch (\Throwable $e) {}
        $db->query("CREATE UNIQUE INDEX ux_blog_posts_slug ON blog_posts (slug)");
      }
    }

    if (!$this->hasIndex($db, 'blog_posts', 'ix_blog_posts_author')) {
      $db->query("CREATE INDEX ix_blog_posts_author ON blog_posts (author_id)");
    }
  }

  public function down(Connection $db): void
  {
    $db->query("DROP TABLE IF EXISTS blog_posts");
  }
};
