<?php
declare(strict_types=1);

use System\Database\Migrations\MigrationInterface;
use System\Database\Connection;

return new class implements MigrationInterface {
  public function up(Connection $db): void
  {
    $db->query("CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(80) NOT NULL,
      email VARCHAR(160) NOT NULL,
      active TINYINT(1) NOT NULL DEFAULT 1,
      created_at DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  }

  public function down(Connection $db): void
  {
    $db->query("DROP TABLE IF EXISTS users");
  }
};
