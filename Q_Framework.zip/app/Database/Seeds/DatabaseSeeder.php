<?php
declare(strict_types=1);

namespace App\Database\Seeds;

use System\Database\Connection;
use System\Database\Seeds\SeederInterface;

/**
 * DatabaseSeeder
 *
 * Ejecuta seeders de demo para que puedas probar el framework de inmediato.
 *
 * Comandos sugeridos:
 *  php bin/console migrate
 *  php bin/console seed DatabaseSeeder
 *
 * Credenciales demo:
 *  - admin@example.com / Admin123! (role admin)
 *  - user@example.com  / User123!  (role user)
 */
final class DatabaseSeeder implements SeederInterface
{
  public function run(Connection $db): void
  {
    (new UserSeeder())->run($db);
    (new PostSeeder())->run($db);
  }
}
