<?php
declare(strict_types=1);

namespace App\Database\Seeds;

use System\Database\Connection;
use System\Database\Seeds\SeederInterface;

/**
 * PostSeeder (PRO examples)
 *
 * Crea posts de prueba para:
 *  - /blog (CRUD)
 *  - /api/v1/posts (paginado JSON)
 */
final class PostSeeder implements SeederInterface
{
  public function run(Connection $db): void
  {
    $now = date('Y-m-d H:i:s');

    // Limpia (solo demo)
    try { $db->query('DELETE FROM blog_posts'); } catch (\Throwable $e) {}

    // Para que los ids queden bonitos en demo (best-effort)
    try { $db->query('ALTER TABLE blog_posts AUTO_INCREMENT = 1'); } catch (\Throwable $e) {}

    $rows = [
      [
        'author_id' => 1,
        'title' => 'Bienvenido a Q_Framework',
        'slug' => 'bienvenido-q-framework',
        'content' => "Este post es de ejemplo.\n\n- Edita /app/Modules/Blog para tu proyecto.\n- Prueba el CRUD: /blog\n- Prueba API: /api/v1/posts",
        'created_at' => $now,
        'updated_at' => $now,
      ],
      [
        'author_id' => 1,
        'title' => 'Guards, Filters y Rutas PRO',
        'slug' => 'guards-filters-rutas-pro',
        'content' => "Ejemplos listos:\n\n✅ /admin con Guard role-based\n✅ /api/v1 con token + rate-limit\n✅ /demo con filtro configurable por ruta",
        'created_at' => $now,
        'updated_at' => $now,
      ],
      [
        'author_id' => 1,
        'title' => 'API v1: Token + Rate Limit',
        'slug' => 'api-v1-token-rate-limit',
        'content' => "Prueba /api/v1/ping con:\nAuthorization: Bearer demo_token\n\nAjusta tokens en .env con API_TOKENS=demo_token,otro_token",
        'created_at' => $now,
        'updated_at' => $now,
      ],
    ];

    foreach ($rows as $r) {
      $db->table('blog_posts')->insert($r);
    }
  }
}
