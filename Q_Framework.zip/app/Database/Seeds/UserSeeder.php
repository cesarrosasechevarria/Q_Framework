<?php
declare(strict_types=1);

namespace App\Database\Seeds;

use System\Database\Connection;
use System\Database\Seeds\SeederInterface;

/**
 * UserSeeder (PRO examples)
 *
 * Crea usuarios de prueba para:
 *  - /auth/login
 *  - /admin (requiere role admin/superadmin)
 */
final class UserSeeder implements SeederInterface
{
  public function run(Connection $db): void
  {
    $now = date('Y-m-d H:i:s');

    // Limpia (solo demo)
    try { $db->query('DELETE FROM users'); } catch (\Throwable $e) {}

    // Para demo: reset ids (best-effort)
    try { $db->query('ALTER TABLE users AUTO_INCREMENT = 1'); } catch (\Throwable $e) {}

    $db->table('users')->insert([
      'name' => 'Admin',
      'email' => 'admin@example.com',
      'password_hash' => password_hash('Admin123!', PASSWORD_DEFAULT),
      'role' => 'admin',
      'created_at' => $now,
      'updated_at' => $now,
    ]);

    $db->table('users')->insert([
      'name' => 'User',
      'email' => 'user@example.com',
      'password_hash' => password_hash('User123!', PASSWORD_DEFAULT),
      'role' => 'user',
      'created_at' => $now,
      'updated_at' => $now,
    ]);
  }
}
