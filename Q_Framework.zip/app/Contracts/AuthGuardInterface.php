<?php
declare(strict_types=1);

namespace App\Contracts;

/**
 * AuthGuardInterface (mínimo)
 *
 * Propósito:
 * - Evitar acople a una implementación estática específica (módulo Auth).
 * - Definir un contrato estable para plugins (RBAC, admin, APIs) que necesiten
 *   consultar al usuario autenticado.
 */
interface AuthGuardInterface
{
  public function check(): bool;
  public function user(): ?array;
  public function id(): ?int;

  /**
   * Login.
   *
   * Firma flexible:
   * - login(array $user)
   * - login(int $id, array $user)
   */
  public function login(int|array $idOrUser, ?array $user = null): void;

  public function logout(): void;
  public function hasRole(string $role): bool;
}
