<?php
declare(strict_types=1);

namespace App\Contracts;

/**
 * MailerInterface (mínimo)
 *
 * Propósito:
 * - Desacoplar tu app del transporte real (mail(), SMTP, API externa).
 * - Permitir que los módulos envíen correo usando un contrato estable.
 */
interface MailerInterface
{
  /**
   * Envía un correo HTML.
   *
   * @param string $to Destinatario.
   * @param string $subject Asunto.
   * @param string $html Cuerpo HTML.
   * @param array<string,string> $headers Cabeceras extra.
   */
  public function send(string $to, string $subject, string $html, array $headers = []): bool;
}
