<?php
declare(strict_types=1);

namespace App\Contracts;

/**
 * LoggerInterface (mínimo)
 *
 * Propósito:
 * - No amarrar módulos/capas a System\Core\Logger (estático).
 * - Permitir reemplazo por cualquier logger (archivo, syslog, cloud) sin tocar el core.
 *
 * Nota:
 * - Contrato deliberadamente pequeño.
 */
interface LoggerInterface
{
  /** Nivel libre (INFO/WARN/ERROR/DEBUG...) según tu implementación. */
  public function log(string $level, string $message, array $context = []): void;

  public function info(string $message, array $context = []): void;
  public function warn(string $message, array $context = []): void;
  public function error(string $message, array $context = []): void;
}
