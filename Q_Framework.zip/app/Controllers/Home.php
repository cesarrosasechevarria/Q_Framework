<?php
declare(strict_types=1);

namespace App\Controllers;

final class Home extends BaseController
{
  protected array $helpers = ['url'];

  public function index()
  {

  echo validador_encriptar("hola");
  echo " ";
  echo json_encode(validador_email("cesarrosasechevarria@gmail.com"));
  echo " ";
  echo json_encode(Validador_phone("962508690","PE"));
  }
}
