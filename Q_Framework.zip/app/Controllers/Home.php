<?php
declare(strict_types=1);

namespace App\Controllers;

final class Home extends BaseController
{
  protected array $helpers = ['url'];

  public function index()
  {
    $app = config('App');
    $sec = config('Security');
    $ten = config('Tenancy');

    $env        = (string) env('APP_ENV', (string)($app->environment ?? 'production'));
    $debug      = (bool) env_bool('APP_DEBUG', (bool)($app->debug ?? false));
    $routeCache = (bool) env_bool('ROUTE_CACHE', (bool)($app->routeCache ?? false));

    $baseCfg      = (string)($app->baseURL ?? '');
    $baseDetected = base_url('/');

    $appKey = (string) env('APP_KEY', '');
    $appKeyOk = ($appKey !== '' && strlen($appKey) >= 16);
    $appKeyInfo = ($appKey !== '' ? ('len=' . strlen($appKey)) : 'vacío');

    $envFile = base_path('.env');
    $envExample = base_path('.env.example');

    $script = (string)($_SERVER['SCRIPT_FILENAME'] ?? '');
    $scriptReal = $script !== '' ? realpath($script) : false;
    $publicReal = defined('PUBLICPATH') ? realpath((string)PUBLICPATH) : realpath(base_path('public'));
    $modePublic = ($scriptReal && $publicReal) ? (str_starts_with($scriptReal, rtrim($publicReal, '/\\') . DIRECTORY_SEPARATOR)) : false;

    $checks = [];

    // .env
    $checks[] = [
      'label' => '.env',
      'status' => is_file($envFile) ? 'ok' : 'warn',
      'info' => is_file($envFile) ? $envFile : 'No existe',
      'fix' => is_file($envExample) ? 'Copia .env.example a .env y edítalo.' : 'Crea un archivo .env en la raíz del proyecto.',
    ];

    // APP_KEY
    $checks[] = [
      'label' => 'APP_KEY',
      'status' => $appKeyOk ? 'ok' : 'fail',
      'info' => $appKeyInfo,
      'fix' => 'Genera una key segura: APP_KEY=base64:' . '<span style="opacity:.75">...</span>' . ' (recomendado 32 bytes).<br><code>php -r "echo \'base64:\'.base64_encode(random_bytes(32));"</code>',
    ];

    // DocumentRoot
    $checks[] = [
      'label' => 'DocumentRoot',
      'status' => $modePublic ? 'ok' : 'warn',
      'info' => $modePublic ? 'public/ (recomendado)' : 'root (usa Setup sin /public)',
      'fix' => $modePublic ? 'OK. En producción mantén DocumentRoot apuntando a <code>public/</code>.' : 'Si no puedes cambiar DocumentRoot, usa <a href="' . base_url('/setup/publicless') . '">Setup (public-less)</a>.',
    ];

    // Writable dirs
    foreach ([
      'write' => base_path('write'),
      'storage' => base_path('storage'),
      'storage/cache' => base_path('storage/cache'),
    ] as $k => $dir) {
      $ok = is_dir($dir) && is_writable($dir);
      $checks[] = [
        'label' => 'writable:' . $k,
        'status' => $ok ? 'ok' : 'fail',
        'info' => $dir,
        'fix' => $ok ? 'OK' : 'Crea la carpeta y otorga permisos de escritura (Apache/PHP).',
      ];
    }

    // Composer (opcional)
    $vendorAutoload = base_path('vendor/autoload.php');
    $checks[] = [
      'label' => 'vendor/autoload.php (opcional)',
      'status' => is_file($vendorAutoload) ? 'ok' : 'warn',
      'info' => is_file($vendorAutoload) ? $vendorAutoload : 'No encontrado',
      'fix' => 'Recomendado: <code>composer install</code>. (Opcional: autoload manual del starter).',
    ];

    // Route cache
    $cacheFile = base_path('storage/cache/routes.' . $env . '.php');
    $hasCache = is_file($cacheFile);
    $checks[] = [
      'label' => 'routes cache',
      'status' => $routeCache ? ($hasCache ? 'ok' : 'warn') : ($hasCache ? 'ok' : 'ok'),
      'info' => $cacheFile,
      'fix' => $routeCache ? ($hasCache ? 'OK' : 'Genera cache: <code>php bin/console route:cache</code>') : 'Opcional. Activa <code>ROUTE_CACHE=1</code> en producción.',
    ];

    // Tenancy
    $tenantEnabled = !empty($ten->enabled);
    $checks[] = [
      'label' => 'Tenancy',
      'status' => $tenantEnabled ? 'ok' : 'ok',
      'info' => $tenantEnabled ? ('enabled · strategy=' . (string)($ten->strategy ?? 'auto')) : 'disabled',
      'fix' => 'Si tu sistema será multi-empresa: activa <code>TENANCY_ENABLED=1</code> y define la estrategia (subdomain/header/query/path).',
    ];

    $counts = ['ok' => 0, 'warn' => 0, 'fail' => 0];
    foreach ($checks as $c) {
      $s = $c['status'] ?? 'ok';
      if (isset($counts[$s])) $counts[$s]++;
    }

    $data = [
      'title'        => 'Q_Framework · Bienvenido',
      'date'         => date('Y-m-d H:i:s'),
      'env'          => $env,
      'debug'        => $debug,
      'routeCache'   => $routeCache,
      'baseCfg'      => $baseCfg,
      'baseDetected' => $baseDetected,
      'appKeyOk'     => $appKeyOk,
      'checks'       => $checks,
      'counts'       => $counts,
      'phpVersion'   => PHP_VERSION,
      'tenantId'     => class_exists('System\\Core\\Tenant') ? \System\Core\Tenant::id() : 'default',
      'csrfEnabled'  => !empty($sec->csrfEnabled),
      'csrfStorage'  => (string)($sec->csrfStorage ?? 'cookie'),
    ];

    return $this->response->html(view('home', $data, 'layout'));
  }
}
