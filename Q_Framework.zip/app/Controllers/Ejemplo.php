<?php
declare(strict_types=1);

namespace App\Controllers;



final class Ejemplo extends BaseController
{
    private $tabla;
    public function __construct()
    {

      $schema = service('schema');
      
      $schema->ensure('usuarios', [
          ['nombre'=>'nombre','type'=>'VARCHAR','max_length'=>120,'nullable'=>false],
          ['nombre'=>'email','type'=>'VARCHAR','max_length'=>120,'nullable'=>false,'unique'=>true],
          ['nombre'=>'meta','type'=>'JSON','nullable'=>true],
      ], [
          'alter'        => true,
          'base_columns' => false,
      ]);

      $this->tabla = service('crud')->table('usuarios');

    }
      
    protected array $helpers = ['url'];

    public function index()
    {
      
      echo "Hola mundo";

      $r = $this->tabla->createResult(['nombre'=>'nombre1']);

      if (!$r->ok) {
        //service('logger')->error('DB error', $r->toArray());

        if (($r->state ?? '') === '23000') {
          return service('response')->json(['ok'=>false,'message'=>'Email duplicado'], 409);
        }

        return service('response')->json(['ok'=>false,'message'=>'No se pudo registrar'], 500);
      }

      return service('response')->json(['ok'=>true,'data'=>$r->toArray()], 201);


    }
}
