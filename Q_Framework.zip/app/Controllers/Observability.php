<?php
declare(strict_types=1);

namespace App\Controllers;

final class Observability extends BaseController
{
  public function metrics()
  {
    $cfg = \config('Observability');
    if (empty($cfg->exposeMetricsEndpoint)) {
      return $this->response->setStatus(404)->html('Not found');
    }

    // Opcional: token
    $token = (string)($cfg->metricsToken ?? '');
    if ($token !== '') {
      $h = (string)($this->request->header('X-Metrics-Token') ?? '');
      $q = (string)($this->request->query('token', '') ?? '');
      if (!hash_equals($token, $h) && !hash_equals($token, $q)) {
        return $this->response->setStatus(401)->html('Unauthorized');
      }
    }

    $txt = \System\Observability\Metrics::renderPrometheus();
    return $this->response
      ->html($txt)
      ->header('Content-Type', 'text/plain; version=0.0.4; charset=UTF-8');
  }
}
