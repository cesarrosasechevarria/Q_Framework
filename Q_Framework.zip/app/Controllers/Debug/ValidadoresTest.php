<?php
declare(strict_types=1);

namespace App\Controllers\Debug;

use App\Controllers\BaseController;

final class ValidadoresTest extends BaseController
{
  public function index()
  {
    helper('validadores');

    $cases = [];

    // 1) Encriptar / desencriptar (texto)
    $valor = 'Valor de prueba: ' . date('c');
    $enc = validador_encriptar($valor);
    $dec = validador_desencriptar($enc);
    $cases[] = [
      'Encriptar -> Desencriptar (texto)',
      $valor,
      $enc,
      $dec,
      ($dec === $valor)
    ];

    // 2) Encriptar / desencriptar (array JSON)
    $arr = ['a'=>1,'b'=>'hola','t'=>time()];
    $enc2 = validador_encriptar($arr);
    $dec2 = validador_desencriptar($enc2, true);
    $cases[] = [
      'Encriptar -> Desencriptar (array JSON)',
      json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
      $enc2,
      json_encode($dec2, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
      (is_array($dec2) && ($dec2['a'] ?? null) === 1)
    ];

    // 3) Email
    [$okEmail, $msgEmail] = Validador_email('test@example.com');
    $cases[] = ['Validador_email', 'test@example.com', $msgEmail, $okEmail ? 'OK' : 'FAIL', (bool)$okEmail];

    // 4) Phone
    [$okPh, $msgPh] = Validador_phone('+51 947 422 276', 'PE');
    $cases[] = ['Validador_phone', '+51 947 422 276 (PE)', $msgPh, $okPh ? 'OK' : 'FAIL', (bool)$okPh];

    // 5) Frase (palabra prohibida)
    $found = Validador_frase('hola cabron');
    $cases[] = ['Validador_frase (detecta palabra)', 'hola cabron', $found === false ? 'ninguna' : (string)$found, $found ? 'DETECTADO' : 'OK', ($found !== false)];

    // 6) Base64
    $b64 = base64_encode('abc123');
    $cases[] = ['validador_base64', $b64, 'base64_encode(abc123)', validador_base64($b64) ? 'true' : 'false', validador_base64($b64) === true];

    // 7) JSON
    $json = '{"x":1,"y":"z"}';
    $cases[] = ['validador_isjson', $json, 'string JSON', validador_isjson($json) ? 'true' : 'false', validador_isjson($json) === true];

    // 8) dias2fechas (2 fechas -> diff)
    $diff = validador_dias2fechas('2026-01-01', '2026-01-25');
    $cases[] = ['validador_dias2fechas (diff)', '2026-01-01 / 2026-01-25', 'diferencia días', (string)$diff, ($diff === 24)];

    // 9) dias2fechas (días -> fecha)
    $fecha = validador_dias2fechas(10);
    $cases[] = ['validador_dias2fechas (sumar)', '10', 'hoy + 10 días', (string)$fecha, (is_string($fecha) && strlen($fecha) === 10)];

    // 10) ocultar letras
    $oc = validador_ocultarletras('ABCDEFGHIJK');
    $cases[] = ['validador_ocultarletras', 'ABCDEFGHIJK', 'ocultar 1/4 - 1/4', (string)$oc, (is_string($oc) && str_contains($oc, '*'))];

    // 11) minificar
    $mini = validador_minificar("  a   b   c  ");
    $cases[] = ['validador_minificar (ligero)', '"  a   b   c  "', 'colapsar espacios', (string)$mini, ($mini === 'a b c')];

    // 12) verificar valores
    $cases[] = ['validador_verificarValores', 'a,b', 'comparador=[a,b,c]', validador_verificarValores('a,b', ['a','b','c']) ? 'true' : 'false', validador_verificarValores('a,b', ['a','b','c']) === true];

    // 13) existe en string
    $ex = validador_existeenstring('hola', 'Hola Mundo');
    $cases[] = ['validador_existeenstring', 'hola in "Hola Mundo"', 'case-insensitive', $ex ? 'true' : 'false', $ex === true];

    // 14) buscar string (csv)
    $bs = validador_buscarstring('a,b,c', 'b');
    $cases[] = ['validador_buscarstring', 'a,b,c buscar b', 'csv -> array', $bs ? 'true' : 'false', $bs === true];

    // 15) sin tildes
    $st = validador_sintildes('áéíóú Ñ');
    $cases[] = ['validador_sintildes', 'áéíóú Ñ', 'normalización', $st, ($st === 'aeiou N')];

    // 16) imagen por extensión
    $ie = validador_imagen_por_extension('foto.JPG');
    $cases[] = ['validador_imagen_por_extension', 'foto.JPG', 'ext -> imagen', $ie ? 'true' : 'false', $ie === true];

    // 17) es imagen (por MIME)
    $ei = validador_esimagen('image/png');
    $cases[] = ['validador_esimagen', 'image/png', 'mime contains image/', $ei ? 'true' : 'null', $ei === true];

    // 18) isurl
    $iu = validador_isurl('https://example.com');
    $cases[] = ['validador_isurl', 'https://example.com', 'FILTER_VALIDATE_URL', $iu ? 'true' : 'null', $iu === true];

    // 19) minificar HTML (legado)
    $mh = validador_minificarHTML("<div>  a  </div>\n<span>  b </span>");
    $cases[] = ['validador_minificarHTML', '<div>  a  </div> <span>  b </span>', 'minify html', $mh, (is_string($mh) && str_contains($mh, '<div>'))];

    // 20) DispMobil (depende del User-Agent)
    $dm = validador_DispMobil();
    $cases[] = ['validador_DispMobil', 'HTTP_USER_AGENT', 'heurística', $dm ? 'true' : 'false', is_bool($dm)];

    // Render
    $rows = '';
    foreach ($cases as $c) {
      [$name, $in, $step, $out, $ok] = $c;
      $rows .= '<tr>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08)"><b>' . htmlspecialchars((string)$name, ENT_QUOTES, 'UTF-8') . '</b></td>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08)"><code>' . htmlspecialchars((string)$in, ENT_QUOTES, 'UTF-8') . '</code></td>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08);opacity:.9">' . htmlspecialchars((string)$step, ENT_QUOTES, 'UTF-8') . '</td>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08)"><code style="white-space:pre-wrap">' . htmlspecialchars((string)$out, ENT_QUOTES, 'UTF-8') . '</code></td>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08);font-weight:800">' . ($ok ? '✅' : '❌') . '</td>'
        . '</tr>';
    }

    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      . '<title>Validadores Test</title>'
      . '<style>body{margin:0;background:#0b1220;color:#e8eefc;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial}main{max-width:1200px;margin:0 auto;padding:24px}h1{font-size:22px;margin:0 0 6px}p{opacity:.9;margin:0 0 14px}a{color:#9ad6ff}table{width:100%;border-collapse:collapse;border:1px solid rgba(255,255,255,.08);border-radius:14px;overflow:hidden}th{background:rgba(255,255,255,.06);text-align:left;padding:10px}code{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:8px}</style>'
      . '</head><body><main>'
      . '<h1>Validadores — Test Secuencial</h1>'
      . '<p>Ruta: <code>/debug/validadores-test</code> · <a href="' . base_url('/debug/doctor') . '">Doctor</a></p>'
      . '<table><thead><tr><th>Test</th><th>Input</th><th>Proceso</th><th>Output</th><th>OK</th></tr></thead><tbody>'
      . $rows
      . '</tbody></table>'
      . '</main></body></html>';

    return response()->html($html);
  }
}
