<?php
declare(strict_types=1);

namespace App\Controllers\Debug;

use App\Controllers\BaseController;

final class Doctor extends BaseController
{
  protected array $helpers = ['url'];

  private function iniBytes(string $val): int
  {
    $v = trim($val);
    if ($v === '') return 0;
    if ($v === '-1') return PHP_INT_MAX;
    $num = (float)$v;
    $unit = strtolower(substr($v, -1));
    if (in_array($unit, ['g','m','k'], true)) {
      $num = (float)substr($v, 0, -1);
      if ($unit === 'g') return (int)($num * 1024 * 1024 * 1024);
      if ($unit === 'm') return (int)($num * 1024 * 1024);
      if ($unit === 'k') return (int)($num * 1024);
    }
    return (int)$num;
  }

  private function mk(string $label, bool $cond, string $info = '', string $fix = '', string $failStatus = 'fail'): array
  {
    return [
      'label' => $label,
      'status' => $cond ? 'ok' : $failStatus,
      'info' => $info,
      'fix' => $cond ? 'OK' : $fix,
    ];
  }

  public function index()
  {
    $app = config('App');
    $sec = config('Security');
    $ses = config('Session');
    $ten = config('Tenancy');

    $env        = (string) env('APP_ENV', (string)($app->environment ?? 'production'));
    $debug      = (bool) env_bool('APP_DEBUG', (bool)($app->debug ?? false));
    $routeCache = (bool) env_bool('ROUTE_CACHE', (bool)($app->routeCache ?? false));

    $baseCfg      = (string)($app->baseURL ?? '');
    $baseDetected = base_url('/');

    $sections = [];

    // ===== Core
    $core = [];
    $core[] = ['label' => 'APP_ENV', 'status' => 'ok', 'info' => $env, 'fix' => ''];
    $core[] = ['label' => 'APP_DEBUG', 'status' => ($env === 'production' && $debug) ? 'warn' : 'ok', 'info' => $debug ? 'true' : 'false', 'fix' => ($env === 'production' && $debug) ? 'En producción recomienda: APP_DEBUG=0' : ''];
    $core[] = ['label' => 'BaseURL (config)', 'status' => ($baseCfg !== '' ? 'ok' : 'warn'), 'info' => ($baseCfg !== '' ? $baseCfg : '(vacío)'), 'fix' => 'Configura baseURL en .env o app/Config/App.php'];
    $core[] = ['label' => 'BaseURL (detectada)', 'status' => 'ok', 'info' => $baseDetected, 'fix' => ''];
    $core[] = ['label' => 'Timezone', 'status' => 'ok', 'info' => (string)date_default_timezone_get(), 'fix' => ''];
    $sections[] = ['title' => 'Core', 'checks' => $core];

    // ===== Paths & permisos
    $paths = [];
    $paths[] = $this->mk('ROOTPATH', defined('ROOTPATH'), defined('ROOTPATH') ? (string)ROOTPATH : base_path(), 'Constante ROOTPATH no definida (bootstrap).', 'warn');
    $paths[] = $this->mk('PUBLICPATH', defined('PUBLICPATH'), defined('PUBLICPATH') ? (string)PUBLICPATH : base_path('public'), 'Constante PUBLICPATH no definida (bootstrap).', 'warn');
    $paths[] = $this->mk('WRITEPATH', defined('WRITEPATH'), defined('WRITEPATH') ? (string)WRITEPATH : base_path('write'), 'Constante WRITEPATH no definida (bootstrap).', 'warn');

    foreach ([
      'write' => base_path('write'),
      'storage' => base_path('storage'),
      'storage/cache' => base_path('storage/cache'),
    ] as $k => $dir) {
      $ok = is_dir($dir) && is_writable($dir);
      $paths[] = $this->mk('writable:' . $k, $ok, $dir, 'Crea la carpeta y otorga permisos de escritura (Apache/PHP).');
    }

    // htaccess presence
    $rootHt = base_path('.htaccess');
    $pubHt  = base_path('public/.htaccess');
    $paths[] = $this->mk('.htaccess (root, public-less)', is_file($rootHt), is_file($rootHt) ? $rootHt : 'No existe', 'Opcional: útil cuando NO puedes apuntar DocumentRoot a public/.', 'warn');
    $paths[] = $this->mk('.htaccess (public)', is_file($pubHt), is_file($pubHt) ? $pubHt : 'No existe', 'Recomendado para Apache + URLs limpias (public/).', 'warn');

    $sections[] = ['title' => 'Paths & permisos', 'checks' => $paths];

    // ===== PHP runtime
    $php = [];
    $php[] = $this->mk('PHP >= 8.1', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION, 'Actualiza PHP a 8.1+ (recomendado 8.2/8.3).');
    $php[] = ['label' => 'SAPI', 'status' => 'ok', 'info' => (string)php_sapi_name(), 'fix' => ''];
    $php[] = ['label' => 'OS', 'status' => 'ok', 'info' => (string)PHP_OS_FAMILY, 'fix' => ''];

    // Extensions (requeridas / recomendadas)
    $reqExt = ['openssl','json','pdo'];
    foreach ($reqExt as $ext) {
      $php[] = $this->mk('ext:' . $ext, extension_loaded($ext), extension_loaded($ext) ? 'loaded' : 'missing', 'Habilita la extensión ' . $ext . ' en php.ini.');
    }
    // pdo_mysql recomendado (si usas MySQL)
    $php[] = $this->mk('ext:pdo_mysql (MySQL)', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? 'loaded' : 'missing', 'Si usarás MySQL, habilita pdo_mysql en php.ini.', 'warn');

    // ini
    $up = ini_get('upload_max_filesize') ?: '';
    $post = ini_get('post_max_size') ?: '';
    $mem = ini_get('memory_limit') ?: '';
    $php[] = ['label' => 'upload_max_filesize', 'status' => 'ok', 'info' => $up, 'fix' => ''];
    $php[] = ['label' => 'post_max_size', 'status' => 'ok', 'info' => $post, 'fix' => ''];
    $php[] = ['label' => 'memory_limit', 'status' => 'ok', 'info' => $mem, 'fix' => ''];

    // coherencia upload/post
    $php[] = $this->mk('post_max_size >= upload_max_filesize', $this->iniBytes($post) >= $this->iniBytes($up), $post . ' vs ' . $up, 'Aumenta post_max_size para permitir uploads grandes.', 'warn');

    $sections[] = ['title' => 'PHP', 'checks' => $php];

    // ===== Composer / vendor
    $cmp = [];
    $vendorAutoload = base_path('vendor/autoload.php');
    $cmp[] = $this->mk('vendor/autoload.php', is_file($vendorAutoload), is_file($vendorAutoload) ? $vendorAutoload : 'No encontrado', 'Recomendado: ejecuta <code>composer install</code>.', 'warn');
    $composerJson = base_path('composer.json');
    $cmp[] = $this->mk('composer.json', is_file($composerJson), is_file($composerJson) ? $composerJson : 'No encontrado', 'El starter debería incluir composer.json (para autoload y dependencias).', 'warn');
    $sections[] = ['title' => 'Composer', 'checks' => $cmp];

    // ===== Routing / Cache
    $rt = [];
    $cacheFile = base_path('storage/cache/routes.' . $env . '.php');
    $hasCache = is_file($cacheFile);
    if ($routeCache) {
      $rt[] = $this->mk('ROUTE_CACHE habilitado', true, 'true', '');
      $rt[] = $this->mk('Archivo cache de rutas', $hasCache, $cacheFile, 'Genera cache: <code>php bin/console route:cache</code>');
    } else {
      $rt[] = $this->mk('ROUTE_CACHE habilitado', false, 'false', 'En producción recomienda: ROUTE_CACHE=1 (y generar cache).', 'warn');
      $rt[] = ['label' => 'Archivo cache de rutas', 'status' => $hasCache ? 'ok' : 'ok', 'info' => $cacheFile, 'fix' => $hasCache ? 'Existe (OK)' : 'No existe (OK)'];
    }
    $sections[] = ['title' => 'Rutas', 'checks' => $rt];

    // ===== Security
    $secChecks = [];
    $appKey = (string) env('APP_KEY', '');
    $appKeyOk = ($appKey !== '' && strlen($appKey) >= 16);
    $secChecks[] = $this->mk('APP_KEY', $appKeyOk, $appKey !== '' ? ('len=' . strlen($appKey)) : 'vacío', 'Define APP_KEY=base64:... (recomendado 32 bytes).');
    $csrfEnabled = !empty($sec->csrfEnabled);
    $secChecks[] = $this->mk('CSRF habilitado', $csrfEnabled, $csrfEnabled ? 'true' : 'false', 'Habilita CSRF para formularios y rutas sensibles.', 'warn');
    $secChecks[] = ['label' => 'CSRF storage', 'status' => 'ok', 'info' => (string)($sec->csrfStorage ?? 'cookie'), 'fix' => ''];
    $secChecks[] = ['label' => 'CSP', 'status' => !empty($app->CSPEnabled) ? 'ok' : 'warn', 'info' => !empty($app->CSPEnabled) ? 'enabled' : 'disabled', 'fix' => 'Recomendado en producción: CSPEnabled=true (revisar compat).'];

    // Session cookie secure en producción
    $isProd = ($env === 'production');
    $cookieSecure = !empty($ses->cookieSecure);
    $secChecks[] = [
      'label' => 'Session cookieSecure',
      'status' => ($isProd && !$cookieSecure) ? 'warn' : 'ok',
      'info' => $cookieSecure ? 'true' : 'false',
      'fix' => ($isProd && !$cookieSecure) ? 'En HTTPS, activa SESSION_COOKIE_SECURE=1.' : '',
    ];

    $sections[] = ['title' => 'Seguridad', 'checks' => $secChecks];

    // ===== Database (opcional si no configurado)
    $dbChecks = [];
    $dbDsn = (string) env('DB_DSN', '');
    $hasDb = trim($dbDsn) !== '' || trim((string)env('DB_CONNECTIONS_JSON', '')) !== '';
    $dbChecks[] = [
      'label' => 'DB configurada (.env)',
      'status' => $hasDb ? 'ok' : 'warn',
      'info' => $hasDb ? 'sí' : 'no',
      'fix' => $hasDb ? 'OK' : 'Configura DB_DSN / DB_USER / DB_PASS (o DB_CONNECTIONS_JSON).',
    ];

    if ($hasDb) {
      try {
        $pdo = service('pdo');
        $pdo->query('SELECT 1');
        $dbChecks[] = ['label' => 'Conexión', 'status' => 'ok', 'info' => 'OK', 'fix' => ''];
      } catch (\Throwable $e) {
        $dbChecks[] = ['label' => 'Conexión', 'status' => 'fail', 'info' => 'Error: ' . $e->getMessage(), 'fix' => 'Revisa DSN/credenciales y disponibilidad del servidor DB.'];
      }
    }
    $sections[] = ['title' => 'Base de datos', 'checks' => $dbChecks];

    // ===== Tenancy
    $tenChecks = [];
    $enabled = !empty($ten->enabled);
    $tenChecks[] = ['label' => 'TENANCY_ENABLED', 'status' => $enabled ? 'ok' : 'ok', 'info' => $enabled ? 'true' : 'false', 'fix' => $enabled ? '' : 'Activa TENANCY_ENABLED=1 si necesitas multi-empresa.'];
    $strategy = (string)($ten->strategy ?? 'auto');
    $tenChecks[] = ['label' => 'Strategy', 'status' => 'ok', 'info' => $strategy, 'fix' => ''];
    $tenantId = class_exists('System\\Core\\Tenant') ? \System\Core\Tenant::id() : 'default';
    $known = class_exists('System\\Core\\Tenant') ? \System\Core\Tenant::knownTenants() : [];
    $tenChecks[] = ['label' => 'Tenant actual', 'status' => 'ok', 'info' => $tenantId, 'fix' => ''];
    $tenChecks[] = ['label' => 'Tenants conocidos', 'status' => 'ok', 'info' => is_array($known) ? (string)count($known) : '0', 'fix' => ''];

    $sections[] = ['title' => 'Tenancy', 'checks' => $tenChecks];

    // Summary counts
    $counts = ['ok' => 0, 'warn' => 0, 'fail' => 0];
    foreach ($sections as $secBlock) {
      foreach (($secBlock['checks'] ?? []) as $c) {
        $s = $c['status'] ?? 'ok';
        if (isset($counts[$s])) $counts[$s]++;
      }
    }

    $data = [
      'title' => 'Doctor',
      'env' => $env,
      'debug' => $debug,
      'routeCache' => $routeCache,
      'phpVersion' => PHP_VERSION,
      'baseDetected' => $baseDetected,
      'sections' => $sections,
      'counts' => $counts,
    ];

    return $this->response->html(view('debug/doctor', $data, 'layout'));
  }
}
