<?php
declare(strict_types=1);

namespace App\Controllers\Debug;

use App\Controllers\BaseController;

final class Doctor extends BaseController
{
  public function index()
  {
    $env   = (string) env('APP_ENV', 'production');
    $debug = env_bool('APP_DEBUG', false);
    $routeCache = env_bool('ROUTE_CACHE', false);

    $checks = [];

    $appKey = (string) env('APP_KEY', '');
    $checks[] = ['APP_KEY', ($appKey !== '' && strlen($appKey) >= 16), $appKey !== '' ? ('len=' . strlen($appKey)) : 'vacío'];

    $dirs = [
      'write'        => base_path('write'),
      'storage'      => base_path('storage'),
      'storage/cache'=> base_path('storage/cache'),
      'vendor'       => base_path('vendor'),
    ];

    foreach ($dirs as $name => $dir) {
      if ($name === 'vendor') {
        $checks[] = ['dir:' . $name, is_dir($dir), $dir];
      } else {
        $checks[] = ['writable:' . $name, is_dir($dir) && is_writable($dir), $dir];
      }
    }

    $checks[] = ['vendor/autoload.php', is_file(base_path('vendor/autoload.php')), 'composer autoload (opcional)'];

    $cacheFile = base_path('storage/cache/routes.' . $env . '.php');
    $checks[] = ['routes cache', is_file($cacheFile), $cacheFile];

    $rows = '';
    foreach ($checks as $c) {
      [$label, $ok, $info] = $c;
      $rows .= '<tr>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08)">' . htmlspecialchars((string)$label, ENT_QUOTES, 'UTF-8') . '</td>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08);font-weight:700">' . ($ok ? '✅' : '❌') . '</td>'
        . '<td style="padding:8px 10px;border-bottom:1px solid rgba(255,255,255,.08);opacity:.9">' . htmlspecialchars((string)$info, ENT_QUOTES, 'UTF-8') . '</td>'
        . '</tr>';
    }

    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      . '<title>QFW Doctor</title>'
      . '<style>body{margin:0;background:#0b1220;color:#e8eefc;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial}main{max-width:980px;margin:0 auto;padding:24px}h1{font-size:22px;margin:0 0 6px}p{opacity:.9;margin:0 0 16px}a{color:#9ad6ff}table{width:100%;border-collapse:collapse;border:1px solid rgba(255,255,255,.08);border-radius:14px;overflow:hidden}th{background:rgba(255,255,255,.06);text-align:left;padding:10px}code{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:8px}</style>'
      . '</head><body><main>'
      . '<h1>Q_Framework Doctor</h1>'
      . '<p>Env: <code>' . htmlspecialchars($env, ENT_QUOTES, 'UTF-8') . '</code> · Debug: <code>' . ($debug ? 'true' : 'false') . '</code> · RouteCache: <code>' . ($routeCache ? 'true' : 'false') . '</code></p>'
      . '<table><thead><tr><th>Check</th><th>OK</th><th>Info</th></tr></thead><tbody>' . $rows . '</tbody></table>'
      . '<p style="margin-top:16px">Links: '
      . '<a href="' . base_url('/debug/validadores-test') . '">Validadores Test</a> · '
      . '<a href="' . base_url('/ValidadoresDebug') . '">Validadores Debug (legacy)</a> · '
      . '<a href="' . base_url('/docs') . '">Docs</a>'
      . '</p>'
      . '<p style="opacity:.85">CLI: <code>php bin/console doctor</code> · <code>php bin/console lint</code> · <code>php bin/console route:cache</code></p>'
      . '</main></body></html>';

    return response()->html($html);
  }
}
