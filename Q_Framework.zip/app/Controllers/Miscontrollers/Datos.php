<?php

namespace App\Controllers\Miscontrollers;

require_once(ROOTPATH . '/vendor/phonevalid/autoload.php');

use System\Support\Path;
use System\Core\Response;

class Datos
{
    private $db;
    private $request;
    private $response;
    private $encrypter;

    public function __construct($db = null, $request = null)
    {
        $this->db       = $db ?: service('db');
        $this->request  = $request ?: service('request');
        $this->response = service('response');
        $this->encrypter = service('encrypter');

        helper([
            '/sistema/files',
            '/sistema/monedas',
            '/sistema/validadores',
            '/sistema/html',
            '/apis/google',
            'formularios', // CSRF helpers
        ]);
    }

    /* =========================================================
     * RESPUESTA JSON (qFetch)
     * ========================================================= */
    private function withCsrf(array $payload): array
    {
        if (!isset($payload['csrf']) && function_exists('Form_csrfToken')) {
            // token actualizado para el frontend
            $payload['csrf'] = Form_csrfToken(false);
        }
        return $payload;
    }

    private function respond(array $payload, int $httpCode = 200): Response
    {
        return $this->response->json($this->withCsrf($payload), $httpCode);
    }

    private function okPayload(string $message, $data = null, array $extra = []): array
    {
        return array_merge([
            'ok'       => true,
            'state'    => 'success',
            'title'    => 'OK',
            'mode'     => 'toast',
            'duration' => 2500,
            'message'  => $message,
            'data'     => $data,
        ], $extra);
    }

    private function failPayload(string $message, array $errors = [], array $extra = []): array
    {
        return array_merge([
            'ok'       => false,
            'state'    => 'danger',
            'title'    => 'Error',
            'mode'     => 'dialog',
            'duration' => 0,
            'message'  => $message,
            'errors'   => $errors,
        ], $extra);
    }

    private function csrfGuardPayload(): ?array
    {
        // Recomendado: usar filter 'csrf' en routes. Esto es un guard adicional.
        if (!function_exists('Form_csrfCheck')) return null;

        try {
            [$ok, $msg, $tok] = Form_csrfCheck($this->request);
            if (!$ok) return $this->failPayload((string)$msg, [], ['csrf' => $tok]);
        } catch (\Throwable $e) {
            return $this->failPayload('CSRF: error validando token', [], ['detail' => $e->getMessage()]);
        }
        return null;
    }

    /* =========================================================
     * HELPERS (input / seguridad / ids)
     * ========================================================= */
    private function postJson(string $key, $default = null)
    {
        $raw = $this->request->getPost($key);
        if ($raw === null || $raw === '') return $default;
        if (is_array($raw)) return $raw;

        $raw = stripslashes((string)$raw);
        $data = json_decode($raw, true);

        return (json_last_error() === JSON_ERROR_NONE) ? $data : $default;
    }

    private function isSafeDbIdent(string $name): bool
    {
        // tabla/columna simple: evita inyección (sin puntos, sin comillas)
        return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $name);
    }

    private function safeDecrypt($token)
    {
        if ($token === null || $token === '') return null;
        try {
            return $this->encrypter->decrypt((string)$token);
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function encodeId($val)
    {
        if ($val === null || $val === '') return $val;
        try {
            return $this->encrypter->encrypt((string)$val);
        } catch (\Throwable $e) {
            return $val;
        }
    }

    private function isIdField(string $k): bool
    {
        // corrige bug típico: strpos() == 0
        return (strpos($k, '_id') !== false) || (strpos($k, 'id_') !== false);
    }

    private function hasUploadedFile(string $inputName): bool
    {
        if (!isset($_FILES[$inputName])) return false;
        $f = $_FILES[$inputName];
        if (!isset($f['tmp_name'])) return false;

        if (is_array($f['tmp_name'])) {
            foreach ($f['tmp_name'] as $tmp) {
                if (!empty($tmp)) return true;
            }
            return false;
        }
        return !empty($f['tmp_name']);
    }

    /**
     * Detecta clave (PK preferida) o fallback a *_id dentro de lo posteado.
     * Retorna ['indice'=>..., 'valor'=>...] o null.
     */
    private function detectIdField(?string $pk, array $colsMap, array $postAssoc): ?array
    {
        if ($pk && array_key_exists($pk, $postAssoc)) {
            return ['indice' => $pk, 'valor' => $postAssoc[$pk]];
        }

        foreach ($postAssoc as $k => $v) {
            if (is_string($k) && str_ends_with($k, '_id') && isset($colsMap[$k])) {
                return ['indice' => $k, 'valor' => $v];
            }
        }

        if (isset($colsMap['id']) && array_key_exists('id', $postAssoc)) {
            return ['indice' => 'id', 'valor' => $postAssoc['id']];
        }

        return null;
    }

    /**
     * EXTRAS: recomendado NO pasar SQL desde el cliente.
     * Soporta:
     *  - search: ['tipo'=>'search','tabla'=>'x','pk'=>'x_id','texto'=>'x_nombre']
     *  - select: ['tipo'=>'select','tabla'=>'x','id'=>'x_id','nombre'=>'x_nombre']  (campo origen: CSV o JSON array)
     *  - json:   ['tipo'=>'json']  (decodifica JSON del campo)
     *  - files:  ['tipo'=>'files'] (resuelve arch_id(s) desde app_archivos y devuelve meta+url)
     */
    private function applyExtras(array &$row, ?array $extras, string $tablaBase): void
    {
        if (!$extras || !is_array($extras)) return;

        foreach ($extras as $key => $extra) {
            if (!is_string($key) || $key === '') continue;
            if (!is_array($extra) || empty($extra['tipo'])) continue;
            if (!array_key_exists($key, $row)) continue;

            $tipo = (string)$extra['tipo'];

            if ($tipo === 'json') {
                $val = $row[$key];
                if (is_string($val) && $val !== '') {
                    $dec = json_decode($val, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $row[$key] = $dec;
                    }
                }
                continue;
            }

            if ($tipo === 'search') {
                $fk = $row[$key];
                if ($fk === null || $fk === '') continue;

                $t  = $extra['tabla'] ?? null;
                $pk = $extra['pk'] ?? null;
                $tx = $extra['texto'] ?? null;

                if (!$t || !$pk || !$tx) continue;
                if (!$this->isSafeDbIdent((string)$t) || !$this->isSafeDbIdent((string)$pk) || !$this->isSafeDbIdent((string)$tx)) continue;
                if (!$this->db->tableExists((string)$t)) continue;

                $r = $this->db->table((string)$t)
                    ->select("$tx AS texto, $pk AS valor")
                    ->where((string)$pk, $fk)
                    ->first();

                if ($r) {
                    $row[$key] = [
                        'texto' => $r['texto'] ?? null,
                        'valor' => $this->encodeId($r['valor'] ?? null),
                    ];
                }
                continue;
            }

            if ($tipo === 'select') {
                $t  = $extra['tabla'] ?? null;
                $id = $extra['id'] ?? null;
                $nm = $extra['nombre'] ?? null;

                if (!$t || !$id || !$nm) continue;
                if (!$this->isSafeDbIdent((string)$t) || !$this->isSafeDbIdent((string)$id) || !$this->isSafeDbIdent((string)$nm)) continue;
                if (!$this->db->tableExists((string)$t)) continue;

                $val = $row[$key];

                // Acepta: CSV "1,2,3" o JSON '["1","2"]' o array real
                $ids = [];
                if (is_array($val)) {
                    $ids = $val;
                } elseif (is_string($val) && $val !== '') {
                    $try = json_decode($val, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($try)) {
                        $ids = $try;
                    } else {
                        $ids = array_map('trim', explode(',', $val));
                    }
                }

                $ids = array_values(array_unique(array_filter(array_map('strval', $ids), fn($x) => $x !== '')));
                if (!$ids) { $row[$key] = []; continue; }

                $rows = $this->db->table((string)$t)
                    ->select("$id AS id, $nm AS texto")
                    ->whereIn((string)$id, $ids)
                    ->get()
                    ->getResultArray();

                foreach ($rows as &$rr) {
                    if (isset($rr['id'])) $rr['id'] = $this->encodeId($rr['id']);
                }

                $row[$key] = $rows;
                continue;
            }

            if ($tipo === 'files') {
                $val = $row[$key];

                // Puede venir: "12" o [12,13] o "12,13" o token(s)
                $ids = [];
                if (is_array($val)) {
                    $ids = $val;
                } elseif (is_string($val) && $val !== '') {
                    $try = json_decode($val, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($try)) {
                        $ids = $try;
                    } else {
                        $ids = array_map('trim', explode(',', $val));
                    }
                } elseif (is_numeric($val)) {
                    $ids = [$val];
                }

                $ids = array_values(array_filter(array_map(function ($x) {
                    if ($x === null || $x === '') return null;
                    if (is_numeric($x)) return (string)$x;
                    $d = $this->safeDecrypt($x);
                    return ($d !== null && $d !== false && $d !== '') ? (string)$d : null;
                }, $ids)));

                if (!$ids) { $row[$key] = []; continue; }

                if (!$this->db->tableExists('app_archivos')) { $row[$key] = []; continue; }

                $archs = $this->db->table('app_archivos')
                    ->whereIn('arch_id', $ids)
                    ->get()
                    ->getResultArray();

                $out = [];
                foreach ($archs as $a) {
                    $doc = json_decode((string)($a['arch_documento'] ?? ''), true) ?? [];
                    $tab = $a['arch_tabla'] ?? $tablaBase;
                    $col = $a['arch_columna'] ?? $key;

                    $nombre = $doc['doc_nombre'] ?? null;
                    $url = $nombre ? base_url("uploads/archivos/{$tab}/{$col}/{$nombre}") : null;

                    $out[] = [
                        'arch_id'     => $this->encodeId($a['arch_id'] ?? null),
                        'doc'         => $doc,
                        'url'         => $url,
                        'arch_tabla'  => $tab,
                        'arch_columna'=> $col,
                    ];
                }

                $row[$key] = $out;
                continue;
            }
        }
    }

    /* =========================================================
     * Registrar (Q_Framework) - Mantiene tu lógica + JSON
     * ========================================================= */
    public function Registrar($codif = false)
    {
        if ($csrfFail = $this->csrfGuardPayload()) {
            return $this->respond($csrfFail);
        }

        $TABLA = trim((string)$this->request->getPost('TABLA'));
        if ($TABLA === '' || !$this->isSafeDbIdent($TABLA)) {
            return $this->respond($this->failPayload("TABLA inválida"));
        }

        if (!$this->db->tableExists($TABLA)) {
            return $this->respond($this->failPayload("La tabla especificada no existe: {$TABLA}"));
        }

        $cols = $this->db->getFieldData($TABLA);
        if (!$cols) {
            return $this->respond($this->failPayload(
                "No se pudo leer la estructura de la tabla: {$TABLA}",
                [],
                ['db_error' => $this->db->error()]
            ));
        }

        $colsMap = [];
        $pk = null;
        foreach ($cols as $c) {
            $name = (string)($c['name'] ?? '');
            if ($name === '') continue;
            $colsMap[$name] = $c;
            if (!$pk && (($c['key'] ?? '') === 'PRI')) $pk = $name;
        }

        $MIDES = $this->postJson('MIDES', []);
        $MVALS = $this->postJson('MVALS', []);
        $TIPOS = $this->postJson('TIPOS', []);
        $DUPLC = $this->postJson('DUPLC', null);
        $EXTRA = $this->postJson('EXTRA', null);
        $FILTR = $this->postJson('FILTR', null);
        $PRCRG = $this->postJson('PRCRG', null);
        $JSONGROUPS = $this->postJson('JSONGROUPS', null);

        $RESPU = $this->request->getPost('RESPU');

        if (!is_array($MIDES) || !is_array($MVALS) || !is_array($TIPOS)) {
            return $this->respond($this->failPayload("Entrada inválida: MIDES/MVALS/TIPOS deben ser JSON arrays."));
        }
        if (count($MIDES) !== count($MVALS) || count($MIDES) !== count($TIPOS)) {
            return $this->respond($this->failPayload("Entrada inválida: MIDES/MVALS/TIPOS no tienen la misma longitud."));
        }

        // POST asociativo crudo
        $ASOCIADD = [];
        for ($i = 0; $i < count($MIDES); $i++) {
            $k = (string)$MIDES[$i];
            $ASOCIADD[$k] = $MVALS[$i];
        }

        // JSONGROUPS => origen->destino
        $camposEnGruposJSON = [];
        $campo2GrupoDestino = [];
        if ($JSONGROUPS !== null) {
            if (!is_array($JSONGROUPS)) {
                return $this->respond($this->failPayload("JSONGROUPS inválido: debe ser objeto/array."));
            }
            foreach ($JSONGROUPS as $colDestino => $campos) {
                if (!is_string($colDestino) || !$this->isSafeDbIdent($colDestino)) {
                    return $this->respond($this->failPayload("JSONGROUPS inválido: columna destino no válida."));
                }
                if (!isset($colsMap[$colDestino])) {
                    return $this->respond($this->failPayload("JSONGROUPS inválido: '{$colDestino}' no existe en '{$TABLA}'."));
                }
                if (!is_array($campos)) continue;

                foreach ($campos as $c) {
                    $c = (string)$c;
                    if ($c === '' || !$this->isSafeDbIdent($c)) continue;
                    $camposEnGruposJSON[] = $c;
                    if (!isset($campo2GrupoDestino[$c])) $campo2GrupoDestino[$c] = $colDestino;
                }
            }
            $camposEnGruposJSON = array_values(array_unique($camposEnGruposJSON));
        }

        // ID/PREFIJO
        $prefijo = $this->detectIdField($pk, $colsMap, $ASOCIADD);

        // Q_MAP (lat/long)
        $camposQMap = [];
        foreach ($TIPOS as $idx => $tipo) {
            if ($tipo === 'q_map') {
                $campoPrincipal = (string)$MIDES[$idx];
                $camposQMap[$campoPrincipal] = [
                    'latitud'  => $campoPrincipal . '_latitud',
                    'longitud' => $campoPrincipal . '_longitud',
                ];
            }
        }

        $ASOCIAD = [];
        $ARCHIVS = [];

        // 1) Procesa campos (excepto q_map y subcampos)
        for ($i = 0; $i < count($MIDES); $i++) {
            $campoActual = (string)$MIDES[$i];
            $tipoActual  = (string)$TIPOS[$i];

            if ($campoActual === '' || !$this->isSafeDbIdent($campoActual)) {
                return $this->respond($this->failPayload("Campo inválido: '{$campoActual}'"));
            }

            if ($tipoActual === 'q_map') continue;

            $esSubMapa = false;
            foreach ($camposQMap as $sub) {
                if ($campoActual === $sub['latitud'] || $campoActual === $sub['longitud']) { $esSubMapa = true; break; }
            }
            if ($esSubMapa) continue;

            $enGrupoJSON   = in_array($campoActual, $camposEnGruposJSON, true);
            $existeEnTabla = isset($colsMap[$campoActual]);

            if (!$existeEnTabla && !$enGrupoJSON) {
                return $this->respond($this->failPayload("El campo '{$campoActual}' no existe en '{$TABLA}' y no está en JSONGROUPS."));
            }

            $rawVal = $MVALS[$i];

            if ($tipoActual === 'password') {
                $v = is_string($rawVal) ? trim($rawVal) : '';
                if ($v === '') continue;
                $VALOR = md5($v);
            } elseif ($tipoActual === 'email') {
                $v = is_string($rawVal) ? trim($rawVal) : '';
                if ($v === '') continue;
                $VALOR = $v;
            } elseif ($tipoActual === 'tel') {
                $VALOR = is_string($rawVal) ? trim($rawVal) : (string)$rawVal;
                if (is_array($EXTRA) && array_key_exists($campoActual, $EXTRA)) {
                    $campoPais = (string)$EXTRA[$campoActual];
                    $pais = $ASOCIADD[$campoPais] ?? null;
                    $phone = Validador_phone((string)$rawVal, (string)$pais);
                    if (!$phone[0]) {
                        return $this->respond($this->failPayload((string)$phone[1]));
                    }
                }
            } elseif ($tipoActual === 'date') {
                $VALOR = is_string($rawVal) ? trim($rawVal) : (string)$rawVal;
                $dmy = $campoActual . '_dmy';
                if (isset($colsMap[$dmy]) && $VALOR !== '') {
                    $ASOCIAD[$dmy] = date("d/m/Y", strtotime($VALOR));
                }
            } elseif ($tipoActual === 'file') {
                $VALOR = '';
                $ARCHIVS[] = $campoActual;
            } elseif ($tipoActual === 'q_pair') {
                $VALOR = json_encode($rawVal, JSON_UNESCAPED_UNICODE);
            } else {
                $VALOR = is_string($rawVal) ? trim($rawVal) : (is_null($rawVal) ? '' : (string)$rawVal);
            }

            $ASOCIAD[$campoActual] = $VALOR;
        }

        // 2) q_map lat/long
        foreach ($camposQMap as $sub) {
            $lat = trim((string)$this->request->getPost($sub['latitud']));
            $lng = trim((string)$this->request->getPost($sub['longitud']));

            if (!isset($colsMap[$sub['latitud']]) || !isset($colsMap[$sub['longitud']])) {
                return $this->respond($this->failPayload("Campos de mapa no existen en '{$TABLA}'."));
            }

            $ASOCIAD[$sub['latitud']]  = $lat;
            $ASOCIAD[$sub['longitud']] = $lng;
        }

        // 3) agrupar JSONGROUPS (mueve campo->columna JSON)
        if (is_array($JSONGROUPS)) {
            foreach ($JSONGROUPS as $colDestino => $camposOrigen) {
                if (!is_array($camposOrigen)) continue;

                $grupo = [];
                foreach ($camposOrigen as $c) {
                    $c = (string)$c;
                    if ($c === '' || !array_key_exists($c, $ASOCIAD)) continue;
                    $grupo[$c] = $ASOCIAD[$c];
                    unset($ASOCIAD[$c]);
                }
                if (!empty($grupo)) {
                    $ASOCIAD[$colDestino] = json_encode($grupo, JSON_UNESCAPED_UNICODE);
                }
            }
        }

        // 4) FILTR
        if (is_array($FILTR)) {
            foreach ($FILTR as $key) {
                $key = (string)$key;
                $v = trim((string)($ASOCIAD[$key] ?? ''));
                if ($v === '') {
                    $campoNombre = strtoupper(substr($key, strrpos($key, '_') + 1));
                    return $this->respond($this->failPayload("Por favor rellene el campo {$campoNombre}"));
                }
            }
        }

        // 5) PRCRG (desencripta)
        if (is_array($PRCRG)) {
            foreach ($PRCRG as $key => $valor) {
                $key = (string)$key;
                $ASOCIAD[$key] = validador_desencriptar((string)$valor) ?? $valor;
            }
            if ($prefijo === null) $prefijo = $this->detectIdField($pk, $colsMap, $ASOCIAD);
        }

        // 6) insert/update
        $mid = null;
        $isUpdate = false;
        if (is_array($prefijo) && !empty($prefijo['indice'])) {
            $mid = validador_desencriptar((string)$prefijo['valor']) ?? $prefijo['valor'];
            if (is_numeric($mid)) $isUpdate = ((int)$mid > 0);
            else $isUpdate = (trim((string)$mid) !== '');

            if ($isUpdate) $ASOCIAD[$prefijo['indice']] = $mid;
        }

        // 7) DUPLC
        if (is_array($DUPLC)) {
            foreach ($DUPLC as $arrdup) {
                if (!is_array($arrdup)) continue;

                $ADUPLI = [];
                foreach ($arrdup as $key) {
                    $key = (string)$key;
                    if (!isset($ASOCIAD[$key]) || $ASOCIAD[$key] === '' || $ASOCIAD[$key] === null) {
                        continue 2;
                    }
                    $ADUPLI[$key] = $ASOCIAD[$key];
                }

                if ($isUpdate && $prefijo && !empty($prefijo['indice'])) {
                    $ADUPLI[$prefijo['indice'] . '!='] = $mid;
                }

                if ($this->db->table($TABLA)->where($ADUPLI)->exists()) {
                    $cad = '';
                    foreach ($ADUPLI as $k => $v) if (!str_contains($k, '_id')) $cad .= " {$v} ";
                    return $this->respond($this->failPayload("{$cad} Ya existe/n en el sistema, no puede duplicarse."));
                }
            }
        }

        // 8) PRECODIGO (⚠️ eval: mantenido porque es tu lógica)
        $precodigo = (string)$this->request->getPost('PRECODIGO');
        if ($precodigo !== '') {
            $codigo = validador_desencriptar($precodigo);
            if (!$codigo) return $this->respond($this->failPayload("Código PRECODIGO corrompido."));

            try {
                eval($codigo);
            } catch (\ParseError $e) {
                return $this->respond($this->failPayload('Error de sintaxis en pre-registro: ' . $e->getMessage()));
            } catch (\Throwable $e) {
                return $this->respond($this->failPayload('Error en pre-registro: ' . $e->getMessage()));
            }
        }

        // Campo ID para where (ideal: prefijo->indice, sino PK)
        $idField = $prefijo['indice'] ?? $pk ?? null;
        if ($isUpdate && (!$idField || !isset($colsMap[$idField]))) {
            return $this->respond($this->failPayload("No se detectó campo ID para actualizar."));
        }

        // ========= TRANSACCIÓN + FILES =========
        try {
            $result = $this->db->retryTransaction(function () use (
                $TABLA, $ASOCIAD, $isUpdate, $idField, $mid, $ARCHIVS, $campo2GrupoDestino, $colsMap, $EXTRA
            ) {
                // A) Insert/Update principal
                if (!$isUpdate) {
                    $ok = $this->db->table($TABLA)->insert($ASOCIAD);
                    if ($ok === false) {
                        $err = $this->db->error();
                        throw new \RuntimeException($err['message'] ?? 'DB insert error');
                    }
                    $idreg = (string)$this->db->insertID();
                    $action = 'insert';
                } else {
                    $ok = $this->db->table($TABLA)->where([$idField => $mid])->update($ASOCIAD);
                    if ($ok === false) {
                        $err = $this->db->error();
                        throw new \RuntimeException($err['message'] ?? 'DB update error');
                    }
                    $idreg = (string)$mid;
                    $action = 'update';
                }

                // B) Files
                $filesSummary = [];

                foreach ($ARCHIVS as $QFILE) {
                    $input = $QFILE . '_file';
                    $ids_archivos = [];

                    $enGrupo = isset($campo2GrupoDestino[$QFILE]);
                    $colGrupo = $enGrupo ? $campo2GrupoDestino[$QFILE] : null;

                    if ($this->hasUploadedFile($input)) {

                        // 1) si update, borrar existentes (DB + físico) + limpiar JSON group si aplica
                        if ($action === 'update') {
                            $existentes = $this->db->table('app_archivos')
                                ->where([
                                    'arch_tabla'   => $TABLA,
                                    'arch_columna' => $QFILE,
                                    'arch_idtabla' => $idreg,
                                ])->get()->getResultArray();

                            foreach ($existentes as $ex) {
                                $doc = json_decode((string)($ex['arch_documento'] ?? ''), true) ?? [];
                                if (!empty($doc['doc_nombre'])) {
                                    $ruta = Path::join(
                                        ROOTPATH, 'public', 'uploads', 'archivos',
                                        $TABLA, $QFILE, (string)$doc['doc_nombre']
                                    );
                                    $ruta = Path::toNative($ruta);
                                    if (is_file($ruta)) @unlink($ruta);
                                }

                                $this->db->table('app_archivos')->where(['arch_id' => $ex['arch_id']])->delete();
                            }

                            if ($enGrupo && $colGrupo) {
                                $row = $this->db->table($TABLA)->select($colGrupo)->where([$idField => $idreg])->first();
                                $grupo = [];
                                if ($row && isset($row[$colGrupo])) $grupo = json_decode((string)$row[$colGrupo], true) ?? [];
                                if (isset($grupo[$QFILE])) {
                                    unset($grupo[$QFILE]);
                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([
                                        $colGrupo => json_encode($grupo, JSON_UNESCAPED_UNICODE),
                                    ]);
                                }
                            } else {
                                // si no es grupo y existe columna, limpia
                                if (isset($colsMap[$QFILE])) {
                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([$QFILE => null]);
                                }
                            }
                        }

                        // 2) subir nuevos
                        $archivos = $_FILES[$input];
                        $esMultiple = is_array($archivos['name']);
                        $cantidad = $esMultiple ? count($archivos['name']) : 1;

                        for ($j = 0; $j < $cantidad; $j++) {
                            $nombre = $esMultiple ? ($archivos['name'][$j] ?? '') : ($archivos['name'] ?? '');
                            $tmp    = $esMultiple ? ($archivos['tmp_name'][$j] ?? '') : ($archivos['tmp_name'] ?? '');
                            $tipo   = $esMultiple ? ($archivos['type'][$j] ?? '') : ($archivos['type'] ?? '');
                            $error  = $esMultiple ? ($archivos['error'][$j] ?? 0) : ($archivos['error'] ?? 0);
                            $tam    = $esMultiple ? ($archivos['size'][$j] ?? 0) : ($archivos['size'] ?? 0);

                            if ($error !== 0 || !$tmp) continue;

                            $extOrig  = strtolower(pathinfo($nombre, PATHINFO_EXTENSION));
                            $mimeOrig = @mime_content_type($tmp) ?: ($tipo ?: 'application/octet-stream');

                            $TIEMPO = time();
                            $nomfile = $idreg . "_" . $QFILE . "_" . $TIEMPO . "_" . $j;

                            $baseDir = Path::join(ROOTPATH, 'public', 'uploads', 'archivos', $TABLA, $QFILE);
                            $baseDir = Path::toNative($baseDir);
                            if (!is_dir($baseDir)) @mkdir($baseDir, 0775, true);

                            $conf = (is_array($EXTRA ?? null) && isset($EXTRA[$QFILE]) && is_array($EXTRA[$QFILE])) ? $EXTRA[$QFILE] : [];
                            $esImagen = (isset($conf['formato']) && $conf['formato'] === 'imagen');

                            $archivoTmp = ['tmp_name' => $tmp, 'type' => $tipo, 'name' => $nombre];

                            if ($esImagen) {
                                if (!empty($conf['ponermarca'])) {
                                    $archivoTmp = files_ponermarcadeagua($archivoTmp);
                                }
                                if (!empty($conf['ancho']) && !empty($conf['alto']) && isset($conf['proporcion'])) {
                                    $archivoTmp = files_cropImage($archivoTmp, (int)$conf['ancho'], (int)$conf['alto'], (string)$conf['proporcion']);
                                }
                                $archivoTmp = files_img2webp($archivoTmp);
                            }

                            if (is_array($archivoTmp) && !empty($archivoTmp['tmp_name'])) {
                                $mimeFinal = @mime_content_type($archivoTmp['tmp_name']) ?: ($archivoTmp['type'] ?? $mimeOrig);
                                $extFinal  = strtolower(pathinfo($archivoTmp['name'] ?? $nombre, PATHINFO_EXTENSION));
                            } else {
                                $mimeFinal = $mimeOrig;
                                $extFinal  = $extOrig ?: 'bin';
                                $archivoTmp = ['tmp_name' => $tmp, 'type' => $mimeFinal, 'name' => $nombre];
                            }

                            if ($mimeFinal === 'image/webp' && $extFinal !== 'webp') $extFinal = 'webp';

                            $nomfileFinal = $nomfile . "." . ($extFinal ?: $extOrig);
                            $ruta = Path::toNative(Path::join($baseDir, $nomfileFinal));

                            if (!files_guardararchivo($archivoTmp, $ruta)) {
                                throw new \RuntimeException("No se subió el archivo: {$nombre}");
                            }

                            $tamFinal = @filesize($ruta) ?: (int)$tam;

                            $datosfilr = [
                                'doc_ext'    => $extFinal ?: $extOrig,
                                'doc_mime'   => $mimeFinal ?: $mimeOrig,
                                'doc_tam'    => $tamFinal,
                                'doc_file'   => $nombre,
                                'doc_nombre' => $nomfileFinal,
                            ];

                            $okIns = $this->db->table('app_archivos')->insert([
                                'arch_tabla'     => $TABLA,
                                'arch_columna'   => $QFILE,
                                'arch_idtabla'   => $idreg,
                                'arch_documento' => json_encode($datosfilr, JSON_UNESCAPED_UNICODE),
                            ]);
                            if ($okIns === false) {
                                $err = $this->db->error();
                                throw new \RuntimeException($err['message'] ?? 'DB insert app_archivos error');
                            }

                            $ids_archivos[] = (string)$this->db->insertID();
                        }

                        // 3) asignación (grupo JSON o columna directa)
                        if (!empty($ids_archivos)) {
                            if ($enGrupo && $colGrupo) {
                                $row = $this->db->table($TABLA)->select($colGrupo)->where([$idField => $idreg])->first();
                                $grupo = [];
                                if ($row && isset($row[$colGrupo])) $grupo = json_decode((string)$row[$colGrupo], true) ?? [];

                                $grupo[$QFILE] = (count($ids_archivos) === 1) ? $ids_archivos[0] : $ids_archivos;

                                $this->db->table($TABLA)->where([$idField => $idreg])->update([
                                    $colGrupo => json_encode($grupo, JSON_UNESCAPED_UNICODE),
                                ]);
                            } else {
                                // si existe la columna física, actualiza
                                if (isset($colsMap[$QFILE])) {
                                    $colType = strtolower((string)($colsMap[$QFILE]['type'] ?? ''));
                                    $isNumeric = (bool)preg_match('/^(tinyint|smallint|mediumint|int|bigint|decimal|float|double)/', $colType);

                                    $valCol = (count($ids_archivos) === 1)
                                        ? $ids_archivos[0]
                                        : ($isNumeric ? $ids_archivos[0] : json_encode($ids_archivos, JSON_UNESCAPED_UNICODE));

                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([$QFILE => $valCol]);
                                }
                            }
                        }

                        $filesSummary[$QFILE] = $ids_archivos;
                    } else {
                        // sin upload nuevo: mantener referencia mínima
                        $campofile = $this->db->table('app_archivos')
                            ->where([
                                'arch_tabla'   => $TABLA,
                                'arch_columna' => $QFILE,
                                'arch_idtabla' => $idreg,
                            ])->first();

                        if ($campofile && isset($campofile['arch_id'])) {
                            $archId = (string)$campofile['arch_id'];

                            if ($enGrupo && $colGrupo) {
                                $row = $this->db->table($TABLA)->select($colGrupo)->where([$idField => $idreg])->first();
                                $grupo = [];
                                if ($row && isset($row[$colGrupo])) $grupo = json_decode((string)$row[$colGrupo], true) ?? [];
                                $grupo[$QFILE] = $archId;

                                $this->db->table($TABLA)->where([$idField => $idreg])->update([
                                    $colGrupo => json_encode($grupo, JSON_UNESCAPED_UNICODE),
                                ]);
                            } else {
                                if (isset($colsMap[$QFILE])) {
                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([$QFILE => $archId]);
                                }
                            }

                            $filesSummary[$QFILE] = [$archId];
                        } else {
                            $filesSummary[$QFILE] = [];
                        }
                    }
                }

                return [
                    'tabla'  => $TABLA,
                    'action' => $action,
                    'id'     => $idreg,
                    'files'  => $filesSummary,
                ];
            }, 3, 60);

            $msg = is_string($RESPU) && $RESPU !== ''
                ? $RESPU
                : (($result['action'] ?? '') === 'update' ? 'Registro actualizado correctamente' : 'Registro realizado correctamente');

            return $this->respond($this->okPayload($msg, $result));

        } catch (\Throwable $e) {
            return $this->respond($this->failPayload(
                "Error al registrar: " . $e->getMessage(),
                [],
                ['db_error' => $this->db->error()]
            ));
        }
    }

    /* =========================================================
     * Cargar (Q_Framework) - JSON + EXTRAS + encrypt IDs
     * ========================================================= */
    public function Cargar($mDATOS = null)
    {
        if ($csrfFail = $this->csrfGuardPayload()) {
            // si es llamada interna ($mDATOS), devolvemos payload array
            if ($mDATOS) return $this->withCsrf($csrfFail);
            return $this->respond($csrfFail);
        }

        // 1) Entrada
        if (!$mDATOS) {
            $TABLA   = (string)$this->request->getPost("TABLA");
            $COLUMNA = (string)$this->request->getPost("COLUMNA");
            $VALOR   = $this->request->getPost("VALOR");
            $EXTRAS  = $this->postJson("EXTRAS", null);

            if (!$this->isSafeDbIdent($TABLA))   return $this->respond($this->failPayload("TABLA inválida"));
            if (!$this->isSafeDbIdent($COLUMNA)) return $this->respond($this->failPayload("COLUMNA inválida"));

            if (!is_numeric($VALOR)) {
                $d = $this->safeDecrypt($VALOR);
                if ($d === null || $d === false || $d === '') {
                    return $this->respond($this->failPayload("VALOR inválido o no se pudo desencriptar"));
                }
                $VALOR = $d;
            }

            if (!$this->db->tableExists($TABLA)) {
                return $this->respond($this->failPayload("La tabla especificada no existe"));
            }

            $row = $this->db->table($TABLA)->where($COLUMNA, $VALOR)->first();
            if (!$row) {
                return $this->respond($this->failPayload("No se encontró registro", [], ['data' => []]));
            }

        } else {
            $EXTRAS = $mDATOS['extras'] ?? null;

            $TABLA = $mDATOS['prms']['tabla'] ?? null;
            $where = $mDATOS['prms']['where'] ?? null;

            if (!$TABLA || !$this->isSafeDbIdent((string)$TABLA) || !is_array($where)) {
                $payload = $this->failPayload("Parámetros inválidos en mDATOS", [], ['data' => []]);
                return $mDATOS ? $this->withCsrf($payload) : $this->respond($payload);
            }

            foreach ($where as $k => $v) {
                if (!$this->isSafeDbIdent((string)$k)) {
                    $payload = $this->failPayload("Where inválido: {$k}", [], ['data' => []]);
                    return $mDATOS ? $this->withCsrf($payload) : $this->respond($payload);
                }
                if (!is_numeric($v)) {
                    $dv = $this->safeDecrypt($v);
                    if ($dv !== null) $where[$k] = $dv;
                }
            }

            if (!$this->db->tableExists((string)$TABLA)) {
                $payload = $this->failPayload("La tabla especificada no existe", [], ['data' => []]);
                return $mDATOS ? $this->withCsrf($payload) : $this->respond($payload);
            }

            $row = $this->db->table((string)$TABLA)->where($where)->first();
            if (!$row) {
                $payload = $this->failPayload("No se encontró registro", [], ['data' => []]);
                return $mDATOS ? $this->withCsrf($payload) : $this->respond($payload);
            }
        }

        // 2) EXTRAS antes de encriptar IDs del registro
        $this->applyExtras($row, is_array($EXTRAS) ? $EXTRAS : null, (string)$TABLA);

        // 3) Encriptar IDs del registro
        foreach ($row as $k => $v) {
            if (is_array($v)) continue;
            if ($this->isIdField((string)$k) && $v !== null && $v !== '') {
                $row[$k] = $this->encodeId($v);
            }
        }

        $data = [$row];

        // 4) Salida
        $payload = $this->okPayload("OK", $data);

        if ($mDATOS) {
            // uso interno: retorna array (NO Response)
            return $this->withCsrf($payload);
        }

        return $this->respond($payload);
    }
}
