<?php
declare(strict_types=1);

namespace App\Controllers\Funciones;

require_once(ROOTPATH.'vendor/phpspreadsheet/autoload.php');
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;

use App\Controllers\BaseController;

class Generales extends BaseController
{

        

    /* ==========================================================
     * qFetch-friendly API helpers (Q_Framework)
     * - Lee parámetros desde POST/GET o JSON body (application/json)
     * - Respuestas JSON consistentes: state/message/data
     * ========================================================== */
    private ?array $__jsonBody = null;

    private function jsonBody(): array
    {
        if ($this->__jsonBody !== null) return $this->__jsonBody;

        $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? ''));
        if (str_contains($ct, 'application/json')) {
            $raw = file_get_contents('php://input') ?: '';
            $j = json_decode($raw, true);
            $this->__jsonBody = is_array($j) ? $j : [];
            return $this->__jsonBody;
        }

        $this->__jsonBody = [];
        return $this->__jsonBody;
    }

    /** Obtiene un parámetro desde POST/GET o JSON body */
    private function in(string $key, $default = null)
    {
        $v = $this->request->getPost($key);
        if ($v !== null) return $v;

        $v = $this->request->getGet($key);
        if ($v !== null) return $v;

        $j = $this->jsonBody();
        if (array_key_exists($key, $j)) return $j[$key];

        return $default;
    }

    /** Respuesta JSON "ok" (compatible legacy: a veces payload viene en message) */
    private function ok($message = 'OK', $data = null)
    {
        // Legacy: si message NO es string y no mandas data, lo tratamos como payload (message+data)
        if ($data === null && !is_string($message)) {
            $payload = $message;
            return $this->response->json([
                'state'   => 'success',
                'message' => $payload,
                'data'    => $payload,
            ]);
        }

        $resp = ['state' => 'success', 'message' => $message];
        if ($data !== null) $resp['data'] = $data;
        return $this->response->json($resp);
    }

    /** Respuesta JSON "error" */
    private function err(string $message = 'Error', int $httpStatus = 200, $data = null)
    {
        $resp = ['state' => 'error', 'message' => $message];
        if ($data !== null) $resp['data'] = $data;

        if (method_exists($this->response, 'setStatusCode')) {
            $this->response->setStatusCode($httpStatus);
        } elseif (method_exists($this->response, 'setStatus')) {
            $this->response->setStatus($httpStatus);
        }

        return $this->response->json($resp);
    }

public function __construct() 
        {
            helper('/evnt/mail');
            helper('/evnt/pagos');
        }
        
		public function index()
		{
			return $this->ok('Bienvenido a Generales');
		}
        
        function procesarCampo(&$ITEM, $ID, &$PARMS, &$TIPOS, &$extrasDato, &$EXTRAS, $datosForm, $tabla)
        {
            
            if (isset($ITEM['campos']['type'])) 
            {
                $tipo = $ITEM['campos']['type'];
        
                if ($tipo == 'q_select' && isset($ITEM['consulta'])) 
                {
                    $ITEM['opciones'] = $this->Datos->datos_combo(
                        "select " . $ITEM['consulta']['valor'] . "," . $ITEM['consulta']['nombre'] . 
                        " from " . $ITEM['consulta']['tabla'],
                        $ITEM['consulta']['valor'],
                        $ITEM['consulta']['nombre']
                    );
        
                    if (isset($datosForm['prms'])) 
                    {
                        $extrasDato[$ID]['tipo'] = 'q_select';
                    }
                }
        
                if ($tipo == 'opcion' && isset($ITEM['consulta'])) 
                {

                    $wRaw = $ITEM['consulta']['where'] ?? null;

                    // Normaliza y valida
                    $wStr = is_string($wRaw) ? trim($wRaw) : '';
                    $hasWhere = $wRaw !== null
                            && $wStr !== ''
                            && strtolower($wStr) !== 'null';

                    // Si es válido, garantiza que empiece con WHERE
                    $whereSQL = '';
                    if ($hasWhere) {
                        $whereSQL = preg_match('/^\s*where\b/i', $wStr) ? " $wStr" : " WHERE $wStr";
                    }

                    $sql = "SELECT {$ITEM['consulta']['valor']}, {$ITEM['consulta']['nombre']}
                            FROM {$ITEM['consulta']['tabla']}{$whereSQL}";

                    $ITEM['opciones'] = $this->Datos->datos_combo(
                        $sql,
                        $ITEM['consulta']['valor'],
                        $ITEM['consulta']['nombre']
                    );
        
                    if (isset($datosForm['prms'])) 
                    {
                        $extrasDato[$ID]['tipo'] = 'opcion';
                    }
                }
        
                if ($tipo == 'q_search' && isset($datosForm['prms'])) 
                {
                    $extrasDato[$ID] = [
                        'tipo' => 'search',
                        'query' => "select tabla_id," . $ITEM['search']['colum'] . "," . $ITEM['search']['detalle'] . 
                                   " from " . $ITEM['search']['tabla'],
                        'column' => $ITEM['search']['colum'],
                        'resp' => 'tabla_id'
                    ];
                }
        
                if ($tipo == 'file') 
                {
                    $EXTRAS[$ID]['tipo'] = 'file';
        
                    if (isset($ITEM['parametros'])) 
                    {
                        $EXTRAS[$ID] = [
                            'formato'    => $ITEM['parametros']['formato'],
                            'ancho'      => $ITEM['parametros']['ancho'] ?? null,
                            'alto'       => $ITEM['parametros']['alto'] ?? null,
                            'proporcion' => $ITEM['parametros']['proporcion'] ?? null
                        ];
                    }
                            
                    if (isset($datosForm['prms']['where'])) 
                    {
                        $query = "select * from app_archivos where arch_tabla='" . $tabla . "' and arch_columna='" . $ID . "' and arch_idtabla='" . $datosForm['prms']['where']['tabla_id'] . "'";
                        $files = $this->Datos->datos_select($query); 

                        if (count($files) > 0) 
                        {
                            $defaultFiles = [];
                            foreach ($files as $file) 
                            {
                                $documento = json_decode($file['arch_documento'], true);
                                $fileName = $documento['doc_file'];
                                $fileUrl = base_url("/funciones/archivos/descargar?file=" . validador_encriptar($file['arch_id']));
                                
                                $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                                $esImagen = in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']);
                                
                                $defaultFiles[] = ['name' => $fileName,'url' => $fileUrl,'isImage' => $esImagen];
                            }
                            
                            // Guardamos el array en un atributo de datos (lo pasaremos como JSON)
                            $ITEM['campos']['data-default-files'] = json_encode($defaultFiles);
                        }
                    }
                }
                                                        
                if ($tipo == 'q_map' && isset($datosForm['prms'])) 
                {
                    // Precargar valores de latitud y longitud si existen
                    $latColumn = $ID . '_latitud';
                    $lonColumn = $ID . '_longitud';
                    
                    $where = $datosForm['prms']['where'] ?? [];
                    $tabla_id = $where['tabla_id'] ?? null;
                    
                    if ($tabla_id) {
                        $query = "SELECT $latColumn, $lonColumn FROM $tabla WHERE tabla_id = ?";
                        $datos = $this->Datos->datos_select($query, [$tabla_id]);
                        
                        if ($datos && count($datos) > 0) {
                            $ITEM['valor_lat'] = $datos[0][$latColumn] ?? '';
                            $ITEM['valor_lon'] = $datos[0][$lonColumn] ?? '';
                            
                            // También asignar a campos para que estén disponibles en el helper
                            $ITEM['campos']['data-lat'] = $ITEM['valor_lat'];
                            $ITEM['campos']['data-lon'] = $ITEM['valor_lon'];
                        }
                    }
                }

                if ($tipo !== 'html') 
                {
                    $PARMS[] = $ID;
                    $TIPOS[] = $tipo;
                }
        
                if (!empty($ITEM['campos']['required'])) 
                {
                    $ITEM['campos']['class'] = ($ITEM['campos']['class'] ?? '') . " danger";
                }
            } 
            else 
            {
                $PARMS[] = $ID;
                $TIPOS[] = null;
            }
        }
    	
    	//funcion general para la creacion de formularios desde archivos
    	function formularios()
    	{
    	    
    	    //recepcion de parametro
            $codi = $this->request->getPost('codi');
            
            //validacion y procesamiento de parametros
            $datosForm = null;
            
            if (validador_isjson($codi)) 
            {
                $parametros = json_decode($codi, true);
                $datosForm = validador_desencriptar($parametros['form'], true, true);
            
                //codigo que modifica el form cuando es llamado desde un input de buscador
                if (!empty($parametros['tipo']) && $parametros['tipo'] === 'search') 
                {
                    $colId = $datosForm['colid'] ?? 'tabla_id';
                    $tabla = $datosForm['tabla'] ?? $parametros['form'];
                    
                    $datosForm['prms'] = 
                    [
                        'tabla' => $tabla,
                        'excluidos' => $datosForm['excluidos'] ?? null,
                        'where' => [$colId => $parametros['valor'] ?? null]
                    ];
                }
            } 
            else 
            {
                $datosForm = validador_desencriptar($codi, true, true);
            }            
            
            if (is_array($datosForm))
            {
                if (isset($datosForm)) 
                {
                    $codi   = $datosForm['form'];
                }                
            }
            
            
            //**************************************************************************************
            //prepaar los datos de ser necesarios
            //**************************************************************************************
            
            $mform      = null;
            $extrasDato = null;
            $extrasForm = null;
            $extras     = null;
            $PARMS      = [];
            $TIPOS      = [];
            $EXTRAS     = [];
            
            if (isset($datosForm['tabla']) || isset($datosForm['prms']['tabla']))
            {
                $ruta  = $datosForm['ruta']  ?? ($datosForm['prms']['ruta']  ?? '');
                $tabla = $datosForm['tabla'] ?? ($datosForm['prms']['tabla'] ?? '');

                $ruta = rtrim($ruta, '/');
                $ruta = $ruta !== '' ? $ruta . '/' : '';

                $formularioPath = ROOTPATH . "public/uploads/formularios/" . $ruta . $tabla . ".json";

                if (is_file($formularioPath))
                {
                    $mform = json_decode(file_get_contents($formularioPath), true);

                    $excluidos = $datosForm['excluidos'] ?? ($datosForm['prms']['excluidos'] ?? null);
                    
                    if (!empty($excluidos) && !empty($mform['FORMULARIO'])) 
                    {
                        $excluidos = (array) $excluidos;
                        $mform['FORMULARIO'] = array_diff_key($mform['FORMULARIO'], array_flip($excluidos));
                    }

                    // Campo oculto tabla_id en raíz
                    $mform['FORMULARIO']['tabla_id'] = [
                        "nombre" => "Id Tabla",
                        "toltip" => null,
                        "icono"  => null,
                        "style"  => "display: none;",
                        "campos" => [
                            "type"  => "text",
                            "class" => "",
                            "value" => ""
                        ]
                    ];

                    // === Procesar EN ÁRBOL (sin aplanar) ===
                    foreach ($mform['FORMULARIO'] as $id_input => &$nodo) 
                    {
                        // Si es un grupo_*, procesar cada subcampo
                        if (is_string($id_input) && substr($id_input, 0, 6) === 'grupo_' && is_array($nodo)) 
                        {
                            foreach ($nodo as $sub_id => &$sub_input) 
                            {
                                $this->procesarCampo($sub_input, $sub_id, $PARMS, $TIPOS, $extrasDato, $EXTRAS, $datosForm, $tabla);
                            }
                            unset($sub_input); // limpiar referencia
                        } 
                        else 
                        {
                            // Campo normal en raíz
                            $this->procesarCampo($nodo, $id_input, $PARMS, $TIPOS, $extrasDato, $EXTRAS, $datosForm, $tabla);
                        }
                    }
                    unset($nodo); // limpiar referencia

                    $mform['PRECODIGO'] = $datosForm['precodigo'] ?? null;
                }
            }
            
            //******************************************************************************
            //creacion de la ruta de importacion de formulacio
            //******************************************************************************

            $formularioPath = APPPATH.'Formularios/' . $codi . '.php';
                        
            // Verificar si el archivo existe antes de incluirlo
            if (!file_exists($formularioPath)) 
            {
                return $this->err('Formulario PHP no encontrado');
				exit;
            }
                        
            // Ruta segura del archivo
            require  $formularioPath;
            
            // Crear el array de respuesta de manera más clara
            $formularioData = 
            [
                "id" => uniqid(), // ID único en lugar de rand()
                "includes" => $includes ?? "",
                "styles" => isset($style) ? validador_minificar($style, 'css') : "",
                "html" => isset($html) ? validador_minificar($html, 'html') : "",
                "javascript" => isset($javascript) ? validador_minificar($javascript, 'js') : ""
            ];
            
			return $this->ok($formularioData);
			}

        //obtener la direccion en base a coordenadas
    	function obtdireccion($lati=null,$longi=null)
    	{
    	    
    	    /*
            error_reporting(E_ALL);
            ini_set("display_errors", 1);
            */
        
    	    if (($lati) and ($longi))
    	    {
    	        $lati=$lati;
    	        $long=$longi;
    	    }
    	    else 
    	    {
    	        $lati=$this->request->getPost('lati') ?? 0;
    	        $long=$this->request->getPost('long') ?? 0;
    	    }

            $result=Mapa_reverso($lati,$long);
            
            $direccion  = isset($result['address']['road']) ? $result['address']['road']  : "";
            $numero     = isset($result['address']['house_number']) ? " ".$result['address']['house_number']  : "";
            $pais       = strtoupper($result['address']['country_code']);
            $estado     = isset($result['address']['state']) ? $result['address']['state'] : "";
            $ciudad     = isset($result['address']['city']) ? $result['address']['city'] : "";
            $mnzona     = isset($result['address']['town']) ? $result['address']['town'] : "";
            $nmpais     = isset($result['address']['country']) ? $result['address']['country'] : "";
            $vecind     = isset($result['address']['neighbourhood']) ? $result['address']['neighbourhood'] : "";
            $postal     = isset($result['address']['postcode']) ? $result['address']['postcode']  : "";        
            
            $result['direccion']=$direccion." ".$numero;

            $result['nmpais']=$nmpais;
            $result['pais']=$pais;
            $result['estado']=$estado;
            $result['ciudad']=$ciudad;
            $result['nmzona']=$mnzona;
            $result['vecind']=$vecind;
            $result['postal']=$postal;

            return $this->response->json($result);
}
    	
    	public function prerecuperar()
    	{
    	    $correo    =  $this->request->getPost('log_mail');
    	    
    	    $usuario=$this->Datos->buscarporquery("select * from evnt_usuarios where usu_email='".$correo."'");

    	    if ($usuario)
    	    {

                $this->email->initialize(mail_smtp());
                
                $this->email->setFrom("noreply@institutointerdisciplinario.org", 'Instituto Interdisciplinario');
                $this->email->setTo($usuario[0]['usu_email']);
                $this->email->setSubject("Recuperación de cuenta");
                $this->email->setMessage(mail_Formato_prerecuclave($usuario[0]['usu_email'],validador_encriptar($usuario[0]['tabla_id'],0,0)));

                if ($this->email->send()) 
                {
    	            return $this->ok("Correo enviado, por favor revise su bandeja de entrada.");
                } 
                else 
                {
                    return $this->err("Error. Ha ocurrido un error al enviar el correo", 200, ["debug" => $this->email->printDebugger()]);
                }
    	        
    	    }
    	    else
    	    {
    	        return $this->err("No se encontró el correo ingresado.");
    	    }
    	    
    	}
    	
        function importarEXCEL()
        {
            if ($this->request->getPost('PRMS')) 
            {
                $prm = validador_desencriptar($this->request->getPost('PRMS'), true, true);
            }
        
            $tabla      = $prm['tabla'];
            $filimport  = $prm['filas'];
            $obligator  = $prm['obligatorios'];
            $duplicados = $prm['duplicados'];
            $precarga   = $prm['precarga'] ?? null;
            $nomfile    = $prm['nomfile'] ?? "FILE";
        
            // Detectar si viene como array (desde q_upload)
            $fileData = $_FILES[$nomfile] ?? null;
            if (!$fileData) {
                return $this->err("No se encontró ningún archivo para importar.");
                return;
            }
        
            // Si es arreglo múltiple, tomamos el primero
            if (is_array($fileData['name'])) {
                $tmp_name = $fileData['tmp_name'][0] ?? null;
            } else {
                $tmp_name = $fileData['tmp_name'] ?? null;
            }
        
            if (!$tmp_name || !file_exists($tmp_name)) {
                return $this->err("No se recibió archivo válido.");
                return;
            }
        
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            $spreadsheet = $reader->load($tmp_name);
            $worksheet = $spreadsheet->setActiveSheetIndex(0);
        
            // Leer encabezados
            $headerRow = $worksheet->getRowIterator(1)->current();
            $cellIterator = $headerRow->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(false);
        
            $importHeaders = [];
            foreach ($cellIterator as $cell) {
                $importHeaders[] = trim($cell->getValue() ?? "");
            }
        
            // Validar estructura esperada
            $esperados = array_map('trim', $filimport);
            if ($importHeaders != $esperados) {
                return $this->err("La estructura de columnas no coincide con la esperada.", 200, ["esperado"=>$esperados,"encontrado"=>$importHeaders]);
            }
        
            $rows = [];
            $filas = 0;
            foreach ($worksheet->getRowIterator() as $row) {
                if ($filas >= 1) {
                    $cellIterator = $row->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(false);
                    $col = 0;
                    $cells = [];
        
                    foreach ($cellIterator as $cell) {
                        $valor = $cell->getValue() ?? "";
                        if ((strlen(trim($valor)) <= 0) && in_array($filimport[$col], $obligator)) {
                            return $this->err("Campo obligatorio vacío.", 200, ["fila"=>($filas+1), "columna"=>($col+1)]);
                        }
                        $cells[$filimport[$col]] = $valor;
                        $col++;
                        if ($col >= count($filimport)) break;
                    }
        
                    if ($precarga) {
                        foreach ($precarga as $key => $val) {
                            $cells[$key] = $val;
                        }
                    }
        
                    $rows[] = $cells;
                }
                $filas++;
            }
        
            $fils = 0;
            $regs = 0;
            $acts = 0;
        
            foreach ($rows as $fila) {
                $existe = false;
                foreach ($duplicados as $dupFile) {
                    $ADUPLI = [];
                    foreach ($dupFile as $keydup) {
                        $ADUPLI[$keydup] = $fila[$keydup];
                    }
        
                    if (!empty($ADUPLI)) {
                        $mitem = $this->db->table($tabla)->where($ADUPLI)->get()->getResultArray();
                        if (count($mitem) > 0) {
                            $this->Datos->update($tabla, $ADUPLI, $fila);
                            $acts++;
                            $existe = true;
                        }
                    }
                }
        
                if (!$existe) {
                    $idfin = $this->Datos->Regentabla($tabla, $fila);
                    if (!$idfin) { return $this->err("DB error al insertar", 200, ["db_error"=>$this->db->error()]); }
$regs++;
                }
                $fils++;
            }
        
            return $this->ok("Importación completada", ["leidos"=>$fils,"registrados"=>$regs,"actualizados"=>$acts]);
}

    	function exportarEXCEL()
    	{

    	    $prm = validador_desencriptar($this->request->getGet('prm'),true,true);
    	    
    	    if(!is_array($prm))
    	    {
    	        return $this->err("Parámetros incorrectos, no se puede procesar.");
    	    }

            if (array_key_exists('where', $prm))
            {
    	        $datos=$this->db->table($prm['tabla'])->select($prm['filtroexport'])->where($prm['where'])->get()->getResultArray();
            }
            else 
            {
    	        $datos=$this->db->table($prm['tabla'])->select($prm['filtroexport'])->get()->getResultArray();
            }
            
            
            
            $spreadsheet = new Spreadsheet();
            $spreadsheet->getActiveSheet()->setTitle('Datos');
            $spreadsheet->getActiveSheet()->fromArray($prm['titulos'], NULL, 'A1');
            $spreadsheet->getActiveSheet()->fromArray($datos, NULL, 'A2');
            
            // Agregar comentarios a los títulos
            if (isset($prm['comentarios']) and is_array($prm['comentarios']))
            {
                $colIndex = 1; // Columnas empiezan en 1 (A)
                foreach ($prm['comentarios'] as $comentario) 
                {
                    if (!empty($comentario)) 
                    {
                        $colLetter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($colIndex);
                        $cell = $colLetter . '1';
                        $spreadsheet->getActiveSheet()->getComment($cell)->getText()->createTextRun($comentario);
                    }
                    $colIndex++;
                }  
            }
            
            if (isset($prm['exporthojas']))
            {
                foreach ($prm['exporthojas'] as $hoja)
                {
                    $hojatab=$spreadsheet->createSheet();
                    $hojatab->setTitle($hoja['nombre']);
                    
                    if (isset($hoja['where']))
                    {
                        $datos=$this->db->table($hoja['tabla'])->select($hoja['campos'])->where($hoja['where'])->get()->getResultArray();
                    }
                    else 
                    {
                        $datos=$this->db->table($hoja['tabla'])->select($hoja['campos'])->get()->getResultArray();

                    }
                    
                    $hojatab->fromArray($hoja['titulos'],NULL,'A1');
                    $hojatab->fromArray($datos,NULL,'A2');
                    
                }
            }
            
            $optionsRange = 'B2:C100';
            
            // write array data to xlsx file
            $writer = new Xlsx($spreadsheet);

            files_DescInicio("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",($prm['tabla'] ?? "Datos").".xlsx");
            $writer->save('php://output');
            files_Descfin();
    
    	}
    	
    	

    	function regdato()
    	{
    	    $tabla      = $this->request->getPost('tabla');
    	    $claven     = $this->request->getPost('claven');
    	    $clavev     = $this->request->getPost('clavev');
    	    $columna    = $this->request->getPost('columna');
    	    $valor      = $this->request->getPost('valor');

    	    $this->Datos->Update($tabla, array($claven=>$clavev), array($columna=>$valor));
			return $this->ok('Actualizado');
		}
    	
    	//***************************************************************************************************
    	//funciones para manejo de consultas
    	//***************************************************************************************************

    	
    	function filtrar()
    	{
    		$this->Datos->buscar();
    	}
    	
		
		//Borra el elemento id de la tabla especifica
		function buscarid()
		{
			$this->Datos->buscarporid();
		}
		
		//*******************************************************
		//Buscador por escritura de elemento
		function filtrarcond()
		{
			$this->Datos->buscar();
		}
		
		//registrar un nuevo articulo
		function registrar()
		{		    
			$this->Datos->Registrar();
		}
		
		//registrar un nuevo articulo
		function regdetalle()
		{            
			$this->Datos->Registrardetalle();
		}
		
		//registrar un nuevo articulo
		function regcondet()
		{
			$this->Datos->regcondet();
		}
		
		//Obtiene los datos de un elemento buscado por id
		function cargar()
		{
			$this->Datos->Cargar();
		}
		
		function detalle()
		{
		    $this->Datos->detalle();
		}
		
		//Borra el elemento id de la tabla especifica
		function borrar()
		{
		    
            $parametro  = validador_desencriptar($this->request->getPost("PARAMETRO"),true,true);

            $logico = $parametro['logico'] ?? true;
            
            if ($this->Datos->Deldetabla($parametro['tabla'],$parametro['condicion'],$logico ))
            {
                 return $this->ok("Registro eliminado");
            }
            else 
            {
             return $this->err("No se pudo eliminar. Revisa parámetros.");
            }
            
		}

		function preprocesar()
		{
			$prmsEnc = $this->in('prms');
			$query   = (string)($this->in('query', '') ?? '');
			$extr    = $this->in('extra');
			$file    = $this->in('file');

			if (!validador_desencriptar($prmsEnc)) {
				return $this->err("Error Parametros incorrectos");
			}

			// Importación Excel (archivo subido)
			if (count($_FILES) > 0) {
				return $this->importarEXCEL(); // ya devuelve JSON
			}

			$prms = validador_desencriptar($prmsEnc, true, true);
			if (!is_array($prms)) {
				return $this->err("Error Parametros incorrectos");
			}

			// Si no hay tipo, devolvemos el objeto desencriptado
			if (!isset($prms['tipo'])) {
				return $this->response->json($prms);
			}

			$prms['prms']['valor'] = $query;

			switch ($prms['tipo']) {
				case 'filtrar':
					// buscar() suele imprimir/salir en algunas versiones legacy; lo dejamos pero devolvemos ok si retorna algo
					$resp = $this->Datos->buscar($prms['prms']);
					if ($resp !== null) return $this->ok($resp);
					return $this->ok("OK");
				default:
					return $this->err("Tipo y parámetro no definido: " . ((string)($prms['tipo'] ?? '')));
			}
		}

		//Borra el elemento id de la tabla especifica
		function delete()
		{
			$resp = $this->Datos->delete();
			return $this->ok($resp);
		}
		
		public function obt_select()
		{
			$prms  = $this->in('prms');
			$query = (string)($this->in('query', '') ?? '');
			$extra = $this->in('extra');
			$ids   = $this->in('ids');

			$prms = validador_desencriptar($prms, true, true);

			if (!$prms) {
				return $this->err("datos de parámetro no válidos");
			}

			// Definir alias fijos para las columnas
			$col_id_alias = 'id_value';
			$col_texto_alias = 'text_value';
			$col_detalle_alias = 'detail_value';

			// Extraer solo la expresión SQL sin alias externo
			$col_texto_expr = $prms['col_texto'];
			
			// Si la expresión contiene " AS " o " as ", tomamos solo la parte de la expresión
			if (preg_match('/(.*)\s+AS\s+\w+$/i', $col_texto_expr, $matches)) {
				$col_texto_expr = trim($matches[1]);
			}

			// Construir columnas con alias fijos
			$cols = [
				"{$prms['col_id']} AS {$col_id_alias}",
				"{$col_texto_expr} AS {$col_texto_alias}"
			];
			
			if (!empty($prms['col_detalle'])) {
				$cols[] = "{$prms['col_detalle']} AS {$col_detalle_alias}";
			}

			// AÑADIR SIEMPRE la columna 'borrado'
			$cols[] = "borrado";

			// También añadir col_extra si se usa
			if (!empty($extra) && !empty($prms['col_extra'])) {
				$cols[] = $prms['col_extra'];
			}

			$cols_str = implode(", ", $cols);

			// Construcción de la consulta base
			if ($ids) {
				$arr_ids = array_map('trim', explode(',', $ids));
				$arr_ids = array_map(function ($v) {
					return is_numeric($v) ? $v : "'" . addslashes($v) . "'";
				}, $arr_ids);
				$ids_str = implode(',', $arr_ids);
				
				$sql = "SELECT {$cols_str} FROM {$prms['tabla']} WHERE {$prms['col_id']} IN ($ids_str)";
				
				if (!empty($prms['where']) && strtolower($prms['where']) !== 'null') {
					$sql .= " AND ({$prms['where']})";
				}
			} else {
				$like = addslashes($query);
				
				// ENFOQUE OPTIMIZADO CON HAVING
				$wheres = [];
				$having_conditions = ["{$col_texto_alias} LIKE '%{$like}%'"];

				// Condiciones normales van en WHERE
				if (!empty($prms['where']) && strtolower($prms['where']) !== 'null') {
					$wheres[] = "({$prms['where']})";
				}

				// Condiciones con col_extra van en WHERE (necesitan la columna original)
				if (!empty($extra) && !empty($prms['col_extra'])) {
					$colExtra = $prms['col_extra'];
					$extras = array_filter(array_map('trim', explode(',', (string)$extra)), 'strlen');

					if (!empty($extras)) {
						$parts = array_map(function($ex) use ($colExtra) {
							return "FIND_IN_SET('".addslashes($ex)."', {$colExtra})";
						}, $extras);

						$wheres[] = '(' . implode(' OR ', $parts) . ')';
					}
				}

				$sql = "SELECT {$cols_str} FROM {$prms['tabla']}";
				
				if (!empty($wheres)) {
					$sql .= " WHERE " . implode(' AND ', $wheres);
				}
				
				$sql .= " HAVING " . implode(' AND ', $having_conditions);
			}

			$respDatos = $this->Datos->datos_select($sql);

			$resp = [];

			foreach ($respDatos as $row) {
				// Usar los alias fijos para acceder a los valores
				$texto = $row[$col_texto_alias];

				// Agregar detalle si existe
				if (!empty($prms['col_detalle']) && isset($row[$col_detalle_alias])) {
					$texto .= " - " . $row[$col_detalle_alias];
				}

				$resp[] = [
					'value' => $row[$col_id_alias],
					'text'  => $texto
				];
			}

			usort($resp, function ($a, $b) {
				return strcmp(mb_strtolower($a['text']), mb_strtolower($b['text']));
			});

			return $this->response->json($resp);
			}

		
		public function setcoockie()
		{
		    $this->Segur->set_Coockie('Mcoockie','q_cookie',31536000);
		}
		
		public function check_usuario()
		{
		    $resp=false;
		    
            if($this->session->get('USUARIO'))
            {
                $resp=true;
            }

            return $this->ok(['logged'=>$resp]);
		}
		

}



