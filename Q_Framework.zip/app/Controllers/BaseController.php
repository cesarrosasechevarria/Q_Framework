<?php
declare(strict_types=1);

namespace App\Controllers;

use PDO;
use System\Core\Controller;
use System\Core\Crypt;
use System\Core\Helper;
use System\Core\Mail;
use System\Core\Request;
use System\Core\Response;
use System\Core\Session;
use System\Database\Connection;

/**
 * BaseController
 *
 * Objetivo:
 * - Mantener un controller base SIMPLE.
 * - Permitir que cualquier controller hijo declare su propio __construct() (opcional).
 * - Mantener la sesión "lazy": NO se inicia hasta que la pidas.
 *
 * Cómo funciona:
 * - El kernel crea el controller (sin ejecutar constructor), asigna Request/Response,
 *   carga helpers declarados en $helpers, y luego invoca el constructor del controller (si existe).
 * - Finalmente llama $controller->__qfw_init() para ejecutar initController().
 *
 * Uso recomendado:
 *
 *   final class Admin extends BaseController {
 *     protected array $helpers = ['url','security'];
 *
 *     *
 *     protected function initController(): void {
 *       // Hook posterior al constructor: ideal para validaciones, defaults, etc.
 *     }
 *   }
 */
abstract class BaseController extends Controller
{

  /** Helpers extra para ESTE controlador (recomendado: carga manual con $helpers o helper() en tu controller). */
  protected array $helpers = [];

  /** Cache de librerías App\Libraries\* */
  private array $libs = [];

  /**
   * Método llamado por el kernel después de construir el controller.
   * Aquí ejecutamos el hook initController().
   */
  final public function __qfw_init(): void
  {
    $this->initController();
  }

  /**
   * Hook opcional para inicialización por controller (se ejecuta DESPUÉS del constructor del controller).
   * Sobrescribe en tus controllers si necesitas inicialización común.
   */
  protected function initController(): void
  {
    // vacío a propósito
  }

/* =========================
     Helpers / Services
     ========================= */

  /**
   * Inicia sesión (a pedido) y retorna Session.
   * Útil cuando una ruta requiere login/CSRF, etc.
   */
  protected function session(): Session
  {
    Session::ensureStarted();
    return new Session();
  }

  /**
   * Retorna Session SOLO si existe cookie (sin crear sesión a visitantes).
   * Ideal para layouts/home.
   */
  protected function sessionOptional(): ?Session
  {
    if (!Session::hasCookie()) return null;
    return $this->session();
  }

  /** DB Connection (QueryBuilder, multi-fuente) */
  protected function db(?string $group = null): Connection
  {
    return \Config\Services::db($group);
  }

  /** PDO (compat) */
  protected function pdo(?string $group = null): PDO
  {
    return \Config\Services::pdo($group);
  }

  /** Encriptación */
  protected function crypt(): string
  {
    return Crypt::class;
  }

  /** Mailer (driver mail básico) */
  protected function mail(): string
  {
    return Mail::class;
  }

  /**
   * Carga 1 o más helpers en runtime.
   * Ej: $this->useHelpers(['url','view']);
   */
  protected function useHelpers(string|array $names): void
  {
    helper($names);
  }

  /**
   * Carga una librería en App\Libraries.
   * Ej:
   *   $csv = $this->lib('Csv'); // App\Libraries\Csv
   *   $csv->toArray(...)
   */
  protected function lib(string $class)
  {
    $class = trim($class);
    if ($class === '') return null;

    if (isset($this->libs[$class])) return $this->libs[$class];

    $fqcn = "App\\Libraries\\{$class}";
    if (!class_exists($fqcn)) {
      throw new \RuntimeException("Library no existe: {$fqcn}. Crea app/Libraries/{$class}.php");
    }

    $this->libs[$class] = new $fqcn();
    return $this->libs[$class];
  }

  /**
   * Guard “rápido” estilo Q_Framework: requiere que exista session('user').
   * - Si no está logueado, redirige a $redirect o base_url('/')
   */
  protected function requireLogin(?string $redirect = null): void
  {
    $user = $this->sessionOptional()?->get('user');
    if ($user) return;

    $to = $redirect ?: \url('/');
    $this->redirect($to)->send();
    exit;
  }
}
