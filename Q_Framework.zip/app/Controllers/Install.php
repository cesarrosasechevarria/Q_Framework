<?php
declare(strict_types=1);

namespace App\Controllers;

use System\Core\Controller;
use System\Core\Response;
use Throwable;

/**
 * Instalador guiado (tipo Q_Framework)
 * - /install
 * - /install/requirements, /install/baseurl, ...
 * Guarda estado en session (default) o file (fallback) según Config\Installer
 */
final class Install extends Controller
{
  private array $steps = ['welcome','requirements','baseurl','security','database','mail','finish'];

  public function index(?string $step = null): Response
  {
    helper('url');
    $inst = config('Installer');

    // Installer disabled
    if (empty($inst->wizardEnabled)) {
      return $this->response->html($this->renderInfo('Instalador deshabilitado', 'Activa INSTALL_WIZARD=1 en .env para usar el instalador.'));
    }

    // Installed lock
    $lockRel = (string)($inst->lockFile ?? 'write/install.lock');
    $lockPath = base_path($lockRel);
    $allowReinstall = (bool)env_bool('INSTALL_ALLOW_REINSTALL', false);

    if (is_file($lockPath) && !$allowReinstall) {
      // Ya instalado: mandar a Home (evita que se vea /install luego de finalizar)
      return $this->response->redirect(base_url('/'));
    }

    $step = $this->normalizeStep($step);

    // Cargar estado (prefer session; si falla, file fallback)
    $data = $this->stateLoad();

    // Post
    if ($this->request->method() === 'POST') {
      try {
        $result = $this->handlePost($step, $data);
        $data = $result['data'];
        $stay = $result['stay'] ?? false;

        $this->stateSave($data);

        // Si finish completó, redirigir a home
        if (($result['done'] ?? false) === true) {
          $this->stateClear();
          return $this->response->redirect(base_url('/?installed=1'));
        }

        // next
        $next = $stay ? $step : $this->nextStep($step);
        return $this->response->redirect(base_url('install/' . $next));
      } catch (Throwable $e) {
        // Guardar error para mostrarlo en UI
        $data['__error'] = $e->getMessage();
        $data['__error_file'] = $e->getFile();
        $data['__error_line'] = $e->getLine();
        $this->stateSave($data);
        return $this->response->redirect(base_url('install/' . $step));
      }
    }

    // Preparar data para vistas
    $checks = $this->requirements();
    $viewData = [
      'step' => $step,
      'data' => $data,
      'checks' => $checks,
      'reqOk' => $this->allOk($checks),
      'baseGuess' => $this->guessBaseURL(),
      'error' => $data['__error'] ?? null,
    ];

    // Renderiza el step (cada view incluye install/_layout.php)
    return $this->response->html(\System\Core\View::render('_system/install/' . $step, $viewData, ''));
  }

  private function normalizeStep(?string $step): string
  {
    $s = $step ?: 'welcome';
    $s = trim(strtolower($s));
    return in_array($s, $this->steps, true) ? $s : 'welcome';
  }

  private function nextStep(string $step): string
  {
    $i = array_search($step, $this->steps, true);
    if ($i === false) return 'welcome';
    return $this->steps[min($i + 1, count($this->steps) - 1)];
  }

  private function handlePost(string $step, array $data): array
  {
    // limpiar error previo
    unset($data['__error'], $data['__error_file'], $data['__error_line']);

    // Step: requirements -> no avanza si algo falla
    if ($step === 'requirements') {
      $checks = $this->requirements();
      if (!$this->allOk($checks)) {
        $data['__error'] = 'Aún faltan requisitos. Corrige lo que está en rojo y vuelve a intentar.';
        return ['data' => $data, 'stay' => true];
      }
      return ['data' => $data];
    }
if ($step === 'baseurl') {
  $base = trim((string)$this->request->post('baseURL', ''));
  if ($base === '' || strtolower($base) === 'auto') {
    // AUTO recomendado: funciona con y sin /public según cómo estés accediendo
    $data['baseURL'] = 'auto';
  } else {
    $data['baseURL'] = rtrim($base, '/') . '/';
  }

  $data['indexPage'] = (string)$this->request->post('indexPage', '');

  // Si el usuario pone "/" lo tomamos como auto
  if ($data['baseURL'] === '/') $data['baseURL'] = 'auto';
}

    if ($step === 'security') {
      $key = (string)$this->request->post('appKey', '');
      if ($key === '') {
        $key = 'base64:' . base64_encode(random_bytes(32));
      }
      $data['APP_KEY'] = $key;

      $data['CSRF_ENABLED'] = $this->request->post('csrfEnabled', '1') ? '1' : '0';
      $data['CSRF_KEY'] = (string)$this->request->post('csrfKey', '_token');
      $data['CSRF_ROTATE'] = $this->request->post('csrfRotate', '0') ? '1' : '0';
    }

    if ($step === 'database') {
      $data['DB_DSN']  = (string)$this->request->post('DB_DSN', '');
      $data['DB_USER'] = (string)$this->request->post('DB_USER', '');
      $data['DB_PASS'] = (string)$this->request->post('DB_PASS', '');
    }

    if ($step === 'mail') {
      $data['MAIL_DRIVER'] = (string)$this->request->post('MAIL_DRIVER', 'mail');
      $data['MAIL_FROM'] = (string)$this->request->post('MAIL_FROM', 'no-reply@example.com');
      $data['MAIL_FROM_NAME'] = (string)$this->request->post('MAIL_FROM_NAME', 'Q_Framework');
      $data['MAIL_HOST'] = (string)$this->request->post('MAIL_HOST', '');
      $data['MAIL_PORT'] = (string)$this->request->post('MAIL_PORT', '587');
      $data['MAIL_USER'] = (string)$this->request->post('MAIL_USER', '');
      $data['MAIL_PASS'] = (string)$this->request->post('MAIL_PASS', '');
      $data['MAIL_ENCRYPTION'] = (string)$this->request->post('MAIL_ENCRYPTION', 'tls');
    }

    if ($step === 'finish') {
      $checks = $this->requirements();
      if (!$this->allOk($checks)) {
        $data['__error'] = 'No se puede finalizar: faltan requisitos (write/ext).';
        return ['data' => $data, 'stay' => true];
      }

      // Asegurar APP_KEY aunque el usuario no haya pasado por "Seguridad"
if (empty($data['APP_KEY'])) {
  $data['APP_KEY'] = 'base64:' . base64_encode(random_bytes(32));
}

// Asegurar baseURL por defecto
if (empty($data['baseURL'])) {
  $data['baseURL'] = 'auto';
}
if (!isset($data['indexPage'])) {
  $data['indexPage'] = '';
}
      // Al finalizar, deshabilitamos el wizard para no volver a mostrar /install.
      // Para re-instalar: borra write/install.lock y pon INSTALL_WIZARD=1 (y opcional INSTALL_ALLOW_REINSTALL=1).
      $data['INSTALL_WIZARD'] = '0';

      $this->writeEnv($data);
      $this->writeLock();

      // listo
      return ['data' => $data, 'done' => true];
    }

    return ['data' => $data];
  }

  private function requirements(): array
  {
    $root = base_path();
    $checks = [];

    // PHP
    $checks[] = ['name' => 'PHP >= 8.1', 'ok' => PHP_VERSION_ID >= 80100, 'detail' => PHP_VERSION, 'required' => true];

    // Extensiones recomendadas
    $exts = [
      ['openssl', true],
      ['json', true],
      ['mbstring', true],
      ['intl', false], // recomendado (Q_Framework-style)
      ['pdo', true],
      ['pdo_mysql', false], // opcional si usarás MySQL
      ['curl', false], // opcional pero útil
    ];
    foreach ($exts as [$e, $req]) {
      $ok = extension_loaded($e);
      $checks[] = ['name' => 'ext: ' . $e, 'ok' => $ok, 'detail' => $ok ? 'ok' : 'missing', 'required' => $req];
    }

    // write/ writable
    $paths = [
      $root.'/write',
      $root.'/write/logs',
      $root.'/write/sessions',
      $root.'/write/cache',
    ];
    foreach ($paths as $p) {
      $ok = is_dir($p) && is_writable($p);
      $checks[] = ['name' => 'writable: ' . str_replace($root.'/', '', $p), 'ok' => $ok, 'detail' => $ok ? 'ok' : 'not writable', 'required' => true];
    }

    // Composer (opcional)
    $autoload = $root.'/vendor/autoload.php';
    $checks[] = ['name' => 'composer vendor/autoload.php (opcional)', 'ok' => is_file($autoload), 'detail' => is_file($autoload) ? 'found' : 'not found', 'required' => false];

    return $checks;
  }

  private function allOk(array $checks): bool
  {
    foreach ($checks as $c) {
      if (!empty($c['required']) && empty($c['ok'])) return false;
    }
    return true;
  }

  private function guessBaseURL(): string
  {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    // SCRIPT_NAME: /Q_Framework/public/index.php  (o /index.php si DocumentRoot apunta a public/)
    $script = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
    $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');

    // Si el instalador se ejecuta desde /public, sugerir la URL limpia (sin /public)
    if (preg_match('#/public$#i', $dir)) {
      $dir = rtrim(str_replace('\\', '/', dirname($dir)), '/');
    }

    if ($dir === '' || $dir === '.') $dir = '';
    return $scheme . '://' . $host . ($dir ? $dir : '') . '/';
  }

  private function writeEnv(array $data): void
{
  $envPath = base_path('.env');

  // defaults (mínimos necesarios)
  $pairs = [
    'APP_ENV'        => env('APP_ENV', 'development'),
    'APP_DEBUG'      => env('APP_DEBUG', '1'),
    'INSTALL_WIZARD' => env('INSTALL_WIZARD', '1'),
    'DEBUG_TOOLBAR'  => env('DEBUG_TOOLBAR', '1'),
    'permittedURIChars' => env('permittedURIChars', 'a-zA-Z 0-9~%.:_\\-'),
  ];

  foreach ($data as $k => $v) {
    if (!is_string($k)) continue;
    $pairs[$k] = (string)$v;
  }

  // Normalizaciones
  if (!empty($pairs['baseURL'])) $pairs['baseURL'] = rtrim((string)$pairs['baseURL'], '/') . '/';
  if (empty($pairs['APP_KEY'])) {
    // Siempre generar en formato base64:... (32 bytes)
    $pairs['APP_KEY'] = 'base64:' . base64_encode(random_bytes(32));
  }

  // Leer .env actual (si existe) y limpiarlo (sin duplicados ni plantillas pegadas)
  $existing = is_file($envPath) ? (string)file_get_contents($envPath) : '';

  // Si una versión previa pegó una plantilla, ignoramos desde ese marcador
  $cut = strpos($existing, '# (Old template below)');
  if ($cut !== false) {
    $existing = substr($existing, 0, $cut);
  }

  $lines = preg_split("/\r\n|\n|\r/", $existing);
  if (!is_array($lines)) $lines = [];

  $outLines = [];
  $seen = [];

  foreach ($lines as $line) {
    $rawLine = (string)$line;
    $trim = trim($rawLine);

    // Mantener comentarios/vacíos
    if ($trim === '' || str_starts_with($trim, '#')) {
      $outLines[] = $rawLine;
      continue;
    }

    if (!str_contains($rawLine, '=')) {
      $outLines[] = $rawLine;
      continue;
    }

    [$k, $v] = explode('=', $rawLine, 2);
    $k = trim($k);

    // Evitar duplicados existentes
    if (isset($seen[$k])) {
      $outLines[] = '# ' . $rawLine;
      continue;
    }
    $seen[$k] = true;

    // Reemplazar keys manejados por instalador
    if (array_key_exists($k, $pairs)) {
      $outLines[] = $k . '=' . $this->escapeEnv((string)$pairs[$k]);
      unset($pairs[$k]);
    } else {
      $outLines[] = $rawLine;
    }
  }

  // Prepend header
  $header = "# Generated by Q_Framework Installer";
  if (empty($outLines) || trim((string)$outLines[0]) !== $header) {
    array_unshift($outLines, $header, '');
  }

  // Agregar keys restantes al final
  if (!empty($pairs)) {
    $outLines[] = '';
    foreach ($pairs as $k => $v) {
      $outLines[] = $k . '=' . $this->escapeEnv((string)$v);
    }
  }

  // Atomic write
  $out = implode("\n", $outLines) . "\n";
  $tmp = $envPath . '.tmp';

  if (@file_put_contents($tmp, $out) === false) {
    throw new \RuntimeException('No se pudo escribir .env (revisa permisos).');
  }
  @rename($tmp, $envPath);
}


  private function escapeEnv(string $v): string
  {
    if (preg_match('/[\s#=]/', $v)) {
      $v = str_replace('"', '"', $v);
      $v = str_replace('"', '\"', $v);
      return '"' . $v . '"';
    }
    return $v;
  }

  private function writeLock(): void
  {
    $inst = config('Installer');
    $lockRel = (string)($inst->lockFile ?? 'write/install.lock');
    $lockPath = base_path($lockRel);

    $dir = dirname($lockPath);
    if (!is_dir($dir)) @mkdir($dir, 0777, true);

    if (@file_put_contents($lockPath, "installed_at=" . date('c') . "\n") === false) {
      throw new \RuntimeException('No se pudo crear install.lock (revisa permisos en write/).');
    }
  }

  private function renderInfo(string $title, string $body, array $links = []): string
  {
    $linksHtml = '';
    foreach ($links as $label => $href) {
      $linksHtml .= '<a class="qfw-btn" href="'.htmlspecialchars($href).'">'.htmlspecialchars($label).'</a> ';
    }

    return \System\Core\View::render('_system/install/_info', [
      'title' => $title,
      'body' => $body,
      'linksHtml' => $linksHtml,
      'step' => 'welcome',
      'content' => '',
    ], '');
  }

  /** Installer state helpers (session first, then file fallback) */
  private function stateLoad(): array
  {
    try {
      $s = session();
      $data = $s->get('__install__', []);
      return is_array($data) ? $data : [];
    } catch (Throwable $e) {
      // fallback file
      $f = base_path('write/install.state.json');
      if (is_file($f)) {
        $j = json_decode((string)file_get_contents($f), true);
        return is_array($j) ? $j : [];
      }
      return [];
    }
  }

  private function stateSave(array $data): void
  {
    try {
      session()->set('__install__', $data);
      return;
    } catch (Throwable $e) {
      $f = base_path('write/install.state.json');
      $dir = dirname($f);
      if (!is_dir($dir)) @mkdir($dir, 0777, true);
      @file_put_contents($f, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
  }

  private function stateClear(): void
  {
    try { session()->remove('__install__'); } catch (Throwable $e) {}
    $f = base_path('write/install.state.json');
    if (is_file($f)) @unlink($f);
  }
}