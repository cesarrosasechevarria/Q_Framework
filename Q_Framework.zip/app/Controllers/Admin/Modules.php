<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

final class Modules extends BaseController
{
  public function index()
  {
    $cfg = \config('Modules');
    $abs = base_path((string)($cfg->path ?? 'app/Modules'));
    $all = \System\Core\PluginManager::discover($abs);
    $enabled = \System\Core\Modules::enabled();

    return $this->view('admin/modules', [
      'all' => $all,
      'enabled' => $enabled,
      'tenant' => \System\Core\Tenant::id(),
      'state' => \System\Core\ModuleState::load(),
    ], 'layout');
  }

  public function enable(string $name)
  {
    \System\Core\ModuleState::enable($name);
    return $this->redirect('/admin/modules');
  }

  public function disable(string $name)
  {
    \System\Core\ModuleState::disable($name);
    return $this->redirect('/admin/modules');
  }
}
