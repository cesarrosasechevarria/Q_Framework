<?php 
declare(strict_types=1);


namespace App\Controllers\Funciones;

use App\Controllers\BaseController; 

class Home extends BaseController
{
    private $credPath;  

    function __construct() 
    {

        session();

        $this->credPath = WRITEPATH . 'seguridad/auth.json';
    }

    public function index()
    {
        $session = session();

        // Rutas base centralizadas
        $homeUrl      = base_url('funciones');
        $explorerUrl  = base_url('funciones/explorador');
        $logoutUrl    = base_url('funciones/Home/logout');

        // Estilos visuales (sin cambiar lógica/estructura)
        echo view('base/includes');
        echo $this->uiStyles();

        if (!$session->get('logueado')) {
            echo $this->loginForm();
            return;
        }
        
        $logo = base_url("public/imagenes/sistema/logos_sistema/Q_Drive.png");

        // Topbar + contenedor InfLoad (manteniendo dropdown y estructura existente)
        echo <<<HTML
        <div class="qx-shell">
            <header>
            <nav class="q_nav header sticky glass elevated gap-md brand-left no-responsive"
                data-max="xl">

                <!-- Brand -->
                <a href="{$explorerUrl}" class="brand" aria-label="Inicio Q_Explorer">
                <img data-src="{$logo}" alt="Logo Q_Explorer" />
                </a>

                <!-- Actions -->
                <div class="actions">
                <div class="q_dropdown_container right">
                    <button type="button" class="link q_dropdown_toggle" aria-label="Menú de usuario">
                    <span class="q_icon" data-icon="user"></span>
                    </button>

                    <div class="q_dropdown fitcontent">
                    <div q_link="{$logoutUrl}" class="q_link item link">Cerrar sesión</div>
                    </div>
                </div>
                </div>

            </nav>
            </header>



            <main>
                <div id="misArchivos"
                     class="q_Infload-container qx-infload"
                     data-modo-directo="true"
                     data-fullscreen="true"
                     data-enable-upload="true"
                     data-enable-search="true">
                </div>
            </main>
        </div>
        HTML;
    }

    public function login()
    {
        $usuario = $this->request->getPost('usuario');
        $clave   = $this->request->getPost('clave');

        $homeUrl = base_url('funciones');

        // Primera vez: registrar
        if (!file_exists($this->credPath)) {
            $data = [
                'usuario' => $usuario,
                'clave'   => password_hash($clave, PASSWORD_DEFAULT),
            ];

            if (!is_dir(dirname($this->credPath))) {
                mkdir(dirname($this->credPath), 0755, true);
            }

            file_put_contents($this->credPath, json_encode($data));
            session()->set('logueado', true);
            return $this->redirect($homeUrl);
        }

        // Siguientes veces: verificar
        $credenciales = json_decode(file_get_contents($this->credPath), true);

        if ($usuario === ($credenciales['usuario'] ?? null) && password_verify($clave, $credenciales['clave'] ?? '')) {
            session()->set('logueado', true);
            return $this->redirect($homeUrl);
        } else {
            return $this->redirect($homeUrl)->with('error', 'Credenciales inválidas');
        }
    }

    public function logout()
    {
        $homeUrl = base_url('funciones');
        session()->destroy();
        return $this->redirect($homeUrl);
    }

    /** ---- UI: Estilos sólo visuales (sin tocar tu lógica) ---- */
    private function uiStyles(): string
    {
        // Usa variables CSS existentes si tu framework ya las define.
        // Todo es "opt-in" y no interfiere con tus clases q_*.
        return <<<HTML
        <style>
            :root{
                --qx-radius-sm: 10px;
                --qx-radius-md: 14px;
                --qx-radius-lg: 20px;
                --qx-shadow-sm: 0 2px 10px rgba(0,0,0,.06);
                --qx-shadow-md: 0 10px 30px rgba(0,0,0,.08);
                --qx-shadow-lg: 0 20px 60px rgba(0,0,0,.10);
                --qx-brand: var(--q_color-primary, #3b82f6);
                --qx-text: var(--q_color-text, #0f172a);
                --qx-text-muted: var(--q_color-text-muted, #64748b);
                --qx-bg: var(--q_color-bg, #ffffff);
                --qx-bg-muted: var(--q_color-bg-muted, #f6f7fb);
                --qx-border: var(--q_color-border, #e5e7eb);
                --qx-ring: color-mix(in srgb, var(--qx-brand) 40%, transparent);
            }

            /* Shell general */
            .qx-shell{
                display:grid;
                grid-template-rows:auto 1fr;
                min-height:100dvh;
                background: var(--qx-bg-muted);
            }

            /* Topbar moderno con blur */
            .qx-topbar{
                position: sticky;
                top: 0;
                z-index: 100;
                backdrop-filter: saturate(150%) blur(8px);
                background: color-mix(in srgb, var(--qx-bg) 85%, transparent);
                border-bottom: 1px solid var(--qx-border);
                box-shadow: var(--qx-shadow-sm);
            }
            .qx-topbar-inner{
                display:flex;
                align-items:center;
                gap:.5rem;
                min-height:36px;
                padding-inline: clamp(12px, 3vw, 24px);
            }

            /* Marca */
            .qx-brand{
                display:flex;
                align-items:center;
                gap:.6rem;
                text-decoration:none;
            }
            .qx-brand-logo{
                max-height: 24px;
                width:auto;
                display:block;
                border-radius: 8px;
            }
            .qx-brand-title{
                font-weight: 700;
                letter-spacing:.2px;
                color: var(--qx-text);
                font-size: clamp(15px, 2vw, 18px);
            }

            /* Botón de usuario (icon-only) */
            .qx-userbtn{
                display:inline-grid;
                place-items:center;
                background: var(--qx-bg);
                transition: transform .08s ease, background .2s ease, border-color .2s ease;
            }
            .qx-userbtn:hover{
                background: color-mix(in srgb, var(--qx-bg) 92%, white 8%);
                border-color: color-mix(in srgb, var(--qx-border) 70%, var(--qx-brand) 30%);
            }
            .qx-userbtn:active{
                transform: scale(.98);
            }

            /* Dropdown refinado */
            .qx-dropdown{
                margin-top: 8px;
                border-radius: var(--qx-radius-sm);
                overflow:hidden;
                border: 1px solid var(--qx-border);
                box-shadow: var(--qx-shadow-md);
                background: var(--qx-bg);
            }
            .qx-dropdown .item{
                padding: .7rem .9rem;
                cursor: pointer;
                white-space: nowrap;
            }
            .qx-dropdown .item:hover{
                background: color-mix(in srgb, var(--qx-brand) 9%, var(--qx-bg) 91%);
            }

            /* InfLoad a pantalla completa sin desfase */
            .qx-infload{
                min-height: 480px;
                background: var(--qx-bg);
                border: 1px solid var(--qx-border);
                box-shadow: var(--qx-shadow-md);
                overflow: hidden;
            }

            /* ----------- LOGIN ----------- */
            .qx-login-wrap{
                min-height: 100dvh;
                display:grid;
                place-items:center;
                padding: clamp(16px, 3vw, 28px);
                background:
                    radial-gradient(80% 60% at 10% 10%, color-mix(in srgb, var(--qx-brand) 12%, transparent) 0%, transparent 60%),
                    radial-gradient(60% 60% at 90% 10%, color-mix(in srgb, var(--qx-brand) 8%, transparent) 0%, transparent 65%),
                    var(--qx-bg-muted);
            }

            .qx-card{
                width: min(92vw, 460px);
                border-radius: var(--qx-radius-lg);
                background: color-mix(in srgb, var(--qx-bg) 92%, white 8%);
                border: 1px solid var(--qx-border);
                box-shadow: var(--qx-shadow-lg);
                padding: clamp(18px, 3.2vw, 28px);
            }

            .qx-card-header{
                display:flex;
                flex-direction:column;
                align-items:center;
                gap:.5rem;
                text-align:center;
            }
            .qx-card-title{
                font-size: clamp(18px, 2.6vw, 22px);
                font-weight: 800;
            }
            .qx-card-sub{
                font-size: 13px;
                color: var(--qx-text-muted);
            }

            .qx-alert{
                margin-top: 12px;
                border: 1px solid color-mix(in srgb, #ef4444 40%, var(--qx-border));
                background: color-mix(in srgb, #ef4444 8%, var(--qx-bg));
                color: #b91c1c;
                border-radius: 12px;
                padding: .65rem .8rem;
                font-size: 13px;
            }

            .qx-field{
                display:flex;
                align-items:center;
                gap:.55rem;
                border:1px solid var(--qx-border);
                background: var(--qx-bg);
                border-radius: 12px;
                padding: .55rem .75rem;
                transition: border-color .2s ease, box-shadow .2s ease;
            }
            .qx-field:focus-within{
                border-color: color-mix(in srgb, var(--qx-brand) 60%, var(--qx-border) 40%);
                box-shadow: 0 0 0 4px var(--qx-ring);
            }
            .qx-field .icon{
                opacity:.85;
                font-size: 16px;
            }
            .qx-field input{
                appearance: none;
                border: none !important;
                outline: none !important;
                width: 100%;
                font-size: 14px;
                background: transparent;
                color: var(--qx-text);
                padding: .2rem 0;
            }

            .qx-submit{
                width: 100%;
                border-radius: 12px;
                padding: .7rem 1rem;
                font-weight: 700;
                letter-spacing: .2px;
                box-shadow: var(--qx-shadow-sm);
            }

            @media (max-width: 520px){
                .qx-brand-title{ display:none; }
                .qx-infload{ height: calc(100dvh - 64px); }
            }
        </style>
        HTML;
    }

    private function loginForm()
    {
        $primeraVez = !file_exists($this->credPath);
        $titulo = $primeraVez ? "• Registro de Acceso Administrativo" : "• Inicio de Sesión";
        $btnText = $primeraVez ? "Registrar y acceder" : "Iniciar sesión";

        $error = session()->flash('error');
        $ayuda = $primeraVez
            ? "Primera vez: crea el usuario y la contraseña para habilitar el acceso."
            : "Ingresa tus credenciales para acceder a Q_Explorer.";

        $loginAction = base_url('funciones/Home/login');

        return <<<HTML
        <div class="qx-login-wrap">
            <div class="qx-card q_form">
                <div class="qx-card-header">
                    <div class="qx-brand" style="gap:.7rem;">
                        <span class="q_form-icon-folder" aria-hidden="true" style="font-size:22px;opacity:.9"></span>
                    </div>
                    <div class="qx-card-title">{$titulo}</div>
                    <div class="qx-card-sub">{$ayuda}</div>
                </div>

                {$this->renderError($error)}

                <form method="post" action="{$loginAction}" style="margin-top:14px;">
                    <div class="grid gap-md" style="grid-template-columns: 1fr;">
                        <label class="qx-field" aria-label="Usuario">
                            <span class="q_form-icon q_form-icon-user icon"></span>
                            <input 
                                type="text" 
                                name="usuario" 
                                placeholder="Nombre de usuario" 
                                class="input required size-md" 
                                autocomplete="username" 
                                required />
                        </label>

                        <label class="qx-field" aria-label="Contraseña">
                            <span class="q_form-icon q_form-icon-password icon"></span>
                            <input 
                                type="password" 
                                name="clave" 
                                placeholder="Contraseña" 
                                class="input required size-md" 
                                autocomplete="current-password" 
                                required />
                        </label>
                    </div>

                    <div class="q_align_flex_center mt-md">
                        <button type="submit" class="q_button primary size-md qx-submit">
                            {$btnText}
                        </button>
                    </div>
                </form>
            </div>
        </div>
        HTML;
    }

    private function renderError($error): string
    {
        if (!$error) return '';
        $safe = esc($error);
        return <<<HTML
            <div class="qx-alert" role="alert">
                {$safe}
            </div>
        HTML;
    }
}