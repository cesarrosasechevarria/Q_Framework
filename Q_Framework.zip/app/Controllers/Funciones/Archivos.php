<?php 

namespace App\Controllers\Funciones;
    
use App\Controllers\BaseController;
use System\Support\Path;


class Archivos extends BaseController
{
	
	//verifica un archivo
    public function deleteFile($fileId = null)
    {
        $ruta = $this->request->getPost('ruta');

        // 🔵 MODO DIRECTO (por ruta absoluta o relativa)
        if ($ruta) {
            $rutaLimpia = urldecode($ruta);
            
            // Convertir a ruta nativa del sistema
            $rutaNativa = Path::toNative($rutaLimpia);
            
            // Resolver ruta real (sin validar contra base)
            $rutaReal = realpath($rutaNativa);
            
            // Si realpath falla, usar la ruta normalizada
            if (!$rutaReal) {
                $rutaReal = $rutaNativa;
            }
            
            // Verificar que la ruta existe en el sistema de archivos
            if (!file_exists($rutaReal)) {
                return $this->response->json([
                    "estado" => "error",
                    "mensaje" => "Ruta no encontrada: " . basename($rutaReal)
                ]);
            }

            // Eliminar archivo
            if (is_file($rutaReal)) {
                // Verificar permisos de escritura
                if (!is_writable($rutaReal)) {
                    return $this->response->json([
                        "estado" => "error",
                        "mensaje" => "Sin permisos para eliminar el archivo"
                    ]);
                }
                
                if (!@unlink($rutaReal)) {
                    $error = error_get_last();
                    return $this->response->json([
                        "estado" => "error",
                        "mensaje" => "No se pudo eliminar el archivo: " . ($error['message'] ?? 'Error desconocido')
                    ]);
                }

                return $this->response->json([
                    'estado' => 'ok',
                    'mensaje' => 'Archivo eliminado correctamente',
                    'delta' => [ 'type' => 'delete', 'items' => [[ 'ruta' => $rutaReal ]] ]
                ]);
            }

            // Eliminar carpeta
            if (is_dir($rutaReal)) {
                // Verificar permisos de escritura
                if (!is_writable($rutaReal)) {
                    return $this->response->json([
                        "estado" => "error",
                        "mensaje" => "Sin permisos para eliminar la carpeta"
                    ]);
                }
                
                if (!$this->eliminarCarpeta($rutaReal)) {
                    $error = error_get_last();
                    return $this->response->json([
                        "estado" => "error",
                        "mensaje" => "No se pudo eliminar la carpeta: " . ($error['message'] ?? 'Error desconocido')
                    ]);
                }

                return $this->response->json([
                    'estado' => 'ok',
                    'mensaje' => 'Carpeta eliminada correctamente',
                    'delta' => [ 'type' => 'delete', 'items' => [[ 'ruta' => $rutaReal ]] ]
                ]);
            }

            return $this->response->json([
                "estado" => "error",
                "mensaje" => "Ruta no es un archivo ni carpeta válida"
            ]);
        }

        // 🔵 MODO BASE DE DATOS (sin cambios)
        $idFile = $fileId ?: validador_desencriptar($this->request->getPost('FILE'));

        if (!$idFile) {
            return $this->response->json([
                "estado" => "error",
                "mensaje" => "Parámetro inválido"
            ]);
        }

        $fileReg = $this->Datos->datos_select(
            $this->Datos->genConsulta('app_archivos', ['arch_id' => $idFile])
        )[0] ?? null;

        if (!$fileReg) {
            return $this->response->json([
                "estado" => "error",
                "mensaje" => "Archivo no encontrado en base de datos"
            ]);
        }

        $mdocu = json_decode($fileReg['arch_documento'], true);
        if (!is_array($mdocu) || !isset($mdocu['doc_nombre'])) {
            return $this->response->json([
                "estado" => "error",
                "mensaje" => "Documento inválido en base de datos"
            ]);
        }

        $rutaArchivo = FCPATH . "uploads/archivos/" .
            $fileReg['arch_tabla'] . "/" .
            $fileReg['arch_columna'] . "/" .
            $mdocu['doc_nombre'];

        if (file_exists($rutaArchivo)) {
            @unlink($rutaArchivo);
        }

        $this->Datos->Deldetabla('app_archivos', ['arch_id' => $fileReg['arch_id']], false);

        return $this->response->json([
            'estado' => 'ok',
            'mensaje' => 'Archivo eliminado correctamente',
            'delta' => [ 'type' => 'delete', 'items' => [[ 'ruta' => $ruta ]] ]
        ]);
    }
    
    private function eliminarCarpeta($ruta)
    {
        if (!is_dir($ruta)) return false;
    
        $objetos = scandir($ruta);
        foreach ($objetos as $objeto) {
            if ($objeto !== '.' && $objeto !== '..') {
                $rutaCompleta = $ruta . DIRECTORY_SEPARATOR . $objeto;
                if (is_dir($rutaCompleta)) {
                    $this->eliminarCarpeta($rutaCompleta);
                } else {
                    @unlink($rutaCompleta);
                }
            }
        }
    
        return @rmdir($ruta);
    }
        
    public function get_upload_limits()
    {
        return $this->response->json([
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size')
        ]);
    }

    public function uploadfile()
    {
    
        $isDirectUpload = $this->request->getPost('modo_directo') === 'true';
    
        // === MODO DIRECTO: ruta absoluta o relativa ===
        if ($isDirectUpload) 
        {
            $rutaDestino = $this->request->getPost('ruta');
            $archivos    = $_FILES['FILE'] ?? null;
    
            if (!$rutaDestino || !$archivos || !isset($archivos['tmp_name'])) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'Ruta o archivos inválidos'
                ]);
            }
    
            // Usar Path para resolver la ruta de forma segura
            $rutaFinal = Path::resolveUnder($rutaDestino, FCPATH, false);
    
            if (!$rutaFinal) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'Ruta de destino no válida'
                ]);
            }
    
            // Crear directorio si no existe
            if (!is_dir($rutaFinal)) {
                if (!mkdir($rutaFinal, 0755, true)) {
                    return $this->response->json([
                        'estado' => 'error',
                        'mensaje' => 'No se pudo crear el directorio destino'
                    ]);
                }
            }
    
            $resultados = [];
            $multi = is_array($archivos['name']);
            $total = $multi ? count($archivos['name']) : 1;
    
            for ($i = 0; $i < $total; $i++) 
            {
                $nombreOriginal = $multi ? $archivos['name'][$i] : $archivos['name'];
                $tmp            = $multi ? $archivos['tmp_name'][$i] : $archivos['tmp_name'];
    
                $nombreSeguro = basename($nombreOriginal);
                $rutaArchivo  = Path::join($rutaFinal, $nombreSeguro);
    
                if (move_uploaded_file($tmp, $rutaArchivo)) {
                    $resultados[] = [
                        'nombre'  => $nombreSeguro,
                        'estado'  => 'ok',
                        'preview' => (in_array(strtolower(pathinfo($nombreSeguro, PATHINFO_EXTENSION)), ['jpg','jpeg','png','gif','webp','bmp','svg','avif']))
                            ? base_url(Path::toUrlPath(str_replace(FCPATH, '', $rutaArchivo)))
                            : null
                    ];
                } else {
                    $resultados[] = [
                        'nombre'  => $nombreSeguro,
                        'estado'  => 'error'
                    ];
                }
            }
    
            $itemsDelta = [];
            foreach (($resultados ?? []) as $r) {
                if (($r['estado'] ?? '') === 'ok' && !empty($r['nombre'])) {
                    $rutaOk = Path::join($rutaFinal, $r['nombre']);
                    $it = $this->buildItemFromPath($rutaOk);
                    if ($it) $itemsDelta[] = $it;
                }
            }
            return $this->response->json([
                'estado'     => 'ok',
                'mensaje'    => 'Archivos procesados',
                'resultados' => $resultados,
                'delta'      => $itemsDelta ? ['type' => 'create', 'items' => $itemsDelta] : null
            ]);
        }
    
        // === MODO BASE DE DATOS (sin cambios de lógica general) ===
        $prms = $this->request->getPost('PRMS');
        $prms = validador_desencriptar($prms, true, true) ?: [
            'idtabla' => 0,
            'tabla'   => 'generico',
            'columna' => 'generico'
        ];
    
        $isMultiple = is_array($_FILES['FILE']['name']);
        $archivos   = $isMultiple ? count($_FILES['FILE']['name']) : 1;
        $resultados = [];
    
        for ($i = 0; $i < $archivos; $i++) {
            $file = [
                'name'     => $isMultiple ? $_FILES['FILE']['name'][$i] : $_FILES['FILE']['name'],
                'tmp_name' => $isMultiple ? $_FILES['FILE']['tmp_name'][$i] : $_FILES['FILE']['tmp_name'],
                'size'     => $isMultiple ? $_FILES['FILE']['size'][$i] : $_FILES['FILE']['size'],
                'type'     => $isMultiple ? $_FILES['FILE']['type'][$i] : $_FILES['FILE']['type'],
            ];
    
            $ext     = pathinfo($file['name'], PATHINFO_EXTENSION);
            $mime    = mime_content_type($file['tmp_name']);
            $tam     = $file['size'];
            $TIEMPO  = time() . "_$i";
            $nomfile = "{$prms['idtabla']}_{$prms['columna']}_$TIEMPO.$ext";
    
            $datosfilr = [
                'doc_ext'     => $ext,
                'doc_mime'    => $mime,
                'doc_tam'     => $tam,
                'doc_file'    => $file['name'],
                'doc_nombre'  => $nomfile,
            ];
    
            $ruta = ROOTPATH . "public/uploads/archivos/{$prms['tabla']}/{$prms['columna']}/$nomfile";
    
            if (validador_esimagen($mime))
            {
                $conv = files_img2webp($file); // ← tu función sin cambios
                $file = files_img2webp_normalize($conv, $file); // ← adaptador
            }
            $subido = files_guardararchivo($file, $ruta);
    
            if ($subido) {
                // Reemplazo si existe uno anterior
                $tabla   = $prms['tabla'];
                $columna = $prms['columna'];
                $id      = $prms['idtabla'];
    
                $nombreOri = addslashes($file['name']);
                $sql = "SELECT * FROM app_archivos WHERE arch_tabla = '$tabla' AND arch_columna = '$columna' AND arch_idtabla = '$id' AND arch_documento LIKE '%\"doc_file\":\"$nombreOri\"%'";
                $existente = $this->Datos->datos_select($sql);
    
                if (!empty($existente)) {
                    $docAnterior = json_decode($existente[0]['arch_documento'], true);
                    if (!empty($docAnterior['doc_nombre'])) {
                        $rutaAnterior = ROOTPATH . "public/uploads/archivos/$tabla/$columna/{$docAnterior['doc_nombre']}";
                        if (is_file($rutaAnterior)) {
                            unlink($rutaAnterior);
                        }
                    }
    
                    $this->Datos->Update('app_archivos', ['arch_id' => $existente[0]['arch_id']], [
                        'arch_documento' => json_encode($datosfilr)
                    ]);
                } else {
                    $this->Datos->Regentabla('app_archivos', [
                        'arch_tabla'     => $tabla,
                        'arch_columna'   => $columna,
                        'arch_idtabla'   => $id,
                        'arch_documento' => json_encode($datosfilr)
                    ]);
                }
    
                $resultados[] = [
                    "estado"  => "ok",
                    "archivo" => $file['name']
                ];
            } else {
                $resultados[] = [
                    "estado"  => "error",
                    "archivo" => $file['name']
                ];
            }
        }
    
        return $this->response->json([
            'state' => 'done',
            'results' => $resultados,
            'delta' => null // En modo BD, usa refresh o implementa buildItemFromDb
        ]);
    }

    public function crear_file()
    {
        $accion        = $this->request->getPost('accion');
        $modo          = $this->request->getPost('modo') ?? 'base_datos';
        $ruta          = $this->request->getPost('ruta');
        $nombre        = $this->request->getPost('nombre');
        $nuevo_nombre  = $this->request->getPost('nuevo_nombre');
        $id            = $this->request->getPost('id');
        $contenido     = $this->request->getPost('contenido') ?? '';
        $origen        = $this->request->getPost('origen');
        $destino       = $this->request->getPost('destino');

        if (!$accion) {
            return $this->response->json(['estado' => 'error', 'mensaje' => 'Falta acción']);
        }

        if (!in_array($accion, ['mover','renombrar','actualizar','comprimir', 'descomprimir']) && !$nombre){
            return $this->response->json(['estado' => 'error', 'mensaje' => 'Faltan datos obligatorios']);
        }
            
        // Validación de nombres
        $errores = [];
        
        if ($nombre) {
            if (trim($nombre) === '') {
                $errores[] = 'El nombre está vacío';
            } elseif (preg_match('/[<>:"\/\\\\|?*\x00-\x1F]/', $nombre)) {
                $errores[] = 'El nombre contiene caracteres no permitidos';
            }
        }
        
        if ($nuevo_nombre) {
            if (trim($nuevo_nombre) === '') {
                $errores[] = 'El nuevo nombre está vacío';
            } elseif (preg_match('/[<>:"\/\\\\|?*\x00-\x1F]/', $nuevo_nombre)) {
                $errores[] = 'El nuevo nombre contiene caracteres no permitidos';
            }
        }
        
        if (!empty($errores)) {
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => implode('; ', $errores)
            ]);
        }

        // 🔁 Nuevo resolver de rutas - SIN RESTRICCIONES
        $resolverRuta = function ($entrada, $mustExist = false) {
            if (!$entrada) return null;
            
            // Decodificar URL si viene codificada
            $entrada = urldecode(trim($entrada));

            // Si es URL, convertir a relativa desde base_url()
            if (filter_var($entrada, FILTER_VALIDATE_URL)) {
                $entrada = str_replace(base_url(), '', $entrada);
            }

            // Normalizar separadores usando Path
            $rutaNativa = Path::toNative($entrada);
            
            // Si debe existir, usar realpath
            if ($mustExist) {
                $rutaReal = realpath($rutaNativa);
                if ($rutaReal === false) {
                    return null; // No existe
                }
                return $rutaReal;
            }
            
            // Para rutas que no existen (creación), devolver normalizada
            return $rutaNativa;
        };

        // 🟦 Crear archivo o carpeta
        if ($accion === 'crear_folder' || $accion === 'crear_archivo') {
            $rutaDestino = $resolverRuta($ruta, true);
            if (!$rutaDestino || !is_dir($rutaDestino)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Directorio destino no válido o no existe']);
            }
            
            // Verificar permisos de escritura
            if (!is_writable($rutaDestino)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de escritura en el directorio']);
            }

            $nuevoNombre = $nombre;
            $i = 1;

            if ($accion === 'crear_archivo') {
                $info = pathinfo($nombre);
                $base = $info['filename'];
                $ext  = isset($info['extension']) ? '.' . $info['extension'] : '';

                while (file_exists($rutaDestino . DIRECTORY_SEPARATOR . $nuevoNombre)) {
                    $nuevoNombre = $base . " ($i)" . $ext;
                    $i++;
                }

                $destinoFinal = $rutaDestino . DIRECTORY_SEPARATOR . $nuevoNombre;
                if (file_put_contents($destinoFinal, $contenido) === false) {
                    return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo crear el archivo']);
                }

                $item = $this->buildItemFromPath($destinoFinal);

                return $this->response->json([
                    'estado'       => 'ok',
                    'mensaje'      => 'Archivo creado',
                    'nombre_final' => $nuevoNombre,
                    'delta'        => ['type' => 'create', 'items' => $item ? [$item] : []]
                ]);
            }

            if ($accion === 'crear_folder') {
                while (is_dir($rutaDestino . DIRECTORY_SEPARATOR . $nuevoNombre)) {
                    $nuevoNombre = $nombre . " ($i)";
                    $i++;
                }

                $destinoFinal = $rutaDestino . DIRECTORY_SEPARATOR . $nuevoNombre;
                if (!mkdir($destinoFinal, 0775, true)) {
                    return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo crear la carpeta']);
                }
                    
                $item = $this->buildItemFromPath($destinoFinal);

                return $this->response->json([
                    'estado'       => 'ok',
                    'mensaje'      => 'Carpeta creada',
                    'nombre_final' => $nuevoNombre,
                    'delta'        => ['type' => 'create', 'items' => $item ? [$item] : []]
                ]);            
            }
        }

        // 🔁 Mover archivo/carpeta
        if ($accion === 'mover') {
            $origenAbs  = $resolverRuta($origen, true);
            $destinoAbs = $resolverRuta($destino, true);

            if (!$origenAbs || !file_exists($origenAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Origen no encontrado']);
            }
            
            // Verificar permisos de origen (lectura)
            if (!is_readable($origenAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de lectura en el origen']);
            }

            if (!$destinoAbs || !is_dir($destinoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Destino no es un directorio válido']);
            }
            
            // Verificar permisos de destino (escritura)
            if (!is_writable($destinoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de escritura en el destino']);
            }

            $nombreArchivo = basename($origenAbs);
            $rutaFinal = $destinoAbs . DIRECTORY_SEPARATOR . $nombreArchivo;

            if (file_exists($rutaFinal)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Ya existe destino con ese nombre']);
            }

            if (!rename($origenAbs, $rutaFinal)) {
                $error = error_get_last();
                return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo mover: ' . ($error['message'] ?? 'Error desconocido')]);
            }
                
            $item = $this->buildItemFromPath($rutaFinal);

            return $this->response->json([
                'estado'  => 'ok',
                'mensaje' => 'Movido correctamente',
                'delta'   => ['type' => 'move', 'from' => $origenAbs, 'item' => $item]
            ]);
        }

        // ✏️ Renombrar (modo directorio)
        if ($accion === 'renombrar' && $modo === 'directorio') {
            $baseAbs = $resolverRuta($ruta, true);
            $origenAbs = $baseAbs . DIRECTORY_SEPARATOR . $nombre;
            $nuevoAbs  = $baseAbs . DIRECTORY_SEPARATOR . $nuevo_nombre;

            if (!$origenAbs || !file_exists($origenAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Archivo/carpeta original no existe']);
            }
            
            // Verificar permisos de escritura en el directorio padre
            $dirPadre = dirname($origenAbs);
            if (!is_writable($dirPadre)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos para renombrar en este directorio']);
            }

            if (file_exists($nuevoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Ya existe archivo con ese nombre']);
            }

            if (!rename($origenAbs, $nuevoAbs)) {
                $error = error_get_last();
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Error al renombrar: ' . ($error['message'] ?? 'Error desconocido')]);
            }
                
            $item = $this->buildItemFromPath($nuevoAbs);

            return $this->response->json([
                'estado'  => 'ok',
                'mensaje' => 'Renombrado correctamente',
                'delta'   => ['type' => 'move', 'from' => $origenAbs, 'item' => $item]
            ]);
        }

        // 📋 Copiar archivo/carpeta
        if ($accion === 'copiar') {
            $origenAbs  = $resolverRuta($origen, true);
            $destinoAbs = $resolverRuta($destino, true);

            if (!$origenAbs || !file_exists($origenAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Origen no encontrado']);
            }
            
            // Verificar permisos de origen (lectura)
            if (!is_readable($origenAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de lectura en el origen']);
            }

            if (!$destinoAbs || !is_dir($destinoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Destino no es un directorio válido']);
            }
            
            // Verificar permisos de destino (escritura)
            if (!is_writable($destinoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de escritura en el destino']);
            }

            $esCarpeta = is_dir($origenAbs);
            $nombreBase = basename($origenAbs);
            $nuevoNombre = $nombre ?: $nombreBase;

            $info = pathinfo($nuevoNombre);
            $base = $info['filename'];
            $ext  = isset($info['extension']) ? '.' . $info['extension'] : '';
            $i    = 1;

            $rutaFinal = $destinoAbs . DIRECTORY_SEPARATOR . $nuevoNombre;
            while (file_exists($rutaFinal)) {
                $nuevoNombre = $base . " ($i)" . $ext;
                $rutaFinal = $destinoAbs . DIRECTORY_SEPARATOR . $nuevoNombre;
                $i++;
            }

            $copiado = $esCarpeta ? $this->copiarCarpetaRecursiva($origenAbs, $rutaFinal) : copy($origenAbs, $rutaFinal);

            if (!$copiado) {
                $error = error_get_last();
                return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo copiar: ' . ($error['message'] ?? 'Error desconocido')]);
            }
                
            $item = $this->buildItemFromPath($rutaFinal);

            return $this->response->json([
                'estado'       => 'ok',
                'mensaje'      => 'Copiado correctamente',
                'nombre_final' => $nuevoNombre,
                'delta'        => ['type' => 'create', 'items' => $item ? [$item] : []]
            ]);
        }

        // ✏️ Renombrar en base de datos (sin cambios)
        if ($accion === 'renombrar' && $modo === 'base_datos') {
            if (!$id) return $this->response->json(['estado' => 'error', 'mensaje' => 'ID faltante']);

            $idReal = validador_desencriptar($id, true);
            if (!$idReal) return $this->response->json(['estado' => 'error', 'mensaje' => 'ID inválido']);

            $registro = $this->Datos->datos_select("SELECT * FROM app_archivos WHERE arch_id = '$idReal'");
            if (!$registro || !isset($registro[0]['arch_documento'])) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Archivo no encontrado']);
            }

            $jsonActual = json_decode($registro[0]['arch_documento'], true);
            if (!is_array($jsonActual)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'JSON inválido']);
            }

            $extOriginal = strtolower(pathinfo($jsonActual['doc_file'], PATHINFO_EXTENSION));
            $extNuevo    = strtolower(pathinfo($nuevo_nombre, PATHINFO_EXTENSION));

            if ($extOriginal !== $extNuevo) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'No se puede cambiar la extensión']);
            }

            $jsonActual['doc_file'] = $nuevo_nombre;
            $this->Datos->Update('app_archivos', ['arch_id' => $idReal], ['arch_documento' => json_encode($jsonActual)]);

            return $this->response->json(['estado' => 'ok', 'mensaje' => 'Nombre actualizado']);
        }

        // 📦 Comprimir archivos seleccionados (modo directorio)
        if ($accion === 'comprimir' && $modo === 'directorio') {
            $archivos = json_decode($this->request->getPost('archivos') ?? '[]', true);
            $rutaBase = $resolverRuta($ruta, true);
        
            if (empty($archivos) || !$rutaBase || !is_dir($rutaBase)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Faltan datos para comprimir']);
            }
            
            // Verificar permisos de escritura en ruta base
            if (!is_writable($rutaBase)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de escritura en el directorio']);
            }
        
            $nombreZipBase = 'comprimido_' . date('Ymd_His') . '.zip';
            $nombreZip = $nombreZipBase;
            $zipPath = $rutaBase . DIRECTORY_SEPARATOR . $nombreZip;
            $i = 1;
        
            while (file_exists($zipPath)) {
                $nombreZip = pathinfo($nombreZipBase, PATHINFO_FILENAME) . " ($i).zip";
                $zipPath = $rutaBase . DIRECTORY_SEPARATOR . $nombreZip;
                $i++;
            }
        
            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) === TRUE) {
                foreach ($archivos as $archivoRuta) {
                    // Resolver cada archivo individualmente
                    $abs = $resolverRuta($archivoRuta, true);
                    if (!$abs || !file_exists($abs)) continue;
        
                    $nombreBase = basename($abs);
        
                    if (is_file($abs)) {
                        // Verificar permisos de lectura
                        if (!is_readable($abs)) continue;
                        
                        $zip->addFile($abs, $nombreBase);
                    } elseif (is_dir($abs)) {
                        // Carpeta: agregar recursivamente
                        $zip->addEmptyDir($nombreBase);
        
                        $iterator = new \RecursiveIteratorIterator(
                            new \RecursiveDirectoryIterator($abs, \FilesystemIterator::SKIP_DOTS),
                            \RecursiveIteratorIterator::LEAVES_ONLY
                        );
        
                        foreach ($iterator as $archivo) {
                            if ($archivo->isDir()) continue;
                            
                            // Verificar permisos de lectura
                            if (!is_readable($archivo->getPathname())) continue;
        
                            $rutaRelativa = Path::relativize($archivo->getPathname(), $abs);
                            $rutaEnZip = Path::join($nombreBase, $rutaRelativa);
        
                            $zip->addFile($archivo->getPathname(), $rutaEnZip);
                        }
                    }
                }
        
                $zip->close();

                $item = $this->buildItemFromPath($zipPath);

                return $this->response->json([
                    'estado'       => 'ok',
                    'mensaje'      => 'Comprimido correctamente en ' . $nombreZip,
                    'nombre_final' => $nombreZip,
                    'delta'        => ['type' => 'create', 'items' => $item ? [$item] : []]
                ]);

            } else {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo crear el archivo ZIP']);
            }
        }

        if ($accion === 'actualizar' && $modo === 'directorio') {
            $permiso = $this->request->getPost('permiso');
            $file = $resolverRuta($ruta, true);
        
            if (!$file || !file_exists($file)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Archivo no encontrado']);
            }
            
            // Verificar permisos de escritura
            if (!is_writable($file)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos para cambiar permisos']);
            }
        
            if (!preg_match('/^[0-7]{3,4}$/', $permiso)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Permiso inválido']);
            }
        
            $permisoOctal = octdec($permiso);
            if (!chmod($file, $permisoOctal)) {
                $error = error_get_last();
                return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo cambiar el permiso: ' . ($error['message'] ?? 'Error desconocido')]);
            }
                    
            $item = $this->buildItemFromPath($file);

            return $this->response->json([
                'estado'  => 'ok',
                'mensaje' => 'Permisos actualizados',
                'delta'   => ['type' => 'update', 'item' => $item]
            ]);
        }
                
        // 📦 Descomprimir archivo ZIP
        if ($accion === 'descomprimir' && $modo === 'directorio') {
            $archivoAbs = $resolverRuta($this->request->getPost('archivo'), true);
            $destinoAbs = $resolverRuta($ruta, true);
        
            if (!$archivoAbs || !file_exists($archivoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Archivo ZIP no encontrado']);
            }
        
            if (!$destinoAbs || !is_dir($destinoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Directorio de destino no válido']);
            }
            
            // Verificar permisos de escritura en destino
            if (!is_writable($destinoAbs)) {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'Sin permisos de escritura en el directorio destino']);
            }
                    
            $zip = new \ZipArchive();
            if ($zip->open($archivoAbs) === true) {
                // Detectar entradas top-level
                $topNames = [];
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $name = trim($zip->getNameIndex($i), '/');
                    if ($name === '') continue;
                    $top = explode('/', $name)[0];
                    $topNames[$top] = true;
                }

                // Extraer
                $zip->extractTo($destinoAbs);
                $zip->close();

                // Construir items
                $items = [];
                foreach (array_keys($topNames) as $top) {
                    $abs = $destinoAbs . DIRECTORY_SEPARATOR . $top;
                    if (file_exists($abs)) {
                        $it = $this->buildItemFromPath($abs);
                        if ($it) $items[] = $it;
                    }
                }

                return $this->response->json([
                    'estado'  => 'ok',
                    'mensaje' => 'Descomprimido correctamente',
                    'delta'   => ['type' => 'create', 'items' => $items]
                ]);
            } else {
                return $this->response->json(['estado' => 'error', 'mensaje' => 'No se pudo abrir el archivo ZIP']);
            }
        }

        return $this->response->json(['estado' => 'error', 'mensaje' => 'Acción no válida']);
    }
    
    private function copiarCarpetaRecursiva($origen, $destino)
    {
        // Validar existencia del origen
        if (!is_dir($origen)) {
            return false;
        }
    
        // Intentar crear carpeta destino
        if (!is_dir($destino)) {
            if (!mkdir($destino, 0775, true)) {
                return false;
            }
        }
    
        $dir = opendir($origen);
        if (!$dir) return false;
    
        while (false !== ($archivo = readdir($dir))) {
            if ($archivo === '.' || $archivo === '..') {
                continue;
            }
    
            $rutaOrigen = $origen . DIRECTORY_SEPARATOR . $archivo;
            $rutaDestino = $destino . DIRECTORY_SEPARATOR . $archivo;
    
            if (is_dir($rutaOrigen)) {
                // Llamada recursiva para subcarpeta
                if (!$this->copiarCarpetaRecursiva($rutaOrigen, $rutaDestino)) {
                    return false;
                }
            } else {
                if (!copy($rutaOrigen, $rutaDestino)) {
                    return false;
                }
            }
        }
    
        closedir($dir);
        return true;
    }


    public function guardar_archivo()
    {
        $idArchivo      = $this->request->getPost('id');
        $nombreArchivo  = $this->request->getPost('file');
        $rutaDirectorio = $this->request->getPost('ruta');
        $contenidoBase64 = $this->request->getPost('contenido');

        if (!$contenidoBase64) {
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => 'Contenido faltante'
            ]);
        }

        $contenido = base64_decode($contenidoBase64);

        // 🔵 Caso 1: Modo base de datos
        if ($idArchivo) {
            $idReal = validador_desencriptar($idArchivo);
            if (!$idReal) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'ID inválido'
                ]);
            }

            $archivo = $this->Datos->datos_select("SELECT * FROM app_archivos WHERE arch_id = $idReal")[0] ?? null;
            if (!$archivo) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'Archivo no encontrado en base de datos'
                ]);
            }

            $documento = json_decode($archivo['arch_documento'], true);
            if (!is_array($documento) || !isset($documento['doc_nombre'])) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'Documento mal formado'
                ]);
            }

            $ruta = FCPATH . "public/uploads/archivos/{$archivo['arch_tabla']}/{$archivo['arch_columna']}/{$documento['doc_nombre']}";

            if (!file_exists($ruta)) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'Archivo físico no encontrado'
                ]);
            }

            if (file_put_contents($ruta, $contenido) === false) {
                $error = error_get_last();
                return $this->response->json([
                    'estado'  => 'error',
                    'mensaje' => 'Error al guardar archivo: ' . ($error['message'] ?? 'Error desconocido')
                ]);
            }

            clearstatcache(true, $ruta);
            $documento['doc_tam']  = filesize($ruta);
            $documento['doc_mime'] = mime_content_type($ruta);

            $this->Datos->Update('app_archivos', ['arch_id' => $idReal], [
                'arch_documento' => json_encode($documento)
            ]);

            return $this->response->json([
                'estado' => 'ok',
                'mensaje' => 'Archivo actualizado correctamente',
                'archivo' => [
                    'doc_tam'  => $documento['doc_tam'],
                    'doc_mime' => $documento['doc_mime']
                ]
            ]);
        }

        // 🔵 Caso 2: Modo directorio absoluto o relativo
        if ($nombreArchivo && $rutaDirectorio) {
            // Normalizar rutas
            $nombreArchivo = urldecode(trim($nombreArchivo));
            $rutaDirectorio = urldecode(trim($rutaDirectorio));
            
            // Determinar la ruta completa
            $directorioReal = Path::toNative($rutaDirectorio);
            
            // Verificar si $directorioReal es un archivo (no directorio)
            if (is_file($directorioReal)) {
                // $rutaDirectorio es en realidad la ruta completa del archivo
                $filePath = $directorioReal;
            } else {
                // $rutaDirectorio es un directorio, combinar con $nombreArchivo
                $filePath = $directorioReal . DIRECTORY_SEPARATOR . $nombreArchivo;
            }
            
            // Verificar si el directorio padre existe y es escribible
            $dirPadre = dirname($filePath);
            if (!is_dir($dirPadre)) {
                // Intentar crear el directorio
                if (!mkdir($dirPadre, 0775, true)) {
                    return $this->response->json([
                        'estado' => 'error',
                        'mensaje' => 'No se pudo crear el directorio: ' . $dirPadre
                    ]);
                }
            }
            
            if (!is_writable($dirPadre)) {
                return $this->response->json([
                    'estado' => 'error',
                    'mensaje' => 'Sin permisos de escritura en el directorio'
                ]);
            }

            if (file_put_contents($filePath, $contenido) === false) {
                $error = error_get_last();
                return $this->response->json([
                    'estado'  => 'error',
                    'mensaje' => 'Error al guardar archivo: ' . ($error['message'] ?? 'Error desconocido')
                ]);
            }
            
            $mime = mime_content_type($filePath);
            $tam  = filesize($filePath);
            
            $item = $this->buildItemFromPath($filePath);
            return $this->response->json([
                'estado' => 'ok',
                'mensaje' => 'Archivo guardado correctamente',
                'archivo' => [
                    'doc_tam'  => $tam,
                    'doc_mime' => $mime
                ],
                'delta' => $item ? ['type' => 'update', 'item' => $item] : null
            ]);
        }

        return $this->response->json([
            'estado' => 'error',
            'mensaje' => 'Datos insuficientes para guardar archivo'
        ]);
    }

    public function leer_archivo()
    {
        $file = $this->request->getPost('file');
        $ruta = $this->request->getPost('ruta');

        // Decodificar si viene codificado
        $file = $file ? urldecode(trim($file)) : '';
        $ruta = $ruta ? urldecode(trim($ruta)) : '';

        // Determinar la ruta completa del archivo
        $filePath = '';
        
        if ($file && Path::isAbsolute($file)) {
            // Si $file es una ruta absoluta, usarla directamente
            $filePath = Path::toNative($file);
        } elseif ($ruta && $file) {
            // Si $ruta es un directorio y $file es relativo, combinarlos
            // Primero normalizar $ruta
            $rutaBase = Path::toNative($ruta);
            
            // Verificar si $ruta es un archivo (no directorio)
            if (is_file($rutaBase)) {
                // $ruta es el archivo, ignorar $file
                $filePath = $rutaBase;
            } else {
                // $ruta es directorio, combinar con $file
                $filePath = $rutaBase . DIRECTORY_SEPARATOR . $file;
            }
        } elseif ($ruta && !$file) {
            // Si solo se proporciona $ruta, asumir que es la ruta completa
            $filePath = Path::toNative($ruta);
        } else {
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => 'Ruta o archivo no proporcionados'
            ]);
        }

        // Verificar que el archivo exista
        if (!file_exists($filePath)) {
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => 'Archivo no encontrado: ' . basename($filePath)
            ]);
        }

        // Verificar que sea un archivo (no directorio)
        if (!is_file($filePath)) {
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => 'La ruta especificada no es un archivo'
            ]);
        }

        // Verificar permisos de lectura
        if (!is_readable($filePath)) {
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => 'Sin permisos para leer el archivo'
            ]);
        }

        // Intentar leer el contenido
        $contenido = @file_get_contents($filePath);

        if ($contenido === false) {
            $error = error_get_last();
            return $this->response->json([
                'estado' => 'error',
                'mensaje' => 'No se pudo leer el archivo: ' . ($error['message'] ?? 'Error desconocido')
            ]);
        }

        // Verificar si el archivo está vacío
        if (strlen($contenido) === 0) {
            return $this->response->json([
                'estado' => 'ok',
                'contenido' => '',
                'mensaje' => 'Archivo vacío'
            ]);
        }

        // Detectar si es binario para posible manejo especial
        $esBinario = $this->esArchivoBinario($contenido);
        
        // Obtener información adicional del archivo
        $mimeType = mime_content_type($filePath);
        $tamano = filesize($filePath);
        $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        return $this->response->json([
            'estado' => 'ok',
            'contenido' => base64_encode($contenido),
            'metadata' => [
                'nombre' => basename($filePath),
                'ruta' => $filePath,
                'tamano' => $tamano,
                'mime' => $mimeType,
                'extension' => $extension,
                'es_binario' => $esBinario,
                'fecha_modificacion' => date('c', filemtime($filePath))
            ]
        ]);
    }

    /**
     * Detecta si un archivo es binario basado en su contenido.
     */
    private function esArchivoBinario(string $contenido): bool
    {
        // Si hay bytes nulos, probablemente es binario
        if (strpos($contenido, "\0") !== false) {
            return true;
        }
        
        // Verificar caracteres no imprimibles (excluyendo tabuladores y saltos de línea)
        $longitud = strlen($contenido);
        $caracteresNoImprimibles = 0;
        
        for ($i = 0; $i < $longitud; $i++) {
            $char = $contenido[$i];
            $ord = ord($char);
            
            // Saltar caracteres de control comunes en texto (tab, LF, CR)
            if ($ord === 9 || $ord === 10 || $ord === 13) {
                continue;
            }
            
            // Si es un caracter de control (0-31) o delete (127), contar como no imprimible
            if ($ord < 32 || $ord === 127) {
                $caracteresNoImprimibles++;
            }
        }
        
        // Si más del 30% son caracteres no imprimibles, considerar binario
        return ($caracteresNoImprimibles / $longitud) > 0.3;
    }
    
    private function obtenerPermisosUnix($ruta)
    {
        if (!file_exists($ruta)) return null;
        $perms = fileperms($ruta);
    
        // Primera letra: tipo
        $info = ($perms & 0x4000) ? 'd' : '-'; // d = directorio, - = archivo
    
        // Usuario
        $info .= ($perms & 0x0100) ? 'r' : '-';
        $info .= ($perms & 0x0080) ? 'w' : '-';
        $info .= ($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x') : '-';
    
        // Grupo
        $info .= ($perms & 0x0020) ? 'r' : '-';
        $info .= ($perms & 0x0010) ? 'w' : '-';
        $info .= ($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x') : '-';
    
        // Otros
        $info .= ($perms & 0x0004) ? 'r' : '-';
        $info .= ($perms & 0x0002) ? 'w' : '-';
        $info .= ($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x') : '-';
    
        $octal = substr(sprintf('%o', $perms), -4);
    
        return "$info ($octal)";
    }

    
    public function obt_files()
    {
        $modo = $this->request->getPost('modo') ?? 'base_datos';

        // =========================================================
        // BÚSQUEDA POR CONTENIDO (estilo KodExplorer) - RESULTADO AGRUPADO
        // =========================================================
        $searchAction = $this->request->getPost('search_action') ?? '';
        if ($searchAction === 'content_search') {
            return $this->response->json($this->_buscarContenidoAgrupado($modo));
        }
        
        // === MODO DIRECTORIO O URL ===
        if ($modo === 'directorio') {
            $rutaInput = $this->request->getPost('ruta') ?? '';
            $urlInput  = $this->request->getPost('url')  ?? '';
            $archivos = [];
            $rutaBreadcrumb = [];

            // === MODO DIRECTORIO LOCAL ===
            $rutaBase = realpath(FCPATH);

            if (trim($rutaInput) === '') {
                $rutaReal = $rutaBase;
            } else {
                // Decodificar la ruta si viene codificada
                $rutaInput = urldecode(trim($rutaInput));
                
                // Si es una URL, extraer la ruta
                if (filter_var($rutaInput, FILTER_VALIDATE_URL)) {
                    $rutaInput = str_replace(base_url(), '', $rutaInput);
                }
                
                // Normalizar la ruta usando Path
                $rutaNormalizada = Path::toUnix($rutaInput);
                $rutaNormalizada = Path::collapseDots($rutaNormalizada);
                
                // Verificar si es ruta absoluta
                if (Path::isAbsolute($rutaNormalizada)) {
                    // Es ruta absoluta, usar realpath
                    $rutaReal = realpath(Path::toNative($rutaNormalizada));
                } else {
                    // Es ruta relativa, resolver desde FCPATH
                    $rutaReal = realpath(Path::join(FCPATH, $rutaNormalizada));
                }
            }

            if (!$rutaReal || !is_dir($rutaReal)) {
                return $this->response->json([
                    'archivos'     => [],
                    'breadcrumb'   => [],
                    'inicio_local' => $rutaBase,
                    'error'        => 'Directorio no encontrado: ' . ($rutaInput ?: '(raíz)')
                ]);
            }

            // Verificar permisos de lectura
            if (!is_readable($rutaReal)) {
                return $this->response->json([
                    'archivos'     => [],
                    'breadcrumb'   => [],
                    'inicio_local' => $rutaBase,
                    'error'        => 'Sin permisos de lectura para el directorio'
                ]);
            }

        $items = scandir($rutaReal);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;

            $rutaCompleta = Path::join($rutaReal, $item);
            $esFolder = is_dir($rutaCompleta);
            $ext = $esFolder ? 'folder' : strtolower(pathinfo($item, PATHINFO_EXTENSION));
            $tamano = $esFolder ? 0 : @filesize($rutaCompleta);
            $esImagen = !$esFolder && in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'tiff', 'tif', 'ico', 'avif']);
            $esVideo  = !$esFolder && in_array($ext, ['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv', 'flv', 'wmv']);
            $esAudio  = !$esFolder && in_array($ext, ['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac']);
            $esDocumento = !$esFolder && in_array($ext, ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'md']);
            
            // Construir URL pública SOLO para rutas dentro de FCPATH
            $urlPublica = '';
            $esAccesibleWeb = false;
            
            if (Path::within($rutaCompleta, ROOTPATH)) {
                $urlPublica = base_url(Path::toUrlPath(Path::relativize($rutaCompleta, ROOTPATH)));
                $esAccesibleWeb = true;
            }
            
            // Determinar ícono según tipo (para cuando NO sea imagen o no sea accesible)
            if ($esFolder) {
                $iconoURL = base_url('public/imagenes/sistema/file_icon/folder.png');
            } elseif ($esVideo) {
                $iconoURL = base_url('public/imagenes/sistema/file_icon/movie/' . 
                    (file_exists(ROOTPATH . 'public/imagenes/sistema/file_icon/movie/' . $ext . '.png') ? $ext : 'file') . '.png');
            } elseif ($esAudio) {
                $iconoURL = base_url('public/imagenes/sistema/file_icon/music/' . 
                    (file_exists(ROOTPATH . 'public/imagenes/sistema/file_icon/music/' . $ext . '.png') ? $ext : 'file') . '.png');
            } elseif ($esDocumento) {
                $iconoURL = base_url('public/imagenes/sistema/file_icon/' . 
                    (file_exists(ROOTPATH . 'public/imagenes/sistema/file_icon/' . $ext . '.png') ? $ext : 'file') . '.png');
            } elseif ($esImagen) {
                // Si es imagen y está en directorio web, usar la imagen misma como ícono/preview
                if ($urlPublica) {
                    $iconoURL = $urlPublica; // ¡IMPORTANTE! Usar la imagen misma
                } else {
                    // Si no es accesible, usar ícono genérico de imagen
                    $iconoURL = base_url('public/imagenes/sistema/file_icon/png.png');
                }
                
            } else {
                $iconoURL = base_url('public/imagenes/sistema/file_icon/' . 
                    (file_exists(ROOTPATH . 'public/imagenes/sistema/file_icon/' . $ext . '.png') ? $ext : 'file') . '.png');
            }
            
            // Para archivos fuera de FCPATH, crear ruta de descarga especial
            $urlDescarga = '';
            if ($esAccesibleWeb) {
                $urlDescarga = $urlPublica;
            } else {
                // Usar endpoint de descarga para archivos protegidos
                $urlDescarga = base_url('funciones/archivos/descargar?file=' . urlencode($rutaCompleta));
            }

            // Determinar preview - REGLA ESPECIAL PARA IMÁGENES
            $previewURL = $iconoURL; // Por defecto el icono
            if ($esImagen && $esAccesibleWeb && $urlPublica) {
                $previewURL = $urlPublica; // Para imágenes accesibles, usar la imagen misma
            }

            $archivos[] = [
                "id"        => 0,
                "nombre"    => $item,
                "file"      => $esAccesibleWeb ? $urlPublica : $rutaCompleta,
                "descargar" => $urlDescarga,
                "preview"   => $previewURL, // Usamos la variable $previewURL
                "ruta"      => $rutaCompleta,
                "url"       => $esFolder ? $rutaCompleta : ($esAccesibleWeb ? $urlPublica : $rutaCompleta),
                "esimagen"  => $esImagen ? "true" : "false",
                "esvideo"   => $esVideo ? "true" : "false",
                "esaudio"   => $esAudio ? "true" : "false",
                "esdoc"     => $esDocumento ? "true" : "false",
                "esfolder"  => $esFolder,
                "tipo"      => $ext,
                "size"      => $tamano,
                "fecha"     => @date("c", @filemtime($rutaCompleta)),
                "editable"  => is_writable($rutaCompleta) ? true : false,
                "permisos"  => $this->obtenerPermisosUnix($rutaCompleta),
                "accesible_web" => $esAccesibleWeb
            ];
        }

        

            // Ordenar: carpetas primero, luego archivos, alfabéticamente
            usort($archivos, function($a, $b) {
                if ($a['esfolder'] && !$b['esfolder']) return -1;
                if (!$a['esfolder'] && $b['esfolder']) return 1;
                return strnatcasecmp($a['nombre'], $b['nombre']);
            });

            // Construir breadcrumb desde la raíz del sistema
            $rutaBreadcrumb = [];
            $current = $rutaReal;
            $segments = [];
            
            // Para sistemas Unix, partir desde /
            if (str_starts_with($current, '/')) {
                while ($current !== '/' && $current !== '') {
                    $segments[] = ['nombre' => basename($current), 'ruta' => $current];
                    $current = dirname($current);
                }
                $segments[] = ['nombre' => 'Root (/)', 'ruta' => '/'];
            } else {
                // Para Windows, partir desde la unidad
                while ($current && dirname($current) !== $current) {
                    $segments[] = ['nombre' => basename($current) ?: $current, 'ruta' => $current];
                    $current = dirname($current);
                }
            }
            
            $rutaBreadcrumb = array_reverse($segments);

            // Asegurar que siempre haya un breadcrumb
            if (empty($rutaBreadcrumb)) {
                $rutaBreadcrumb[] = ['nombre' => 'Root', 'ruta' => '/'];
            }

            return $this->response->json([
                'archivos'     => $archivos,
                'breadcrumb'   => $rutaBreadcrumb,
                'ruta_actual'  => $rutaReal,
                'inicio_local' => $rutaBase,
                'fcpath'       => FCPATH,
                'apppath'      => APPPATH,
                'rootpath'     => ROOTPATH
            ]);
        }

        // === MODO BASE DE DATOS ===
        $limit  = 20;
        $offset = $this->request->getPost('offset') ?? 0;
        $prms   = $this->request->getPost('prms')  ?? null;
        $query  = $this->request->getPost('query') ?? "";

        if (!validador_desencriptar($prms)) {
            $prms = [
                'tabla'   => "generico",
                'columna' => "generico",
            ];
        } else {
            $prms = validador_desencriptar($prms, true, true);
        }

        $sql = "SELECT * FROM app_archivos WHERE arch_tabla='" . addslashes($prms['tabla']) . "' AND arch_columna='" . addslashes($prms['columna']) . "'";
        
        if (!empty($query)) {
            $query = addslashes($query);
            if (preg_match('/^\*\.(\w+)$/', $query, $matches)) {
                $ext = strtolower($matches[1]);
                $sql .= " AND LOWER(JSON_UNQUOTE(JSON_EXTRACT(arch_documento, '$.doc_ext'))) = '$ext'";
            } else {
                $sql .= " AND LOWER(JSON_UNQUOTE(JSON_EXTRACT(arch_documento, '$.doc_file'))) LIKE '%" . strtolower($query) . "%'";
            }
        }

        $sql .= " ORDER BY arch_id DESC LIMIT $limit OFFSET $offset";
        $archivosDato = $this->Datos->datos_select($sql);
        $archivos = [];

        foreach ($archivosDato as $archivo) {
            $fileData = json_decode($archivo['arch_documento'], true);

            if (!is_array($fileData) || !isset($fileData['doc_file'], $fileData['doc_ext'], $fileData['doc_nombre'], $fileData['doc_mime'])) {
                continue;
            }

            $nombreArchivo = $fileData['doc_file'];
            $nombreInterno = $fileData['doc_nombre'];
            $ext           = strtolower($fileData['doc_ext']);

            $subPath    = "uploads/archivos/{$archivo['arch_tabla']}/{$archivo['arch_columna']}/$nombreInterno";
            $rutaPublica = "/public/" . $subPath;
            $filePath    = base_url($rutaPublica);
            $fullPath    = FCPATH . ltrim($rutaPublica, '/');

            $tamano = file_exists($fullPath) ? filesize($fullPath) : 0;
            $fecha  = file_exists($fullPath) ? date("c", filemtime($fullPath)) : null;

            $esImagen = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'tiff', 'tif', 'ico', 'avif']);
            $esVideo  = in_array($ext, ['mp4', 'webm', 'ogg']);
                
            $iconoURL = $esVideo
                ? base_url('public/imagenes/sistema/file_icon/movie/' . (file_exists(FCPATH . 'public/imagenes/sistema/file_icon/movie/' . $ext . '.png') ? $ext : 'file') . '.png')
                : base_url('public/imagenes/sistema/file_icon/' . (file_exists(FCPATH . 'public/imagenes/sistema/file_icon/' . $ext . '.png') ? $ext : 'file') . '.png');
            
            $vistaPrevia = $esImagen ? $filePath : $iconoURL;

            $archivos[] = [
                "id"        => validador_encriptar($archivo['arch_id']),
                "nombre"    => $nombreArchivo,
                "file"      => base_url($rutaPublica),
                "descargar" => base_url("/funciones/archivos/descargar?file=" . urlencode($fullPath)),
                "preview"   => $vistaPrevia,
                "ruta"      => validador_encriptar($archivo['arch_id']),
                "url"       => null,
                "esimagen"  => $esImagen ? "true" : "false",
                "esvideo"   => $esVideo ? "true" : "false",
                "esfolder"  => false,
                "tipo"      => $ext,
                "size"      => $tamano,
                "fecha"     => $fecha,
                "editable"  => true,
                "permisos"  => $this->obtenerPermisosUnix($fullPath)
            ];
        }

        return $this->response->json([
            'archivos'   => $archivos,
            'breadcrumb' => []
        ]);
    }
                    
    public function descargar()
    {
        $archivos   = $this->request->getPost('archivos');
        $modo       = $this->request->getPost('modo') ?? 'base_datos';
        $getFileId  = $this->request->getGet('file');
            
        if ($getFileId) 
        {
            $idDesencriptado = validador_desencriptar($getFileId);
            if (!$idDesencriptado) 
            {
                return $this->response->setStatus(400)->setBody("ID inválido en GET");
            }
    
            $fileReg = $this->Datos->datos_select("SELECT * FROM app_archivos WHERE arch_id = '$idDesencriptado'")[0] ?? null;
            if (!$fileReg) 
            {
                return $this->response->setStatus(404)->setBody("Archivo no encontrado en base de datos");
            }
    
            $doc = json_decode($fileReg['arch_documento'], true);
            if (!isset($doc['doc_nombre'], $doc['doc_file'])) 
            {
                return $this->response->setStatus(500)->setBody("Documento mal formado");
            }
    
            $ruta = FCPATH . "public/uploads/archivos/{$fileReg['arch_tabla']}/{$fileReg['arch_columna']}/{$doc['doc_nombre']}";
            return $this->descargarArchivoStream($ruta, $doc['doc_file']);
        }
        
        if ($archivos) 
        {
            $archivos = json_decode($archivos, true);
            if (!is_array($archivos)) 
            {
                return $this->response->setStatus(400)->setBody("Parámetro inválido");
            }

            // Si solo es un archivo real, entregarlo directamente
            if (count($archivos) === 1) 
            {
                $item = $archivos[0];
                $modo = strtolower($modo);
                $tipo = strtolower($item['type'] ?? '');
                            
                if ($modo === 'base_datos') 
                {
                    $idDesencriptado = validador_desencriptar($item['path'] ?? '');
                    if (!$idDesencriptado) 
                    {
                        return $this->response->setStatus(400)->setBody("ID inválido");
                    }
                
                    $fileReg = $this->Datos->datos_select("SELECT * FROM app_archivos WHERE arch_id = '$idDesencriptado'")[0] ?? null;
                
                    if (!$fileReg) 
                    {
                        return $this->response->setStatus(404)->setBody("Archivo no encontrado en base de datos");
                    }
                
                    $doc = json_decode($fileReg['arch_documento'], true);
                    if (!isset($doc['doc_nombre'])) 
                    {
                        return $this->response->setStatus(500)->setBody("Documento mal formado");
                    }
                
                    $rutaArchivo = FCPATH . "public/uploads/archivos/{$fileReg['arch_tabla']}/{$fileReg['arch_columna']}/{$doc['doc_nombre']}";

                    return $this->descargarArchivoStream($rutaArchivo, $doc['doc_file']);
                }

                // modo directorio
                $ruta = realpath($item['path'] ?? '');
                if ($ruta && is_file($ruta) && $tipo === 'file') 
                {
                    return $this->descargarArchivoStream($ruta, basename($ruta));
                }
            }

            // Crear ZIP para múltiples archivos o carpetas
            $zipPath = tempnam(sys_get_temp_dir(), 'zip');
            $zip = new \ZipArchive();
            if (!$zip->open($zipPath, \ZipArchive::OVERWRITE)) 
            {
                return $this->response->setStatus(500)->setBody("No se pudo crear el ZIP");
            }

            foreach ($archivos as $item) 
            {
                $tipo = strtolower($item['type'] ?? '');
                $nombreVisible = $item['name'] ?? 'archivo';
            
                if ($modo === 'base_datos') 
                {
                    $idDesencriptado = validador_desencriptar($item['path'] ?? '');
                    if (!$idDesencriptado) continue;
            
                    $fileReg = $this->Datos->datos_select("SELECT * FROM app_archivos WHERE arch_id = '$idDesencriptado'")[0] ?? null;
            
                    if (!$fileReg) continue;
            
                    $doc = json_decode($fileReg['arch_documento'], true);
                    if (!isset($doc['doc_nombre'], $doc['doc_file'])) continue;
            
                    $rutaArchivo = FCPATH . "public/uploads/archivos/{$fileReg['arch_tabla']}/{$fileReg['arch_columna']}/{$doc['doc_nombre']}";
            
                    if (is_file($rutaArchivo)) 
                    {
                        $zip->addFile($rutaArchivo, $doc['doc_file']);
                    }
                } 
                else 
                {
                    $ruta = realpath($item['path'] ?? '');
                    $nombreVisible = $item['name'] ?? basename($ruta);
        
                    if (!$ruta || !file_exists($ruta)) continue;
        
                    if (is_file($ruta)) 
                    {
                        $zip->addFile($ruta, $nombreVisible);
                    } 
                    elseif (is_dir($ruta)) 
                    {
                        $this->agregarCarpetaAlZip($zip, $ruta, $nombreVisible);
                    }
                }
            }

            $zip->close();

            // Asignar nombre dinámico al ZIP según carpeta común
            $nombreZip = "archivos.zip";

            if (count($archivos) > 1) {
                $carpetas = [];

                foreach ($archivos as $item) 
                {
                    if ($modo === 'base_datos') 
                    {
                        $idDesencriptado = validador_desencriptar($item['path'] ?? '');
                        if ($idDesencriptado) 
                        {
                            $fileReg = $this->Datos->datos_select("SELECT * FROM app_archivos WHERE arch_id = '$idDesencriptado'")[0] ?? null;
                            if ($fileReg) 
                            {
                                $carpetas[] = $fileReg['arch_tabla'] . '_' . $fileReg['arch_columna'];
                            }
                        }
                    }
                    else 
                    {
                        $ruta = realpath($item['path'] ?? '');
                        if ($ruta) 
                        {
                            $carpetas[] = basename(dirname($ruta));
                        }
                    }
                }

                $carpetasUnicas = array_unique($carpetas);
                if (count($carpetasUnicas) === 1) 
                {
                    $nombreZip = $carpetasUnicas[0] . ".zip";
                } 
                else 
                {
                    $nombreZip = "descarga_multiple.zip";
                }
            }

            return $this->descargarArchivoStream($zipPath, $nombreZip);
        }

        return $this->response->setStatus(404)->setBody("Parametros incorrectos");
    }



    private function agregarCarpetaAlZip(\ZipArchive $zip, string $rutaCarpeta, string $nombreEnZip)
    {
        $archivos = scandir($rutaCarpeta);
        foreach ($archivos as $archivo) {
            if ($archivo === '.' || $archivo === '..') continue;
    
            $rutaCompleta = $rutaCarpeta . DIRECTORY_SEPARATOR . $archivo;
            $rutaZip = $nombreEnZip . '/' . $archivo;
    
            if (is_dir($rutaCompleta)) {
                $zip->addEmptyDir($rutaZip);
                $this->agregarCarpetaAlZip($zip, $rutaCompleta, $rutaZip); // llamada recursiva
            } else {
                $zip->addFile($rutaCompleta, $rutaZip);
            }
        }
    }
    
                        
    private function descargarArchivoStream(string $ruta, string $nombreDescarga)
    {
        if (!file_exists($ruta) || !is_readable($ruta)) {
            return $this->response->setStatus(404)->setBody("Archivo no disponible");
        }
    
        @set_time_limit(0);
        @ini_set('memory_limit', '512M');
        @ob_end_clean();
        @ini_set('zlib.output_compression', 'Off');
    
        $esTemporal = str_starts_with($ruta, sys_get_temp_dir());
        if ($esTemporal) {
            register_shutdown_function(fn() => @unlink($ruta));
        }
    
        $nombreSeguro = basename($nombreDescarga);
        $nombreDescargaSeguro = rawurlencode($nombreSeguro); // ← importante
    
        header("Content-Description: File Transfer");
        header("Content-Type: application/octet-stream");
        header("Content-Disposition: attachment; filename*=UTF-8''{$nombreDescargaSeguro}");
        header("Expires: 0");
        header("Cache-Control: no-store, no-cache, must-revalidate");
        header("Pragma: public");
        header("Content-Length: " . filesize($ruta));
        header("Connection: close");
    
        flush();
        $chunkSize = 1024 * 1024;
        $handle = fopen($ruta, 'rb');
        if ($handle === false) {
            return $this->response->setStatus(500)->setBody("Error al abrir archivo");
        }
    
        while (!feof($handle)) {
            echo fread($handle, $chunkSize);
            flush();
            @ob_flush();
        }
    
        fclose($handle);
        if ($esTemporal) @unlink($ruta);
        exit;
    }

    private function descargarCarpetaZip($folderPath)
    {
        if (!is_dir($folderPath)) return false;

        $zipPath = tempnam(sys_get_temp_dir(), 'zip');
        $zip = new \ZipArchive();

        if ($zip->open($zipPath, \ZipArchive::OVERWRITE) !== true) {
            echo "❌ No se pudo crear ZIP";
            exit();
        }

        // CORRECCIÓN: Pasar los parámetros en el orden correcto
        // y usar basename() para el nombre en el ZIP
        $this->agregarCarpetaAlZip($zip, $folderPath, basename($folderPath));
        
        $zip->close();

        $zipName = basename($folderPath) . ".zip";
        return $this->descargarArchivoStream($zipPath, $zipName);
    }



    /**
     * Construye un item (shape de obt_files) desde una ruta absoluta en disco.
     * Retorna null si la ruta no existe.
     */
    function buildItemFromPath($rutaAbs)
    {
        if (!$rutaAbs || !file_exists($rutaAbs)) return null;

        $isDir      = is_dir($rutaAbs);
        $rel        = str_replace('\\','/', str_replace(FCPATH, '', $rutaAbs));
        if (!str_starts_with($rel, '/')) $rel = '/'.$rel;

        $nombre     = basename($rutaAbs);
        $size       = $isDir ? 0 : @filesize($rutaAbs);
        $mtime      = @filemtime($rutaAbs);
        $ext        = $isDir ? 'folder' : strtolower(pathinfo($rutaAbs, PATHINFO_EXTENSION));
        $esImagen   = in_array($ext, ['jpg','jpeg','png','gif','webp','bmp','svg','avif']);
        $esVideo    = in_array($ext, ['mp4','webm','ogg','mov','mkv','avi']);

        // URL pública del recurso (si aplica)
        $urlPublica = base_url(ltrim($rel,'/'));

        // --- Resolución del ícono estilo KodExplorer ---
        // Base de íconos en filesystem y en web
        $iconBaseFs  = rtrim(FCPATH, '/').'/public/imagenes/sistema/file_icon/';
        $iconBaseUrl = base_url('public/imagenes/sistema/file_icon/');

        // Selección de ícono por tipo
        if ($isDir) {
            // Carpeta
            $iconoUrl = $iconBaseUrl.'folder.png';
            if (!is_file($iconBaseFs.'folder.png')) {
                // Si no hubiera folder.png por algún motivo, fallback a file.png
                $iconoUrl = $iconBaseUrl.'file.png';
            }
        } elseif ($esVideo) {
            // Video: buscar en subcarpeta movie/ por extensión; fallback a movie/file.png o file.png
            $movieFs  = $iconBaseFs.'movie/';
            $movieUrl = $iconBaseUrl.'movie/';
            $iconoUrl = is_file($movieFs.$ext.'.png') ? ($movieUrl.$ext.'.png')
                       : (is_file($movieFs.'file.png') ? ($movieUrl.'file.png') : ($iconBaseUrl.'file.png'));
        } else {
            // Archivo general por extensión; fallback a file.png
            $iconoUrl = is_file($iconBaseFs.$ext.'.png') ? ($iconBaseUrl.$ext.'.png') : ($iconBaseUrl.'file.png');
        }

        // Preview final (solo para la vista previa, sin tocar otras lógicas)
        $preview = $esImagen ? $urlPublica : $iconoUrl;

        return [
            'id'        => null,
            'nombre'    => $nombre,
            'file'      => $urlPublica,
            'preview'   => $preview,       // ← ahora siempre hay preview (imagen o ícono)
            'ruta'      => $rutaAbs,
            'url'       => $rutaAbs,
            'esimagen'  => $esImagen,
            'esvideo'   => $esVideo,
            'esfolder'  => $isDir ? true : false,
            'tipo'      => $ext,
            'size'      => $size ?: 0,
            'fecha'     => $mtime ? date('c',$mtime) : null,
            'editable'  => is_writable($rutaAbs) ? true : false,
            'permisos'  => method_exists($this,'obtenerPermisosUnix') ? $this->obtenerPermisosUnix($rutaAbs) : null,

            // Opcional: si quieres consumir el ícono explícitamente además del preview
            'icono'     => $iconoUrl
        ];
    }



    // =========================================================
    // Helpers: Búsqueda por contenido (agrupado por archivo)
    // =========================================================
    private function _parseFileTypeFilter($raw)
    {
        $raw = trim((string)$raw);
        if ($raw === '') return [];

        // Acepta: "js", ".js", "*.js", "js,php,txt", "js|php"
        $raw = strtolower($raw);
        $raw = str_replace(['*', ' '], '', $raw);
        $parts = preg_split('/[,\|;]+/', $raw);

        $exts = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p === '') continue;
            if (str_starts_with($p, '.')) $p = substr($p, 1);
            if ($p === '') continue;
            $exts[$p] = true;
        }
        return array_keys($exts);
    }

    private function _isProbablyBinary($path)
    {
        if (!is_file($path) || !is_readable($path)) return true;

        $fh = @fopen($path, 'rb');
        if (!$fh) return true;
        $chunk = @fread($fh, 2048);
        @fclose($fh);

        if ($chunk === false || $chunk === '') return false;

        // Si hay bytes nulos, probablemente es binario
        return (strpos($chunk, "\0") !== false);
    }

    private function _searchMatchesInFile($path, $needle, $ignoreCase = true, $maxMatches = 60)
    {
        $matches = [];
        if (!is_file($path) || !is_readable($path)) return $matches;

        // Evitar binarios
        if ($this->_isProbablyBinary($path)) return $matches;

        $needle = (string)$needle;
        if ($needle === '') return $matches;

        try {
            $file = new \SplFileObject($path, 'r');
            $file->setFlags(\SplFileObject::DROP_NEW_LINE);

            $lineNo = 0;
            while (!$file->eof()) {
                $line = $file->fgets();
                $lineNo++;

                if ($line === false) continue;

                $hay = $ignoreCase ? stripos($line, $needle) !== false : strpos($line, $needle) !== false;
                if ($hay) {
                    $snippet = trim((string)$line);
                    if (strlen($snippet) > 260) $snippet = substr($snippet, 0, 260) . '…';

                    $matches[] = [
                        'line'    => $lineNo,
                        'snippet' => $snippet
                    ];

                    if (count($matches) >= $maxMatches) break;
                }
            }
        } catch (\Throwable $e) {
            // silencioso
        }

        return $matches;
    }

    private function _iconForExt($ext, $isVideo = false)
    {
        $ext = strtolower((string)$ext);
        $ext = $ext ?: 'file';

        $baseIconDir = FCPATH . 'public/imagenes/sistema/file_icon/';
        if ($isVideo) {
            $movieDir = $baseIconDir . 'movie/';
            $fileName = (file_exists($movieDir . $ext . '.png')) ? $ext : 'file';
            return base_url('public/imagenes/sistema/file_icon/movie/' . $fileName . '.png');
        }

        $fileName = (file_exists($baseIconDir . $ext . '.png')) ? $ext : 'file';
        return base_url('public/imagenes/sistema/file_icon/' . $fileName . '.png');
    }

    private function _buildMetaFromPath($rutaCompleta)
    {
        $rutaCompleta = (string)$rutaCompleta;
        $item = basename($rutaCompleta);
        $esFolder = is_dir($rutaCompleta) ? "true" : "false";

        $tamano = is_file($rutaCompleta) ? @filesize($rutaCompleta) : 0;
        $ext = $esFolder === "true" ? "folder" : strtolower(pathinfo($rutaCompleta, PATHINFO_EXTENSION));
        $esImagen = in_array($ext, ['jpg','jpeg','png','gif','bmp','webp','svg','tiff','tif','ico','avif']);
        $esVideo  = in_array($ext, ['mp4','webm','ogg']);

        $iconoURL = $this->_iconForExt($ext, $esVideo);

        $relativa = str_replace(realpath(FCPATH), '', $rutaCompleta);
        $urlBase  = base_url(ltrim(str_replace(DIRECTORY_SEPARATOR, '/', $relativa), '/'));

        return [
            "id"        => 0,
            "nombre"    => $item,
            "file"      => $urlBase,
            "descargar" => base_url('funciones/archivos/descargar?file=' . urlencode($rutaCompleta)),
            "preview"   => $esImagen ? $urlBase : $iconoURL,
            "ruta"      => $rutaCompleta,
            "ruta_dir"  => dirname($rutaCompleta),
            "url"       => $urlBase,
            "esimagen"  => $esImagen ? "true" : "false",
            "esvideo"   => $esVideo ? "true" : "false",
            "esfolder"  => $esFolder,
            "tipo"      => $ext,
            "size"      => $tamano,
            "fecha"     => @date("c", @filemtime($rutaCompleta)),
            "editable"  => is_writable($rutaCompleta) ? true : false,
            "permisos"  => $this->obtenerPermisosUnix($rutaCompleta)
        ];
    }

    private function _buscarContenidoAgrupado($modo)
    {
        $query = (string)($this->request->getPost('query') ?? '');
        $query = trim($query);

        $ignoreCase = ($this->request->getPost('ignore_case') ?? '1') === '1';
        $fileTypeRaw = $this->request->getPost('file_type') ?? '';
        $filterExts = $this->_parseFileTypeFilter($fileTypeRaw);

        // Por defecto: solo extensiones "texto"
        $defaultTextExts = ['txt','md','js','ts','jsx','tsx','php','html','htm','css','scss','json','xml','yml','yaml','ini','env','sql','py','java','c','cpp','h','cs','go','rb','sh','bat','ps1','csv','log'];
        $allowedExts = !empty($filterExts) ? $filterExts : $defaultTextExts;

        $maxFiles      = (int)($this->request->getPost('max_files') ?? 3000);
        $maxFileSizeKB = (int)($this->request->getPost('max_kb') ?? 2048); // 2MB
        $maxMatchesPerFile = (int)($this->request->getPost('max_matches_file') ?? 80);
        $maxTotalMatches   = (int)($this->request->getPost('max_matches_total') ?? 500);

        if ($query === '') {
            return [
                'estado' => 'ok',
                'total_matches' => 0,
                'total_files' => 0,
                'results' => []
            ];
        }

        if ($modo === 'directorio') {
            $rutaInput = $this->request->getPost('ruta') ?? '';
            
            if (trim($rutaInput) === '') {
                // Si no se especifica ruta, usar el directorio home del usuario
                $rutaReal = getenv('HOME') ?: '/';
            } else {
                // Decodificar y normalizar la ruta
                $rutaInput = urldecode(trim($rutaInput));
                $rutaNormalizada = Path::toUnix($rutaInput);
                $rutaNormalizada = Path::collapseDots($rutaNormalizada);
                
                if (Path::isAbsolute($rutaNormalizada)) {
                    $rutaReal = realpath(Path::toNative($rutaNormalizada));
                } else {
                    // Si es relativa, partir del directorio actual
                    $rutaReal = realpath(Path::join(getcwd(), $rutaNormalizada));
                }
            }

            if (!$rutaReal || !is_dir($rutaReal)) {
                return [
                    'estado' => 'ok',
                    'total_matches' => 0,
                    'total_files' => 0,
                    'results' => [],
                    'mensaje' => 'Ruta inválida'
                ];
            }

            // Seguridad: podemos restringir a ciertos directorios si lo deseas
            // Por ejemplo, solo permitir búsqueda en directorios específicos
            $directoriosPermitidos = [
                FCPATH,
                APPPATH,
                ROOTPATH,
                getenv('HOME') ?: '/home',
                '/var/www'
            ];
            
            $permitido = false;
            foreach ($directoriosPermitidos as $dirPermitido) {
                if (Path::within($rutaReal, $dirPermitido)) {
                    $permitido = true;
                    break;
                }
            }
            
            if (!$permitido) {
                return [
                    'estado' => 'ok',
                    'total_matches' => 0,
                    'total_files' => 0,
                    'results' => [],
                    'mensaje' => 'Ruta no permitida para búsqueda'
                ];
            }

            $results = [];
            $totalMatches = 0;

            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($rutaReal, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST
            );

            $scanned = 0;
            foreach ($it as $fileInfo) {
                if ($scanned >= $maxFiles) break;
                if (!$fileInfo->isFile()) continue;

                $fullPath = $fileInfo->getPathname();
                $scanned++;

                $size = (int)$fileInfo->getSize();
                if ($size > ($maxFileSizeKB * 1024)) continue;

                $ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
                if (!in_array($ext, $allowedExts)) continue;

                $matches = $this->_searchMatchesInFile($fullPath, $query, $ignoreCase, $maxMatchesPerFile);
                if (empty($matches)) continue;

                $meta = $this->_buildMetaFromPath($fullPath);
                $count = count($matches);

                $results[] = [
                    'file' => $meta,
                    'match_count' => $count,
                    'matches' => $matches
                ];

                $totalMatches += $count;
                if ($totalMatches >= $maxTotalMatches) break;
            }

            return [
                'estado' => 'ok',
                'modo' => 'directorio',
                'query' => $query,
                'total_matches' => $totalMatches,
                'total_files' => count($results),
                'results' => $results
            ];
        }

        // ===========================
        // MODO BASE DE DATOS
        // ===========================
        $prms = $this->request->getPost('prms') ?? null;

        if (!validador_desencriptar($prms)) {
            $prms = [
                'tabla'   => "generico",
                'columna' => "generico",
            ];
        } else {
            $prms = validador_desencriptar($prms, true, true);
        }

        $sql = "SELECT * FROM app_archivos WHERE arch_tabla='" . addslashes($prms['tabla']) . "' AND arch_columna='" . addslashes($prms['columna']) . "'";
        $rows = $this->Datos->datos_select($sql);

        $results = [];
        $totalMatches = 0;

        $scanned = 0;
        foreach ($rows as $archivo) {
            if ($scanned >= $maxFiles) break;

            $fileData = json_decode($archivo['arch_documento'] ?? '', true);
            if (empty($fileData) || empty($fileData['doc_nombre']) || empty($fileData['doc_ext'])) continue;

            $ext = strtolower($fileData['doc_ext']);
            if (!in_array($ext, $allowedExts)) continue;

            $subPath = "uploads/archivos/{$archivo['arch_tabla']}/{$archivo['arch_columna']}/{$fileData['doc_nombre']}";
            $rutaPublica = "/public/" . $subPath;
            $fullPath = FCPATH . ltrim($rutaPublica, '/');

            if (!is_file($fullPath) || !is_readable($fullPath)) continue;

            $size = @filesize($fullPath);
            if ($size === false) $size = 0;
            if ($size > ($maxFileSizeKB * 1024)) continue;

            $scanned++;

            $matches = $this->_searchMatchesInFile($fullPath, $query, $ignoreCase, $maxMatchesPerFile);
            if (empty($matches)) continue;

            $esImagen = in_array($ext, ['jpg','jpeg','png','gif','bmp','webp','svg','tiff','tif','ico','avif']);
            $esVideo  = in_array($ext, ['mp4','webm','ogg']);
            $iconoURL = $this->_iconForExt($ext, $esVideo);
            $fileUrl  = base_url($rutaPublica);

            $meta = [
                "id"        => validador_encriptar($archivo['arch_id']),
                "nombre"    => $fileData['doc_file'] ?? $fileData['doc_nombre'],
                "file"      => $fileUrl,
                "descargar" => base_url("/funciones/archivos/descargar?file=" . urlencode($fullPath)),
                "preview"   => $esImagen ? $fileUrl : $iconoURL,
                "ruta"      => validador_encriptar($archivo['arch_id']),
                "url"       => $fileUrl,
                "esimagen"  => $esImagen ? "true" : "false",
                "esvideo"   => $esVideo ? "true" : "false",
                "esfolder"  => "false",
                "tipo"      => $ext,
                "size"      => $size,
                "fecha"     => file_exists($fullPath) ? date("c", filemtime($fullPath)) : null,
                "editable"  => false,
                "permisos"  => null
            ];

            $count = count($matches);

            $results[] = [
                'file' => $meta,
                'match_count' => $count,
                'matches' => $matches
            ];

            $totalMatches += $count;
            if ($totalMatches >= $maxTotalMatches) break;
        }

        return [
            'estado' => 'ok',
            'modo' => 'base_datos',
            'query' => $query,
            'total_matches' => $totalMatches,
            'total_files' => count($results),
            'results' => $results
        ];
    }

} 
?>