<?php
declare(strict_types=1);

namespace App\Controllers;

/**
 * ValidadoresDebug
 *
 * Controller utilitario para probar rápidamente el helper "validadores".
 * Ruta sugerida (dev):
 *  - /ValidadoresDebug
 *  - /debug/validadores
 */
final class ValidadoresDebug extends BaseController
{
  protected array $helpers = ['url'];

  public function index(): string|\System\Core\Response
  {
    // Asegura carga (aunque tengas autoload global)
    helper(['validadores']);

    $in = [
      'email'   => (string)$this->request->input('email', 'test@example.com'),
      'phone'   => (string)$this->request->input('phone', '+51947422276'),
      'country' => (string)$this->request->input('country', 'PE'),
      'phrase'  => (string)$this->request->input('phrase', 'Hola mundo'),
      'base64'  => (string)$this->request->input('base64', 'SG9sYSBtdW5kbw=='),
      'json'    => (string)$this->request->input('json', '{"ok":true}'),
      'plain'   => (string)$this->request->input('plain', 'texto a encriptar'),
      'cipher'  => (string)$this->request->input('cipher', ''),
    ];

    $results = $this->run($in);

    // Forzar JSON si ?format=json
    $format = strtolower((string)$this->request->get('format', ''));
    if ($this->request->wantsJson() || $format === 'json') {
      return $this->json($results, 200);
    }

    return $this->renderHtml($in, $results);
  }

  private function run(array $in): array
  {
    // Informativo: vendors detectados
    $vendorInfo = [
      'composer_autoload' => is_file(base_path('vendor/autoload.php')),
      'validmail_factory' => class_exists('EmailValidation\\EmailValidatorFactory'),
      'libphonenumber'    => class_exists('libphonenumber\\PhoneNumberUtil'),
    ];

    $emailRes = Validador_email($in['email']);
    $phoneRes = Validador_phone($in['phone'], $in['country']);
    $badWord  = Validador_frase($in['phrase']); // false|string
    $b64Ok    = validador_base64($in['base64']);
    $jsonOk   = validador_isjson($in['json']);

    // Encriptación / desencriptación
    $cipher = trim((string)$in['cipher']) !== '' ? (string)$in['cipher'] : null;
    $cipherFromPlain = null;

    if ($cipher === null && trim((string)$in['plain']) !== '') {
      try {
        $cipherFromPlain = validador_encriptar($in['plain']);
        if (is_string($cipherFromPlain) && $cipherFromPlain !== '') {
          $cipher = $cipherFromPlain;
        }
      } catch (\Throwable $e) {
        $cipherFromPlain = ['error' => $e->getMessage()];
      }
    }

    $decrypted = null;
    if (is_string($cipher) && $cipher !== '') {
      try {
        $decrypted = validador_desencriptar($cipher, false);
      } catch (\Throwable $e) {
        $decrypted = ['error' => $e->getMessage()];
      }
    }

    return [
      'vendor' => $vendorInfo,
      'input'  => $in,
      'tests'  => [
        'Validador_email' => ['ok' => (bool)($emailRes[0] ?? false), 'raw' => $emailRes],
        'Validador_phone' => ['ok' => (bool)($phoneRes[0] ?? false), 'raw' => $phoneRes],
        'Validador_frase' => ['found' => $badWord],
        'validador_base64' => ['ok' => (bool)$b64Ok],
        'validador_isjson' => ['ok' => (bool)$jsonOk],
        'encryption' => [
          'cipher_from_plain' => $cipherFromPlain,
          'cipher_used'       => $cipher,
          'decrypted'         => $decrypted,
        ],
      ],
      'howto' => [
        'html' => 'Abre /ValidadoresDebug',
        'json' => 'Abre /ValidadoresDebug?format=json',
      ],
    ];
  }

  private function renderHtml(array $in, array $results): string
  {
    $esc = static fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $pre = static fn($v) => htmlspecialchars(json_encode($v, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) ?: '', ENT_QUOTES, 'UTF-8');

    $action = url('/ValidadoresDebug');

    $html = '<!doctype html><html lang="es"><head><meta charset="utf-8">';
    $html .= '<meta name="viewport" content="width=device-width, initial-scale=1">';
    $html .= '<title>Validadores Debug</title>';
    $html .= '<style>
      body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:18px;max-width:1100px;margin:0 auto;background:#0b1220;color:#e8eefc}
      a{color:#9cc9ff}
      .row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
      label{font-size:12px;color:#b8c4dd}
      input,textarea{width:100%;padding:10px;border:1px solid rgba(255,255,255,.14);border-radius:12px;background:rgba(255,255,255,.06);color:#e8eefc}
      textarea{min-height:90px}
      .card{border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:14px;margin-top:14px;background:rgba(255,255,255,.03)}
      .btn{display:inline-block;padding:10px 14px;border-radius:12px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);text-decoration:none;color:#e8eefc;cursor:pointer}
      .btn-primary{background:#2b67ff;border-color:#2b67ff}
      pre{white-space:pre-wrap;word-break:break-word;background:#050a15;color:#e6e6e6;padding:12px;border-radius:12px;overflow:auto}
      .muted{color:#b8c4dd;font-size:12px;opacity:.9}
      code{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:8px}
    </style></head><body>';

    $html .= '<h2>Validadores Debug</h2>';
    $html .= '<div class="muted">Tip: agrega <code>?format=json</code> para ver respuesta JSON.</div>';

    $html .= '<div class="card"><form method="post" action="'.$esc($action).'">';
    $html .= '<div class="row">';

    $html .= '<div><label>Email</label><input name="email" value="'.$esc($in['email']).'"></div>';
    $html .= '<div><label>Teléfono</label><input name="phone" value="'.$esc($in['phone']).'"></div>';

    $html .= '<div><label>País (ISO2)</label><input name="country" value="'.$esc($in['country']).'"></div>';
    $html .= '<div><label>Frase (detecta palabra prohibida)</label><input name="phrase" value="'.$esc($in['phrase']).'"></div>';

    $html .= '<div><label>Base64</label><input name="base64" value="'.$esc($in['base64']).'"></div>';
    $html .= '<div><label>JSON</label><input name="json" value="'.$esc($in['json']).'"></div>';

    $html .= '<div><label>Texto a encriptar</label><textarea name="plain">'.$esc($in['plain']).'</textarea></div>';
    $html .= '<div><label>Cipher (si lo pegas aquí, se intenta desencriptar)</label><textarea name="cipher">'.$esc($in['cipher']).'</textarea></div>';

    $html .= '</div>';
    $html .= '<div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap">';
    $html .= '<button class="btn btn-primary" type="submit">Probar</button>';
    $html .= '<a class="btn" href="'. $esc(url('/ValidadoresDebug?format=json')) .'">Ver JSON</a>';
    $html .= '</div>';
    $html .= '</form></div>';

    $html .= '<div class="card"><h3>Resultados</h3>';
    $html .= '<pre>'.$pre($results).'</pre>';
    $html .= '</div>';

    $html .= '</body></html>';
    return $html;
  }
}
