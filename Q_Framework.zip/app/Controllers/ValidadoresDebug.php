<?php
declare(strict_types=1);

namespace App\Controllers;

use System\Core\Response;

/**
 * ValidadoresDebug (DESHABILITADO)
 *
 * Este controller existía solo como utilidad de desarrollo para probar el helper "validadores".
 * Como este build no incluye dicho helper, se deja deshabilitado para evitar errores y exposición
 * accidental en producción.
 *
 * Recomendación: elimina este archivo y sus rutas si ya no lo necesitas.
 */
final class ValidadoresDebug extends BaseController
{
  protected array $helpers = ['url'];

  public function index(): string|Response
  {
    $html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
          . '<title>Endpoint deshabilitado</title>'
          . '<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:32px;line-height:1.55}code{background:#f3f4f6;padding:2px 6px;border-radius:6px}h1{font-size:20px;margin:0 0 12px}p{margin:8px 0;color:#111}small{color:#666}</style>'
          . '</head><body>'
          . '<h1>Endpoint deshabilitado</h1>'
          . '<p>Este endpoint era solo para desarrollo y fue retirado de este build del framework.</p>'
          . '<p>Acción recomendada: elimina <code>app/Controllers/ValidadoresDebug.php</code> y remueve sus rutas en <code>app/Config/Routes.php</code>.</p>'
          . '<small>Q_Framework</small>'
          . '</body></html>';

    return $this->response->setStatus(404)->setBody($html);
  }
}
