<?php
declare(strict_types=1);

namespace App\Support;

use App\Contracts\MailerInterface;
use System\Core\Mail;

/**
 * MailerAdapter
 *
 * Implementación por defecto de MailerInterface.
 * Envía usando System\Core\Mail::send(), que por defecto usa PHP mail().
 *
 * Para reemplazar el transporte (SMTP/API), crea tu propia implementación y
 * bindea el contrato en un Provider.
 */
final class MailerAdapter implements MailerInterface
{
  public function send(string $to, string $subject, string $html, array $headers = []): bool
  {
    return Mail::send($to, $subject, $html, $headers);
  }
}
