<?php
declare(strict_types=1);

namespace App\Support;

/**
 * Url extendida (opcional).
 *
 * Para activarla:
 *  - En app/Config/App.php: $this->urlClass = \App\Support\Url::class;
 *  - O en .env: URL_CLASS=App\Support\Url
 *
 * Recomendación:
 *  - Mantén esta clase delgada y delega a parent::base() cuando sea posible.
 */
class Url extends \System\Core\Url
{
    // Ejemplo: forzar un prefijo o ajustar comportamiento en hosting particular.
    // public static function base(string $path = ''): string
    // {
    //     return parent::base($path);
    // }
}
