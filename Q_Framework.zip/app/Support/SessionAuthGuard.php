<?php
declare(strict_types=1);

namespace App\Support;

use App\Contracts\AuthGuardInterface;
use System\Core\Session;

/**
 * SessionAuthGuard
 *
 * Guard por defecto basado en Session.
 * Convención: guarda el usuario autenticado en $_SESSION['user'].
 *
 * Compatible con el módulo Modules\Auth\Support\Auth (misma convención).
 */
final class SessionAuthGuard implements AuthGuardInterface
{
  public function check(): bool
  {
    Session::ensureStarted();
    return !empty($_SESSION['user']);
  }

  public function user(): ?array
  {
    Session::ensureStarted();
    $u = $_SESSION['user'] ?? null;
    return is_array($u) ? $u : null;
  }

  public function id(): ?int
  {
    $u = $this->user();
    if (!$u) return null;
    return isset($u['id']) ? (int)$u['id'] : null;
  }

  public function login(int|array $idOrUser, ?array $user = null): void
  {
    Session::ensureStarted();

    if (is_array($idOrUser)) {
      $user = $idOrUser;
    } else {
      $user = $user ?? ['id' => $idOrUser];
      $user['id'] = (int)$idOrUser;
    }

    // Sanitiza: no guardar hashes/secretos
    unset($user['password_hash'], $user['password'], $user['token'], $user['secret']);

    // Normaliza
    if (isset($user['email'])) $user['email'] = strtolower(trim((string)$user['email']));
    if (isset($user['role']))  $user['role']  = strtolower(trim((string)$user['role']));

    $_SESSION['user'] = $user;
    @session_regenerate_id(true);
  }

  public function logout(): void
  {
    Session::ensureStarted();
    unset($_SESSION['user']);
    @session_regenerate_id(true);
  }

  public function hasRole(string $role): bool
  {
    $u = $this->user();
    if (!$u) return false;
    return strtolower((string)($u['role'] ?? '')) === strtolower(trim($role));
  }
}
