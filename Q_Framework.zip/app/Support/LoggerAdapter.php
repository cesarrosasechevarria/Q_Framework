<?php
declare(strict_types=1);

namespace App\Support;

use App\Contracts\LoggerInterface;
use System\Core\Logger as CoreLogger;

/**
 * LoggerAdapter
 *
 * Implementación por defecto del contrato LoggerInterface.
 * Encapsula System\Core\Logger (estático) para que módulos/capas dependan de un contrato.
 */
final class LoggerAdapter implements LoggerInterface
{
  public function log(string $level, string $message, array $context = []): void
  {
    $lvl = strtoupper(trim($level));
    // Mantener niveles conocidos
    switch ($lvl) {
      case 'WARN':
      case 'WARNING':
        $this->warn($message, $context);
        break;
      case 'ERROR':
      case 'ERR':
        $this->error($message, $context);
        break;
      default:
        $this->info($message, $context);
        break;
    }
  }

  public function info(string $message, array $context = []): void
  {
    CoreLogger::info($message, $context);
  }

  public function warn(string $message, array $context = []): void
  {
    CoreLogger::warn($message, $context);
  }

  public function error(string $message, array $context = []): void
  {
    CoreLogger::error($message, $context);
  }
}
