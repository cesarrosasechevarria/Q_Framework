<?php
/** @var string $detectedBase */
/** @var string $currentBase */
/** @var bool $hasPublic */
/** @var array|null $result */
?>
<div class="qfw-card">
  <h1 style="margin-top:0">URLs limpias (sin <code>/public</code>)</h1>
  <p class="qfw-muted" style="margin-top:0">
    En producción, lo recomendado (Q_Framework) es que el <strong>DocumentRoot</strong> apunte a <code>public/</code>.
    Pero si estás en XAMPP o hosting compartido y no puedes cambiar el DocumentRoot, Q_Framework puede trabajar
    con un <strong>shim .htaccess</strong> en la raíz para que la URL quede limpia.
  </p>

  <?php if (is_array($result)): ?>
    <?php if (!empty($result['ok'])): ?>
      <div class="qfw-card" style="border:1px solid rgba(34,197,94,.45); background:rgba(34,197,94,.06); margin-top:12px">
        <div style="font-weight:900">✅ Listo</div>
        <div class="qfw-muted" style="margin-top:6px"><?= e((string)($result['message'] ?? '')) ?></div>
        <div style="margin-top:10px; display:flex; gap:10px; flex-wrap:wrap">
          <a class="qfw-btn" href="<?= e((string)($result['baseURL'] ?? $detectedBase)) ?>">Abrir Home (URL limpia)</a>
          <a class="qfw-btn" href="<?= route_url('docs.publicless') ?>">Ver guía completa</a>
        </div>
      </div>
    <?php else: ?>
      <div class="qfw-card" style="border:1px solid rgba(239,68,68,.45); background:rgba(239,68,68,.06); margin-top:12px">
        <div style="font-weight:900">⚠️ No se pudo aplicar</div>
        <div class="qfw-muted" style="margin-top:6px"><?= e((string)($result['message'] ?? 'Error desconocido')) ?></div>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  <div class="qfw-card" style="margin-top:14px">
    <div style="font-weight:900">Detección</div>
    <div class="qfw-muted" style="margin-top:8px">
      BaseURL configurada: <code><?= e($currentBase ?: '(vacío)') ?></code><br>
      BaseURL recomendada (detectada): <code><?= e($detectedBase) ?></code>
    </div>

    <?php if ($hasPublic): ?>
      <div class="qfw-muted" style="margin-top:10px">
        Detectamos que tu <code>baseURL</code> termina en <code>/public</code>. Eso hace que los enlaces muestren <code>/public</code>.
      </div>
      <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px">
        <a class="qfw-btn" href="<?= route_url('setup.publicless') ?>?apply=1">Activar URL limpia automáticamente</a>
        <a class="qfw-btn" href="<?= route_url('docs.publicless') ?>">Ver guía (DocumentRoot / VirtualHost)</a>
      </div>
    <?php else: ?>
      <div class="qfw-muted" style="margin-top:10px">
        Tu <code>baseURL</code> ya se ve limpia. Si aún navegas con <code>/public</code>, revisa la guía.
      </div>
      <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px">
        <a class="qfw-btn" href="<?= route_url('docs.publicless') ?>">Ver guía completa</a>
        <a class="qfw-btn" href="<?= route_url('home') ?>">Volver</a>
      </div>
    <?php endif; ?>
  </div>

  <div class="qfw-card" style="margin-top:14px">
    <div style="font-weight:900">Recomendado (PRO)</div>
    <p class="qfw-muted" style="margin-top:8px">
      Si puedes, configura tu servidor para que el DocumentRoot apunte a <code>public/</code>:
      es la opción más segura (no expones <code>app/</code>, <code>system/</code>, <code>.env</code>).
      El modo <em>shim</em> es útil cuando no tienes control del DocumentRoot.
    </p>
  </div>
</div>
