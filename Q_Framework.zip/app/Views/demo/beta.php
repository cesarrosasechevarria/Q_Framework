<div class="qfw-container">
  <div class="qfw-card">
    <h1 class="qfw-h1">Feature: Beta</h1>
    <p class="qfw-muted">
      Si estás viendo esto, significa que el filtro <b>FeatureFlagFilter</b> pasó correctamente.
    </p>

    <p>Session key requerida: <code>feature_beta === true</code></p>

    <div style="margin-top:16px">
      <a class="qfw-btn" href="<?= route_url('demo.public') ?>">Volver</a>
    </div>
  </div>
</div>
