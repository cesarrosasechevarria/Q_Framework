<div class="qfw-container">
  <div class="qfw-card">
    <h1 class="qfw-h1">Demo PRO</h1>
    <p class="qfw-muted">
      Esta sección muestra ejemplos reales de <b>Guard</b>, <b>Filters</b> y <b>API token</b> listos para copiar.
    </p>

    <h3 class="qfw-h3">1) Guard por ruta</h3>
    <p>Ruta protegida: <code>/demo/secure</code> (requiere sesión <code>user</code>).</p>

    <h3 class="qfw-h3">2) Filter configurable por ruta</h3>
    <p>Ruta: <code>/demo/beta</code> usa:</p>
    <pre><code>feature:flag=beta&amp;source=session&amp;key=feature_beta&amp;redirect=@demo.public</code></pre>
    <p>Para habilitarla rápido: <a class="qfw-btn" href="<?= route_url('demo.enable_beta') ?>">Habilitar beta (requiere login)</a></p>

    <h3 class="qfw-h3">3) API token + rate limit</h3>
    <p>Prueba con curl:</p>
    <pre><code>curl -H "Authorization: Bearer demo_token" "<?= base_url('/api/v1/ping') ?>"</code></pre>

    <div style="margin-top:16px">
      <a class="qfw-btn" href="<?= route_url('docs.index') ?>">Ver documentación</a>
    </div>
  </div>
</div>
