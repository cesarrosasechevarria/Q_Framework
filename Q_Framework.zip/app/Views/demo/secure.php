<?php $user = $user ?? auth_user(); ?>
<div class="qfw-container">
  <div class="qfw-card">
    <h1 class="qfw-h1">Guard por ruta</h1>
    <p class="qfw-muted">Esta ruta usa <code>guard</code> directamente en la definición de ruta.</p>

    <div class="qfw-card" style="padding:14px;margin-top:12px">
      <div class="qfw-kv"><b>Email</b><span><?= e($user['email'] ?? '-') ?></span></div>
      <div class="qfw-kv"><b>Rol</b><span><?= e($user['role'] ?? '-') ?></span></div>
    </div>

    <div style="margin-top:16px">
      <a class="qfw-btn" href="<?= route_url('demo.public') ?>">Volver</a>
    </div>
  </div>
</div>
