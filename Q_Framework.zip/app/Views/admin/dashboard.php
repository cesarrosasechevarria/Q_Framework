<?php
/** @var array|null $user */
$user = $user ?? auth_user();
?>
<div class="qfw-container">
  <div class="qfw-card">
    <h1 class="qfw-h1">Admin Dashboard</h1>
    <p class="qfw-muted">Ejemplo PRO: rutas protegidas por <b>GuardFilter</b> (role-based), sin repetir validaciones en cada controller.</p>

    <div class="qfw-grid" style="margin-top:16px">
      <div class="qfw-card" style="padding:14px">
        <div class="qfw-kv"><b>Usuario</b><span><?= e($user['email'] ?? '-') ?></span></div>
        <div class="qfw-kv"><b>Nombre</b><span><?= e($user['name'] ?? '-') ?></span></div>
        <div class="qfw-kv"><b>Rol</b><span><?= e($user['role'] ?? '-') ?></span></div>
      </div>

      <div class="qfw-card" style="padding:14px">
        <h3 class="qfw-h3">Acciones</h3>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
          <a class="qfw-btn" href="<?= route_url('admin.profile') ?>">Perfil</a>
          <a class="qfw-btn" href="<?= route_url('admin.modules') ?>">Módulos</a>
          <a class="qfw-btn" href="<?= route_url('demo.public') ?>">Demo</a>
          <a class="qfw-btn" href="<?= route_url('docs.index') ?>">Docs</a>
        </div>
      </div>
    </div>

    <hr class="qfw-hr">

    <h3 class="qfw-h3">API PRO (token + rate-limit)</h3>
    <p class="qfw-muted">
      Prueba: <code>/api/v1/ping</code> con header <code>Authorization: Bearer &lt;token&gt;</code>.<br>
      Token de ejemplo en <code>.env</code>: <code>API_TOKENS=demo_token</code>.
    </p>
  </div>
</div>
