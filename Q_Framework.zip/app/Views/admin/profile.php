<?php
$user = $user ?? auth_user();
?>
<div class="qfw-container">
  <div class="qfw-card">
    <h1 class="qfw-h1">Perfil</h1>
    <p class="qfw-muted">Vista de ejemplo. Tu app real puede cargar datos desde DB.</p>

    <div class="qfw-card" style="padding:14px;margin-top:16px">
      <div class="qfw-kv"><b>ID</b><span><?= e($user['id'] ?? '-') ?></span></div>
      <div class="qfw-kv"><b>Email</b><span><?= e($user['email'] ?? '-') ?></span></div>
      <div class="qfw-kv"><b>Nombre</b><span><?= e($user['name'] ?? '-') ?></span></div>
      <div class="qfw-kv"><b>Rol</b><span><?= e($user['role'] ?? '-') ?></span></div>
    </div>

    <div style="margin-top:16px">
      <a class="qfw-btn" href="<?= route_url('admin.dashboard') ?>">Volver</a>
    </div>
  </div>
</div>
