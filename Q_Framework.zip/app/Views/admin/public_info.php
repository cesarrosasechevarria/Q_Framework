<div class="qfw-container">
  <div class="qfw-card">
    <h1 class="qfw-h1">Admin / Public info</h1>
    <p class="qfw-muted">
      Esta ruta está dentro del group <code>/admin</code>, pero se marcó con <code>guard=false</code> para demostrar que
      puedes tener <b>excepciones</b> sin duplicar código.
    </p>

    <h3 class="qfw-h3">Cómo funciona</h3>
    <ul>
      <li>El group <code>/admin</code> tiene <code>guard</code> con <code>require=user</code> + <code>match=user.role in [admin, superadmin]</code>.</li>
      <li>Esta ruta desactiva el guard: <code>$r->get(..., ['guard' => false]);</code></li>
    </ul>

    <a class="qfw-btn" href="<?= route_url('admin.dashboard') ?>">Ir al dashboard</a>
  </div>
</div>
