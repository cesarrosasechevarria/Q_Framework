<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Plugins / Módulos</title>
  <style>
    body{font-family:system-ui,Segoe UI,Arial;margin:24px;}
    table{border-collapse:collapse;width:100%;}
    th,td{border:1px solid #ddd;padding:8px;}
    th{text-align:left;background:#f5f5f5;}
    .tag{display:inline-block;padding:2px 8px;border-radius:999px;background:#eef;}
    .on{background:#e8f9e8;}
    .off{background:#ffecec;}
    .muted{color:#666;font-size:13px;}
    a.btn{display:inline-block;padding:6px 10px;border:1px solid #ccc;border-radius:8px;text-decoration:none;}
  </style>
</head>
<body>
  <h1>Plugins / Módulos</h1>
  <p class="muted">Tenant: <span class="tag"><?= htmlspecialchars((string)$tenant) ?></span>
  &nbsp; Estado: <span class="tag"><?= htmlspecialchars((string)($state['mode'] ?? 'override')) ?></span></p>

  <table>
    <thead>
      <tr>
        <th>Módulo</th>
        <th>Estado</th>
        <th>Acción</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach (($all ?? []) as $m):
        $isOn = in_array($m, (array)$enabled, true);
      ?>
      <tr>
        <td><?= htmlspecialchars((string)$m) ?></td>
        <td>
          <?php if ($isOn): ?>
            <span class="tag on">HABILITADO</span>
          <?php else: ?>
            <span class="tag off">DESHABILITADO</span>
          <?php endif; ?>
        </td>
        <td>
          <?php if ($isOn): ?>
            <a class="btn" href="/admin/modules/disable/<?= urlencode((string)$m) ?>">Desactivar</a>
          <?php else: ?>
            <a class="btn" href="/admin/modules/enable/<?= urlencode((string)$m) ?>">Activar</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p class="muted" style="margin-top:16px;">Los cambios se guardan en JSON por tenant (write/tenants/&lt;tenant&gt;/modules/modules.json) y se aplican en el siguiente request.</p>
</body>
</html>
