<!DOCTYPE html>
<html lang="es">
<head>
<?php
    // ================== Base ==================
    $base = base_url();
    
    // ================== Defaults IEICI ==================
    $defaults = [
        'title'       => 'IEICI — Instituto de Estudios Interdisciplinarios en Ciencias, Investigación e Ingeniería',
        'description' => 'Formación y producción científica con enfoque interdisciplinario en ciencias, investigación e ingeniería.',
        'keywords'    => 'ciencia, investigación, ingeniería, interdisciplinario, instituto, IEICI',
        'author'      => 'IEICI',
        // Banner / logo horizontal (ajusta la ruta si usas otra)
        'image'       => base_url('public/imagenes/sistema/logos/socialblanco.webp?v=' . time()),
        'image_alt'   => 'IEICI — Logotipo institucional',
        'image_w'     => 1461,
        'image_h'     => 271,
        'theme_color' => '#111111',
    ];

    // ================== SEO (override opcional) ==================
    /** En el controller puedes pasar:
     *  $seo = ['title'=>..., 'description'=>..., 'keywords'=>..., 'author'=>..., 'image'=>..., 'image_alt'=>..., 'image_w'=>..., 'image_h'=>..., 'theme_color'=>...];
     */
    $seo = isset($seo) && is_array($seo) ? array_replace($defaults, $seo) : $defaults;

    // ================== Open Graph (override opcional) ==================
    /** $og = ['type'=>'website','url'=>..., 'title'=>..., 'description'=>..., 'image'=>..., 'image_alt'=>..., 'image_w'=>..., 'image_h'=>...] */
    $og = array_replace([
        'type'        => 'website',
        'url'         => $base,
        'title'       => $seo['title'],
        'description' => $seo['description'],
        'image'       => $seo['image'],
        'image_alt'   => $seo['image_alt'],
        'image_w'     => $seo['image_w'],
        'image_h'     => $seo['image_h'],
    ], isset($og) && is_array($og) ? $og : []);

    // ================== Twitter (override opcional) ==================
    /** $tw = ['card'=>'summary_large_image','title'=>..., 'description'=>..., 'image'=>..., 'image_alt'=>...] */
    $tw = array_replace([
        'card'        => 'summary_large_image',
        'title'       => $seo['title'],
        'description' => $seo['description'],
        'image'       => $seo['image'],
        'image_alt'   => $seo['image_alt'],
    ], isset($tw) && is_array($tw) ? $tw : []);

    // ================== Favicons (override opcional) ==================
    /** $fav = ['ico'=>..., 'png16'=>..., 'png32'=>..., 'png192'=>..., 'apple'=>..., 'mask'=>..., 'mscfg'=>..., 'theme'=>...] */
    $fav = array_replace([
        'ico'    => base_url('favicon.ico?v=2'),
        'png16'  => base_url('public/imagenes/sistema/favicon-16.png'),
        'png32'  => base_url('public/imagenes/sistema/favicon-32.png'),
        'png192' => base_url('public/imagenes/sistema/favicon-192.png'),
        'apple'  => base_url('public/imagenes/sistema/apple-touch-icon.png'),
        'mask'   => base_url('public/imagenes/sistema/safari-pinned-tab.svg'),
        'mscfg'  => base_url('browserconfig.xml'),
        'theme'  => $seo['theme_color'],
    ], isset($fav) && is_array($fav) ? $fav : []);
?>

    <!-- Metas básicas -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta http-equiv="ScreenOrientation" content="autoRotate:disabled">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="robots" content="index, follow"/>
    <meta name="author" content="<?= esc($seo['author']) ?>">
    <meta name="theme-color" content="<?= esc($seo['theme_color']) ?>">
    <meta name="base_url" content="<?= $base ?>">
    <meta http-equiv="expires" content="43200"/>
        
    <?= csrf_meta(); ?>

    <title><?= esc($seo['title']) ?></title>
    <meta name="description" content="<?= esc($seo['description']) ?>">
    <meta name="keywords" content="<?= esc($seo['keywords']) ?>">

    <!-- Canonical -->
    <link rel="canonical" href="<?= $base ?>">

    <!-- Open Graph -->
    <meta property="og:site_name" content="IEICI">
    <meta property="og:url" content="<?= esc($og['url']) ?>">
    <meta property="og:type" content="<?= esc($og['type']) ?>">
    <meta property="og:title" content="<?= esc($og['title']) ?>">
    <meta property="og:description" content="<?= esc($og['description']) ?>">
    <meta property="og:image" content="<?= esc($og['image']) ?>">
    <meta property="og:image:secure_url" content="<?= esc($og['image']) ?>">
    <meta property="og:image:alt" content="<?= esc($og['image_alt']) ?>">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="<?= (int)$og['image_w'] ?>">
    <meta property="og:image:height" content="<?= (int)$og['image_h'] ?>">

    <!-- Twitter -->
    <meta name="twitter:card" content="<?= esc($tw['card']) ?>">
    <meta name="twitter:title" content="<?= esc($tw['title']) ?>">
    <meta name="twitter:description" content="<?= esc($tw['description']) ?>">
    <meta name="twitter:image" content="<?= esc($tw['image']) ?>">
    <meta name="twitter:image:alt" content="<?= esc($tw['image_alt']) ?>">

    <!-- JSON-LD Organization -->
    <script type="application/ld+json">
    {
      "@context":"https://schema.org",
      "@type":"Organization",
      "name":"Instituto de Estudios Interdisciplinarios en Ciencias, Investigación e Ingeniería",
      "url":"<?= $base ?>",
      "logo":"<?= esc($seo['image']) ?>"
    }
    </script>
    

    <!-- PWA -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="msapplication-starturl" content="/">
    <link rel="manifest" href="<?= base_url('manifest.json?v=2') ?>">

    <!-- Favicons -->
    <link rel="shortcut icon" type="image/x-icon" href="<?= $fav['ico'] ?>">
    <link rel="icon" type="image/png" sizes="16x16"  href="<?= $fav['png16'] ?>">
    <link rel="icon" type="image/png" sizes="32x32"  href="<?= $fav['png32'] ?>">
    <link rel="icon" type="image/png" sizes="192x192" href="<?= $fav['png192'] ?>">
    <link rel="apple-touch-icon" href="<?= $fav['apple'] ?>">
    <link rel="mask-icon" href="<?= $fav['mask'] ?>" color="<?= esc($fav['theme']) ?>">
    <meta name="msapplication-config" content="<?= $fav['mscfg'] ?>">
 
    <!-- Performance -->
    <link rel="preconnect" href="<?= $base ?>" crossorigin>
    <link rel="preload" as="image" href="<?= esc($seo['image']) ?>">

    <!-- LIBRERÍAS CSS -->
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/estilos/q_icons.css?v=20'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/estilos/Q_Lib_Mail.css?v=6'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/estilos/Q_Lib.css?v=1211'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Editor/q_editor.css?v=2'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Infload/InfLoad.css?v=77'); ?>">

    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Kpi/q_kpi.css?v=51'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Chart/q_chart.css?v=49'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Calendar/q_calendar.css?v=4'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Stepper/q_stepper.css?v=4'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Sort/q_sort.css?v=22'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Map/Q_Map.css?v=3'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Pair/Q_Pair.css?v=122'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Table/Q_Table.css?v=64'); ?>">
    <link rel="stylesheet" href="<?= base_url('public/librerias/propios/Q_Nav/q_nav.css?v=1'); ?>">

    <!-- LIBRERÍAS JS -->

    <script defer  src="<?= base_url('public/librerias/propios/estilos/q-icons.js?v=20'); ?>"></script>
    <script defer  src="<?= base_url('public/librerias/propios/estilos/Q_Lib.js?v=1211'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Editor/q_editor.js?v=2'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Infload/InfLoad.js?v=77'); ?>" ></script>

    <script defer  src="<?= base_url('public/librerias/propios/Q_Kpi/q_kpi.js?v=51'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Chart/q_chart.js?v=47'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Calendar/q_calendar.js?v=4'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Stepper/q_stepper.js?v=4'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Sort/q_sort.js?v=20'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Map/Q_Map.js?v=3'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Pair/Q_Pair.js?v=122'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Table/Q_Table.js?v=64'); ?>" ></script>
    <script defer  src="<?= base_url('public/librerias/propios/Q_Nav/q_nav.js?v=1'); ?>" ></script>

    <script defer  src="<?= base_url('public/librerias/propios/js/misfunciones.js?v=662'); ?>" ></script>
            
    <!-- Q_Rich principal -->
    <script type="module" src="<?= base_url('public/librerias/propios/Q_Rich/q_rich.js?v=496'); ?>"></script>

    <!-- Push/PWA (opcional) --> 
    <script defer src="/public/app/mainpwa.js?v=71"></script>

    <!-- Includes externos opcionales -->
    <?php if (isset($includes)) echo $includes; ?>
    
</head>
