<?php
/** @var string $date */
/** @var string $env */
/** @var bool $debug */
/** @var bool $routeCache */
/** @var string $baseCfg */
/** @var string $baseDetected */
/** @var array $checks */
/** @var array $counts */
/** @var string $phpVersion */
/** @var string $tenantId */
/** @var bool $csrfEnabled */
/** @var string $csrfStorage */
?>
<style>
.qfw-chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center}
.qfw-chip{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;border:1px solid var(--qfw-border);background:rgba(255,255,255,.06);font-weight:800}
.qfw-dot{width:10px;height:10px;border-radius:999px;background:rgba(255,255,255,.25);display:inline-block}
.qfw-dot.ok{background:#1fbf5b}
.qfw-dot.warn{background:#fbbf24}
.qfw-dot.fail{background:#ff5c5c}
.qfw-table{width:100%;border-collapse:collapse;border:1px solid var(--qfw-border);border-radius:14px;overflow:hidden}

.qfw-table{table-layout:fixed}
.qfw-table th,.qfw-table td{overflow-wrap:anywhere;word-break:break-word}
.qfw-table .qfw-kbd{white-space:normal;display:inline}
.qfw-table td code,.qfw-table td kbd{white-space:normal;overflow-wrap:anywhere;word-break:break-word}
.qfw-table td pre{white-space:pre-wrap}
.qfw-table th{background:rgba(255,255,255,.06);text-align:left;padding:10px}
.qfw-table td{padding:10px;border-top:1px solid rgba(255,255,255,.08);vertical-align:top}
.qfw-kbd{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:8px}
.qfw-chip{max-width:100%}
.qfw-chip .qfw-kbd{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block}
@media (max-width: 520px){.qfw-chip .qfw-kbd{max-width:240px}}

.qfw-grid{display:grid;grid-template-columns:repeat(12,1fr);gap:12px}
.qfw-col-6{grid-column:span 6}
.qfw-col-12{grid-column:span 12}
@media (max-width: 900px){.qfw-col-6{grid-column:span 12}}
.qfw-h2{margin:0 0 8px;font-size:18px}
.qfw-pre{margin:10px 0 0;background:rgba(255,255,255,.06);border:1px solid var(--qfw-border);border-radius:14px;padding:12px;overflow:auto}
</style>

<div class="qfw-card">
  <h1 style="margin:0">Q_Framework PRO+ · Bienvenido</h1>
  <p class="qfw-muted" style="margin:6px 0 0">
    Servidor: <span class="qfw-kbd"><?= e($phpVersion) ?></span> ·
    Env: <span class="qfw-kbd"><?= e($env) ?></span> ·
    Debug: <span class="qfw-kbd"><?= $debug ? 'true' : 'false' ?></span> ·
    RouteCache: <span class="qfw-kbd"><?= $routeCache ? 'true' : 'false' ?></span> ·
    Tenant: <span class="qfw-kbd"><?= e($tenantId) ?></span>
  </p>

  <div class="qfw-chips">
    <span class="qfw-chip"><span class="qfw-dot ok"></span><?= (int)($counts['ok'] ?? 0) ?> OK</span>
    <span class="qfw-chip"><span class="qfw-dot warn"></span><?= (int)($counts['warn'] ?? 0) ?> Avisos</span>
    <span class="qfw-chip"><span class="qfw-dot fail"></span><?= (int)($counts['fail'] ?? 0) ?> Errores</span>
    <span class="qfw-chip">Hora: <span class="qfw-kbd"><?= e($date) ?></span></span>
  </div>

  <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
    <a class="qfw-btn primary" href="<?= route_url('docs.index') ?>">📘 Manual</a>
    <a class="qfw-btn" href="<?= route_url('debug.doctor') ?>">🩺 Doctor</a>
    <a class="qfw-btn" href="<?= route_url('setup.publicless') ?>" title="Guía para usar sin /public">🧩 Setup (public-less)</a>
  </div>
</div>

<div class="qfw-grid" style="margin-top:14px">
  <div class="qfw-card qfw-col-6">
    <div style="font-weight:900">BaseURL</div>
    <p class="qfw-muted" style="margin:8px 0 0">
      Config: <span class="qfw-kbd"><?= e($baseCfg ?: '(vacío)') ?></span><br>
      Detectada: <span class="qfw-kbd"><?= e($baseDetected) ?></span>
    </p>
  </div>

  <div class="qfw-card qfw-col-6">
    <div style="font-weight:900">Seguridad rápida</div>
    <p class="qfw-muted" style="margin:8px 0 0">
      CSRF: <span class="qfw-kbd"><?= $csrfEnabled ? 'on' : 'off' ?></span> ·
      storage: <span class="qfw-kbd"><?= e($csrfStorage) ?></span><br>
      Recomendación: en producción usa HTTPS + cookies seguras.
    </p>
  </div>

  <div class="qfw-card qfw-col-12">
    <h2 class="qfw-h2">Checklist</h2>
    <table class="qfw-table">
      <thead>
        <tr>
          <th style="width:240px">Check</th>
          <th style="width:120px">Estado</th>
          <th>Info</th>
          <th style="width:360px">Sugerencia</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach (($checks ?? []) as $c): 
        $status = (string)($c['status'] ?? 'ok');
        $dot = $status === 'fail' ? 'fail' : ($status === 'warn' ? 'warn' : 'ok');
        $label = (string)($c['label'] ?? '');
        $info  = (string)($c['info'] ?? '');
        $fix   = (string)($c['fix'] ?? '');
      ?>
        <tr>
          <td><strong><?= e($label) ?></strong></td>
          <td><span class="qfw-chip"><span class="qfw-dot <?= e($dot) ?>"></span><?= e(strtoupper($status)) ?></span></td>
          <td class="qfw-muted"><?= $info === '' ? '' : e($info) ?></td>
          <td class="qfw-muted"><?= $fix ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="qfw-card" style="margin-top:14px">
  <h2 class="qfw-h2">Guía rápida</h2>
  <ol class="qfw-muted" style="margin:0;padding-left:18px">
    <li><strong>DocumentRoot</strong>: recomendado apuntar a <code>public/</code>. Si no puedes, usa <a href="<?= route_url('setup.publicless') ?>">Setup (public-less)</a>.</li>
    <li><strong>.env</strong>: copia <code>.env.example</code> → <code>.env</code> y ajusta: <code>APP_ENV</code>, <code>APP_DEBUG</code>, <code>APP_KEY</code>, <code>baseURL</code>, DB.</li>
    <li><strong>Composer</strong> (recomendado): <code>composer install</code> para habilitar librerías externas y herramientas.</li>
    <li><strong>Producción</strong>: <code>APP_ENV=production</code>, <code>APP_DEBUG=0</code>, <code>ROUTE_CACHE=1</code> y HTTPS.</li>
  </ol>

  <div class="qfw-grid" style="margin-top:12px">
    <div class="qfw-col-12">
      <div style="font-weight:900">Crear un controller</div>
<pre class="qfw-pre"><code>&lt;?php
namespace App\Controllers;

final class Ejemplo extends BaseController
{
  protected array $helpers = ['url'];

  public function index()
  {
    return $this-&gt;response-&gt;html('Hola mundo');
  }
}
</code></pre>
    </div>
    <div class="qfw-col-12">
      <div style="font-weight:900">Agregar una ruta</div>
<pre class="qfw-pre"><code>// app/Config/Routes.php
$routes-&gt;get('/ejemplo', 'App\\Controllers\\Ejemplo@index', [
  'as' =&gt; 'ejemplo.index'
]);
</code></pre>
    </div>
    <div class="qfw-col-12">
      <div style="font-weight:900">Servicios (DB / CRUD / Schema)</div>
<pre class="qfw-pre"><code>$db = service('db');                 // Connection
$schema = service('schema');         // helpers de esquema
$crud = service('crud')-&gt;table('usuarios');

// 1) asegurar tabla
$schema-&gt;ensure('usuarios', [
  ['nombre'=&gt;'nombre','type'=&gt;'VARCHAR','max_length'=&gt;120,'nullable'=&gt;false],
  ['nombre'=&gt;'email','type'=&gt;'VARCHAR','max_length'=&gt;120,'nullable'=&gt;false,'unique'=&gt;true],
], ['alter'=&gt;true,'base_columns'=&gt;true]);

// 2) crear
$r = $crud-&gt;createResult(['nombre'=&gt;'Ana','email'=&gt;'ana@demo.com']);
</code></pre>
    </div>
  </div>

  <p class="qfw-muted" style="margin:12px 0 0">
    Para diagnóstico completo usa <a href="<?= route_url('debug.doctor') ?>">Doctor</a> o CLI:
    <code class="qfw-kbd">php bin/console doctor</code>,
    <code class="qfw-kbd">php bin/console route:list</code>,
    <code class="qfw-kbd">php bin/console route:cache</code>.
  </p>
</div>
