<div class="qfw-card">
  <h1 style="margin-top:0"><?= e($title ?? 'Q_Framework') ?></h1>
  <p class="qfw-muted" style="margin-top:0">Hora servidor: <code><?= e($date ?? '') ?></code></p>

  <?php if (!empty($justInstalled)): ?>
    <div class="qfw-alert ok" style="margin-top:10px">
      🎉 <strong>Instalación finalizada.</strong> Ya puedes empezar a construir tu aplicación.
    </div>
  <?php endif; ?>

  <?php if (!empty($installed) && !empty($keySet)): ?>
    <div class="qfw-card" style="border-color:rgba(31,191,91,.45); margin:12px 0">
      <div style="font-weight:900">✅ Instalado correctamente</div>
      <div class="qfw-muted">APP_KEY detectado (<code><?= e($appKeyHint ?? '') ?></code>) y lock presente (<code><?= e($lockRel ?? '') ?></code>).</div>
      <div class="qfw-muted" style="margin-top:8px">Base URL detectada: <code><?= e($baseDetected ?? '') ?></code></div>
      <div style="margin-top:12px; display:flex; gap:10px; flex-wrap:wrap">
        <a class="qfw-btn primary" href="<?= e($docsUrl ?? base_url('/docs/')) ?>">📘 Abrir Manual (HTML)</a>
        <a class="qfw-btn" href="<?= e(base_url('/')) ?>">🏠 Inicio</a>
      </div>
    </div>



    <h2 style="margin:18px 0 8px">Módulos de ejemplo incluidos</h2>
    <p class="qfw-muted" style="margin-top:0">
      Este paquete incluye módulos listos como ejemplo (se auto-descubren en <code>app/Modules</code>):
      <code>Auth</code>, <code>Admin</code>, <code>Files</code>, <code>Api</code>, <code>Blog</code>.
    </p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 0">
      <a class="qfw-btn" href="<?= route_url('auth.login') ?>">🔐 Auth</a>
      <a class="qfw-btn" href="<?= route_url('admin.dashboard') ?>">🧭 Admin</a>
      <a class="qfw-btn" href="<?= route_url('files.index') ?>">📁 Files</a>
      <a class="qfw-btn" href="<?= route_url('api.status') ?>">🧩 API</a>
      <a class="qfw-btn" href="<?= route_url('blog.index') ?>">📝 Blog</a>
    </div>
    <p class="qfw-muted" style="margin-top:10px">
      Para <strong>Auth/Blog</strong> primero ejecuta migraciones: <code>php bin/console migrate</code>.
    </p>
    <h2 style="margin:18px 0 8px">Siguientes pasos</h2>
    <ol class="qfw-muted" style="margin-top:0">
      <li>Crea un controller en <code>app/Controllers</code> (extiende <code>BaseController</code>).</li>
      <li>Declara rutas en <code>app/Config/Routes.php</code>.</li>
      <li>Crea vistas en <code>app/Views</code> (opcional: usa <code>layout.php</code>).</li>
      <li>Configura DB en <code>.env</code> y usa el QueryBuilder (ver manual).</li>
      <li>Activa CSRF y filtros solo donde lo necesites (ver manual).</li>
    </ol>
  <?php else: ?>
    <div class="qfw-card" style="border-color:rgba(224,82,82,.55); margin:12px 0">
      <div style="font-weight:900">⚠️ Instalación incompleta</div>
      <div class="qfw-muted" style="margin-top:6px">
        <?php if (empty($installed)): ?>
          No se encontró el lock (<code><?= e($lockRel ?? 'write/install.lock') ?></code>).
        <?php else: ?>
          Se encontró el lock, pero falta <code>APP_KEY</code> en <code>.env</code>.
        <?php endif; ?>
      </div>
      <div style="margin-top:10px">
        <a class="qfw-btn primary" href="<?= route_url('install') ?>">Abrir instalador ➜</a>
      </div>
    </div>
  <?php endif; ?>
</div>
