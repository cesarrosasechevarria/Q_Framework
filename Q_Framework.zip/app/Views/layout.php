<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= e($title ?? 'Q_Framework') ?></title>
  <link rel="stylesheet" href="<?= base_url('assets/qfw.css') ?>">
  <script defer src="<?= base_url('assets/qfw.js') ?>"></script>
<style>
/* Critical fallback: si el CSS externo no carga, al menos se verá PRO */
:root{color-scheme:light dark;--qfw-bg:#0b1220;--qfw-surface:#0f1a2e;--qfw-surface-2:rgba(255,255,255,.06);--qfw-text:#e6edf3;--qfw-muted:rgba(230,237,243,.65);--qfw-border:rgba(255,255,255,.10);--qfw-shadow:0 30px 80px rgba(0,0,0,.45);--qfw-accent:#ff8a3d;--qfw-radius:16px;--qfw-radius-sm:12px;}
@media (prefers-color-scheme: light){:root{--qfw-bg:#f6f7fb;--qfw-surface:#fff;--qfw-surface-2:#f1f2f6;--qfw-text:#0b1020;--qfw-muted:rgba(11,16,32,.62);--qfw-border:rgba(11,16,32,.14);--qfw-shadow:0 10px 30px rgba(0,0,0,.06);--qfw-accent:#ff7a18;}}
html,body{height:100%}
body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;line-height:1.45;background:var(--qfw-bg);color:var(--qfw-text);}
a{color:inherit}
code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
.qfw-header{position:sticky;top:0;z-index:10;display:flex;gap:10px;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--qfw-border);background:linear-gradient(180deg,rgba(0,0,0,.18),rgba(0,0,0,0));backdrop-filter:blur(10px);}
.qfw-brand strong{font-weight:900}
.qfw-muted{color:var(--qfw-muted)}
.qfw-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.qfw-main{max-width:1050px;margin:0 auto;padding:28px 18px 80px}
.qfw-card{background:var(--qfw-surface);border:1px solid var(--qfw-border);border-radius:var(--qfw-radius);box-shadow:var(--qfw-shadow);padding:18px}
.qfw-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 12px;border-radius:999px;border:1px solid var(--qfw-border);background:rgba(255,255,255,.06);text-decoration:none;color:inherit}
.qfw-btn:hover{transform:translateY(-1px)}
.qfw-btn.primary{background:var(--qfw-accent);color:#111;border-color:transparent;font-weight:800}
.qfw-btn.icon{width:40px;height:40px;justify-content:center}
.qfw-ok{color:#1fbf5b;font-weight:900}
.qfw-bad{color:#ff5c5c;font-weight:900}
</style>

</head>
<body>
    <header class="qfw-header">
    <div class="qfw-brand">
      <div>
        <strong>Q_Framework PRO+</strong>
        <span class="qfw-muted">· starter</span>
      </div>
    </div>
    <div class="qfw-row">
      <button class="qfw-btn icon" type="button" data-qfw-theme-toggle title="Tema">🌓</button>
      <a class="qfw-btn" href="<?= route_url('home') ?>">Home</a>
      <a class="qfw-btn" href="<?= route_url('docs.index') ?>">Docs</a>
      <a class="qfw-btn" href="<?= route_url('setup.publicless') ?>" title="Guía/Setup para usar sin /public">Setup</a>
    </div>
  </header>
<main class="qfw-main">
    <?= $content ?? '' ?>
  </main>
</body>
</html>
