<?php
/** Override de errores (app) - puedes personalizar libremente */
$title = $title ?? 'Error';
$message = $message ?? '';
$code = $code ?? 500;
$traceId = $traceId ?? '';
?>
<div class="qfw-card">
  <h1 style="margin:0 0 6px"><?= e((string)$code) ?> - <?= e((string)$title) ?></h1>
  <p class="qfw-muted" style="margin:0 0 12px"><?= e((string)$message) ?></p>
  <?php if (!empty($traceId)): ?>
    <div class="qfw-muted">Trace ID: <code><?= e((string)$traceId) ?></code></div>
  <?php endif; ?>
  <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap">
    <a class="qfw-btn primary" href="<?= base_url('/') ?>">🏠 Ir al inicio</a>
    <a class="qfw-btn" href="javascript:history.back()">↩️ Volver</a>
  </div>
</div>
