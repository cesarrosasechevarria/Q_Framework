<?php
/** @var string $env */
/** @var bool $debug */
/** @var bool $routeCache */
/** @var string $phpVersion */
/** @var string $baseDetected */
/** @var array $sections */
/** @var array $counts */
?>
<style>
.qfw-chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;align-items:center}
.qfw-chip{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;border:1px solid var(--qfw-border);background:rgba(255,255,255,.06);font-weight:800}
.qfw-dot{width:10px;height:10px;border-radius:999px;background:rgba(255,255,255,.25);display:inline-block}
.qfw-dot.ok{background:#1fbf5b}
.qfw-dot.warn{background:#fbbf24}
.qfw-dot.fail{background:#ff5c5c}
.qfw-table{width:100%;border-collapse:collapse;border:1px solid var(--qfw-border);border-radius:14px;overflow:hidden}

.qfw-table{table-layout:fixed}
.qfw-table th,.qfw-table td{overflow-wrap:anywhere;word-break:break-word}
.qfw-table .qfw-kbd{white-space:normal;display:inline}
.qfw-table td code,.qfw-table td kbd{white-space:normal;overflow-wrap:anywhere;word-break:break-word}
.qfw-table td pre{white-space:pre-wrap}
.qfw-table th{background:rgba(255,255,255,.06);text-align:left;padding:10px}
.qfw-table td{padding:10px;border-top:1px solid rgba(255,255,255,.08);vertical-align:top}
.qfw-kbd{background:rgba(255,255,255,.08);padding:2px 6px;border-radius:8px}
.qfw-chip{max-width:100%}
.qfw-chip .qfw-kbd{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block}
@media (max-width: 520px){.qfw-chip .qfw-kbd{max-width:240px}}

.qfw-h2{margin:0 0 8px;font-size:18px}
.qfw-muted2{opacity:.85}
</style>

<div class="qfw-card">
  <h1 style="margin:0">Q_Framework Doctor</h1>
  <p class="qfw-muted" style="margin:6px 0 0">
    PHP: <span class="qfw-kbd"><?= e($phpVersion) ?></span> ·
    Env: <span class="qfw-kbd"><?= e($env) ?></span> ·
    Debug: <span class="qfw-kbd"><?= $debug ? 'true' : 'false' ?></span> ·
    RouteCache: <span class="qfw-kbd"><?= $routeCache ? 'true' : 'false' ?></span>
  </p>

  <div class="qfw-chips">
    <span class="qfw-chip"><span class="qfw-dot ok"></span><?= (int)($counts['ok'] ?? 0) ?> OK</span>
    <span class="qfw-chip"><span class="qfw-dot warn"></span><?= (int)($counts['warn'] ?? 0) ?> Avisos</span>
    <span class="qfw-chip"><span class="qfw-dot fail"></span><?= (int)($counts['fail'] ?? 0) ?> Errores</span>
    <span class="qfw-chip">Base: <span class="qfw-kbd"><?= e($baseDetected) ?></span></span>
  </div>

  <div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">
    <a class="qfw-btn" href="<?= route_url('home') ?>">🏠 Home</a>
    <a class="qfw-btn" href="<?= route_url('docs.index') ?>">📘 Docs</a>
    <a class="qfw-btn" href="<?= route_url('setup.publicless') ?>">🧩 Setup</a>
  </div>

  <p class="qfw-muted2" style="margin:12px 0 0">
    CLI: <code class="qfw-kbd">php bin/console doctor</code> ·
    <code class="qfw-kbd">php bin/console route:list</code> ·
    <code class="qfw-kbd">php bin/console route:cache</code>
  </p>
</div>

<?php foreach (($sections ?? []) as $sec): ?>
  <div class="qfw-card" style="margin-top:14px">
    <h2 class="qfw-h2"><?= e((string)($sec['title'] ?? '')) ?></h2>
    <table class="qfw-table">
      <thead>
        <tr>
          <th style="width:260px">Check</th>
          <th style="width:110px">Estado</th>
          <th>Info</th>
          <th style="width:360px">Sugerencia</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach (($sec['checks'] ?? []) as $c):
        $status = (string)($c['status'] ?? 'ok');
        $dot = $status === 'fail' ? 'fail' : ($status === 'warn' ? 'warn' : 'ok');
        $label = (string)($c['label'] ?? '');
        $info  = (string)($c['info'] ?? '');
        $fix   = (string)($c['fix'] ?? '');
      ?>
        <tr>
          <td><strong><?= e($label) ?></strong></td>
          <td><span class="qfw-chip"><span class="qfw-dot <?= e($dot) ?>"></span><?= e(strtoupper($status)) ?></span></td>
          <td class="qfw-muted"><?= $info === '' ? '' : e($info) ?></td>
          <td class="qfw-muted"><?= $fix ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endforeach; ?>
