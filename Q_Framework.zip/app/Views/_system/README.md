# Override opcional de vistas del sistema

Las vistas internas del framework viven en `system/Views/_system/`.
Si necesitas reemplazar alguna, puedes copiarla aquí manteniendo la misma ruta.
