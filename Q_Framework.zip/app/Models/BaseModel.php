<?php
declare(strict_types=1);

namespace App\Models;

use System\Database\Model;

/**
 * BaseModel (PRO only)
 *
 * No sobrescribe paginate().
 * Hereda paginate() PRO desde System\Database\Model.
 */
abstract class BaseModel extends Model
{
  // Si necesitas defaults de tu app, ponlos aquí,
  // pero NO redefinas paginate() en modo offset.
}
