<?php
declare(strict_types=1);

namespace App\Models;

use System\Database\QueryBuilder;
use System\Database\Connection;

/**
 * Tabla (Model PRO, compatible con tu estilo Q_Framework)
 *
 * Uso:
 *   $m = (new Tabla())->setTabla('usuarios');
 *   $rows = $m->builder()->where('activo',1)->get()->getResultArray();
 *
 * Soft delete (por defecto):
 *   - Aplica filtro borrado=0 automáticamente (configurable)
 *   - delete($id) => borrado=1
 *   - delete($id,false) => DELETE real
 *   - restore($id) => borrado=0
 */
class Tabla
{
  protected string $table = '';
  protected string $primaryKey = 'tabla_id';
  protected array $allowedFields = [];
  protected string $returnType = 'array';

  protected bool $filtroBorrado = true;
  protected string $DBGroup = 'default';

  public function setTabla(string $table, bool $usarFiltroBorrado = true): self
  {
    $this->table = $table;
    $this->filtroBorrado = $usarFiltroBorrado;
    return $this;
  }

  public function getTabla(): string
  {
    return $this->table;
  }

  public function setId(string $id): self
  {
    $this->primaryKey = $id;
    return $this;
  }

  public function setCampos(array $campos): self
  {
    $this->allowedFields = $campos;
    return $this;
  }

  /** Grupo DB (multi-fuente) */
  public function setDatabase(string $database): self
  {
    $this->DBGroup = $database;
    return $this;
  }

  /** Connection actual */
  public function db(): Connection
  {
    return \Config\Services::db($this->DBGroup);
  }

  /** Builder de la tabla (con filtro soft delete si aplica) */
  public function builder(?string $table = null): QueryBuilder
  {
    $t = $table ?? $this->table;
    $b = $this->db()->table($t);

    // SoftDeletes global
    $sd = config('SoftDeletes');
    $field = (string)($sd->field ?? 'borrado');
    $active = (int)($sd->valueActive ?? 0);

    if ($this->filtroBorrado && !empty($sd->enabled)) {
      $b->where("{$t}.{$field}", $active);
    }
    return $b;
  }

  public function sinFiltroBorrado(): self
  {
    $this->filtroBorrado = false;
    return $this;
  }

  // ========= CRUD básico =========

  public function find($id): ?array
  {
    if ($this->table === '') return null;
    return $this->builder()->where($this->primaryKey, $id)->first();
  }

  public function findAll(int $limit = 0, int $offset = 0): array
  {
    if ($this->table === '') return [];
    $b = $this->builder();
    if ($limit > 0) $b->limit($limit, $offset);
    return $b->get()->getResultArray();
  }

  public function insert(array $data): string
  {
    if ($this->table === '') return '';
    $data = $this->filterAllowed($data);
    return $this->db()->table($this->table)->insert($data);
  }

  public function update($id, array $data): int
  {
    if ($this->table === '') return 0;
    $data = $this->filterAllowed($data);
    return $this->db()->table($this->table)->where($this->primaryKey, $id)->update($data);
  }

  /** delete: soft por defecto */
  public function delete($id, bool $soft = true): int
  {
    if ($this->table === '') return 0;
    $sd = config('SoftDeletes');
    $field = (string)($sd->field ?? 'borrado');
    $deleted = (int)($sd->valueDeleted ?? 1);

    if ($soft && !empty($sd->enabled)) {
      return $this->db()->table($this->table)->where($this->primaryKey, $id)->update([$field => $deleted]);
    }
    return $this->db()->table($this->table)->where($this->primaryKey, $id)->delete();
  }

  public function restore($id): int
  {
    if ($this->table === '') return 0;
    $sd = config('SoftDeletes');
    $field = (string)($sd->field ?? 'borrado');
    $active = (int)($sd->valueActive ?? 0);
    return $this->db()->table($this->table)->where($this->primaryKey, $id)->update([$field => $active]);
  }

  /**
   * Ejecuta consulta directa con paginación desde SQL (compat tu Tabla.php)
   */
  public function obt_datos_query(string $query, int $limit, int $count): array
  {
    $sql = $query . " LIMIT {$count}, {$limit}";
    return $this->db()->query($sql)->getResultArray();
  }

  private function filterAllowed(array $data): array
  {
    if (!$this->allowedFields) return $data;
    $out = [];
    foreach ($data as $k=>$v) {
      if (in_array($k, $this->allowedFields, true)) $out[$k] = $v;
    }
    return $out;
  }
}
