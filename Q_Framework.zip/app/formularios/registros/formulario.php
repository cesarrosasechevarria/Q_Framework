<?php
declare(strict_types=1);

use App\Libraries\Datos;

// Q_Framework
$request = service('request'); // si lo necesitas luego
$db      = service('db');      // si lo necesitas luego

// Datos ya se auto-inyecta con services, pero puedes pasar db/request si quieres:
$Datos = new Datos($db, $request);

// Si no hay datos del formulario => redirect Q_Framework
if (empty($datosForm)) {
    redirect(base_url());
    exit;
}

/**
 * =========================================================
 * Precargar datos (modo edición) usando Datos::Cargar()
 * =========================================================
 * - En Q_Framework, Cargar($mDATOS) devuelve payload array (NO JSON string).
 * - Además aplica extras internamente con Presenter (applyExtras()).
 */
if (isset($datosForm['prms']) && isset($mform['FORMULARIO'])) {

    // Extras para lookups/files/map/json_get, etc.
    $datosForm['extras'] = $extrasDato ?? null;

    // Cargar registro
    $payload = $Datos->Cargar($datosForm); // <-- devuelve array

    if (is_array($payload) && ($payload['ok'] ?? false)) {
        $row = $payload['data'][0] ?? [];
        if (is_array($row) && $row) {
            Form_valor_a_form($row, $mform['FORMULARIO']);
        }
    } else {
        // Opcional: si quieres manejar error de carga
        // $msg = is_array($payload) ? ($payload['message'] ?? 'Error') : 'Error';
        // logger()->warning('Cargar falló', ['payload' => $payload]);
    }
}

/**
 * =========================================================
 * PRECARGA (igual que antes)
 * =========================================================
 */
$PRECARGA = [
    'fecha'     => date("Y-m-d"),
    'fecha_dmy' => date("d/m/Y"),
];

if (isset($datosForm['precarga']) && is_array($datosForm['precarga'])) {
    $PRECARGA = array_replace($PRECARGA, $datosForm['precarga']);
}

foreach (['precarga', 'PRECARGA'] as $k) {
    if (isset($mform[$k]) && is_array($mform[$k])) {
        $PRECARGA = array_replace($PRECARGA, $mform[$k]);
    }
}

if (isset($datosForm['parametros']) && is_array($datosForm['parametros'])) {
    foreach ($datosForm['parametros'] as $key => $value) {
        $mform['FORMULARIO'][$key]['prms'] = $value['prms'];
    }
}

$NEWARRAY = [
    'FPOST'     => $datosForm['fpost'] ?? $datosForm['prms']['fpost'] ?? "/funciones/crud/registrar",
    'TABLA'     => $datosForm['tabla'] ?? $datosForm['prms']['tabla'],
    'PARMS'     => $PARMS ?? null,
    'FILTR'     => null,
    'PRCRG'     => $PRECARGA,
    'EXTRA'     => $EXTRAS ?? null,
    'SEARCH'    => null,
    'TIPOS'     => $TIPOS ?? null,
    'DUPLC'     => $mform['DUPLIREG'] ?? null,
    'PRECODIGO' => null,
    'JSONGROUP' => $mform['JSONGROUP'] ?? null,
];

$formulario = [
    'NOMBRFRM' => 'temporal',
    'CABECERA' => "<h2 class='title'>" . ($mform['TITULO'] ?? 'Sin título') . "</h2>",
    'INPUTS'   => $mform['FORMULARIO'],
    'GRUPOS'   => $mform['GRUPOS'] ?? null,
    'SUBMIT'   => "<input type='submit' class='q_button primary q_width-full' value='REGISTRAR'>",
    'SUBMITB'  => "procesar()",
    'EXTRAS'   => $extrasForm ?? null,
];

$html = view('formularios/q_regedi', $formulario);

$includes = "";

$javascript = "
function procesar() {
  registrarentabla(" . json_encode($NEWARRAY) . ");
}
";
