<?php
return [
  'welcome' => 'Bienvenido',
  'installed_ok' => 'Instalación finalizada. Ya puedes empezar.',
];
