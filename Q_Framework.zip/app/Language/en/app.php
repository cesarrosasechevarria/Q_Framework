<?php
return [
  'welcome' => 'Welcome',
  'installed_ok' => 'Installation completed. You can start now.',
];
