<?php

namespace App\Libraries;

if (is_file(ROOTPATH . '/vendor/phonevalid/autoload.php')) {
    require_once ROOTPATH . '/vendor/phonevalid/autoload.php';
}

use System\Support\Path;
use System\Core\Response;

class Datos
{
    private $db;
    private $request;
    private $response;
    private $encrypter;
    private $presenter;

    public function __construct($db = null, $request = null)
    {
        $this->db       = $db ?: service('db');
        $this->request  = $request ?: service('request');
        $this->response = service('response');
        $this->encrypter = service('encrypter');

        // Presenter CORE para EXTRAS (lookup/files/map/json_get)
        $this->presenter = service('presenter');

        helper([
            '/sistema/files',
            '/sistema/monedas',
            '/sistema/validadores',
            '/sistema/html',
            '/apis/google',
        ]);
    }

    /* =========================================================
     * RESPUESTA JSON (qFetch)
     * ========================================================= */
    private function respond(array $payload, int $httpCode = 200): Response
    {
        return $this->response->json($payload, $httpCode);
    }

    private function okPayload(string $message, $data = null, array $extra = []): array
    {
        return array_merge([
            'ok'       => true,
            'state'    => 'success',
            'title'    => 'OK',
            'mode'     => 'toast',
            'duration' => 2500,
            'message'  => $message,
            'data'     => $data,
        ], $extra);
    }

    private function failPayload(string $message, array $errors = [], array $extra = []): array
    {
        return array_merge([
            'ok'       => false,
            'state'    => 'danger',
            'title'    => 'Error',
            'mode'     => 'dialog',
            'duration' => 0,
            'message'  => $message,
            'errors'   => $errors,
        ], $extra);
    }

    /* =========================================================
     * HELPERS (input / seguridad / ids)
     * ========================================================= */
    private function postJson(string $key, $default = null)
    {
        $raw = $this->request->getPost($key);
        if ($raw === null || $raw === '') return $default;
        if (is_array($raw)) return $raw;

        $raw = stripslashes((string)$raw);
        $data = json_decode($raw, true);

        return (json_last_error() === JSON_ERROR_NONE) ? $data : $default;
    }

    private function isSafeDbIdent(string $name): bool
    {
        return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $name);
    }

    private function safeDecrypt($token)
    {
        if ($token === null || $token === '') return null;
        try {
            return $this->encrypter->decrypt((string)$token);
        } catch (\Throwable $e) {
            return null;
        }
    }

    private function encodeId($val)
    {
        if ($val === null || $val === '') return $val;
        try {
            return $this->encrypter->encrypt((string)$val);
        } catch (\Throwable $e) {
            return $val;
        }
    }

    private function isIdField(string $k): bool
    {
        return (strpos($k, '_id') !== false) || (strpos($k, 'id_') !== false);
    }

    private function hasUploadedFile(string $inputName): bool
    {
        if (!isset($_FILES[$inputName])) return false;
        $f = $_FILES[$inputName];
        if (!isset($f['tmp_name'])) return false;

        if (is_array($f['tmp_name'])) {
            foreach ($f['tmp_name'] as $tmp) {
                if (!empty($tmp)) return true;
            }
            return false;
        }
        return !empty($f['tmp_name']);
    }

    private function detectIdField(?string $pk, array $colsMap, array $postAssoc): ?array
    {
        if ($pk && array_key_exists($pk, $postAssoc)) {
            return ['indice' => $pk, 'valor' => $postAssoc[$pk]];
        }

        foreach ($postAssoc as $k => $v) {
            if (is_string($k) && str_ends_with($k, '_id') && isset($colsMap[$k])) {
                return ['indice' => $k, 'valor' => $v];
            }
        }

        if (isset($colsMap['id']) && array_key_exists('id', $postAssoc)) {
            return ['indice' => 'id', 'valor' => $postAssoc['id']];
        }

        return null;
    }

    private function applyExtras(array &$row, ?array $extras, string $tablaBase): void
    {
        // Aplica EXTRAS usando el Presenter CORE (System\Database\Presenter\ExtrasPresenter)
        // y mantiene compat con tus extras legacy: json/search/select/files.

        $pk = $this->getPrimaryKey($tablaBase);

        $idMatcher = function ($key, $val, $rowAll) use ($pk): bool {
            if (!is_string($key) || $key === '') return false;
            if ($key === 'id') return true;
            if ($pk && $key === $pk) return true;
            return (strpos($key, '_id') !== false) || (strpos($key, 'id_') !== false);
        };

        // 1) Convertir extras legacy -> extras CORE del presenter
        [$presenterExtras, $jsonFields, $fileFields] = $this->buildPresenterExtras($extras, $row);

        // 2) Presenter: aplica extras + encripta IDs
        $row = $this->presenter->presentRow($row, $presenterExtras ?: null, [
            'encrypt_ids'        => true,
            'decrypt_input_ids'  => true,
            'id_fields'          => $idMatcher,
        ]);

        // 3) Compat legacy: tipo=json (decode completo)
        if (!empty($jsonFields)) {
            foreach ($jsonFields as $k) {
                if (!array_key_exists($k, $row)) continue;
                $val = $row[$k];
                if (is_string($val) && $val !== '') {
                    $dec = json_decode($val, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $row[$k] = $dec;
                    }
                }
            }
        }

        // 4) Compat legacy: tipo=files (estructura antigua: arch_id/doc/url/arch_tabla/arch_columna)
        if (!empty($fileFields)) {
            foreach ($fileFields as $k) {
                if (!array_key_exists($k, $row)) continue;
                $row[$k] = $this->remapFilesLegacy($row[$k], $tablaBase, $k);
            }
        }
    }

    private function getPrimaryKey(string $tabla): ?string
    {
        try {
            $cols = $this->db->getFieldData($tabla);
            if (!is_array($cols)) return null;

            foreach ($cols as $c) {
                $name = (string)($c['name'] ?? '');
                $key  = (string)($c['key'] ?? '');
                if ($name !== '' && strtoupper($key) === 'PRI') {
                    return $name;
                }
            }
        } catch (\Throwable $e) {
            // ignore
        }
        return null;
    }

    private function encryptIdFields(array &$row, ?string $pk = null): void
    {
        foreach ($row as $k => $v) {
            if (is_array($v)) continue;

            $kk = (string)$k;
            $isId = ($kk === 'id') || ($pk && $kk === $pk) || $this->isIdField($kk);

            if ($isId && $v !== null && $v !== '') {
                $row[$k] = $this->encodeId($v);
            }
        }
    }

    private function isListArray(array $arr): bool
    {
        if (function_exists('array_is_list')) return array_is_list($arr);
        $i = 0;
        foreach ($arr as $k => $v) {
            if ($k !== $i++) return false;
        }
        return true;
    }

    /**
     * Normaliza tus EXTRAS legacy (json/search/select/files) a EXTRAS del Presenter CORE.
     *
     * @return array [presenterExtras, jsonFields, fileFields]
     */
    private function buildPresenterExtras(?array $extras, array $row): array
    {
        $presenterExtras = [];
        $jsonFields = [];
        $fileFields = [];

        if (!$extras || !is_array($extras)) {
            return [$presenterExtras, $jsonFields, $fileFields];
        }

        foreach ($extras as $field => $spec) {
            if (!is_string($field) || $field === '') continue;
            if (!is_array($spec)) continue;
            if (!array_key_exists($field, $row)) continue;

            $tipo = strtolower((string)($spec['type'] ?? $spec['tipo'] ?? ''));
            if ($tipo === '') continue;

            // Compat legacy
            if ($tipo === 'json') {
                $jsonFields[] = $field;
                continue;
            }

            if ($tipo === 'search') {
                // search -> lookup
                $presenterExtras[$field] = [
                    'type' => 'lookup',
                    'table' => $spec['tabla'] ?? ($spec['table'] ?? ''),
                    'value' => $spec['pk'] ?? ($spec['value'] ?? ($spec['id'] ?? '')),
                    'label' => $spec['texto'] ?? ($spec['label'] ?? ($spec['nombre'] ?? '')),
                    'as'    => $spec['as'] ?? 'pair',
                ];
                if (isset($spec['where']) && is_array($spec['where'])) $presenterExtras[$field]['where'] = $spec['where'];
                if (isset($spec['keys'])  && is_array($spec['keys']))  $presenterExtras[$field]['keys']  = $spec['keys'];
                if (array_key_exists('encrypt_value', $spec)) $presenterExtras[$field]['encrypt_value'] = (bool)$spec['encrypt_value'];
                if (array_key_exists('null', $spec)) $presenterExtras[$field]['null'] = $spec['null'];
                continue;
            }

            if ($tipo === 'select') {
                // select -> lookup_multi (retorna lista de {id, texto} para compat UI)
                $presenterExtras[$field] = [
                    'type'        => 'lookup_multi',
                    'table'       => $spec['tabla'] ?? ($spec['table'] ?? ''),
                    'value'       => $spec['id'] ?? ($spec['value'] ?? ($spec['pk'] ?? '')),
                    'label'       => $spec['nombre'] ?? ($spec['texto'] ?? ($spec['label'] ?? '')),
                    'source'      => $spec['source'] ?? 'auto',
                    'as'          => $spec['as'] ?? 'list',
                    'keys'        => $spec['keys'] ?? ['texto' => 'texto', 'valor' => 'id'],
                    'keep_order'  => array_key_exists('keep_order', $spec) ? (bool)$spec['keep_order'] : true,
                ];
                if (array_key_exists('encrypt_value', $spec)) $presenterExtras[$field]['encrypt_value'] = (bool)$spec['encrypt_value'];
                if (array_key_exists('include_none', $spec))  $presenterExtras[$field]['include_none']  = (bool)$spec['include_none'];
                if (isset($spec['none_value'])) $presenterExtras[$field]['none_value'] = $spec['none_value'];
                if (isset($spec['none_label'])) $presenterExtras[$field]['none_label'] = $spec['none_label'];
                if (array_key_exists('null', $spec)) $presenterExtras[$field]['null'] = $spec['null'];
                continue;
            }

            if ($tipo === 'files' || $tipo === 'file') {
                $presenterExtras[$field] = [
                    'type'      => 'files',
                    'as'        => 'files',
                    'source'    => $spec['source'] ?? 'auto',
                    'base_url'  => $spec['base_url'] ?? 'uploads/archivos',
                ];
                if (array_key_exists('encrypt_id', $spec)) $presenterExtras[$field]['encrypt_id'] = (bool)$spec['encrypt_id'];
                if (array_key_exists('null', $spec)) $presenterExtras[$field]['null'] = $spec['null'];
                $fileFields[] = $field;
                continue;
            }

            // Ya viene en formato CORE (lookup/lookup_multi/files/map/json_get...)
            if (in_array($tipo, ['lookup','lookup_multi','files','map','badge','json_get','combo','options','options_html'], true)) {
                $spec['type'] = $tipo;
                // normaliza alias
                if ($tipo === 'badge') $spec['type'] = 'map';
                if ($tipo === 'combo' || $tipo === 'options' || $tipo === 'options_html') {
                    $spec['type'] = 'options_html';
                }
                if ($tipo === 'files') $fileFields[] = $field;
                $presenterExtras[$field] = $spec;
                continue;
            }
        }

        return [$presenterExtras, $jsonFields, $fileFields];
    }

    /**
     * Convierte salida de Presenter->files() a tu formato legacy.
     * legacy: [{arch_id, doc:{...}, url, arch_tabla, arch_columna}, ...]
     */
    private function remapFilesLegacy($val, string $tablaBase, string $col): array
    {
        if ($val === null || $val === '' || $val === false) return [];

        $items = [];

        if (is_array($val)) {
            if ($this->isListArray($val)) $items = $val;
            else $items = [$val];
        } else {
            return [];
        }

        $out = [];
        foreach ($items as $f) {
            if (!is_array($f)) continue;

            $doc = [
                'doc_ext'    => $f['ext'] ?? ($f['doc_ext'] ?? ''),
                'doc_mime'   => $f['mime'] ?? ($f['doc_mime'] ?? ''),
                'doc_tam'    => $f['size'] ?? ($f['doc_tam'] ?? 0),
                'doc_file'   => $f['name'] ?? ($f['doc_file'] ?? ''),
                'doc_nombre' => $f['stored'] ?? ($f['doc_nombre'] ?? ''),
            ];

            $out[] = [
                'arch_id'      => $f['id'] ?? ($f['arch_id'] ?? null),
                'doc'          => $doc,
                'url'          => $f['url'] ?? null,
                'arch_tabla'   => $f['table'] ?? ($f['arch_tabla'] ?? $tablaBase),
                'arch_columna' => $f['column'] ?? ($f['arch_columna'] ?? $col),
            ];
        }

        return $out;
    }


/* =========================================================
     * Registrar (Q_Framework)
     * ========================================================= */
    public function Registrar($codif = false)
    {
        $TABLA = trim((string)$this->request->getPost('TABLA'));
        if ($TABLA === '' || !$this->isSafeDbIdent($TABLA)) {
            return $this->respond($this->failPayload("TABLA inválida"));
        }

        if (!$this->db->tableExists($TABLA)) {
            return $this->respond($this->failPayload("La tabla especificada no existe: {$TABLA}"));
        }

        $cols = $this->db->getFieldData($TABLA);
        if (!$cols) {
            return $this->respond($this->failPayload(
                "No se pudo leer la estructura de la tabla: {$TABLA}",
                [],
                ['db_error' => $this->db->error()]
            ));
        }

        $colsMap = [];
        $pk = null;
        foreach ($cols as $c) {
            $name = (string)($c['name'] ?? '');
            if ($name === '') continue;
            $colsMap[$name] = $c;
            if (!$pk && (($c['key'] ?? '') === 'PRI')) $pk = $name;
        }

        $MIDES = $this->postJson('MIDES', []);
        $MVALS = $this->postJson('MVALS', []);
        $TIPOS = $this->postJson('TIPOS', []);
        $DUPLC = $this->postJson('DUPLC', null);
        $EXTRA = $this->postJson('EXTRA', null);
        $FILTR = $this->postJson('FILTR', null);
        $PRCRG = $this->postJson('PRCRG', null);
        $JSONGROUPS = $this->postJson('JSONGROUPS', null);

        $RESPU = $this->request->getPost('RESPU');

        if (!is_array($MIDES) || !is_array($MVALS) || !is_array($TIPOS)) {
            return $this->respond($this->failPayload("Entrada inválida: MIDES/MVALS/TIPOS deben ser JSON arrays."));
        }
        if (count($MIDES) !== count($MVALS) || count($MIDES) !== count($TIPOS)) {
            return $this->respond($this->failPayload("Entrada inválida: MIDES/MVALS/TIPOS no tienen la misma longitud."));
        }

        $ASOCIADD = [];
        for ($i = 0; $i < count($MIDES); $i++) {
            $k = (string)$MIDES[$i];
            $ASOCIADD[$k] = $MVALS[$i];
        }

        $camposEnGruposJSON = [];
        $campo2GrupoDestino = [];
        if ($JSONGROUPS !== null) {
            if (!is_array($JSONGROUPS)) {
                return $this->respond($this->failPayload("JSONGROUPS inválido: debe ser objeto/array."));
            }
            foreach ($JSONGROUPS as $colDestino => $campos) {
                if (!is_string($colDestino) || !$this->isSafeDbIdent($colDestino)) {
                    return $this->respond($this->failPayload("JSONGROUPS inválido: columna destino no válida."));
                }
                if (!isset($colsMap[$colDestino])) {
                    return $this->respond($this->failPayload("JSONGROUPS inválido: '{$colDestino}' no existe en '{$TABLA}'."));
                }
                if (!is_array($campos)) continue;

                foreach ($campos as $c) {
                    $c = (string)$c;
                    if ($c === '' || !$this->isSafeDbIdent($c)) continue;
                    $camposEnGruposJSON[] = $c;
                    if (!isset($campo2GrupoDestino[$c])) $campo2GrupoDestino[$c] = $colDestino;
                }
            }
            $camposEnGruposJSON = array_values(array_unique($camposEnGruposJSON));
        }

        $prefijo = $this->detectIdField($pk, $colsMap, $ASOCIADD);

        $camposQMap = [];
        foreach ($TIPOS as $idx => $tipo) {
            if ($tipo === 'q_map') {
                $campoPrincipal = (string)$MIDES[$idx];
                $camposQMap[$campoPrincipal] = [
                    'latitud'  => $campoPrincipal . '_latitud',
                    'longitud' => $campoPrincipal . '_longitud',
                ];
            }
        }

        $ASOCIAD = [];
        $ARCHIVS = [];

        for ($i = 0; $i < count($MIDES); $i++) {
            $campoActual = (string)$MIDES[$i];
            $tipoActual  = (string)$TIPOS[$i];

            if ($campoActual === '' || !$this->isSafeDbIdent($campoActual)) {
                return $this->respond($this->failPayload("Campo inválido: '{$campoActual}'"));
            }

            if ($tipoActual === 'q_map') continue;

            $esSubMapa = false;
            foreach ($camposQMap as $sub) {
                if ($campoActual === $sub['latitud'] || $campoActual === $sub['longitud']) { $esSubMapa = true; break; }
            }
            if ($esSubMapa) continue;

            $enGrupoJSON   = in_array($campoActual, $camposEnGruposJSON, true);
            $existeEnTabla = isset($colsMap[$campoActual]);

            if (!$existeEnTabla && !$enGrupoJSON) {
                return $this->respond($this->failPayload("El campo '{$campoActual}' no existe en '{$TABLA}' y no está en JSONGROUPS."));
            }

            $rawVal = $MVALS[$i];

            if ($tipoActual === 'password') {
                $v = is_string($rawVal) ? trim($rawVal) : '';
                if ($v === '') continue;
                $VALOR = md5($v);
            } elseif ($tipoActual === 'email') {
                $v = is_string($rawVal) ? trim($rawVal) : '';
                if ($v === '') continue;
                $VALOR = $v;
            } elseif ($tipoActual === 'tel') {
                $VALOR = is_string($rawVal) ? trim($rawVal) : (string)$rawVal;
                if (is_array($EXTRA) && array_key_exists($campoActual, $EXTRA)) {
                    $campoPais = (string)$EXTRA[$campoActual];
                    $pais = $ASOCIADD[$campoPais] ?? null;
                    $phone = Validador_phone((string)$rawVal, (string)$pais);
                    if (!$phone[0]) {
                        return $this->respond($this->failPayload((string)$phone[1]));
                    }
                }
            } elseif ($tipoActual === 'date') {
                $VALOR = is_string($rawVal) ? trim($rawVal) : (string)$rawVal;
                $dmy = $campoActual . '_dmy';
                if (isset($colsMap[$dmy]) && $VALOR !== '') {
                    $ASOCIAD[$dmy] = date("d/m/Y", strtotime($VALOR));
                }
            } elseif ($tipoActual === 'file') {
                $VALOR = '';
                $ARCHIVS[] = $campoActual;
            } elseif ($tipoActual === 'q_pair') {
                $VALOR = json_encode($rawVal, JSON_UNESCAPED_UNICODE);
            } else {
                $VALOR = is_string($rawVal) ? trim($rawVal) : (is_null($rawVal) ? '' : (string)$rawVal);
            }

            $ASOCIAD[$campoActual] = $VALOR;
        }

        foreach ($camposQMap as $sub) {
            $lat = trim((string)$this->request->getPost($sub['latitud']));
            $lng = trim((string)$this->request->getPost($sub['longitud']));

            if (!isset($colsMap[$sub['latitud']]) || !isset($colsMap[$sub['longitud']])) {
                return $this->respond($this->failPayload("Campos de mapa no existen en '{$TABLA}'."));
            }

            $ASOCIAD[$sub['latitud']]  = $lat;
            $ASOCIAD[$sub['longitud']] = $lng;
        }

        if (is_array($JSONGROUPS)) {
            foreach ($JSONGROUPS as $colDestino => $camposOrigen) {
                if (!is_array($camposOrigen)) continue;

                $grupo = [];
                foreach ($camposOrigen as $c) {
                    $c = (string)$c;
                    if ($c === '' || !array_key_exists($c, $ASOCIAD)) continue;
                    $grupo[$c] = $ASOCIAD[$c];
                    unset($ASOCIAD[$c]);
                }
                if (!empty($grupo)) {
                    $ASOCIAD[$colDestino] = json_encode($grupo, JSON_UNESCAPED_UNICODE);
                }
            }
        }

        if (is_array($FILTR)) {
            foreach ($FILTR as $key) {
                $key = (string)$key;
                $v = trim((string)($ASOCIAD[$key] ?? ''));
                if ($v === '') {
                    $campoNombre = strtoupper(substr($key, strrpos($key, '_') + 1));
                    return $this->respond($this->failPayload("Por favor rellene el campo {$campoNombre}"));
                }
            }
        }

        if (is_array($PRCRG)) {
            foreach ($PRCRG as $key => $valor) {
                $key = (string)$key;
                $ASOCIAD[$key] = validador_desencriptar((string)$valor) ?? $valor;
            }
            if ($prefijo === null) $prefijo = $this->detectIdField($pk, $colsMap, $ASOCIAD);
        }

        $mid = null;
        $isUpdate = false;
        if (is_array($prefijo) && !empty($prefijo['indice'])) {
            $mid = validador_desencriptar((string)$prefijo['valor']) ?? $prefijo['valor'];
            if (is_numeric($mid)) $isUpdate = ((int)$mid > 0);
            else $isUpdate = (trim((string)$mid) !== '');

            if ($isUpdate) $ASOCIAD[$prefijo['indice']] = $mid;
        }

        // 🔐 Normalizar IDs/FKs en campos numéricos:
        // Permite que el front envíe tokens encriptados (ej: cli_id="...") y acá se desencripta
        // antes de guardar (evita guardar strings en columnas INT).
        foreach ($ASOCIAD as $k => $v) {
            if (!isset($colsMap[$k])) continue;

            $type = strtolower((string)($colsMap[$k]['type'] ?? ''));
            $isNumeric = (bool)preg_match('/\b(int|tinyint|smallint|mediumint|bigint|decimal|numeric|float|double)\b/', $type);
            if (!$isNumeric) continue;

            if (is_string($v)) {
                $vv = trim($v);
                if ($vv !== '' && !is_numeric($vv)) {
                    $dec = $this->safeDecrypt($vv);
                    if ($dec !== null && $dec !== false && $dec !== '') {
                        $ASOCIAD[$k] = $dec;
                    }
                }
            }
        }

        if (is_array($DUPLC)) {
            foreach ($DUPLC as $arrdup) {
                if (!is_array($arrdup)) continue;

                $ADUPLI = [];
                foreach ($arrdup as $key) {
                    $key = (string)$key;
                    if (!isset($ASOCIAD[$key]) || $ASOCIAD[$key] === '' || $ASOCIAD[$key] === null) {
                        continue 2;
                    }
                    $ADUPLI[$key] = $ASOCIAD[$key];
                }

                if ($isUpdate && $prefijo && !empty($prefijo['indice'])) {
                    $ADUPLI[$prefijo['indice'] . '!='] = $mid;
                }

                if ($this->db->table($TABLA)->where($ADUPLI)->exists()) {
                    $cad = '';
                    foreach ($ADUPLI as $k => $v) if (!str_contains($k, '_id')) $cad .= " {$v} ";
                    return $this->respond($this->failPayload("{$cad} Ya existe/n en el sistema, no puede duplicarse."));
                }
            }
        }

        $precodigo = (string)$this->request->getPost('PRECODIGO');
        if ($precodigo !== '') {
            $codigo = validador_desencriptar($precodigo);
            if (!$codigo) return $this->respond($this->failPayload("Código PRECODIGO corrompido."));

            try {
                eval($codigo);
            } catch (\ParseError $e) {
                return $this->respond($this->failPayload('Error de sintaxis en pre-registro: ' . $e->getMessage()));
            } catch (\Throwable $e) {
                return $this->respond($this->failPayload('Error en pre-registro: ' . $e->getMessage()));
            }
        }

        $idField = $prefijo['indice'] ?? $pk ?? null;
        if ($isUpdate && (!$idField || !isset($colsMap[$idField]))) {
            return $this->respond($this->failPayload("No se detectó campo ID para actualizar."));
        }

        try {
            $result = $this->db->retryTransaction(function () use (
                $TABLA, $ASOCIAD, $isUpdate, $idField, $mid, $ARCHIVS, $campo2GrupoDestino, $colsMap, $EXTRA
            ) {
                if (!$isUpdate) {
                    $ok = $this->db->table($TABLA)->insert($ASOCIAD);
                    if ($ok === false) {
                        $err = $this->db->error();
                        throw new \RuntimeException($err['message'] ?? 'DB insert error');
                    }
                    $idreg = (string)$this->db->insertID();
                    $action = 'insert';
                } else {
                    $ok = $this->db->table($TABLA)->where([$idField => $mid])->update($ASOCIAD);
                    if ($ok === false) {
                        $err = $this->db->error();
                        throw new \RuntimeException($err['message'] ?? 'DB update error');
                    }
                    $idreg = (string)$mid;
                    $action = 'update';
                }

                $filesSummary = [];

                foreach ($ARCHIVS as $QFILE) {
                    $input = $QFILE . '_file';
                    $ids_archivos = [];

                    $enGrupo = isset($campo2GrupoDestino[$QFILE]);
                    $colGrupo = $enGrupo ? $campo2GrupoDestino[$QFILE] : null;

                    if ($this->hasUploadedFile($input)) {
                        if ($action === 'update') {
                            $existentes = $this->db->table('app_archivos')
                                ->where([
                                    'arch_tabla'   => $TABLA,
                                    'arch_columna' => $QFILE,
                                    'arch_idtabla' => $idreg,
                                ])->get()->getResultArray();

                            foreach ($existentes as $ex) {
                                $doc = json_decode((string)($ex['arch_documento'] ?? ''), true) ?? [];
                                if (!empty($doc['doc_nombre'])) {
                                    $ruta = Path::join(
                                        ROOTPATH, 'public', 'uploads', 'archivos',
                                        $TABLA, $QFILE, (string)$doc['doc_nombre']
                                    );
                                    $ruta = Path::toNative($ruta);
                                    if (is_file($ruta)) @unlink($ruta);
                                }

                                $this->db->table('app_archivos')->where(['arch_id' => $ex['arch_id']])->delete();
                            }

                            if ($enGrupo && $colGrupo) {
                                $row = $this->db->table($TABLA)->select($colGrupo)->where([$idField => $idreg])->first();
                                $grupo = [];
                                if ($row && isset($row[$colGrupo])) $grupo = json_decode((string)$row[$colGrupo], true) ?? [];
                                if (isset($grupo[$QFILE])) {
                                    unset($grupo[$QFILE]);
                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([
                                        $colGrupo => json_encode($grupo, JSON_UNESCAPED_UNICODE),
                                    ]);
                                }
                            } else {
                                if (isset($colsMap[$QFILE])) {
                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([$QFILE => null]);
                                }
                            }
                        }

                        $archivos = $_FILES[$input];
                        $esMultiple = is_array($archivos['name']);
                        $cantidad = $esMultiple ? count($archivos['name']) : 1;

                        for ($j = 0; $j < $cantidad; $j++) {
                            $nombre = $esMultiple ? ($archivos['name'][$j] ?? '') : ($archivos['name'] ?? '');
                            $tmp    = $esMultiple ? ($archivos['tmp_name'][$j] ?? '') : ($archivos['tmp_name'] ?? '');
                            $tipo   = $esMultiple ? ($archivos['type'][$j] ?? '') : ($archivos['type'] ?? '');
                            $error  = $esMultiple ? ($archivos['error'][$j] ?? 0) : ($archivos['error'] ?? 0);
                            $tam    = $esMultiple ? ($archivos['size'][$j] ?? 0) : ($archivos['size'] ?? 0);

                            if ($error !== 0 || !$tmp) continue;

                            $extOrig  = strtolower(pathinfo($nombre, PATHINFO_EXTENSION));
                            $mimeOrig = @mime_content_type($tmp) ?: ($tipo ?: 'application/octet-stream');

                            $TIEMPO = time();
                            $nomfile = $idreg . "_" . $QFILE . "_" . $TIEMPO . "_" . $j;

                            $baseDir = Path::join(ROOTPATH, 'public', 'uploads', 'archivos', $TABLA, $QFILE);
                            $baseDir = Path::toNative($baseDir);
                            if (!is_dir($baseDir)) @mkdir($baseDir, 0775, true);

                            $conf = (is_array($EXTRA ?? null) && isset($EXTRA[$QFILE]) && is_array($EXTRA[$QFILE])) ? $EXTRA[$QFILE] : [];
                            $esImagen = (isset($conf['formato']) && $conf['formato'] === 'imagen');

                            $archivoTmp = ['tmp_name' => $tmp, 'type' => $tipo, 'name' => $nombre];

                            if ($esImagen) {
                                if (!empty($conf['ponermarca'])) {
                                    $archivoTmp = files_ponermarcadeagua($archivoTmp);
                                }
                                if (!empty($conf['ancho']) && !empty($conf['alto']) && isset($conf['proporcion'])) {
                                    $archivoTmp = files_cropImage($archivoTmp, (int)$conf['ancho'], (int)$conf['alto'], (string)$conf['proporcion']);
                                }
                                $archivoTmp = files_img2webp($archivoTmp);
                            }

                            if (is_array($archivoTmp) && !empty($archivoTmp['tmp_name'])) {
                                $mimeFinal = @mime_content_type($archivoTmp['tmp_name']) ?: ($archivoTmp['type'] ?? $mimeOrig);
                                $extFinal  = strtolower(pathinfo($archivoTmp['name'] ?? $nombre, PATHINFO_EXTENSION));
                            } else {
                                $mimeFinal = $mimeOrig;
                                $extFinal  = $extOrig ?: 'bin';
                                $archivoTmp = ['tmp_name' => $tmp, 'type' => $mimeFinal, 'name' => $nombre];
                            }

                            if ($mimeFinal === 'image/webp' && $extFinal !== 'webp') $extFinal = 'webp';

                            $nomfileFinal = $nomfile . "." . ($extFinal ?: $extOrig);
                            $ruta = Path::toNative(Path::join($baseDir, $nomfileFinal));

                            if (!files_guardararchivo($archivoTmp, $ruta)) {
                                throw new \RuntimeException("No se subió el archivo: {$nombre}");
                            }

                            $tamFinal = @filesize($ruta) ?: (int)$tam;

                            $datosfilr = [
                                'doc_ext'    => $extFinal ?: $extOrig,
                                'doc_mime'   => $mimeFinal ?: $mimeOrig,
                                'doc_tam'    => $tamFinal,
                                'doc_file'   => $nombre,
                                'doc_nombre' => $nomfileFinal,
                            ];

                            $okIns = $this->db->table('app_archivos')->insert([
                                'arch_tabla'     => $TABLA,
                                'arch_columna'   => $QFILE,
                                'arch_idtabla'   => $idreg,
                                'arch_documento' => json_encode($datosfilr, JSON_UNESCAPED_UNICODE),
                            ]);
                            if ($okIns === false) {
                                $err = $this->db->error();
                                throw new \RuntimeException($err['message'] ?? 'DB insert app_archivos error');
                            }

                            $ids_archivos[] = (string)$this->db->insertID();
                        }

                        if (!empty($ids_archivos)) {
                            if ($enGrupo && $colGrupo) {
                                $row = $this->db->table($TABLA)->select($colGrupo)->where([$idField => $idreg])->first();
                                $grupo = [];
                                if ($row && isset($row[$colGrupo])) $grupo = json_decode((string)$row[$colGrupo], true) ?? [];

                                $grupo[$QFILE] = (count($ids_archivos) === 1) ? $ids_archivos[0] : $ids_archivos;

                                $this->db->table($TABLA)->where([$idField => $idreg])->update([
                                    $colGrupo => json_encode($grupo, JSON_UNESCAPED_UNICODE),
                                ]);
                            } else {
                                if (isset($colsMap[$QFILE])) {
                                    $colType = strtolower((string)($colsMap[$QFILE]['type'] ?? ''));
                                    $isNumeric = (bool)preg_match('/^(tinyint|smallint|mediumint|int|bigint|decimal|float|double)/', $colType);

                                    $valCol = (count($ids_archivos) === 1)
                                        ? $ids_archivos[0]
                                        : ($isNumeric ? $ids_archivos[0] : json_encode($ids_archivos, JSON_UNESCAPED_UNICODE));

                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([$QFILE => $valCol]);
                                }
                            }
                        }

                        $filesSummary[$QFILE] = $ids_archivos;
                    } else {
                        $campofile = $this->db->table('app_archivos')
                            ->where([
                                'arch_tabla'   => $TABLA,
                                'arch_columna' => $QFILE,
                                'arch_idtabla' => $idreg,
                            ])->first();

                        if ($campofile && isset($campofile['arch_id'])) {
                            $archId = (string)$campofile['arch_id'];

                            if ($enGrupo && $colGrupo) {
                                $row = $this->db->table($TABLA)->select($colGrupo)->where([$idField => $idreg])->first();
                                $grupo = [];
                                if ($row && isset($row[$colGrupo])) $grupo = json_decode((string)$row[$colGrupo], true) ?? [];
                                $grupo[$QFILE] = $archId;

                                $this->db->table($TABLA)->where([$idField => $idreg])->update([
                                    $colGrupo => json_encode($grupo, JSON_UNESCAPED_UNICODE),
                                ]);
                            } else {
                                if (isset($colsMap[$QFILE])) {
                                    $this->db->table($TABLA)->where([$idField => $idreg])->update([$QFILE => $archId]);
                                }
                            }

                            $filesSummary[$QFILE] = [$archId];
                        } else {
                            $filesSummary[$QFILE] = [];
                        }
                    }
                }

                return [
                    'tabla'  => $TABLA,
                    'action' => $action,
                    'id'     => $idreg,
                    'files'  => $filesSummary,
                ];
            }, 3, 60);

            $msg = is_string($RESPU) && $RESPU !== ''
                ? $RESPU
                : (($result['action'] ?? '') === 'update' ? 'Registro actualizado correctamente' : 'Registro realizado correctamente');

            return $this->respond($this->okPayload($msg, $result));

        } catch (\Throwable $e) {
            return $this->respond($this->failPayload(
                "Error al registrar: " . $e->getMessage(),
                [],
                ['db_error' => $this->db->error()]
            ));
        }
    }

    /* =========================================================
     * Cargar (Q_Framework)
     * ========================================================= */
    public function Cargar($mDATOS = null)
    {
        if (!$mDATOS) {
            $TABLA   = (string)$this->request->getPost("TABLA");
            $COLUMNA = (string)$this->request->getPost("COLUMNA");
            $VALOR   = $this->request->getPost("VALOR");
            $EXTRAS  = $this->postJson("EXTRAS", null);

            if (!$this->isSafeDbIdent($TABLA))   return $this->respond($this->failPayload("TABLA inválida"));
            if (!$this->isSafeDbIdent($COLUMNA)) return $this->respond($this->failPayload("COLUMNA inválida"));

            if (!is_numeric($VALOR)) {
                $d = $this->safeDecrypt($VALOR);
                if ($d === null || $d === false || $d === '') {
                    return $this->respond($this->failPayload("VALOR inválido o no se pudo desencriptar"));
                }
                $VALOR = $d;
            }

            if (!$this->db->tableExists($TABLA)) {
                return $this->respond($this->failPayload("La tabla especificada no existe"));
            }

            $row = $this->db->table($TABLA)->where($COLUMNA, $VALOR)->first();
            if (!$row) {
                return $this->respond($this->failPayload("No se encontró registro", [], ['data' => []]));
            }

        } else {
            $EXTRAS = $mDATOS['extras'] ?? null;

            $TABLA = $mDATOS['prms']['tabla'] ?? null;
            $where = $mDATOS['prms']['where'] ?? null;

            if (!$TABLA || !$this->isSafeDbIdent((string)$TABLA) || !is_array($where)) {
                $payload = $this->failPayload("Parámetros inválidos en mDATOS", [], ['data' => []]);
                return $mDATOS ? $payload : $this->respond($payload);
            }

            foreach ($where as $k => $v) {
                if (!$this->isSafeDbIdent((string)$k)) {
                    $payload = $this->failPayload("Where inválido: {$k}", [], ['data' => []]);
                    return $mDATOS ? $payload : $this->respond($payload);
                }
                if (!is_numeric($v)) {
                    $dv = $this->safeDecrypt($v);
                    if ($dv !== null) $where[$k] = $dv;
                }
            }

            if (!$this->db->tableExists((string)$TABLA)) {
                $payload = $this->failPayload("La tabla especificada no existe", [], ['data' => []]);
                return $mDATOS ? $payload : $this->respond($payload);
            }

            $row = $this->db->table((string)$TABLA)->where($where)->first();
            if (!$row) {
                $payload = $this->failPayload("No se encontró registro", [], ['data' => []]);
                return $mDATOS ? $payload : $this->respond($payload);
            }
        }

        $this->applyExtras($row, is_array($EXTRAS) ? $EXTRAS : null, (string)$TABLA);

        $data = [$row];

        $payload = $this->okPayload("OK", $data);

        if ($mDATOS) {
            return $payload;
        }

        return $this->respond($payload);
    }
}