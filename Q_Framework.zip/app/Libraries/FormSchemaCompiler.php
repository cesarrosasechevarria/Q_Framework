<?php
declare(strict_types=1);

namespace App\Libraries;

/**
 * FormSchemaCompiler
 * ------------------
 * Convierte un FormSchema (JSON/array UI) a ColumnSpec[] (formato de Q_Framework Schema)
 * para poder hacer:
 *   service('schema')->ensure($table, $columns, $options)
 */
final class FormSchemaCompiler
{
    /**
     * Convierte schema JSON/array a ColumnSpec[] (para service('schema')->ensure()).
     *
     * @param array|string $schema JSON string o array del form-schema
     * @param array $opt Opciones del compilador (ver defaults)
     * @return array ColumnSpec[]
     */
    public static function toColumns(array|string $schema, array $opt = []): array
    {
        $opt = array_merge([
            'default_varchar' => 255,
            'textarea_as_text' => false,     // true => TEXT; false => VARCHAR(maxlength|500)
            'select_multiple_as' => 'json',  // json (por defecto)
            'file_store' => 'path',          // path => VARCHAR(255) | id => INT
            'add_file_meta' => true,         // agrega <campo>_meta JSON para file/image/avatar
            'skip_types' => ['html','button','submit','reset','separator','header','divider'],
            'infer_select_types' => false,   // intenta inferir tipo desde DB (si posible)
            'db' => null,                    // inyecta conexión db (opcional)
        ], $opt);

        $data = self::normalizeSchema($schema);
        if ($data === null) return [];

        $cols = [];

        self::walkNode($data, function(string $fieldKey, array $fieldDef) use (&$cols, $opt) {
            $col = self::buildColumn($fieldKey, $fieldDef, $opt);
            if ($col === null) return;

            // columna principal
            self::addCol($cols, $col);

            // meta para archivos (si aplica)
            $uiType = strtolower((string)($fieldDef['campos']['type'] ?? ''));
            if ($opt['add_file_meta'] && in_array($uiType, ['file','image','avatar'], true)) {
                self::addCol($cols, [
                    'name' => $fieldKey . '_meta',
                    'type' => 'JSON',
                    'nullable' => true,
                    'default' => null,
                ]);
            }
        });

        return self::uniqueByName($cols);
    }

    /* =========================================================
     * Internals
     * ========================================================= */

    private static function normalizeSchema(array|string $schema): ?array
    {
        if (is_string($schema)) {
            $decoded = json_decode($schema, true);
            return is_array($decoded) ? $decoded : null;
        }
        return is_array($schema) ? $schema : null;
    }

    private static function addCol(array &$cols, array $col): void
    {
        if (!isset($col['name']) && isset($col['nombre'])) $col['name'] = $col['nombre'];
        unset($col['nombre']);
        if (!isset($col['name']) || $col['name'] === '') return;
        $cols[] = $col;
    }

    private static function uniqueByName(array $cols): array
    {
        $seen = [];
        $out = [];
        foreach ($cols as $c) {
            $n = $c['name'] ?? null;
            if (!$n) continue;
            if (isset($seen[$n])) continue;
            $seen[$n] = true;
            $out[] = $c;
        }
        return $out;
    }

    private static function isAssoc(array $arr): bool
    {
        $keys = array_keys($arr);
        return $keys !== range(0, count($arr) - 1);
    }

    private static function toBool(mixed $v, bool $default=false): bool
    {
        if (is_bool($v)) return $v;
        if (is_numeric($v)) return (int)$v === 1;
        if (is_string($v)) return in_array(strtolower($v), ['1','true','yes','si','sí'], true);
        return $default;
    }

    /**
     * Recorre recursivamente el schema.
     * Llama a $onField($fieldKey, $fieldDef) por cada control real (tiene 'campos').
     */
    private static function walkNode(array $node, callable $onField): void
    {
        foreach ($node as $key => $val) {
            if (!is_array($val)) continue;

            // Campo directo: contiene 'campos'
            if (isset($val['campos']) && is_array($val['campos'])) {
                $onField((string)$key, $val);
                continue;
            }

            // Grupo asociativo: grupo_0, grupo_1 o cualquier object de campos
            if (self::isAssoc($val)) {
                self::walkNode($val, $onField);
                continue;
            }

            // Lista
            foreach ($val as $item) {
                if (is_array($item)) self::walkNode($item, $onField);
            }
        }
    }

    private static function buildColumn(string $fieldKey, array $fieldDef, array $opt): ?array
    {
        $campos = $fieldDef['campos'] ?? [];
        if (!is_array($campos)) $campos = [];

        $uiType = strtolower((string)($campos['type'] ?? ''));
        if ($uiType === '' || in_array($uiType, $opt['skip_types'], true)) return null;

        $required = self::toBool($campos['required'] ?? false, false);

        $col = [
            'name' => $fieldKey,
            'nullable' => self::toBool($campos['nullable'] ?? null, !$required),
            'unique' => self::toBool($campos['unique'] ?? false, false),
            'default' => $campos['default'] ?? null,
            'unsigned' => self::toBool($campos['unsigned'] ?? false, false),
            'auto_increment' => self::toBool($campos['auto_increment'] ?? false, false),
            'primary' => self::toBool($campos['primary'] ?? false, false),
        ];
        if (array_key_exists('comment', $campos)) $col['comment'] = $campos['comment'];

        // Override duro: db_type
        // db_type=IGNORE => no genera columna
        if (isset($campos['db_type'])) {
            $dbType = strtoupper(trim((string)$campos['db_type']));
            if ($dbType === 'IGNORE') return null;

            $col['type'] = $dbType;
            if (isset($campos['length'])) $col['length'] = (int)$campos['length'];
            if (isset($campos['precision'])) $col['precision'] = (int)$campos['precision'];
            if (isset($campos['scale'])) $col['scale'] = (int)$campos['scale'];

            if (in_array($dbType, ['ENUM','SET'], true)) {
                $values = $campos['values'] ?? ($fieldDef['opciones'] ?? null);
                $col['values'] = self::normalizeEnumValues($values);
            }
            return $col;
        }

        // Inferencias por UI
        switch ($uiType) {
            // Strings “normales”
            case 'text':
            case 'email':
            case 'password':
            case 'url':
            case 'search':
            case 'radio':
            case 'hidden':
            case 'slug':
            case 'color':
            case 'tel':
                $col['type'] = 'VARCHAR';
                $max = isset($campos['maxlength']) ? (int)$campos['maxlength'] : (int)$opt['default_varchar'];
                if ($uiType === 'tel') $max = min(max($max, 20), 32);
                $col['length'] = $max;
                break;

            case 'textarea':
                if ($opt['textarea_as_text']) {
                    $col['type'] = 'TEXT';
                } else {
                    $col['type'] = 'VARCHAR';
                    $col['length'] = isset($campos['maxlength']) ? (int)$campos['maxlength'] : 500;
                }
                break;

            // Selects
            case 'q_select':
            case 'dropdown':
                $multiple = self::toBool($campos['multiple'] ?? false, false);
                if ($multiple) {
                    $col['type'] = 'JSON';
                } else {
                    // intentar inferir desde DB si optado
                    $param = $fieldDef['parametros'] ?? [];
                    $t = is_array($param) ? ($param['tabla'] ?? null) : null;
                    $c = is_array($param) ? ($param['col_id'] ?? null) : null;

                    $inf = null;
                    if ($opt['infer_select_types'] && is_string($t) && is_string($c)) {
                        $inf = self::inferColumnTypeFromDb($t, $c, $opt['db']);
                    }
                    if (!$inf) {
                        $inf = self::inferSelectTypeHeuristic(is_string($c) ? $c : null);
                    }
                    $col['type'] = $inf['type'];
                    if (isset($inf['length'])) $col['length'] = $inf['length'];
                    if (isset($inf['unsigned'])) $col['unsigned'] = (bool)$inf['unsigned'];
                }
                break;

            // Opción con opciones => ENUM
            case 'opcion':
            case 'enum':
            case 'status':
            case 'state':
                $values = $fieldDef['opciones'] ?? ($campos['values'] ?? null);
                $col['type'] = 'ENUM';
                $col['values'] = self::normalizeEnumValues($values) ?: ['activo','inactivo'];
                break;

            // Booleanos
            case 'checkbox':
            case 'boolean':
            case 'switch':
                $col['type'] = 'TINYINT';
                $col['length'] = 1;
                if ($col['default'] === null) $col['default'] = 0;
                break;

            // Fechas
            case 'date':
                $col['type'] = 'DATE';
                break;
            case 'datetime':
            case 'datetime-local':
                $col['type'] = 'DATETIME';
                break;
            case 'time':
                $col['type'] = 'TIME';
                break;
            case 'timestamp':
                $col['type'] = 'TIMESTAMP';
                break;

            // Números (básico)
            case 'number':
            case 'integer':
            case 'int':
                $col['type'] = 'INT';
                $col['length'] = 11;
                break;

            case 'decimal':
                $col['type'] = 'DECIMAL';
                $col['precision'] = (int)($campos['precision'] ?? 10);
                $col['scale'] = (int)($campos['scale'] ?? 2);
                break;

            // Archivos
            case 'file':
            case 'image':
            case 'avatar':
                if ($opt['file_store'] === 'id') {
                    $col['type'] = 'INT';
                    $col['length'] = 11;
                    $col['unsigned'] = true;
                } else {
                    $col['type'] = 'VARCHAR';
                    $col['length'] = 255;
                }
                break;

            // JSON explícito
            case 'json':
            case 'array':
                $col['type'] = 'JSON';
                break;

            default:
                $col['type'] = 'VARCHAR';
                $col['length'] = isset($campos['maxlength']) ? (int)$campos['maxlength'] : (int)$opt['default_varchar'];
                break;
        }

        return $col;
    }

    private static function normalizeEnumValues(mixed $values): array
    {
        if (!is_array($values)) return [];
        $assoc = array_keys($values) !== range(0, count($values) - 1);
        return $assoc ? array_keys($values) : array_values($values);
    }

    private static function inferSelectTypeHeuristic(?string $colId): array
    {
        $colId = $colId ? strtolower($colId) : '';
        if ($colId === 'iso2') return ['type'=>'CHAR','length'=>2];
        if ($colId === 'iso3') return ['type'=>'CHAR','length'=>3];
        if ($colId === 'uuid') return ['type'=>'CHAR','length'=>36];
        if ($colId === 'tabla_id' || $colId === 'id' || str_ends_with($colId, '_id')) {
            return ['type'=>'INT','length'=>11,'unsigned'=>true];
        }
        return ['type'=>'VARCHAR','length'=>255];
    }

    /**
     * Inferencia desde DB si existe getFieldData().
     * - Si falla, retorna null y se usa heurística.
     */
    private static function inferColumnTypeFromDb(string $table, string $column, mixed $db = null): ?array
    {
        // Obtener db si no se inyectó
        if ($db === null && function_exists('service')) {
            try { $db = service('db'); } catch (\Throwable $e) { $db = null; }
        }
        if (!$db) return null;

        // getFieldData estilo CI o similar
        if (!method_exists($db, 'getFieldData')) return null;

        try {
            $fields = $db->getFieldData($table);
        } catch (\Throwable $e) {
            return null;
        }

        if (!is_array($fields)) return null;

        $columnLower = strtolower($column);
        foreach ($fields as $f) {
            // soporta objetos o arrays
            $name = is_object($f) ? ($f->name ?? null) : ($f['name'] ?? null);
            if (!$name) continue;
            if (strtolower((string)$name) !== $columnLower) continue;

            // tipo puede venir como "varchar", "int", etc.
            $type = is_object($f) ? ($f->type ?? null) : ($f['type'] ?? null);
            $max  = is_object($f) ? ($f->max_length ?? null) : ($f['max_length'] ?? null);
            $unsigned = is_object($f) ? ($f->unsigned ?? null) : ($f['unsigned'] ?? null);

            if (!$type) return null;

            $type = strtoupper((string)$type);

            // Normalizaciones mínimas
            if ($type === 'VARCHAR') return ['type'=>'VARCHAR', 'length'=>(int)($max ?: 255)];
            if ($type === 'CHAR') return ['type'=>'CHAR', 'length'=>(int)($max ?: 1)];
            if (in_array($type, ['INT','INTEGER','BIGINT','SMALLINT','MEDIUMINT','TINYINT'], true)) {
                return ['type'=>($type === 'INTEGER' ? 'INT' : $type), 'length'=>(int)($max ?: 11), 'unsigned'=>(bool)$unsigned];
            }
            if (in_array($type, ['DECIMAL','FLOAT','DOUBLE','DATE','DATETIME','TIME','TIMESTAMP','TEXT','MEDIUMTEXT','LONGTEXT','JSON'], true)) {
                return ['type'=>$type];
            }

            // Fallback
            return ['type'=>'VARCHAR', 'length'=>255];
        }

        return null;
    }
}
