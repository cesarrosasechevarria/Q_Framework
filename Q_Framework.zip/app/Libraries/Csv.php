<?php
declare(strict_types=1);

namespace App\Libraries;

/**
 * Ejemplo de Librería (App\Libraries\Csv)
 * Uso desde un controlador:
 *   $csv = $this->lib('Csv');
 *   $rows = $csv->parse($content);
 */
final class Csv
{
  public function parse(string $csv, string $delimiter = ','): array
  {
    $lines = preg_split("/\r\n|\n|\r/", trim($csv));
    $out = [];
    foreach ($lines as $line) {
      if ($line === '') continue;
      $out[] = str_getcsv($line, $delimiter);
    }
    return $out;
  }
}
