<?php
declare(strict_types=1);

namespace App\Providers;

use System\Core\ServiceProvider;
use System\Core\Events;
use System\Core\Logger;

/**
 * AppServiceProvider
 *
 * Ejemplo de extensión "pro":
 * - Registrar listeners (Events)
 * - Registrar bindings en container (Providers::container())
 * - Añadir rutas extras (Routes::add)
 */
final class AppServiceProvider extends ServiceProvider
{
  public function register(): void
  {
    // =============================
    // Contratos (interfaces) mínimos
    // =============================
    // Estos bindings viven en la capa App (no en System) para mantener
    // el core pequeño. Puedes reemplazarlos en tu propio Provider.

    // Logger
    $this->singleton(\App\Contracts\LoggerInterface::class, fn($c) => new \App\Support\LoggerAdapter());
    $this->singleton('logger', fn($c) => $c->get(\App\Contracts\LoggerInterface::class));

    // Mailer
    $this->singleton(\App\Contracts\MailerInterface::class, fn($c) => new \App\Support\MailerAdapter());
    $this->singleton('mailer', fn($c) => $c->get(\App\Contracts\MailerInterface::class));

    // Auth guard (session)
    $this->singleton(\App\Contracts\AuthGuardInterface::class, fn($c) => new \App\Support\SessionAuthGuard());
    $this->singleton('auth', fn($c) => $c->get(\App\Contracts\AuthGuardInterface::class));
    $this->singleton('guard', fn($c) => $c->get(\App\Contracts\AuthGuardInterface::class));

    // Ejemplo extra:
    // $this->singleton('my_service', fn($c) => new \App\Support\MyService());
  }

  public function boot(): void
  {
    // Listener de ejemplo
    Events::on('before.controller', function(array $ctx) {
      // Logger::info('before.controller', $ctx);
    }, 0);
  }
}
