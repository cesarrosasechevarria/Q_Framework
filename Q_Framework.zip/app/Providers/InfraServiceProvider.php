<?php
declare(strict_types=1);

namespace App\Providers;

use System\Core\ServiceProvider;
use System\Cache\RedisClient;
use System\Core\Logger;

/**
 * InfraServiceProvider (opcional, PRO)
 *
 * Objetivo:
 * - Mantener el core pequeño, pero dejar "infra" lista para producción.
 * - Fuente única: el Container.
 *
 * Incluye:
 * - Redis compartido (1 conexión) reutilizada por Cache (y Metrics si se activa).
 * - Override seguro del binding "cache" para reutilizar el RedisClient y mantener tenant-aware.
 * - Ajustes de observabilidad (formato de logs) por config/env.
 *
 * Se activa con .env:
 * - CACHE_DRIVER=redis
 * - OBS_ENABLED / OBS_* (ver app/Config/Observability.php)
 */
final class InfraServiceProvider extends ServiceProvider
{
  public function register(): void
  {
    $c = $this->container();

    // -------------------------
    // Redis client compartido
    // -------------------------
    // No obliga a Redis: sólo se usará si CACHE_DRIVER=redis o MetricsDriver=redis.
    // Si no hay Redis en el entorno, el sistema seguirá funcionando con FileCache/Metrics file.
    $c->singleton('redis', function($c) {
      $cache = \config('Cache');

      $host = (string)($cache->redisHost ?? \env('REDIS_HOST', '127.0.0.1'));
      $port = (int)($cache->redisPort ?? (int)\env('REDIS_PORT', 6379));
      $auth = (string)($cache->redisAuth ?? (string)\env('REDIS_AUTH', ''));
      $db   = (int)($cache->redisDb ?? (int)\env('REDIS_DB', 0));
      $timeout = (float)($cache->redisTimeout ?? (float)\env('REDIS_TIMEOUT', 1.5));
      $persist = !empty($cache->redisPersistent) || \env_bool('REDIS_PERSISTENT', false);

      return new RedisClient($host, $port, $timeout, $persist, $auth, $db);
    });

    // ---------------------------------------------------------
    // Override del binding "cache" (tenant-aware + Redis shared)
    // ---------------------------------------------------------
    // El core ya define un binding default. Aquí lo reemplazamos por uno PRO:
    // - reusa el RedisClient compartido (evita múltiples conexiones)
    // - conserva el comportamiento tenant-aware: cache:<tenantId>
    // - conserva FileCache por tenant si driver=file
    $c->forget('cache');
    $c->bind('cache', function($c){
      $tid = class_exists(\System\Core\Tenant::class) ? \System\Core\Tenant::id() : 'default';
      $id = 'cache:' . $tid;
      if ($c->has($id)) return $c->get($id);

      $cfg = \config('Cache');
      $driver = strtolower((string)($cfg->driver ?? 'file'));

      if ($driver === 'redis') {
        // Cliente redis compartido
        $client = $c->get('redis');

        $prefix = (string)($cfg->prefix ?? 'qfw');
        $prefix = rtrim($prefix, ':') . ':' . $tid . ':';

        $obj = new \System\Cache\RedisCache($client, $prefix);
      } else {
        $path = (string)($cfg->path ?? 'write/cache');
        $isAbs = str_starts_with($path, '/') || preg_match('/^[A-Za-z]:\\\\/', $path);
        $abs = $isAbs ? $path : base_path($path);
        $abs = rtrim($abs,'/\\') . DIRECTORY_SEPARATOR . $tid;

        $obj = new \System\Cache\FileCache($abs);
      }

      $c->instance($id, $obj);
      return $obj;
    });

    // Mantener contrato del core
    $c->bind(\System\Cache\CacheInterface::class, fn($c) => $c->get('cache'));
  }

  public function boot(): void
  {
    // -------------------------
    // Observabilidad (logs)
    // -------------------------
    // Centraliza el formato de logs sin tocar tu core.
    $obs = \config('Observability');
    if (!empty($obs->enabled) && !empty($obs->logEnabled)) {
      $fmt = (string)($obs->logFormat ?? 'json');
      Logger::setFormat($fmt);
    }
  }
}
