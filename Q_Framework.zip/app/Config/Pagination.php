<?php
declare(strict_types=1);

namespace Config;

final class Pagination
{
  /**
   * Parametro de página en querystring (ej: ?page=2)
   */
  public string $pageParam = 'page';

  /**
   * Si true, en la página 1 NO agrega ?page=1 (URLs más limpias)
   */
  public bool $omitFirstPage = true;

  /**
   * Ventana de páginas alrededor de la actual (2 => muestra +/-2)
   */
  public int $window = 2;
}
