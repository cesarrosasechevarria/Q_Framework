<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Modules extends BaseConfig
{
  /** auto-descubrimiento en app/Modules */
  public bool $autoDiscover = true;

  /** lista habilitada si autoDiscover=false */
  public array $enabled = ['Auth','Admin','Platform'];

  /** ruta relativa a ROOTPATH */
  public string $path = 'app/Modules';

  /** permitir activar/desactivar en runtime (por tenant) */
  public bool $runtimeToggle = true;

  /** nombre de archivo JSON en write/tenants/<tenant>/modules/ */
  public string $stateFile = 'modules.json';

  /** override|merge */
  public string $stateMode = 'override';

  public function __construct()
  {
    $this->autoDiscover = (bool)\env_bool('MODULES_AUTO_DISCOVER', $this->autoDiscover);
    $this->path = (string)\env('MODULES_PATH', $this->path);
    $this->runtimeToggle = (bool)\env_bool('MODULES_RUNTIME_TOGGLE', $this->runtimeToggle);
    $this->stateFile = (string)\env('MODULES_STATE_FILE', $this->stateFile);
    $this->stateMode = (string)\env('MODULES_STATE_MODE', $this->stateMode);

    // enabled (JSON) opcional
    $en = \env('MODULES_ENABLED', null);
    if (is_string($en) && $en !== '') {
      $arr = json_decode($en, true);
      if (is_array($arr)) $this->enabled = array_values(array_map('strval', $arr));
    }
  }
}
