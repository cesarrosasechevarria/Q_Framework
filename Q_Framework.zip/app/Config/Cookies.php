<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Cookies extends BaseConfig
{
  public string $prefix = '';
  public string $path = '/';
  public string $domain = '';
  public bool $secure = false;
  public bool $httpOnly = true;
  public string $sameSite = 'Lax';

  public function __construct()
  {
    $this->prefix = (string) env('COOKIE_PREFIX', $this->prefix);
    $this->path = (string) env('COOKIE_PATH', $this->path);
    $this->domain = (string) env('COOKIE_DOMAIN', $this->domain);
    $this->secure = env_bool('COOKIE_SECURE', $this->secure);
    $this->httpOnly = env_bool('COOKIE_HTTPONLY', $this->httpOnly);
    $this->sameSite = (string) env('COOKIE_SAMESITE', $this->sameSite);
  }
}
