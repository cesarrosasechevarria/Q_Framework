<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Mail extends BaseConfig
{
  /**
   * driver:
   * - mail (PHP mail())
   * - smtp (placeholder para implementar luego)
   */
  public string $driver = 'mail';

  public string $fromEmail = 'no-reply@example.com';
  public string $fromName  = 'Q_Framework';

  // SMTP (opcionales)
  public string $host = '';
  public int $port = 587;
  public string $username = '';
  public string $password = '';
  public string $encryption = 'tls'; // tls/ssl/''

  public function __construct()
  {
    $this->driver = (string) env('MAIL_DRIVER', $this->driver);
    $this->fromEmail = (string) env('MAIL_FROM', $this->fromEmail);
    $this->fromName  = (string) env('MAIL_FROM_NAME', $this->fromName);

    $this->host = (string) env('MAIL_HOST', $this->host);
    $this->port = env_int('MAIL_PORT', $this->port);
    $this->username = (string) env('MAIL_USER', $this->username);
    $this->password = (string) env('MAIL_PASS', $this->password);
    $this->encryption = (string) env('MAIL_ENCRYPTION', $this->encryption);
  }
}
