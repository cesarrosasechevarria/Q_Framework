<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Migrations extends BaseConfig
{
  /** Ruta relativa a ROOTPATH (compat) */
  public string $path = 'app/Database/Migrations';

  /**
   * Varias rutas (relativas a ROOTPATH). Si está vacía, se usa $path.
   * Ej: ['app/Database/Migrations', 'app/Database/Migrations/Tenant']
   */
  public array $paths = ['app/Database/Migrations'];

  /** Incluir app/Modules/<modulo>/Database/Migrations automáticamente */
  public bool $includeModules = true;
}
