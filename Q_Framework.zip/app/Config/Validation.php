<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Validation extends BaseConfig
{
  /** Mensajes base por regla */
  public array $messages = [
    'required' => 'El campo {field} es obligatorio.',
    'min'      => 'El campo {field} debe tener al menos {arg} caracteres.',
    'max'      => 'El campo {field} debe tener máximo {arg} caracteres.',
    'email'    => 'El campo {field} debe ser un email válido.',
    'integer'  => 'El campo {field} debe ser un entero.',
    'numeric'  => 'El campo {field} debe ser numérico.',
    'in'       => 'El campo {field} tiene un valor no permitido.',
    'regex'    => 'El campo {field} no cumple el formato esperado.',
    'alpha_dash' => 'El campo {field} solo permite letras, números, guiones y _ .',
  ];
}
