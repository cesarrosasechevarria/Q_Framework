<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Session extends BaseConfig
{
  public string $name = 'QFWSESSID';
  public string $savePath = ''; // write/sessions por defecto desde bootstrap
  public int $lifetime = 0; // 0 = hasta cerrar navegador
  public bool $cookieSecure = false;
  public bool $cookieHttpOnly = true;
  public string $cookieSameSite = 'Lax';

  public function __construct()
  {
    $this->name = (string) env('SESSION_NAME', $this->name);
    $this->lifetime = env_int('SESSION_LIFETIME', $this->lifetime);
    $this->cookieSecure = env_bool('SESSION_COOKIE_SECURE', $this->cookieSecure);
    $this->cookieHttpOnly = env_bool('SESSION_COOKIE_HTTPONLY', $this->cookieHttpOnly);
    $this->cookieSameSite = (string) env('SESSION_COOKIE_SAMESITE', $this->cookieSameSite);
  }
}
