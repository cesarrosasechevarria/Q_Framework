<?php
declare(strict_types=1);

namespace Config;

/**
 * Config\Output
 * Controla perfiles de salida (minimal|api|debug|full).
 */
final class Output
{
  /** Perfil por defecto si no se especifica */
  public string $defaultProfile = 'api';

  /**
   * Permitir que el perfil sea solicitado por query/header.
   * IMPORTANTE: solo se aplica en APP_DEBUG=1.
   */
  public bool $allowOverride = true;

  /** Querystring para override en debug: ?out=debug */
  public string $overrideQueryKey = 'out';

  /** Header para override en debug: X-Q-Output: full */
  public string $overrideHeader = 'X-Q-Output';

  /** Incluir trace_id en respuestas (recomendado) */
  public bool $includeTraceId = true;

  /**
   * En perfil full (solo debug), permitir incluir sql/params si el dev lo desea.
   * (DbResult->safeArray() NO los incluye por defecto).
   */
  public bool $includeSqlInFull = true;
  public bool $includeParamsInFull = true;

  /** En minimal, incluir action (update/insert/delete) */
  public bool $minimalIncludeAction = false;

  /** Keys a eliminar del array de DbResult en cada perfil */
  public array $dropApi = ['table','meta','time_ms','sql','params'];
  public array $dropDebug = ['sql','params'];
  public array $dropFull = []; // opcional
}
