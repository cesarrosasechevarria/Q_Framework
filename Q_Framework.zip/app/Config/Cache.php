<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Cache extends BaseConfig
{
  /** file|redis */
  public string $driver = 'file';

  /** ttl por defecto */
  public int $ttl = 3600;

  /** prefijo global (se añadirá TENANT_ID automáticamente) */
  public string $prefix = 'qfw';

  /** carpeta para file cache (base, luego /<tenant>/...) */
  public string $path = 'write/cache';

  /** Redis (cache distribuido) */
  public string $redisHost = '127.0.0.1';
  public int $redisPort = 6379;
  public string $redisAuth = '';
  public int $redisDb = 0;
  public float $redisTimeout = 1.5;
  public bool $redisPersistent = false;

  public function __construct()
  {
    $this->driver = (string)\env('CACHE_DRIVER', $this->driver);
    $this->ttl = (int)\env('CACHE_TTL', $this->ttl);
    $this->prefix = (string)\env('CACHE_PREFIX', $this->prefix);
    $this->path = (string)\env('CACHE_PATH', $this->path);

    $this->redisHost = (string)\env('REDIS_HOST', $this->redisHost);
    $this->redisPort = (int)\env('REDIS_PORT', $this->redisPort);
    $this->redisAuth = (string)\env('REDIS_AUTH', $this->redisAuth);
    $this->redisDb = (int)\env('REDIS_DB', $this->redisDb);
    $this->redisTimeout = (float)\env('REDIS_TIMEOUT', $this->redisTimeout);
    $this->redisPersistent = (bool)\env_bool('REDIS_PERSISTENT', $this->redisPersistent);
  }
}
