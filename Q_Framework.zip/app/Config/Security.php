<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Security extends BaseConfig
{
  /** CSRF */
  public bool $csrfEnabled = true;
  public string $csrfKey = '_token';
  public bool $csrfRotate = false;

  /**
   * Dónde se almacena el token:
   * - cookie (recomendado: no inicia sesión)
   * - session
   */
  public string $csrfStorage = 'cookie';

  /** Nombre del cookie CSRF (cuando storage=cookie) */
  public string $csrfCookieName = 'QFW_CSRF';

  /** Header para enviar CSRF en APIs */
  public string $csrfHeader = 'X-CSRF-TOKEN';

  /** TTL de cookie CSRF (segundos). 0 = sesión del navegador */
  public int $csrfExpire = 0;

  /** Overrides opcionales del cookie CSRF */
  public ?bool $csrfCookieSecure = null;
  public ?bool $csrfCookieHttpOnly = null;
  public ?string $csrfCookieSameSite = null;


  /** =========================
   * Rate Limiting (PRO)
   * =========================
   * Se recomienda para endpoints sensibles (login, reset password, etc.)
   */
  public int $loginMaxAttempts = 8;       // intentos
  public int $loginDecaySeconds = 600;    // ventana (segundos)
  public string $loginRatePrefix = 'rl:login'; // prefijo de key

  /** =========================
   * API Tokens (PRO)
   * =========================
   * Protege endpoints /api/v1/* usando el filtro 'api'.
   *
   * Config en .env:
   *   API_TOKENS=demo_token,otro_token
   */
  public string $apiTokenHeader = 'Authorization';
  public string $apiTokenQuery  = 'api_token';
  public array $apiTokens = [];

  /** Rate limit sugerido para API (usado por RateLimitFilter si no se pasan args) */
  public int $apiMaxAttempts = 120;
  public int $apiDecaySeconds = 60;
  public string $apiRatePrefix = 'rl:api';

  /** Key de sesión para URL intended (usado por GuardFilter + Auth) */
  public string $intendedKey = '_qfw_intended';

  public function __construct()
  {
    $this->csrfEnabled = env_bool('CSRF_ENABLED', $this->csrfEnabled);
    $this->csrfKey = (string) env('CSRF_KEY', $this->csrfKey);
    $this->csrfRotate = env_bool('CSRF_ROTATE', $this->csrfRotate);

    $this->csrfStorage = (string) env('CSRF_STORAGE', $this->csrfStorage);
    $this->csrfCookieName = (string) env('CSRF_COOKIE', $this->csrfCookieName);
    $this->csrfHeader = (string) env('CSRF_HEADER', $this->csrfHeader);
    $this->csrfExpire = (int) env('CSRF_EXPIRE', (string)$this->csrfExpire);

    $sec = env('CSRF_COOKIE_SECURE', null);
    if ($sec !== null && $sec !== '') $this->csrfCookieSecure = (bool) env_bool('CSRF_COOKIE_SECURE', false);

    $ho = env('CSRF_COOKIE_HTTPONLY', null);
    if ($ho !== null && $ho !== '') $this->csrfCookieHttpOnly = (bool) env_bool('CSRF_COOKIE_HTTPONLY', true);

    $ss = env('CSRF_COOKIE_SAMESITE', null);
    if (is_string($ss) && $ss !== '') $this->csrfCookieSameSite = $ss;

    // Rate limiting login (opcional por env)
    $this->loginMaxAttempts = (int) env('LOGIN_RATE_MAX', (string)$this->loginMaxAttempts);
    $this->loginDecaySeconds = (int) env('LOGIN_RATE_DECAY', (string)$this->loginDecaySeconds);
    $this->loginRatePrefix = (string) env('LOGIN_RATE_PREFIX', $this->loginRatePrefix);

    // Intended key
    $this->intendedKey = (string) env('INTENDED_KEY', $this->intendedKey);

    // API Tokens (PRO)
    $this->apiTokenHeader = (string) env('API_TOKEN_HEADER', $this->apiTokenHeader);
    $this->apiTokenQuery  = (string) env('API_TOKEN_QUERY', $this->apiTokenQuery);

    $tok = (string) env('API_TOKENS', '');
    if (trim($tok) !== '') {
      $this->apiTokens = array_values(array_filter(array_map('trim', preg_split('/\s*,\s*/', $tok)), fn($x) => $x !== ''));
    }

    // Rate limit sugerido para API
    $this->apiMaxAttempts = (int) env('API_RATE_MAX', (string)$this->apiMaxAttempts);
    $this->apiDecaySeconds = (int) env('API_RATE_DECAY', (string)$this->apiDecaySeconds);
    $this->apiRatePrefix = (string) env('API_RATE_PREFIX', $this->apiRatePrefix);
  }
}
