<?php
declare(strict_types=1);

use System\Core\RouteCollection;

/**
 * Rutas de tu aplicación.
 *
 * Nota:
 * - En este starter NO se incluye instalador web.
 * - La configuración se realiza con la guía de bienvenida (Home) + .env + CLI (php qfw doctor).
 */
return function(RouteCollection $routes) {

  // Home (Guía de bienvenida)
  $routes->get('/', 'App\\Controllers\\Home@index', ['as' => 'home']);
  $routes->get('/home', 'App\\Controllers\\Home@index');

  // Ejemplo
  $routes->get('/ejemplo', 'App\\Controllers\\Ejemplo@index');

  // Observabilidad: metrics (Prometheus)
  $obs = config('Observability');
  if (!empty($obs->exposeMetricsEndpoint)) {
    $metricsRoute = is_string($obs->metricsRoute ?? null) && $obs->metricsRoute ? (string)$obs->metricsRoute : '/_metrics';
    $routes->get($metricsRoute, 'App\\Controllers\\Observability@metrics', ['as' => 'metrics']);
  }

  // Admin: gestor de módulos (plugins) por tenant
  $routes->group('/admin', ['filters' => ['auth:@auth.login']], function(RouteCollection $r){
    $r->get('/modules', 'App\\Controllers\\Admin\\Modules@index', ['as' => 'admin.modules']);
    $r->get('/modules/enable/{name}', 'App\\Controllers\\Admin\\Modules@enable');
    $r->get('/modules/disable/{name}', 'App\\Controllers\\Admin\\Modules@disable');
  });

  // =========================
  // Debug (solo en development)
  // =========================
  if ((string)env('APP_ENV', 'production') !== 'production') {
    $routes->get('/debug/doctor', 'App\\Controllers\\Debug\\Doctor@index', ['as' => 'debug.doctor']);
  }

};
