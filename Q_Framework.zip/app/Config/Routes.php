<?php
declare(strict_types=1);

use System\Core\RouteCollection;

/**
 * Rutas de tu aplicación.
 *
 * Skeleton:
 * - Mantén aquí SOLO lo que tu proyecto usa.
 * - El instalador (/install) es opcional y se controla con INSTALL_WIZARD en .env
 */
return function(RouteCollection $routes) {

  // Home
  $routes->get('/', 'App\\Controllers\\Home@index', ['as' => 'home']);
  $routes->get('/home', 'App\\Controllers\\Home@index');
  $routes->get('/ejemplo', 'App\\Controllers\\Ejemplo@index');

  // Instalador (opcional)
  $routes->any('/install', 'App\\Controllers\\Install@index', ['as' => 'install']);
  $routes->any('/install/{step}', 'App\\Controllers\\Install@index');

  $routes->auto('/funciones', 'App\\Controllers\\Funciones', [
    'require'  => 'csrf',
    'defaultController' => 'Home',
    'defaultMethod'     => 'index',
  ]);

  // Observabilidad: metrics (Prometheus)
  $obs = config('Observability');
  if (!empty($obs->exposeMetricsEndpoint)) {
    $metricsRoute = is_string($obs->metricsRoute ?? null) && $obs->metricsRoute ? (string)$obs->metricsRoute : '/_metrics';
    $routes->get($metricsRoute, 'App\\Controllers\\Observability@metrics', ['as' => 'metrics']);
  }

  // Admin: gestor de módulos (plugins) por tenant
  $routes->group('/admin', ['filters' => ['auth:@auth.login']], function(RouteCollection $r){
    $r->get('/modules', 'App\\Controllers\\Admin\\Modules@index', ['as' => 'admin.modules']);
    $r->get('/modules/enable/{name}', 'App\\Controllers\\Admin\\Modules@enable');
    $r->get('/modules/disable/{name}', 'App\\Controllers\\Admin\\Modules@disable');
  });

  // v9: ejemplo GuardFilter (protección por sesión a nivel de rutas/grupos)
  // - require: sesión 'user' debe existir
  // - match:   valida valores dentro de la sesión (dot-notation)
  // - redirect: a dónde volver si no cumple
  //
  // $routes->group('/panel', [
  //   'guard' => [
  //     'require'  => 'user',
  //     'match'    => ['user.role' => ['admin','editor']],
  //     'redirect' => '@auth.login',
  //   ],
  // ], function(RouteCollection $r){
  //   $r->get('/', 'App\\Controllers\\Home@index');
  // });

  // =========================
  // Debug (solo en development)
  // =========================
  // Útil para validar helpers / libs mientras adaptas el framework.
  if ((string)env('APP_ENV', 'production') !== 'production') {
    $routes->any('/ValidadoresDebug', 'App\\Controllers\\ValidadoresDebug@index', ['as' => 'debug.validadores']);
    $routes->any('/debug/validadores', 'App\\Controllers\\ValidadoresDebug@index');
    $routes->get('/debug/doctor', 'App\\Controllers\\Debug\\Doctor@index', ['as' => 'debug.doctor']);
    $routes->any('/debug/validadores-test', 'App\\Controllers\\Debug\\ValidadoresTest@index', ['as' => 'debug.validadores_test']);
    // Alias corto
    $routes->any('/ValidadoresTest', 'App\\Controllers\\Debug\\ValidadoresTest@index');
  }

};
