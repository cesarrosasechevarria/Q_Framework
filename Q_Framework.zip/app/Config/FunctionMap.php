<?php
declare(strict_types=1);

namespace Config;

/**
 * Mapa central de funciones -> helper requerido (modo Lazy Load).
 * 
 * Úsalo para:
 * - Documentación
 * - Sugerencias automáticas en la pantalla de error (Errors.php)
 * 
 * Nota:
 * - Solo incluye funciones propias del framework y helpers.
 * - Para clases de vendor, ver sugerencias en Errors.php (Class not found).
 */
final class FunctionMap
{
  /**
   * Función (en minúsculas) => helper
   * @var array<string,string>
   */
  public array $fnToHelper = [
    // URL
    'base_url'   => 'url',
    'route_url'  => 'url',
    'site_url'   => 'url',
    'current_url'=> 'url',
    'previous_url'=> 'url',
    'uri_string' => 'url',
    'url_is'     => 'url',
    'prep_url'   => 'url',
    'anchor'     => 'url',
    'add_query'  => 'url',
    'remove_query'=> 'url',
    'build_url'  => 'url',
    'redirect'   => 'url',
    'asset_url'  => 'url',
    'url'        => 'url',

    // Security
    'csrf_token' => 'security',
    'csrf_field' => 'security',
    'csrf_meta'  => 'security',
    'random_str' => 'security',
    'hash_password'   => 'security',
    'verify_password' => 'security',
    'auth_user'  => 'security',
    'csp_nonce'  => 'security',
    'csp_attr'   => 'security',

    // Cookies
    'cookie_get'    => 'cookie',
    'cookie_set'    => 'cookie',
    'cookie_delete' => 'cookie',

    // Pagination
    'paginate'    => 'pagination',
    'pager_links' => 'pagination',

    // View / Core (siempre disponibles)
    'e'   => '@core',
    'esc' => '@core',

    // Array
    'array_get' => 'array',
    'array_has' => 'array',
    'array_set' => 'array',
    'array_forget' => 'array',

    // Text
    'str_limit' => 'text',
    'word_limiter' => 'text',
    'slugify' => 'text',

    // App
    'app_timezone' => 'app',
    'app_locale'   => 'app',
  ];

  /**
   * Prefijos que siempre apuntan a un helper.
   * @var array<string,string>
   */
  public array $prefixToHelper = [
    'validador_' => 'validadores',
    'Validador_' => 'validadores',
  ];
}
