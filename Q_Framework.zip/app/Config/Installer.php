<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Installer extends BaseConfig
{
  public bool $wizardEnabled = true;
  public string $lockFile = 'write/install.lock';

  public function __construct()
  {
    $this->wizardEnabled = env_bool('INSTALL_WIZARD', $this->wizardEnabled);
  }
}
