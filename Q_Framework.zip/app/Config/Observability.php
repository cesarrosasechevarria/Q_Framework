<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Observability extends BaseConfig
{
  public bool $enabled = true;

  // Logs
  public bool $logEnabled = true;
  public string $logFormat = 'json'; // json|text

  // Tracing
  public bool $tracingEnabled = true;
  public string $traceHeader = 'traceparent'; // W3C

  // Metrics
  public bool $metricsEnabled = true;
  public string $metricsDriver = 'file'; // file|redis
  public string $metricsPath = 'write/metrics';

  // Endpoints
  public bool $exposeMetricsEndpoint = true;
  public string $metricsRoute = '/_metrics';

  public function __construct()
  {
    $this->enabled = (bool)\env_bool('OBS_ENABLED', $this->enabled);
    $this->logEnabled = (bool)\env_bool('OBS_LOG_ENABLED', $this->logEnabled);
    $this->logFormat = (string)\env('OBS_LOG_FORMAT', $this->logFormat);
    $this->tracingEnabled = (bool)\env_bool('OBS_TRACING_ENABLED', $this->tracingEnabled);
    $this->traceHeader = (string)\env('OBS_TRACE_HEADER', $this->traceHeader);
    $this->metricsEnabled = (bool)\env_bool('OBS_METRICS_ENABLED', $this->metricsEnabled);
    $this->metricsDriver = (string)\env('OBS_METRICS_DRIVER', $this->metricsDriver);
    $this->metricsPath = (string)\env('OBS_METRICS_PATH', $this->metricsPath);
    $this->exposeMetricsEndpoint = (bool)\env_bool('OBS_EXPOSE_METRICS', $this->exposeMetricsEndpoint);
    $this->metricsRoute = (string)\env('OBS_METRICS_ROUTE', $this->metricsRoute);
  }
}
