<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Tenancy extends BaseConfig
{
  public bool $enabled = false;
  /** auto|header|query|subdomain|path */
  public string $strategy = 'auto';
  public string $defaultTenant = 'default';
  public string $header = 'X-Tenant-ID';
  public string $queryParam = 'tenant';
  public string $pathPrefix = 't';
  public bool $onlyKnownTenants = true;
  public string $tenantsPath = 'app/Tenants';
  public string $tenantsWritePath = 'write/tenants';
  public bool $loadTenantEnv = true;

  public function __construct()
  {
    $this->enabled = (bool)\env_bool('TENANCY_ENABLED', $this->enabled);
    $this->strategy = (string)\env('TENANT_STRATEGY', $this->strategy);
    $this->defaultTenant = (string)\env('TENANT_DEFAULT', $this->defaultTenant);
    $this->header = (string)\env('TENANT_HEADER', $this->header);
    $this->queryParam = (string)\env('TENANT_QUERY', $this->queryParam);
    $this->pathPrefix = (string)\env('TENANT_PATH_PREFIX', $this->pathPrefix);
    $this->onlyKnownTenants = (bool)\env_bool('TENANT_ONLY_KNOWN', $this->onlyKnownTenants);
    $this->tenantsPath = (string)\env('TENANTS_PATH', $this->tenantsPath);
    $this->tenantsWritePath = (string)\env('TENANTS_WRITE_PATH', $this->tenantsWritePath);
    $this->loadTenantEnv = (bool)\env_bool('TENANT_ENV_ENABLED', $this->loadTenantEnv);
  }
}
