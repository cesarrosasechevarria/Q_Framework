<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Tenancy extends BaseConfig
{
  public bool $enabled = false;

  /** auto|header|query|subdomain|path */
  public string $strategy = 'auto';

  /** Tenant usado cuando no hay candidato (ej: dominio base tuapp.com) */
  public string $defaultTenant = 'default';

  /** Header/query/path */
  public string $header = 'X-Tenant-ID';
  public string $queryParam = 'tenant';
  public string $pathPrefix = 't';

  /**
   * Solo permitir tenants conocidos.
   * - Si registry=filesystem -> carpetas en app/Tenants/<tenant>
   * - Si registry=db -> tabla system_db.tenants
   */
  public bool $onlyKnownTenants = true;

  /**
   * Modo profesional: si llega un subdominio/tenant desconocido
   * NO se debe “caer” a default silenciosamente.
   * - true  => marca TENANT_INVALID y App responderá 404/redirect (configurable)
   * - false => fallback como hoy (defaultTenant o primero conocido)
   */
  public bool $strictUnknownTenant = false;

  /** Qué hacer si TENANT_INVALID */
  public string $unknownTenantAction = '404'; // 404 | redirect
  public string $unknownTenantRedirect = '';  // si action=redirect, destino (si vacío usa App::baseURL host)

  /** Descubrimiento de tenants: filesystem|db|both */
  public string $registry = 'filesystem';

  /** Config registry=db (system DB) */
  public string $registryGroup = 'system';
  public string $registryTable = 'tenants';
  public string $registryIdColumn = 'id';
  public string $registryStatusColumn = 'status';
  public string $registryActiveValue = 'active';

  /**
   * Subdomain rules (profesional)
   * - baseDomains: dominios base válidos (["tuapp.com","tuapp.pe"])
   * - reservedSubdomains: subdominios que NO son tenant (www, api, docs, etc.)
   */
  public array $baseDomains = [];
  public array $reservedSubdomains = ['www','app','api','docs','static','assets','cdn','mail'];

  /** Paths */
  public string $tenantsPath = 'app/Tenants';
  public string $tenantsWritePath = 'write/tenants';

  /** Cargar overrides .env por tenant */
  public bool $loadTenantEnv = true;

  public function __construct()
  {
    $this->enabled = (bool)\env_bool('TENANCY_ENABLED', $this->enabled);
    $this->strategy = (string)\env('TENANT_STRATEGY', $this->strategy);
    $this->defaultTenant = (string)\env('TENANT_DEFAULT', $this->defaultTenant);
    $this->header = (string)\env('TENANT_HEADER', $this->header);
    $this->queryParam = (string)\env('TENANT_QUERY', $this->queryParam);
    $this->pathPrefix = (string)\env('TENANT_PATH_PREFIX', $this->pathPrefix);
    $this->onlyKnownTenants = (bool)\env_bool('TENANT_ONLY_KNOWN', $this->onlyKnownTenants);

    $this->strictUnknownTenant = (bool)\env_bool('TENANT_STRICT', $this->strictUnknownTenant);
    $this->unknownTenantAction = (string)\env('TENANT_UNKNOWN_ACTION', $this->unknownTenantAction);
    $this->unknownTenantRedirect = (string)\env('TENANT_UNKNOWN_REDIRECT', $this->unknownTenantRedirect);

    $this->registry = (string)\env('TENANT_REGISTRY', $this->registry);
    $this->registryGroup = (string)\env('TENANT_REGISTRY_GROUP', $this->registryGroup);
    $this->registryTable = (string)\env('TENANT_REGISTRY_TABLE', $this->registryTable);
    $this->registryIdColumn = (string)\env('TENANT_REGISTRY_ID', $this->registryIdColumn);
    $this->registryStatusColumn = (string)\env('TENANT_REGISTRY_STATUS', $this->registryStatusColumn);
    $this->registryActiveValue = (string)\env('TENANT_REGISTRY_ACTIVE', $this->registryActiveValue);

    // base domains: JSON o CSV
    $bd = \env_json('TENANT_BASE_DOMAINS', null);
    if (is_array($bd)) {
      $this->baseDomains = array_values(array_filter(array_map('strtolower', array_map('trim', $bd))));
    } else {
      $csv = (string)\env('TENANT_BASE_DOMAINS', '');
      if (trim($csv) !== '') {
        $this->baseDomains = array_values(array_filter(array_map('strtolower', array_map('trim', explode(',', $csv)))));
      }
    }

    // reserved: JSON o CSV
    $rs = \env_json('TENANT_RESERVED_SUBDOMAINS', null);
    if (is_array($rs)) {
      $this->reservedSubdomains = array_values(array_filter(array_map('strtolower', array_map('trim', $rs))));
    } else {
      $csv2 = (string)\env('TENANT_RESERVED_SUBDOMAINS', '');
      if (trim($csv2) !== '') {
        $this->reservedSubdomains = array_values(array_filter(array_map('strtolower', array_map('trim', explode(',', $csv2)))));
      }
    }

    $this->tenantsPath = (string)\env('TENANTS_PATH', $this->tenantsPath);
    $this->tenantsWritePath = (string)\env('TENANTS_WRITE_PATH', $this->tenantsWritePath);
    $this->loadTenantEnv = (bool)\env_bool('TENANT_ENV_ENABLED', $this->loadTenantEnv);
  }
}
