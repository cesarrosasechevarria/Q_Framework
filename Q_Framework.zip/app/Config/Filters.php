<?php
declare(strict_types=1);

/**
 * Filters (middlewares)
 *
 * - aliases: nombres cortos -> clase filtro
 * - globals: before/after global (para toda la app)
 * - patterns: aplica filtros por patrón de ruta
 *
 * NOTA:
 * Este starter incluye un módulo de Auth (opcional) y un AuthFilter listo para usar.
 * Si quieres un filtro 'auth', créalo en app/Filters/AuthFilter.php y regístralo aquí.
 */
return [
  'aliases' => [
    'auth' => App\Filters\AuthFilter::class,
    // v9: guard de sesión configurable por ruta/grupo
    'guard' => System\Filters\GuardFilter::class,
    'csrf' => System\Filters\CsrfFilter::class,
    'sec'  => System\Filters\SecurityHeadersFilter::class,
    'obs'  => System\Filters\ObservabilityFilter::class,

    // PRO: API token (Authorization: Bearer / X-API-KEY / ?api_token=)
    'api'  => App\Filters\ApiTokenFilter::class,

    // PRO: rate limit (429) - útil para API o endpoints sensibles
    'rate' => System\Filters\RateLimitFilter::class,

    // PRO: feature flags por ruta (beta features, A/B simple, etc.)
    'feature' => App\Filters\FeatureFlagFilter::class,
  ],

  'globals' => [
    'before' => [
      'obs',
      // 'csrf', // Actívalo si quieres CSRF global (útil si casi todo es POST)
    ],
    'after'  => [
      'obs',
      'sec', // headers seguros globales por defecto
    ],
  ],

  'patterns' => [
    // '/admin/*' => ['auth'], // ejemplo
  ],
];
