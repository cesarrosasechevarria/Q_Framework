<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Constants extends BaseConfig
{
  /** @var array<string,mixed> */
  public array $constants = [
    'APP_NAME'    => 'Q_Framework',
    'APP_VERSION' => '1.0.0',
  ];

  public function __construct()
  {
    $name = env('APP_NAME', null);
    if (is_string($name) && $name !== '') $this->constants['APP_NAME'] = $name;

    $ver = env('APP_VERSION', null);
    if (is_string($ver) && $ver !== '') $this->constants['APP_VERSION'] = $ver;
  }
}
