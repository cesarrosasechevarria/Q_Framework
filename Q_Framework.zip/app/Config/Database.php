<?php
declare(strict_types=1);

namespace Config;

use PDO;
use System\Config\BaseConfig;
use System\Database\Connection;
use System\Core\DB;

/**
 * Database (multi-fuente)
 *
 * - Grupo por defecto:
 *     DB_DEFAULT_GROUP=default
 * - Conexión por defecto (compat):
 *     DB_DSN=...
 *     DB_USER=...
 *     DB_PASS=...
 * - Múltiples conexiones (JSON):
 *     DB_CONNECTIONS_JSON={"analytics":{"dsn":"...","user":"...","pass":"..."}}
 * - Alternativa por prefijo (opcional):
 *     DB_ANALYTICS_DSN=...
 *     DB_ANALYTICS_USER=...
 *     DB_ANALYTICS_PASS=...
 */
final class Database extends BaseConfig
{
  public string $defaultGroup = 'default';

  /** Seguridad: evita UPDATE/DELETE sin WHERE (recomendado true). */
  public bool $protectWrites = true;

  /** Seguridad: escapa/valida identificadores (tabla/columna) por defecto. */
  public bool $strictIdentifiers = true;


/**
 * Columnas internas que normalmente NO quieres exponer en listados/JSON.
 *
 * Uso:
 * - QueryBuilder->selectPublic()      (select * excepto estas)
 * - TableCrud->findPublic/allPublic() (helpers)
 * - DbResult->safeArray(['hidePublic'=>true]) (fallback en salida)
 */
public array $hiddenSelectFields = [
  'borrado',
  'fecha',
  'fecha_dmy',
  // timestamps comunes (si los usas)
  'created_at',
  'updated_at',
  'deleted_at',
];

/**
 * Opcional: overrides por tabla.
 * - Si existe la clave '*', se mergea como base.
 * - Si existe la clave 'usuarios', se mergea para esa tabla.
 *
 * Ej:
 *   public array $hiddenSelectFieldsByTable = [
 *     '*' => ['borrado','fecha','fecha_dmy'],
 *     'usuarios' => ['usu_password'],
 *   ];
 */
public array $hiddenSelectFieldsByTable = [];


  /** @var array<string, array{dsn:string,user:string,pass:string,options:array}> */
  public array $connections = [];

  /** Opciones PDO comunes */
  public array $defaultOptions = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
  ];

  public function __construct()
  {
    $this->defaultGroup = (string)env('DB_DEFAULT_GROUP', $this->defaultGroup);

    // ====== Default (compat) ======
    $dsn  = (string)env('DB_DSN',  'mysql:host=127.0.0.1;dbname=ejemplo;charset=utf8mb4');
    $user = (string)env('DB_USER', 'root');
    $pass = (string)env('DB_PASS', '');

    $opt = env_json('DB_OPTIONS', null);
    $options = $this->defaultOptions;
    if (is_array($opt)) $options = array_replace($options, $opt);

    $this->connections['default'] = [
      'dsn'     => $dsn,
      'user'    => $user,
      'pass'    => $pass,
      'options' => $options,
    ];

    // ====== Extras por JSON ======
    $json = env_json('DB_CONNECTIONS_JSON', null);
    if (is_array($json)) {
      foreach ($json as $name => $cfg) {
        if (!is_array($cfg)) continue;
        $n = strtolower(trim((string)$name));
        if ($n === '') continue;

        $this->connections[$n] = [
          'dsn'     => (string)($cfg['dsn'] ?? ''),
          'user'    => (string)($cfg['user'] ?? ''),
          'pass'    => (string)($cfg['pass'] ?? ''),
          'options' => is_array($cfg['options'] ?? null) ? array_replace($options, (array)$cfg['options']) : $options,
        ];
      }
    }

    // ====== Extras por prefijo DB_<GROUP>_DSN ======
    foreach ($_ENV as $k => $v) {
      if (!is_string($k)) continue;
      if (!preg_match('/^DB_([A-Z0-9_]+)_DSN$/', $k, $m)) continue;

      $g = strtolower($m[1]);
      $dsn2 = (string)$v;
      if ($dsn2 === '') continue;

      $this->connections[$g] = [
        'dsn'     => $dsn2,
        'user'    => (string)env('DB_'.$m[1].'_USER', ''),
        'pass'    => (string)env('DB_'.$m[1].'_PASS', ''),
        'options' => $options,
      ];
    }
  }

  /** Compat estilo Q_Framework: \Config\Database::connect('grupo') */
  public static function connect(?string $group = null): Connection
  {
    return DB::connect($group);
  }
}
