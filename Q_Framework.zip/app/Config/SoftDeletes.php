<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

/**
 * SoftDeletes (global)
 *
 * Por defecto: borrado lógico usando campo 'borrado'
 * - SOFT_DELETE_ENABLED=1
 * - SOFT_DELETE_FIELD=borrado
 * - SOFT_DELETE_VALUE_DELETED=1
 * - SOFT_DELETE_VALUE_ACTIVE=0
 */
final class SoftDeletes extends BaseConfig
{
  public bool $enabled = true;
  public string $field = 'borrado';
  public int $valueDeleted = 1;
  public int $valueActive  = 0;

  public function __construct()
  {
    $this->enabled = env_bool('SOFT_DELETE_ENABLED', $this->enabled);
    $this->field = (string)env('SOFT_DELETE_FIELD', $this->field);
    $this->valueDeleted = (int)env('SOFT_DELETE_VALUE_DELETED', (string)$this->valueDeleted);
    $this->valueActive  = (int)env('SOFT_DELETE_VALUE_ACTIVE',  (string)$this->valueActive);
  }
}
