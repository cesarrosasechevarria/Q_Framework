<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class I18n extends BaseConfig
{
  public string $defaultLocale = 'es';

  /** Si true, intenta detectar por Accept-Language */
  public bool $negotiateLocale = false;

  /** Soportados (prioridad) */
  public array $supportedLocales = ['es','en'];
}
