<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

/**
 * Configuración del pager (render de enlaces).
 *
 * - Para cambiar el HTML del pager, copia el template core:
 *     system/Views/_system/pagers/qfw_default.php
 *   a:
 *     app/Views/_system/pagers/qfw_default.php
 *   y edítalo.
 */
final class Pager extends BaseConfig
{
  /** View template por defecto (sin .php) */
  public string $template = '_system/pagers/qfw_default';

  /** Layout opcional (normalmente vacío para partials) */
  public string $layout = '';

  /** Mostrar botones primera/última */
  public bool $showFirstLast = true;

  /** Mostrar resumen "Página X de Y" */
  public bool $showSummary = true;

  /* =========================
     CLASES / ESTILO
  ========================= */
  public string $navClass = 'qfw-pager';
  public string $rowClass = 'qfw-row';

  public string $btnClass = 'qfw-btn';
  public string $activeBtnClass = 'qfw-btn primary';

  public string $disabledClass = 'qfw-btn';
  public string $disabledStyle = 'opacity:.45; pointer-events:none';

  public string $summaryClass = 'qfw-muted';

  /* =========================
     LABELS
  ========================= */
  public string $labelFirst = '«';
  public string $labelPrev  = '‹';
  public string $labelNext  = '›';
  public string $labelLast  = '»';
}
