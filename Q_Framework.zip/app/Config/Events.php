<?php
declare(strict_types=1);

/**
 * Events config
 *
 * Define listeners para eventos del kernel.
 *
 * Eventos disponibles (v7):
 * - app.start
 * - routing.start / routing.end
 * - filters.before / filters.after
 * - controller.before / controller.after
 * - response.before_send / response.after_send
 *
 * Cada listener:
 *   ['fn' => callable|ClassInvocable::class, 'priority' => 0]
 */
return [
  // 'app.start' => [
  //   ['fn' => function($p){ \System\Core\Logger::info('App start', (array)$p); }, 'priority' => 0],
  // ],
];
