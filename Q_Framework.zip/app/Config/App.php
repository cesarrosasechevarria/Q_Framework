<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class App extends BaseConfig
{
  /** Base URL (con trailing slash recomendado). Puede venir de env('baseURL'). */
  public string $baseURL = 'http://localhost/Q_Framework';

  /** Clase URL CORE (puedes extender en App\\Support\\Url y apuntar aquí). */
  // Nota: usa separadores de namespace normales (\System\Core\Url::class)
  public string $urlClass = \System\Core\Url::class;

  /** Hostnames adicionales permitidos (aparte del hostname de baseURL) */
  public array $allowedHostnames = [];

  /** index.php o '' si removiste index.php con rewrite */
  public string $indexPage = '';

  /**
   * REQUEST_URI (default), QUERY_STRING, PATH_INFO
   * En XAMPP normalmente REQUEST_URI.
   */
  public string $uriProtocol = 'REQUEST_URI';

  /**
   * Regex character group, usado en: '/\A[<permittedURIChars>]+\z/iu'
   * Default: a-z 0-9~%.:_\-
   */
  public string $permittedURIChars = 'a-zA-Z 0-9~%.:_\-';

  /** Locale por defecto */
  public string $defaultLocale = 'es';

  /** Negociar locale por Accept-Language */
  public bool $negotiateLocale = false;

  /** Locales soportados (ordenados por prioridad) */
  public array $supportedLocales = ['es', 'en'];

  /** Timezone de la app */
  public string $appTimezone = 'America/Lima';

  /** Charset por defecto */
  public string $charset = 'UTF-8';

  /**
   * Salida directa desde controllers (echo/print/var_dump).
   *
   * Valores:
   *  - 'append_html' (default): añade la salida capturada al body si no es JSON ni redirect.
   *  - 'debug': no la añade; solo muestra un bloque debug en HTML (dev) + headers informativos.
   *  - 'ignore': descarta la salida capturada (solo headers informativos).
   */
  public string $controllerOutputMode = 'append_html';

  /** Fuerza HTTPS global (redirect + HSTS). */
  public bool $forceGlobalSecureRequests = false;

  /**
   * Reverse proxy IPs whitelist (ip => header)
   * Ej:
   *  ['10.0.0.1' => 'X-Forwarded-For']
   */
  public array $proxyIPs = [];

  /** CSP toggle (básico) */
  public bool $CSPEnabled = false;

  /** CSP en modo Report-Only (no bloquea, solo reporta). */
  public bool $CSPReportOnly = false;

  /** Permite estilos inline (compat), recomendado desactivar gradualmente. */
  public bool $CSPAllowUnsafeInlineStyles = true;

  /** Directivas CSP adicionales (sin incluir default-src). Ej: "connect-src https://api.miapp.com" */
  public string $CSPExtra = '';

  /**
   * Helpers globales (opcional).
   *
   * En este starter se habilitan por defecto para dar compatibilidad inmediata
   * con controllers heredados que llaman funciones helper sin `helper('...')`.
   * Si prefieres performance/aislamiento, pon $autoloadGlobalHelpers=false y
   * carga helpers por controller.
   */
  public array $globalHelpers = ['security','files','validadores','formularios', 'files'];

  /** Si es true, bootstrap cargará $globalHelpers automáticamente. */
  public bool $autoloadGlobalHelpers = true;

/** Layout por defecto */
  public string $defaultLayout = '';

  /** Auto Routing (tipo CI). Útil en development; en producción se recomienda desactivar. */
  public bool $autoRoute = false;

  /** Si true, traduce dashes en URL a CamelCase (user-profile -> userProfile) */
  public bool $translateURIDashes = true;

    /** Si true, permite usar dots como separador en AutoRoute: /admin.users.edit -> /admin/users/edit
   *  Recomendado: usar solo si necesitas URLs con dots (evita usarlo para versiones tipo /v1.0).
   */
  public bool $translateURIDots = false;

  /** Default controller/method (cuando path es / o faltan segmentos) */
  public string $defaultController = 'Home';
  public string $defaultMethod     = 'index';

  /** Namespaces permitidos para autoroute (seguridad) */
  public array $autoRouteNamespaces = ['App\\Controllers'];


  /** CSRF config */
  public array $csrf = [
    'enabled' => true,
    'key'     => '_token',
    'rotate'  => false,
  ];

  public function __construct()
  {
    // ===== env overrides (tipo Q_Framework) =====
    $this->baseURL = rtrim((string)env('baseURL', env('BASE_URL', $this->baseURL)), '/') . '/';
    $this->urlClass = (string)env('URL_CLASS', $this->urlClass);
    $this->indexPage = (string)env('indexPage', $this->indexPage);
    $this->uriProtocol = (string)env('uriProtocol', $this->uriProtocol);
    // Layout global (opcional). Vacío = sin layout (estilo CI4)
    $dl = trim((string)env('DEFAULT_LAYOUT', $this->defaultLayout));
    if ($dl === '0' || strtolower($dl) === 'false' || strtolower($dl) === 'none') $dl = '';
    $this->defaultLayout = $dl;

    $this->permittedURIChars = (string)env('permittedURIChars', $this->permittedURIChars);

    $this->defaultLocale = (string)env('defaultLocale', $this->defaultLocale);
    $this->negotiateLocale = (bool)env_bool('negotiateLocale', $this->negotiateLocale);

    $locales = env('supportedLocales', null);
    if (is_string($locales) && $locales !== '') {
      $arr = json_decode($locales, true);
      if (is_array($arr) && $arr) $this->supportedLocales = array_values($arr);
    }

    $this->appTimezone = (string)env('appTimezone', $this->appTimezone);
    $this->charset = (string)env('charset', $this->charset);
    $this->forceGlobalSecureRequests = (bool)env_bool('forceGlobalSecureRequests', $this->forceGlobalSecureRequests);

    // allowedHostnames, proxyIPs, CSPEnabled (opcionales vía env JSON)
    $allowed = env('allowedHostnames', null);
    if (is_string($allowed) && $allowed !== '') {
      $arr = json_decode($allowed, true);
      if (is_array($arr)) $this->allowedHostnames = array_values($arr);
    }

    $proxy = env('proxyIPs', null);
    if (is_string($proxy) && $proxy !== '') {
      $arr = json_decode($proxy, true);
      if (is_array($arr)) $this->proxyIPs = $arr;
    }

    $this->CSPEnabled = (bool)env_bool('CSPEnabled', $this->CSPEnabled);


    // AutoRoute (configurable por env)
    // - AUTO_ROUTE=1 en development si quieres /Controller/method sin definir rutas
    $this->autoRoute = (bool)env_bool('AUTO_ROUTE', $this->autoRoute);
    $this->translateURIDashes = (bool)env_bool('AUTO_ROUTE_TRANSLATE_DASHES', $this->translateURIDashes);
    $this->defaultController = (string)env('DEFAULT_CONTROLLER', $this->defaultController);
    $this->defaultMethod     = (string)env('DEFAULT_METHOD', $this->defaultMethod);

    $ns = env('AUTO_ROUTE_NAMESPACES', null);
    if (is_string($ns) && $ns !== '') {
      $arr = json_decode($ns, true);
      if (is_array($arr) && $arr) $this->autoRouteNamespaces = array_values($arr);
    }


    // CSP
    $this->CSPEnabled = env_bool('CSP_ENABLED', $this->CSPEnabled);
    $this->CSPReportOnly = env_bool('CSP_REPORT_ONLY', $this->CSPReportOnly);
    $this->CSPAllowUnsafeInlineStyles = env_bool('CSP_UNSAFE_INLINE_STYLES', $this->CSPAllowUnsafeInlineStyles);
    $this->CSPExtra = (string)env('CSP_EXTRA', $this->CSPExtra);

    // timezone real
    if ($this->appTimezone) @date_default_timezone_set($this->appTimezone);
  }
}
