<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Debug extends BaseConfig
{
  /** Toolbar sólo en development + APP_DEBUG=1 */
  public bool $toolbarEnabled = true;

  /** Mostrar lista de archivos incluidos */
  public bool $collectFiles = true;

  /** Mostrar variables (GET/POST/SESSION) */
  public bool $collectVars = true;

  /** Registrar queries DB (si usas DB::pdo/DB::query) */
  public bool $collectDb = true;

  public function __construct()
  {
    $this->toolbarEnabled = env_bool('DEBUG_TOOLBAR', $this->toolbarEnabled);
    $this->collectFiles = env_bool('DEBUG_COLLECT_FILES', $this->collectFiles);
    $this->collectVars  = env_bool('DEBUG_COLLECT_VARS',  $this->collectVars);
    $this->collectDb    = env_bool('DEBUG_COLLECT_DB',    $this->collectDb);
  }
}
