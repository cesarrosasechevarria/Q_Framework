<?php
declare(strict_types=1);

namespace Config;

use PDO;
use System\Core\DB;
use System\Core\Mail;
use System\Core\Session;
use System\Core\Request;
use System\Core\Response;
use System\Services\Encrypter;
use System\Database\Connection;
use App\Controllers\Miscontrollers\Datos;
use System\Cache\FileCache;
use System\Cache\CacheInterface;
use System\Validation\Validator;
use System\I18n\Lang;
use System\Database\Migrations\Migrator;
use System\Security\RateLimiter;
use App\Contracts\LoggerInterface;
use App\Contracts\MailerInterface;
use App\Contracts\AuthGuardInterface;
use App\Support\LoggerAdapter;
use App\Support\MailerAdapter;
use App\Support\SessionAuthGuard;

/**
 * Services (estilo Q_Framework, simple)
 *
 * Atajos:
 *   $db   = service('db');            // Connection (default)
 *   $pdo  = service('pdo');           // PDO (default)
 *   $sess = service('session');       // Session (inicia si se pide)
 *   $enc  = service('encrypter');     // Encrypter (objeto)
 *   $log  = service('logger');        // LoggerInterface (contrato)
 *   $mail = service('mailer');        // MailerInterface (contrato)
 *   $auth = service('auth');          // AuthGuardInterface (contrato)
 *
 * Multi-DB:
 *   $db2 = \Config\Services::db('analytics');
 *   $pdo2= \Config\Services::pdo('analytics');
 */
final class Services
{
  /** @var array<string,mixed> */
  private static array $shared = [];

  /**
   * Service locator simple.
   * - Respeta overrides del Container (Providers::container()) si existen.
   */
  public static function get(string $name)
  {
    $raw = trim($name);
    if ($raw === '') return null;

    // Atajos con sufijo (db:grupo, pdo:grupo, migrator:grupo, seeder:grupo)
    if (str_contains($raw, ':')) {
      [$p, $rest] = explode(':', $raw, 2);
      $p = strtolower(trim($p));
      $rest = trim($rest);
      return match ($p) {
        'db'       => self::db($rest !== '' ? $rest : null),
        'pdo'      => self::pdo($rest !== '' ? $rest : null),
        'migrator' => self::migrator($rest !== '' ? $rest : null),
        'seeder'   => self::seeder($rest !== '' ? $rest : null),
        default    => null,
      };
    }

    // Fuente única: Container (Providers)
    \System\Core\Providers::boot();
    $c = \System\Core\Providers::container();

    $key = strtolower($raw);
    if ($c->has($key)) return $c->get($key);
    if ($c->has($raw)) return $c->get($raw);

    // Fallback compat (por si un servicio fue removido del container)
    $name = strtolower($raw);
    return match ($name) {
      'db'          => self::db(),
      'pdo'         => self::pdo(),
      'session'     => self::session(),
      'encrypter'   => self::encrypter(),
      'logger'      => self::logger(),
      'mailer'      => self::mailer(),
      'auth'        => self::auth(),
      'guard'       => self::auth(),
      'mail'        => self::mail(),
      'request'     => self::request(),
      'response'    => self::response(),
      'cache'       => self::cache(),
      'validator'   => self::validator(),
      'lang'        => self::lang(),
      'migrator'    => self::migrator(),
      'seeder'      => self::seeder(),
      'ratelimiter' => self::ratelimiter(),
      default       => null,
    };
  }

  /**
   * Resetea servicios compartidos (todo o uno específico).
   * Útil para multi-tenant en runtime / CLI.
   */
  public static function reset(?string $name = null): void
  {
    if ($name === null) { self::$shared = []; return; }
    $name = strtolower(trim($name));
    unset(self::$shared[$name]);
  }

  /**
   * Define/inyecta una instancia compartida (compat).
   * Útil para tests o para "seeding" en scripts.
   */
  public static function instance(string $name, $object): void
  {
    $name = strtolower(trim($name));
    self::$shared[$name] = $object;
  }

  /**
   * Limpia servicios request-scoped (cuando se usa KernelContext).
   * No toca DB/Cache globales.
   */
  public static function clearRequestScoped(): void
  {
    unset(self::$shared['request'], self::$shared['response'], self::$shared['session'], self::$shared['validator'], self::$shared['lang']);
    foreach (array_keys(self::$shared) as $k) {
      if (is_string($k) && str_starts_with($k, 'datos:')) unset(self::$shared[$k]);
    }
  }

    /** Connection por defecto */
  public static function db(?string $group = null): Connection
  {
    \System\Core\Providers::boot();
    $c = \System\Core\Providers::container();

    $g = strtolower((string)($group ?: 'default'));
    if ($g === 'default') return $c->get('db');

    $id = 'db:' . $g;
    if ($c->has($id)) return $c->get($id);

    if (!isset(self::$shared[$id])) self::$shared[$id] = DB::connect($group);
    return self::$shared[$id];
  }


    /** PDO (compat) */
  public static function pdo(?string $group = null): PDO
  {
    \System\Core\Providers::boot();
    $c = \System\Core\Providers::container();

    $g = strtolower((string)($group ?: 'default'));
    if ($g === 'default') return $c->get('pdo');

    $id = 'pdo:' . $g;
    if ($c->has($id)) return $c->get($id);

    if (!isset(self::$shared[$id])) self::$shared[$id] = DB::pdo($group);
    return self::$shared[$id];
  }


    /** Inicia sesión (a pedido) */
  public static function session(): Session
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get('session');
  }
  /** No inicia sesión (para helpers/lecturas) */
  public static function sessionOptional(): ?Session
  {
    return Session::isStarted() ? new Session() : null;
  }

    public static function encrypter(): Encrypter
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get(Encrypter::class);
  }


  /** Logger (contrato). Default: App\Support\LoggerAdapter -> System\Core\Logger */
  public static function logger(): LoggerInterface
  {
    // Fuente de verdad: Providers Container (evita instancias duplicadas).
    // Permite reemplazar logger vía app/Providers sin tocar el core.
    \System\Core\Providers::boot();
    try {
      $c = \System\Core\Providers::container();
      if (method_exists($c, 'has') && $c->has(\App\Contracts\LoggerInterface::class)) {
        $inst = $c->get(\App\Contracts\LoggerInterface::class);
        self::$shared['logger'] = $inst;
        return $inst;
      }
    } catch (\Throwable) {
      // ignore (fallback)
    }

    // Fallback: adapter por defecto
    if (!isset(self::$shared['logger'])) self::$shared['logger'] = new LoggerAdapter();
    return self::$shared['logger'];
  }

  /** Mailer (contrato). Default: App\Support\MailerAdapter -> System\Core\Mail::send */
  public static function mailer(): MailerInterface
  {
    // Fuente de verdad: Providers Container (evita instancias duplicadas).
    \System\Core\Providers::boot();
    try {
      $c = \System\Core\Providers::container();
      if (method_exists($c, 'has') && $c->has(\App\Contracts\MailerInterface::class)) {
        $inst = $c->get(\App\Contracts\MailerInterface::class);
        self::$shared['mailer'] = $inst;
        return $inst;
      }
    } catch (\Throwable) {
      // ignore (fallback)
    }

    if (!isset(self::$shared['mailer'])) self::$shared['mailer'] = new MailerAdapter();
    return self::$shared['mailer'];
  }

  /** Auth guard (contrato). Default: SessionAuthGuard (session('user')). */
  public static function auth(): AuthGuardInterface
  {
    // Fuente de verdad: Providers Container (evita instancias duplicadas).
    \System\Core\Providers::boot();
    try {
      $c = \System\Core\Providers::container();
      if (method_exists($c, 'has') && $c->has(\App\Contracts\AuthGuardInterface::class)) {
        $inst = $c->get(\App\Contracts\AuthGuardInterface::class);
        self::$shared['auth'] = $inst;
        return $inst;
      }
    } catch (\Throwable) {
      // ignore (fallback)
    }

    if (!isset(self::$shared['auth'])) self::$shared['auth'] = new SessionAuthGuard();
    return self::$shared['auth'];
  }

  public static function mail(): string
  {
    return Mail::class;
  }

    public static function request(): Request
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get('request');
  }


    public static function response(): Response
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get('response');
  }


  // ==============================
  // Cache / Validation / Lang / Migrations
  // ==============================

    public static function cache(): CacheInterface
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get(CacheInterface::class);
  }
    public static function validator(): Validator
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get(Validator::class);
  }
    public static function lang(): Lang
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get(Lang::class);
  }
    public static function migrator(?string $group = null): Migrator
  {
    \System\Core\Providers::boot();
    $c = \System\Core\Providers::container();

    $g = strtolower((string)($group ?: 'default'));
    if ($g === 'default') return $c->get('migrator');

    $id = 'migrator:' . $g;
    if ($c->has($id)) return $c->get($id);

    if (!isset(self::$shared[$id])) {
      $cfg = config('Migrations');

      // 1) rutas base (relativas a ROOTPATH)
      $rel = [];
      if (is_array($cfg->paths ?? null) && !empty($cfg->paths)) {
        foreach ($cfg->paths as $rp) {
          if (is_string($rp) && trim($rp) !== '') $rel[] = trim($rp);
        }
      }
      if (!$rel) {
        $p1 = is_string($cfg->path ?? null) ? trim((string)$cfg->path) : '';
        if ($p1 !== '') $rel[] = $p1;
      }

      // 2) convertir a absolutas
      $abs = [];
      foreach ($rel as $rp) $abs[] = base_path($rp);

      // 3) incluir migrations de módulos (si aplica)
      if (!empty($cfg->includeModules)) {
        foreach (\System\Core\Modules::migrationPaths() as $mp) $abs[] = $mp;
      }

      $abs = array_values(array_unique(array_filter($abs, fn($v) => is_string($v) && $v !== '')));
      self::$shared[$id] = new Migrator(self::db($group), $abs);
    }

    return self::$shared[$id];
  }

  /** v9: SeederRunner */

    public static function seeder(?string $group = null): \System\Database\Seeds\SeederRunner
  {
    \System\Core\Providers::boot();
    $c = \System\Core\Providers::container();

    $g = strtolower((string)($group ?: 'default'));
    if ($g === 'default') return $c->get('seeder');

    $id = 'seeder:' . $g;
    if ($c->has($id)) return $c->get($id);

    if (!isset(self::$shared[$id])) self::$shared[$id] = new \System\Database\Seeds\SeederRunner($group ?: 'default');
    return self::$shared[$id];
  }
  /**
   * Factory: Datos (tu controlador utilitario de consultas)
   * Uso:
   *   $Datos = \Config\Services::datos();            // default DB
   *   $Datos = \Config\Services::datos('analytics'); // otro grupo
   */
  public static function datos(?string $group = null): Datos
  {
    $ctx = \System\Core\KernelContext::current();
    if ($ctx) {
      $g = strtolower((string)($group ?: 'default'));
      return $ctx->scopedGetOrSet('datos:' . $g, function () use ($group) {
        return new Datos(self::db($group), self::request(), self::encrypter());
      });
    }

    $key = 'datos:' . strtolower((string)($group ?: 'default'));
    if (!isset(self::$shared[$key])) {
      self::$shared[$key] = new Datos(self::db($group), self::request(), self::encrypter());
    }
    return self::$shared[$key];
  }

  /** RateLimiter (seguridad: login, APIs, etc.) */
    public static function ratelimiter(): RateLimiter
  {
    \System\Core\Providers::boot();
    return \System\Core\Providers::container()->get('ratelimiter');
  }
}
