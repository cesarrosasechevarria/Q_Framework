<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

/**
 * Routing
 * - AUTO_ROUTE: si está activo y no hay ruta declarada, intenta resolver:
 *     /Controller/method/param1/param2
 *   Ej:
 *     /home        -> App\Controllers\Home@index
 *     /users/show/5-> App\Controllers\Users@show('5')
 *
 * Recomendación: úsalo SOLO en desarrollo.
 */
final class Routing extends BaseConfig
{
  public bool $autoRoute = false;

  /** Namespace base para controllers */
  public string $controllerNamespace = 'App\\Controllers\\';

  /** Método por defecto si no se especifica */
  public string $defaultMethod = 'index';

  /**
   * Si es false, el Router hará match case-insensitive:
   * - '/Ejemplo' matchea '/ejemplo'
   * - también aplica a rutas con {params}
   */
  public bool $caseSensitivePaths = true;

  public function __construct()
  {
    $this->autoRoute = env_bool('AUTO_ROUTE', $this->autoRoute);
    $this->caseSensitivePaths = env_bool('ROUTE_CASE_SENSITIVE', $this->caseSensitivePaths);
  }
}
