<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

final class Encryption extends BaseConfig
{
  /** aes-256-gcm recomendado */
  public string $cipher = 'aes-256-gcm';

  /** key en base64 o texto (QFW lo normaliza internamente). */
  public string $key = '';

  public function __construct()
  {
    $this->cipher = (string) env('ENC_CIPHER', $this->cipher);
    $this->key = (string) env('APP_KEY', env('ENC_KEY', $this->key));
  }
}
