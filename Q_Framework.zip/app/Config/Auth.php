<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

/**
 * Configuración del módulo Auth (PRO)
 */
final class Auth extends BaseConfig
{
  /**
   * Habilita el registro público.
   * - En producción suele desactivarse.
   * - Override por .env: AUTH_REGISTRATION=1|0
   */
  public bool $registrationEnabled = true;

  /** Rol por defecto para nuevos registros. Override por .env: AUTH_DEFAULT_ROLE=user */
  public string $defaultRole = 'user';

  public function __construct()
  {
    // Si no se define, en producción se recomienda apagar por defecto.
    $env = (string) env('APP_ENV', 'development');
    $default = ($env !== 'production');
    $this->registrationEnabled = env_bool('AUTH_REGISTRATION', $default);
    $this->defaultRole = (string) env('AUTH_DEFAULT_ROLE', $this->defaultRole);
  }
}
