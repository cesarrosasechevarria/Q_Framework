<?php
declare(strict_types=1);

namespace Config;

use System\Config\BaseConfig;

/**
 * Providers
 *
 * Lista de Service Providers que se cargarán en bootstrap.
 * Puedes registrar aquí tus providers (App\Providers\...).
 */
final class Providers extends BaseConfig
{
  /** @var list<class-string<\System\Core\ProviderInterface>> */
  public array $providers = [
    \App\Providers\InfraServiceProvider::class,
    \App\Providers\AppServiceProvider::class,
  ];
}
