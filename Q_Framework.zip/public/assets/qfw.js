/* Q_Framework Theme Switcher
   - Auto: no data-theme (uses prefers-color-scheme)
   - Manual: html[data-theme="light|dark"]
*/
(function(){
  const KEY = 'qfw-theme'; // system|light|dark
  const root = document.documentElement;

  function apply(mode){
    if (!mode || mode === 'system'){
      root.removeAttribute('data-theme');
      return;
    }
    root.setAttribute('data-theme', mode);
  }

  function current(){
    return localStorage.getItem(KEY) || 'system';
  }

  function next(mode){
    // cycle: system -> dark -> light -> system
    if (mode === 'system') return 'dark';
    if (mode === 'dark') return 'light';
    return 'system';
  }

  function icon(mode){
    if (mode === 'dark') return '🌙';
    if (mode === 'light') return '☀️';
    return '🌓';
  }

  function label(mode){
    if (mode === 'dark') return 'Oscuro';
    if (mode === 'light') return 'Claro';
    return 'Auto';
  }

  function syncBtn(btn, mode){
    btn.innerHTML = icon(mode);
    btn.title = 'Tema: ' + label(mode) + ' (click para cambiar)';
    btn.setAttribute('aria-label', 'Tema: ' + label(mode));
    btn.dataset.theme = mode;
  }

  // Apply saved ASAP
  apply(current());

  function init(){
    document.querySelectorAll('[data-qfw-theme-toggle]').forEach(btn=>{
      syncBtn(btn, current());
      btn.addEventListener('click', ()=>{
        const m = next(current());
        localStorage.setItem(KEY, m);
        apply(m);
        document.querySelectorAll('[data-qfw-theme-toggle]').forEach(b=>syncBtn(b, m));
      });
    });
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
