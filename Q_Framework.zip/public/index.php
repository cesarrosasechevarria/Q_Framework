<?php

// Opcional: si NO deseas usar Composer (vendor/autoload.php), activa el modo manual:
// define('QFW_USE_VENDOR_AUTOLOAD', false);

declare(strict_types=1);

// Captura cualquier salida temprana (incluyendo errores fatales mostrados por PHP)
// para que el manejador de errores del framework pueda renderizar su vista sin “salirse”.
if (!ob_get_level()) {
  ob_start();
}

/**
 * Q_Framework Front Controller (PRO)
 * - Preflight: requisitos mínimos + permisos
 * - Autoload: Composer si existe; si no, fallback autoload propio
 * - Installer Wizard: /install (opcional)
 */

define('QFW_START', microtime(true));

$root = dirname(__DIR__);

// Compat compatible constants (con slash final)
if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);
if (!defined('ROOTPATH'))  define('ROOTPATH', rtrim($root, '/\\') . DS);
if (!defined('APPPATH'))   define('APPPATH', ROOTPATH . 'app' . DS);
if (!defined('SYSTEMPATH'))define('SYSTEMPATH', ROOTPATH . 'system' . DS);
// Carpeta de escritura del framework (logs/cache/sessions/locks)
if (!defined('WRITEPATH')) define('WRITEPATH', ROOTPATH . 'write' . DS);
if (!defined('PUBLICPATH'))define('PUBLICPATH', ROOTPATH . 'public' . DS);
// Front Controller path (public/)
if (!defined('FCPATH'))    define('FCPATH', PUBLICPATH);

// ====== Preflight ultra temprano (sin framework) ======
$errors = [];

if (PHP_VERSION_ID < 80100) {
  $errors[] = "PHP 8.1+ requerido. Tu versión: " . PHP_VERSION;
}

$requiredExt = ['openssl','json','pdo'];
foreach ($requiredExt as $ext) {
  if (!extension_loaded($ext)) $errors[] = "Extensión requerida faltante: {$ext}";
}

$dirs = [
  $root . '/write/logs',
  $root . '/write/sessions',
  $root . '/write/cache',
];

foreach ($dirs as $d) {
  if (!is_dir($d)) @mkdir($d, 0775, true);
  if (!is_dir($d)) $errors[] = "No se pudo crear el directorio: {$d}";
  elseif (!is_writable($d)) $errors[] = "El directorio no es escribible: {$d}";
}

if (!is_file($root . '/bootstrap.php')) {
  $errors[] = "No se encuentra bootstrap.php en la raíz del proyecto.";
}

if (!empty($errors)) {
  http_response_code(500);
  header('Content-Type: text/html; charset=UTF-8');

  echo "<h1>Q_Framework - Preflight falló</h1>";
  echo "<p>Corrige estos requisitos y vuelve a cargar:</p><ul>";
  foreach ($errors as $e) echo "<li><code>" . htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . "</code></li>";
  echo "</ul>";

  echo "<h3>Tips rápidos (XAMPP/Windows)</h3>";
  echo "<ol>";
  echo "<li>Asegúrate de usar PHP 8.1+ (XAMPP actualizado).</li>";
  echo "<li>Verifica extensiones en <code>php.ini</code>: openssl, pdo, json.</li>";
  echo "<li>Da permisos de escritura a <code>write/</code> o ejecuta Apache con permisos adecuados.</li>";
  echo "</ol>";
  exit;
}

// ====== Autoload ======
require $root . '/autoload.php';

// ====== Bootstrap & Env ======
require $root . '/bootstrap.php';

// ====== Installer Wizard (si no hay lock) ======
$instCfg = config('Installer');
$lock = $root . '/' . ltrim((string)($instCfg->lockFile ?? 'write/install.lock'), '/\\');

$uri = $_SERVER['REQUEST_URI'] ?? '/';
$path = parse_url($uri, PHP_URL_PATH) ?: '/';

if (!is_file($lock) && !empty($instCfg->wizardEnabled)) {
  // Permitir health check sin instalar
  if (stripos($path, '_health.php') === false && stripos($path, '/install') === false) {
    header('Location: ' . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/') . '/install');
    exit;
  }
}

// ====== Run ======
$app = new System\Core\App();
$app->run();
