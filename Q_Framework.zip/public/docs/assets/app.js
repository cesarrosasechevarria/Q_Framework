(function(){
  function slugify(s){
    return (s||'')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/[^a-z0-9\s\-]/g,'')
      .trim().replace(/\s+/g,'-').replace(/-+/g,'-');
  }
  function uniqueId(base, used){
    var id = base || 'sec';
    var i = 2;
    while(used[id]){ id = base + '-' + (i++); }
    used[id]=true;
    return id;
  }
  function isInsideNoToc(el){
    while(el){
      if(el.dataset && el.dataset.noToc==="1") return true;
      el = el.parentElement;
    }
    return false;
  }

  // Active link
  var docPath = location.pathname;
  var path = (function(){
    var m = docPath.match(/\/docs\/(.+)$/);
    if(m && m[1]) return m[1];
    if(docPath.endsWith('/')) return 'index.html';
    return docPath.split('/').pop();
  })();
  document.querySelectorAll('.nav a').forEach(function(a){
    if(a.getAttribute('href')===path){a.classList.add('active');}
  });

  // TOC (En esta página)
  var toc = document.getElementById('toc');
  var main = document.querySelector('.doc');
  if(toc && main){
    var used = {};
    var hs = main.querySelectorAll('h2, h3');
    var wrap = document.createElement('div');
    var count = 0;
    hs.forEach(function(h){
      if(isInsideNoToc(h)) return;
      var base = slugify(h.textContent);
      if(!h.id){ h.id = uniqueId(base, used); } else { used[h.id]=true; }
      var a = document.createElement('a');
      var id = h.id;
      a.href = docPath + '#'+id;
      a.addEventListener('click', function(e){
        var el = document.getElementById(id);
        if(!el) return;
        e.preventDefault();
        el.scrollIntoView({behavior:'smooth', block:'start'});
        try{ history.replaceState(null, '', docPath + '#'+id); }catch(err){ location.hash = '#'+id; }
      });
      a.textContent = h.textContent;
      a.className = (h.tagName==='H3') ? 'toc__h3' : 'toc__h2';
      wrap.appendChild(a);
      count++;
    });
    if(count){ toc.appendChild(wrap); } else { toc.remove(); }
  }

  
  // Fix in-page anchors when <base href> is used
  document.querySelectorAll('.doc a[href^="#"]').forEach(function(a){
    var href = a.getAttribute('href');
    if(href && href.startsWith('#')){
      a.setAttribute('href', docPath + href);
    }
  });

  // Global Search (Ctrl/Cmd+K) + "/" shortcut
  var CMDK_ID = 'q_cmdk';
  var palette = document.getElementById(CMDK_ID);
  if(!palette){
    palette = document.createElement('div');
    palette.id = CMDK_ID;
    palette.className = 'cmdk hidden';
    palette.innerHTML = `
      <div class="cmdk__backdrop" data-cmdk-close="1"></div>
      <div class="cmdk__panel" role="dialog" aria-modal="true" aria-label="Buscar en el manual">
        <div class="cmdk__bar">
          <span class="cmdk__icon">⌕</span>
          <input class="cmdk__input" placeholder="Buscar servicios, funciones, ejemplos… (Ctrl+K)" />
          <kbd class="cmdk__kbd">Esc</kbd>
        </div>
        <div class="cmdk__hint">Tip: escribe “schema ensure”, “crud paginate”, “csrf api”, “uploads webp”.</div>
        <div class="cmdk__results"></div>
      </div>
    `;
    document.body.appendChild(palette);
  }

  var input = palette.querySelector('.cmdk__input');
  var resultsEl = palette.querySelector('.cmdk__results');
  var data = null;
  var loaded = false;
  var active = 0;
  var lastItems = [];

  function esc(s){ return (s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function highlight(text, tokens){
    var out = esc(text||'');
    tokens.forEach(function(t){
      if(!t) return;
      var re = new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'ig');
      out = out.replace(re, function(m){ return '<mark>'+m+'</mark>'; });
    });
    return out;
  }

  function scoreItem(it, tokens){
    var title = (it.title||'').toLowerCase();
    var text  = (it.text||it.snippet||'').toLowerCase();
    var score = 0;
    tokens.forEach(function(t){
      var tt = (t||'').toLowerCase();
      if(!tt) return;
      if(title.includes(tt)) score += 12;
      if(text.includes(tt))  score += 3;
      if(tt.length >= 6 && title.indexOf(tt)===0) score += 6;
    });
    return score;
  }

  function render(items, tokens){
    lastItems = items;
    active = 0;
    resultsEl.innerHTML = '';
    if(!items.length){
      resultsEl.innerHTML = `<div class="cmdk__empty">Sin resultados. Prueba con: <code>db transaction</code>, <code>schema base_columns</code>, <code>crud soft delete</code>.</div>`;
      return;
    }
    var list = document.createElement('div');
    list.className = 'cmdk__list';
    items.slice(0,14).forEach(function(it, i){
      var row = document.createElement('a');
      row.className = 'cmdk__item' + (i===0 ? ' active' : '');
      row.href = it.path;
      row.dataset.idx = String(i);
      row.innerHTML = `
        <div class="cmdk__meta">
          <span class="cmdk__badge">${esc((it.section||'docs').toUpperCase())}</span>
          <span class="cmdk__path">${esc(it.path)}</span>
        </div>
        <div class="cmdk__title">${highlight(it.title||'', tokens)}</div>
        <div class="cmdk__snippet">${highlight(it.snippet||'', tokens)}</div>
      `;
      list.appendChild(row);
    });
    resultsEl.appendChild(list);
  }

  function doSearch(q){
    q = (q||'').trim();
    var tokens = q.toLowerCase().split(/\s+/).filter(Boolean);
    if(!tokens.length){ render([], tokens); return; }
    var section = null;
    // soporte "section:services crud"
    if(tokens[0].startsWith('section:')){
      section = tokens.shift().slice(8);
    }
    var scored = data
      .filter(function(it){
        if(section && (it.section||'').toLowerCase() !== section) return false;
        return true;
      })
      .map(function(it){
        return {it:it, s:scoreItem(it, tokens)};
      })
      .filter(function(x){ return x.s>0; })
      .sort(function(a,b){ return b.s-a.s; })
      .slice(0,40)
      .map(function(x){ return x.it; });
    render(scored, tokens);
  }

  function openCmdk(){
    palette.classList.remove('hidden');
    document.body.classList.add('modal-open');
    input.value = '';
    input.focus();
    if(!loaded){
      loaded = true;
      fetch('assets/search-index.json')
        .then(function(r){ return r.json(); })
        .then(function(j){ data = j || []; })
        .catch(function(){ data = []; })
        .finally(function(){ doSearch(''); });
    } else {
      doSearch('');
    }
  }
  function closeCmdk(){
    palette.classList.add('hidden');
    document.body.classList.remove('modal-open');
  }

  palette.addEventListener('click', function(e){
    if(e.target && e.target.dataset && e.target.dataset.cmdkClose==="1"){ closeCmdk(); }
  });

  input.addEventListener('input', function(){ if(data) doSearch(input.value); });

  // keyboard nav
  palette.addEventListener('keydown', function(e){
    if(e.key==='Escape'){ e.preventDefault(); closeCmdk(); return; }
    var items = palette.querySelectorAll('.cmdk__item');
    if(!items.length) return;
    if(e.key==='ArrowDown'){
      e.preventDefault();
      active = Math.min(active+1, items.length-1);
    } else if(e.key==='ArrowUp'){
      e.preventDefault();
      active = Math.max(active-1, 0);
    } else if(e.key==='Enter'){
      e.preventDefault();
      items[active].click();
      return;
    } else {
      return;
    }
    items.forEach(function(a,i){ a.classList.toggle('active', i===active); });
    items[active].scrollIntoView({block:'nearest'});
  });

  document.addEventListener('keydown', function(e){
    var t = e.target;
    var isTyping = t && (t.tagName==='INPUT' || t.tagName==='TEXTAREA' || t.isContentEditable);
    var cmdk = (e.ctrlKey || e.metaKey) && (e.key==='k' || e.key==='K');
    if(cmdk){
      e.preventDefault();
      openCmdk();
      return;
    }
    if(!isTyping && e.key==='/'){
      e.preventDefault();
      openCmdk();
      return;
    }
  });

  // Optional button hook (if present in header)
  document.querySelectorAll('[data-open-cmdk]').forEach(function(btn){
    btn.addEventListener('click', function(e){ e.preventDefault(); openCmdk(); });
  });

})();
