
(async function(){
  const input = document.getElementById('q');
  const results = document.getElementById('results');
  const sectionFilter = document.getElementById('sectionFilter');

  const data = await fetch('assets/search-index.json').then(r=>r.json()).catch(()=>[]);

  const sections = Array.from(new Set(data.map(x => (x.section||'Docs').trim()).filter(Boolean))).sort();
  if (sectionFilter) {
    sections.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s;
      opt.textContent = s;
      sectionFilter.appendChild(opt);
    });
  }

  function esc(s){ return (s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  function highlight(text, tokens){
    let out = esc(text||'');
    tokens.forEach(t=>{
      if(!t) return;
      const re = new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'), 'ig');
      out = out.replace(re, m => `<mark>${m}</mark>`);
    });
    return out;
  }

  function render(items, tokens){
    results.innerHTML = '';
    if(!items.length){
      results.innerHTML = '<p class="kicker">Sin resultados.</p>';
      return;
    }
    items.slice(0,60).forEach(it=>{
      const d = document.createElement('div');
      d.className='card';
      d.style.marginBottom='10px';

      const title = highlight(it.title||'', tokens);
      const snip  = highlight(it.snippet||'', tokens);

      d.innerHTML = `
        <div class="row" style="display:flex;justify-content:space-between;gap:10px;align-items:center;">
          <div class="badge">${esc(it.section||'Docs')}</div>
          <div class="kicker" style="opacity:.8">${esc(it.path||'')}</div>
        </div>
        <h3 style="margin:8px 0 6px"><a href="${esc(it.path)}">${title}</a></h3>
        <p class="kicker">${snip}</p>
      `;
      results.appendChild(d);
    });
  }

  function scoreItem(it, tokens){
    const title = (it.title||'').toLowerCase();
    const text  = (it.text||'').toLowerCase();
    let score = 0;
    tokens.forEach(t=>{
      const tt = t.toLowerCase();
      if(!tt) return;
      if(title.includes(tt)) score += 5;
      if(text.includes(tt)) score += 1;
      if(tt.includes('(') || tt.includes('\\\\') || tt.includes('@') || tt.includes('_')) score += 1;
    });
    return score;
  }

  function search(q){
    q = (q||'').trim();
    const tokens = q.toLowerCase().split(/\s+/).filter(Boolean);
    const sec = sectionFilter ? (sectionFilter.value||'') : '';

    if(!tokens.length){ render([], tokens); return; }

    const scored = data
      .filter(it => !sec || (it.section||'Docs') === sec)
      .map(it => ({it, score: scoreItem(it, tokens)}))
      .filter(x => x.score > 0)
      .sort((a,b)=>b.score-a.score)
      .map(x=>x.it);

    render(scored, tokens);
  }

  input.addEventListener('input', ()=>search(input.value));
  if (sectionFilter) sectionFilter.addEventListener('change', ()=>search(input.value));

  const urlQ = new URLSearchParams(location.search).get('q');
  if(urlQ){ input.value = urlQ; search(urlQ); }
})();
