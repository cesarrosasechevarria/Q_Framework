<?php
declare(strict_types=1);

$root = dirname(__DIR__);

header('Content-Type: text/html; charset=UTF-8');

$uri = $_SERVER['REQUEST_URI'] ?? '';
$script = $_SERVER['SCRIPT_NAME'] ?? '';
$path = parse_url($uri, PHP_URL_PATH) ?: '/';
$baseDir = str_replace('\\', '/', dirname((string)$script));
$baseDir = rtrim($baseDir, '/');
if ($baseDir === '.' || $baseDir === '/') $baseDir = '';

echo "<h1>Q_Framework - Health Check</h1>";

echo "<h3>Request</h3>";
echo "<ul>";
echo "<li>REQUEST_URI: <code>".htmlspecialchars($uri, ENT_QUOTES,'UTF-8')."</code></li>";
echo "<li>PATH_INFO(parse_url): <code>".htmlspecialchars((string)$path, ENT_QUOTES,'UTF-8')."</code></li>";
echo "<li>SCRIPT_NAME: <code>".htmlspecialchars((string)$script, ENT_QUOTES,'UTF-8')."</code></li>";
echo "<li>BaseDir detectado: <code>".htmlspecialchars((string)$baseDir, ENT_QUOTES,'UTF-8')."</code></li>";
echo "</ul>";

echo "<h3>Paths</h3>";
echo "<ul>";
echo "<li>Root: <code>".htmlspecialchars($root, ENT_QUOTES,'UTF-8')."</code></li>";
echo "<li>Public: <code>".htmlspecialchars(__DIR__, ENT_QUOTES,'UTF-8')."</code></li>";
echo "<li>Composer autoload: <code>".htmlspecialchars($root.'/vendor/autoload.php', ENT_QUOTES,'UTF-8')."</code> ";
echo is_file($root.'/vendor/autoload.php') ? "✅" : "❌";
echo "</li>";
echo "</ul>";

echo "<h3>PHP</h3>";
echo "<ul>";
echo "<li>Version: <code>".htmlspecialchars(PHP_VERSION, ENT_QUOTES,'UTF-8')."</code></li>";
echo "<li>SAPI: <code>".htmlspecialchars(PHP_SAPI, ENT_QUOTES,'UTF-8')."</code></li>";
echo "</ul>";

$exts = ['openssl','json','pdo','pdo_mysql','mbstring','intl'];
echo "<h3>Extensiones</h3><ul>";
foreach ($exts as $e) {
  echo "<li><code>{$e}</code> : " . (extension_loaded($e) ? "✅" : "❌") . "</li>";
}
echo "</ul>";

$dirs = [$root.'/write/logs',$root.'/write/sessions',$root.'/write/cache'];
echo "<h3>Permisos write/</h3><ul>";
foreach ($dirs as $d) {
  echo "<li><code>".htmlspecialchars($d, ENT_QUOTES,'UTF-8')."</code> : ";
  echo is_dir($d) ? "dir ✅" : "dir ❌";
  echo " | writable: " . (is_writable($d) ? "✅" : "❌");
  echo "</li>";
}
echo "</ul>";

echo "<h3>Recomendación</h3>";
echo "<p>Si quieres usar Composer, abre CMD en la raíz y ejecuta:</p>";
echo "<pre>composer install
composer dump-autoload -o</pre>";
echo "<p>Para ver este diagnóstico: <code>/_health.php</code></p>";
