# Changelog

## 1.1.7 (2026-01-27)

- Router/AutoRoute: soporte de **controllerAliases** en scoped auto routes:
  - Ej: `['inicio'=>'Home']` permite `/funciones/inicio/login` => `Home@login` sin crear `Inicio.php`.
- Router/AutoRoute: modo opcional **methodFirst** (`/funciones/login` => `Home@login` si existe).
- Views/Layout (CI4-style): `defaultLayout` vacío por defecto; reactivable con `DEFAULT_LAYOUT=layout`.
- Starter: controllers del starter piden layout explícitamente para mantener UI.


## 1.1.4 (2026-01-27)

- Router: parámetros tipados en rutas: <code>{id:int}</code>, <code>{valor:num}</code>, <code>{slug:slug}</code>, <code>{path:*}</code> (wildcard) + casting básico.
- Routes: <code>route_url()</code> ahora reemplaza placeholders tipados (<code>{id:int}</code>) además de los simples.
- Routing: nuevo <b>AutoRoute por prefijo</b> (scoped) con <code>$routes->auto('/prefijo', 'Namespace', ['filters'=>[...]])</code> para habilitar AutoRoute por partes y forzar CSRF/Auth.
- CLI: <code>route:list</code> ignora keys internas (<code>_names</code>, <code>_auto</code>).
- Docs: manual actualizado (Router + Config/App) y buscador regenerado.

## 1.1.3 (2026-01-26)

- Docs: Cada servicio ahora incluye una sección "Mapa del servicio" con acceso, características, configuración y funciones principales.
- Docs: Búsqueda actualizada para incluir los mapas por servicio.

## 1.0.9 - Docs: Paginación (URLs y comportamiento)
- Docs: Paginación: sección nueva “Cómo aparece en la URL” (pageParam, omitFirstPage, preservación de filtros, múltiples listas, out-of-range, baseUrl).
- Docs: Versionado de documentación actualizado a 1.0.9.


## 1.0.8 - Docs PRO (QueryBuilder avanzado + UI/estilos)
- DB/QueryBuilder: nuevos helpers `exists()`, `doesntExist()`, `value()`.
- DB/QueryBuilder: `whereIn()` y `like()` ahora validan/escapan columnas cuando `strictIdentifiers` está activo.
- Docs: QueryBuilder ampliado con casos reales (duplicidad, consultas vacías, order seguro, `EXISTS`, `whereIn` con lista vacía, reporte + paginate).
- Docs: Paginación ampliada (theme por variables CSS, integración con UI propia vía `linksArray()`).
- Docs: nueva guía **UI y estilos** (qfw.css/qfw.js, overrides sin tocar core).

## 1.0.7 - QueryBuilder PRO + Paginación (docs + fixes)
- DB/QueryBuilder: `countAllResults()` ahora cuenta correctamente con `GROUP BY/HAVING` y `DISTINCT` (usa subquery cuando corresponde).
- DB/QueryBuilder: nuevo `insertBatch()` (INSERT multi-fila).
- DB/Pager: aliases para API/compat (`page()`, `total()`, `pages()`, `next()`, `prev()`, `links()`).
- Docs: QueryBuilder ampliado (combinaciones AND/OR, RAW seguro, escrituras, conteo).
- Docs: nueva página **Paginación** (cómo usar `paginate()+pager()`, cómo cambiar template, clases y CSS).
- Docs: sidebar actualizado para incluir Paginación + search-index regenerado.

## 1.0.6 - Docs: Tipos de sistemas + lenguaje neutral
- Docs: guía nueva "Tipos de sistemas" (qué construir + qué necesitas + pasos recomendados por caso).
- Docs: "Capacidades" reescrita como "Capacidades y casos de uso" (sin lenguaje de “venta”; enfoque para cualquier equipo).
- Docs: sidebar de Guía unificada y enlaces corregidos (incluye la nueva página).
- Docs: search-index regenerado.

## 1.0.5 - Docs: Capacidades (primera versión)
- Docs: primera sección de capacidades del framework y checklist de uso en producción (previa).

## 1.0.4 - Infra PRO (Redis/DB/Observabilidad) + ajustes de CLI
- Infra: Provider y configuración por .env para Redis/observabilidad (opcional).
- CLI: mejoras de comandos y diagnóstico.

## 1.0.5 · 2026-01-26

- Docs: nuevo apartado **“Capacidades y roadmap comercial”** (qué incluye, qué se hace como módulos, checklist para venderlo).
- Docs: navegación y buscador actualizados (search-index regenerado).
- Versionado: actualizado banner de documentación y VERSION.txt.

## 1.0.3 - Servicios: Container como fuente única (completo)
- Core: Providers ahora define bindings por defecto SIN llamar a \Config\Services (evita recursión y consolida la “verdad” en el Container).
- Config\Services: db/pdo/cache/request/response/session/validator/lang/ratelimiter/migrator/seeder ahora delegan al Container (no solo logger/mailer/auth).
- service('db:grupo') / service('pdo:grupo') / service('migrator:grupo') / service('seeder:grupo'): atajos con sufijo para grupos.
- Cache/RateLimiter: instancias tenant-aware (cache:{tenant} / ratelimiter:{tenant}) para aislar prefijos/quotas por tenant.
- Docs: manual actualizado a v1.0.3 + aclaración de “fuente única” y ejemplos de override; search-index regenerado.

## 1.0.2 - Contracts: fuente única de servicios (Container/Services)
- Fix: evita instancias duplicadas de logger/mailer/auth: \Config\Services::{
  logger|mailer|auth
}() ahora delegan al Providers::container().
- Docs: aclarado en manual (Container, Services, Mail, Auth) que service('...') y Config\Services::* retornan el mismo singleton.
- Docs: header de versión unificado (Versión 1.0.2 · Actualizado 2026-01-26).

## 1.0.1 - Docs + Redis PairCode + Contratos mínimos (App)
- Cache: guía Redis + patrón "código → payload" con TTL (PairCode).
- CacheInterface: añadido has().
- App: contratos mínimos LoggerInterface/MailerInterface/AuthGuardInterface + adapters por defecto.
- Docs: CLI/bin/console y mapa de servicios ampliados.

## 1.0.0 - Core Patch (KernelContext + Scoped Services)
- KernelContext: contexto por request (stack) para procesos persistentes (RoadRunner/Swoole/workers/CLI loops).
- Services: request/response/session/validator/lang/datos ahora son request-scoped cuando KernelContext está activo (evita fugas entre requests).
- App: run() envuelto en begin/end con finally (limpieza garantizada aun con returns/excepciones).
- Uri: validación permittedURIChars ahora lanza HttpException (sin exit/echo).
- App: soporte configurable para salida directa en controllers (echo/print) vía App::$controllerOutputMode (default: append_html).
- Response: sanitización anti-CRLF en headers y manejo seguro de errores de json_encode().
- Config/Services/DB: reset de cachés para multi-tenant/CLI (config_clear_cache(), Services::reset(), DB::reset()), integrado en Tenant::switch().

## 1.0.0 - Core Locked
- Core estable (Router, App, Response, Errors, Crypt).
- Debug tools habilitados solo en entornos no-production.
- CLI tools: doctor, lint, route:list, route:cache, route:clear.
- Helpers system: validadores / files con vendor loader opcional y fallbacks.
- Route cache por entorno: storage/cache/routes.<env>.php
- Smoke test script agregado en tests/smoke.php
- Cache: soporte Redis opcional + utilitario PairCode (token → payload con TTL).
- CacheInterface: añade has() para consistencia con el manual y ejemplos.
- Docs: CLI ampliada (bin/console + qfw/qfw.bat) y referencia completa de comandos.
- CLI: help() actualizado para listar make:migration/make:module/migrate:status.

## 1.1.2
- Docs (Models): agregado uso de tabla dinámica con <code>App\Models\Tabla</code> (setTabla/setId/setDatabase), seguridad con allowlist, duplicidad y paginación (qué se espera).
- Docs (Datos): agregado patrón “tabla dinámica + allowlist” para endpoints/servicios genéricos, con paginación y filtros.
- Docs (Services API): nota y ejemplo enlazado a Models para tabla dinámica.
- Docs: search-index regenerado y versión del manual actualizada.

## 1.1.1
- Restaurado manual completo de QueryBuilder (combinaciones complejas).
- Re-ampliados manuales de Services para mantener el mismo nivel de detalle (Cache, Session, DB, Transactions, Validator, Mail, Encrypter, Lang, RateLimiter, Services map).