<?php
return array (
  'exp' => 1770383788,
  'val' => '[{"nombre":"nombre","type":"VARCHAR","max_length":120,"nullable":false},{"nombre":"email","type":"VARCHAR","max_length":120,"nullable":false},{"nombre":"meta","type":"JSON","nullable":true}]',
);
