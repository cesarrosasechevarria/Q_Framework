<?php
declare(strict_types=1);

/**
 * Q_Framework Smoke Test v1.0.0
 * Ejecuta pruebas rápidas del core sin depender de phpunit.
 *
 * Uso:
 *   php tests/smoke.php
 */

echo "Q_Framework Smoke Test v1.0.0\n";

require dirname(__DIR__) . '/bootstrap.php';
// Si no hay APP_KEY, usar una temporal solo para el smoke test
if (empty($_ENV['APP_KEY']) && empty($_ENV['ENC_KEY'])) {
  $tmp = random_bytes(32);
  $_ENV['APP_KEY'] = 'base64:' . base64_encode($tmp);
}


// 1) Helpers
helper(['validadores', 'files']);
if (!function_exists('Validador_email')) { echo "FAIL: helper validadores no cargó\n"; exit(1); }
if (!function_exists('qfw_vendor_try_autoload')) { echo "FAIL: vendor utils no disponibles\n"; exit(1); }
echo "OK: Helpers\n";

// 2) Crypt / Encrypter (requiere APP_KEY o ENC_KEY en .env)
try {
  $enc = \Config\Services::encrypter();
  $plain = 'test-' . date('c');
  $token = $enc->encrypt($plain);
  $back  = $enc->decrypt($token);
  if ($back !== $plain) { echo "FAIL: Crypt mismatch\n"; exit(1); }
  echo "OK: Crypt\n";
} catch (Throwable $e) {
  echo "WARN: Crypt no pudo probarse (APP_KEY faltante?) -> " . $e->getMessage() . "\n";
}

// 3) Router compile (solo carga config)
try {
  $routes = new \System\Core\RouteCollection();
  $fn = require base_path('app/Config/Routes.php');
  if (is_callable($fn)) $fn($routes);
  $compiled = $routes->compile();
  if (!is_array($compiled) || empty($compiled)) {
    echo "WARN: Rutas compiladas vacías\n";
  } else {
    echo "OK: Router compile (" . count($compiled) . ")\n";
  }
} catch (Throwable $e) {
  echo "FAIL: Router compile -> " . $e->getMessage() . "\n";
  exit(1);
}

echo "SMOKE TEST FINISHED\n";
