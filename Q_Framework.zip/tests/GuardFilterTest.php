<?php
declare(strict_types=1);

use System\Core\Request;
use System\Core\Response;
use System\Filters\GuardFilter;
use System\Testing\TestCase;

final class GuardFilterTest extends TestCase
{
  private function getPrivate(object $obj, string $prop)
  {
    $ref = new ReflectionClass($obj);
    $p = $ref->getProperty($prop);
    $p->setAccessible(true);
    return $p->getValue($obj);
  }

  public function testGuardRedirectsWhenSessionMissing(): void
  {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI'] = '/admin';
    $_SERVER['HTTP_ACCEPT'] = 'text/html';

    // Asegura sesión limpia
    $_SESSION = [];

    $req = new Request();
    $res = new Response();

    $f = new GuardFilter();
    $f->setArgs([
      'require' => 'user',
      'redirect' => '/auth/login',
      'remember' => true,
      'status' => 302,
    ]);

    $out = $f->before($req, $res);
    $this->assertTrue($out instanceof Response, 'debe retornar Response');

    $status = $this->getPrivate($out, 'status');
    $this->assertEquals(302, $status, 'status debe ser 302');

    $headers = $this->getPrivate($out, 'headers');
    $this->assertTrue(isset($headers['Location']), 'Location debe estar seteado');
    $this->assertEquals('/auth/login', $headers['Location'], 'Location incorrecto');
  }

  public function testGuardReturnsJsonWhenWantsJson(): void
  {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI'] = '/api/secure';
    $_SERVER['HTTP_ACCEPT'] = 'application/json';

    $_SESSION = [];

    $req = new Request();
    $res = new Response();

    $f = new GuardFilter();
    $f->setArgs([
      'require' => 'user',
      'status' => 401,
      'message' => 'No autorizado',
    ]);

    $out = $f->before($req, $res);
    $this->assertTrue($out instanceof Response, 'debe retornar Response');

    $status = $this->getPrivate($out, 'status');
    $this->assertEquals(401, $status, 'status debe ser 401');

    $headers = $this->getPrivate($out, 'headers');
    $this->assertTrue(str_contains(($headers['Content-Type'] ?? ''), 'application/json'), 'debe ser JSON');

    $body = $this->getPrivate($out, 'body');
    $this->assertTrue(str_contains((string)$body, 'No autorizado'), 'body debe contener mensaje');
  }
}
