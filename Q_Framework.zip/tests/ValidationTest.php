<?php
declare(strict_types=1);

use System\Testing\TestCase;
use System\Validation\Validator;

final class ValidationTest extends TestCase
{
  public function testBuiltInEmailRule(): void
  {
    $v = new Validator();

    $ok = $v->passes(
      ['correo' => 'test@example.com'],
      ['correo' => 'required|email']
    );
    $this->assertTrue($ok, 'email debe pasar');

    $bad = $v->passes(
      ['correo' => 'no-es-email'],
      ['correo' => 'required|email']
    );
    $this->assertFalse($bad, 'email debe fallar');
  }
}
