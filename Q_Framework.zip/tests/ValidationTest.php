<?php
declare(strict_types=1);

use System\Testing\TestCase;
use System\Validation\Validator;

final class ValidationTest extends TestCase
{
  public function testCustomValidatorsFromHelper(): void
  {
    // Carga helper del usuario (registra rules)
    helper('validadores');

    $v = new Validator();
    $ok = $v->validate(
      ['correo' => 'required|email_strict'],
      ['correo' => 'test@example.com']
    );
    $this->assertTrue($ok, 'email_strict debe pasar');

    $bad = $v->validate(
      ['correo' => 'required|email_strict'],
      ['correo' => 'no-es-email']
    );
    $this->assertFalse($bad, 'email_strict debe fallar');
  }
}
