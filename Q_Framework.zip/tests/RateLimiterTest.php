<?php
declare(strict_types=1);

use System\Cache\FileCache;
use System\Security\RateLimiter;
use System\Testing\TestCase;

final class RateLimiterTest extends TestCase
{
  public function testRateLimiterBlocksAfterMaxAttempts(): void
  {
    $dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'qfw_rl_' . bin2hex(random_bytes(4));
    $cache = new FileCache($dir);
    $rl = new RateLimiter($cache);

    $key = $rl->key('rl:test:abc');

    // 3 intentos permitidos
    $a1 = $rl->attempt($key, 3, 1);
    $this->assertTrue($a1['ok'] === true, 'intento 1 debe ser ok');

    $a2 = $rl->attempt($key, 3, 1);
    $this->assertTrue($a2['ok'] === true, 'intento 2 debe ser ok');

    $a3 = $rl->attempt($key, 3, 1);
    $this->assertTrue($a3['ok'] === true, 'intento 3 debe ser ok');

    $a4 = $rl->attempt($key, 3, 1);
    $this->assertTrue($a4['ok'] === false, 'intento 4 debe bloquear');

    // Debe desbloquear tras decay
    sleep(2);
    $a5 = $rl->attempt($key, 3, 1);
    $this->assertTrue($a5['ok'] === true, 'debe desbloquear tras decay');
  }
}
