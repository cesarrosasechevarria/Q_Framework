<?php
declare(strict_types=1);

use System\Core\Csrf;
use System\Testing\TestCase;

final class CsrfTest extends TestCase
{
  public function testCsrfTokenVerifyCookieStorage(): void
  {
    // Simula cookie vacía
    $_COOKIE = [];

    $t = Csrf::token();
    $this->assertTrue($t !== '', 'token vacio');

    // Simula que el navegador guarda la cookie
    $_COOKIE[Csrf::cookieName()] = $t;

    $this->assertTrue(Csrf::verify($t), 'verify debe pasar');
    $this->assertFalse(Csrf::verify('bad-token'), 'verify debe fallar');
  }
}
