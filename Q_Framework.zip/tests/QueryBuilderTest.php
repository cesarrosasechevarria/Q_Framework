<?php
declare(strict_types=1);

use System\Database\Connection;
use System\Testing\TestCase;

final class QueryBuilderTest extends TestCase
{
  public function testWhereGroupingCompiles(): void
  {
    $pdo = new PDO('sqlite::memory:');
    $db = new Connection('test', $pdo);

    $sql = $db->table('users')
      ->select('id')
      ->groupStart()
        ->where('a', 1)
        ->orWhere('b', 2)
      ->groupEnd()
      ->where('c', 3)
      ->getCompiledSelect();

    // Debe contener: ((`a` = :p0 OR (`b` = :p1)) AND (`c` = :p2)) aprox
    $this->assertContains('WHERE', $sql);
    $this->assertContains('(', $sql);
    $this->assertContains('`a`', $sql);
    $this->assertContains('OR', $sql);
    $this->assertContains('`c`', $sql);
  }
}
