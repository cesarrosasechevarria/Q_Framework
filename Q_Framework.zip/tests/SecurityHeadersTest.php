<?php
declare(strict_types=1);

use System\Core\Request;
use System\Core\Response;
use System\Filters\SecurityHeadersFilter;
use System\Testing\TestCase;

final class SecurityHeadersTest extends TestCase
{
  private function getPrivate(object $obj, string $prop)
  {
    $ref = new ReflectionClass($obj);
    $p = $ref->getProperty($prop);
    $p->setAccessible(true);
    return $p->getValue($obj);
  }

  public function testSecurityHeadersAreApplied(): void
  {
    $_SERVER['REQUEST_METHOD'] = 'GET';
    $_SERVER['REQUEST_URI'] = '/';
    $_SERVER['HTTP_ACCEPT'] = 'text/html';

    $req = new Request();
    $res = new Response();

    $f = new SecurityHeadersFilter();
    $out = $f->after($req, $res) ?? $res;

    $headers = $this->getPrivate($out, 'headers');

    // Mínimos esperados
    $this->assertTrue(isset($headers['X-Frame-Options']), 'X-Frame-Options faltante');
    $this->assertTrue(isset($headers['X-Content-Type-Options']), 'X-Content-Type-Options faltante');
  }
}
