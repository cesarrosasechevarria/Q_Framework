# CORE LOCK v1.0.0

Esta versión define el **núcleo estable** del framework.  
El objetivo es mantener una base **pequeña, robusta y profesional** sobre la que se construyen módulos a medida.

## Áreas bloqueadas (solo bugfix)
- system/Core/*
- system/Support/*
- system/Config/*
- system/Validation/*
- system/Http/*
- system/Security/*
- system/CLI/* (solo correcciones, no features)

## Reglas
1) No se agregan features nuevas al core.
2) Solo correcciones de bugs y seguridad.
3) Toda nueva funcionalidad va a:
   - app/Modules
   - app/Libraries
   - app/Services
   - app/Helpers/system
4) Todo cambio en core requiere: **lint + smoke test**.

## Filosofía
**Small core. Stable core. Extend via modules.**
