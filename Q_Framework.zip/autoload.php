<?php
declare(strict_types=1);

/**
 * Q_Framework Autoload Bootstrap (SECURE)
 * 
 * Problema resuelto:
 * - composer.json tiene "autoload.files": ["system/Support/Functions.php"]
 * - Si tú incluyes Functions.php ANTES de vendor/autoload.php, Composer lo vuelve a incluir
 *   (porque su flag global aún no existe) => Cannot redeclare base_path()/env()
 *
 * Solución:
 * 1) Cargar vendor/autoload.php primero (si existe)
 * 2) Cargar Functions.php SOLO si no existe base_path()
 * 3) Registrar autoloader propio como fallback (no depende de Composer)
 */

$root = __DIR__;

if (!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

// 1) Vendor autoload (opcional) - primero para evitar doble include de Functions.php
$composerAutoload = $root . '/vendor/autoload.php';
$useVendor = defined('QFW_USE_VENDOR_AUTOLOAD') ? (bool) QFW_USE_VENDOR_AUTOLOAD : true;
if ($useVendor && is_file($composerAutoload)) {
  require_once $composerAutoload;
}

// 2) Core functions (base_path, env, etc.) solo si aún no existen
if (!function_exists('base_path')) {
  require_once $root . '/system/Support/Functions.php';
}

// 3) Autoloader propio (fallback). No depende de Composer.
if (!function_exists('qfw_register_autoloader')) {
  require_once $root . '/system/Support/Autoload.php';
}
qfw_register_autoloader($root);
