<?php
declare(strict_types=1);

namespace App\Filters;

use System\Core\FilterInterface;
use System\Core\Request;
use System\Core\Response;

final class AuthFilter implements FilterInterface
{
  public function before(Request $request, Response $response): ?Response
  {
    // No iniciar sesión a visitantes: solo si hay cookie
    $u = auth_user();
    if ($u) return null;

    // Si necesitas iniciar sesión sí o sí, usa session()->get('user')
    // Aquí devolvemos redirect simple (HTML); puedes adaptar a JSON.
    return $response->redirect(base_url('/login'));
  }

  public function after(Request $request, Response $response): ?Response
  {
    return null;
  }
}
