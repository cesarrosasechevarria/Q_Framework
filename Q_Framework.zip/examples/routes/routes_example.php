<?php
declare(strict_types=1);

use System\Core\RouteCollection;

// Ejemplo de archivo de rutas para copiar ideas.
return function(RouteCollection $routes) {

  $routes->get('/', 'App\\Controllers\\Home@index', ['as' => 'home']);

  // CRUD
  $routes->get('/users', 'App\\Controllers\\Users@index', ['as' => 'users.index']);
  $routes->get('/users/{id}', 'App\\Controllers\\Users@show', ['as' => 'users.show']);

  // CSRF solo en POST sensibles
  $routes->post('/users', 'App\\Controllers\\Users@store', ['filters' => ['csrf']]);

  // Grupo protegido (requiere que tú crees el filtro 'auth' en app/Filters)
  $routes->group('/admin', ['filters' => ['auth']], function($r) {
    $r->get('/', 'App\\Controllers\\Admin@index', ['as' => 'admin.home']);
    $r->get('/reports', 'App\\Controllers\\Admin@reports', ['as' => 'admin.reports']);
  });

};
