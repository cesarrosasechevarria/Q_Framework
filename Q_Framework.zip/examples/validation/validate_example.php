<?php
// Ejemplo rápido (para copiar a un controller)
[$ok, $errors] = validate($_POST, [
  'email' => 'required|email',
  'name'  => 'required|min:3|max:80',
]);

if (!$ok) {
  // $errors['email'][0] ...
}
