<?php
declare(strict_types=1);

namespace App\Controllers;

final class Auth extends BaseController
{
  protected array $helpers = ['url','security'];

  public function loginForm(): string
  {
    $err = session_optional()?->flash('error');
    return $this->view('auth/login', ['title'=>'Ingresar', 'error'=>$err]);
  }

  public function login()
  {
    $u = (string)$this->request->post('username','');
    $p = (string)$this->request->post('password','');

    // DEMO: reemplaza por validación real contra DB.
    if ($u === 'admin' && $p === 'admin') {
      $this->session()->set('user', ['username' => $u]);
      return $this->redirect(base_url('/'));
    }

    $this->session()->flash('error', 'Credenciales inválidas');
    return $this->redirect(base_url('/login'));
  }

  public function logout()
  {
    $this->session()->destroy();
    return $this->redirect(base_url('/'));
  }
}
