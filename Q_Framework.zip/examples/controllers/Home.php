<?php
declare(strict_types=1);

namespace App\Controllers;

use System\Core\View;

/**
 * Ejemplo: Home controller mínimo
 */
final class Home extends BaseController
{
  public function index(): void
  {
    echo View::render('home', [
      'title' => 'Q_Framework',
      'time'  => date('Y-m-d H:i:s'),
    ]);
  }
}
