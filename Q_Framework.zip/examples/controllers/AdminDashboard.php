<?php
declare(strict_types=1);

namespace App\Controllers;

use System\Core\View;

/**
 * Ejemplo: controller protegido con filtro "auth".
 * En routes:
 *   $routes->get('/admin', 'App\\Controllers\\AdminDashboard@index', ['filters'=>['auth']]);
 */
final class AdminDashboard extends BaseController
{
  public function index(): void
  {
    echo View::render('admin/dashboard', [
      'title' => 'Panel',
      'user'  => session()->get('user') ?? [],
    ]);
  }
}
