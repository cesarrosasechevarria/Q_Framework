<?php
declare(strict_types=1);

namespace App\Controllers;

final class Users extends BaseController
{
  protected array $helpers = ['url','security'];

  public function index(): string
  {
    $db = $this->db();
    $res = $db->table('users')->orderBy('id','DESC')->paginate(10);

    return $this->view('users/index', [
      'title' => 'Usuarios',
      'rows'  => $res['data'],
      'pager' => $res['pager'],
      'meta'  => $res['meta'],
    ]);
  }

  public function show(string $id): string
  {
    $row = $this->db()->table('users')->where('id', $id)->first();
    if (!$row) {
      return \System\Core\Errors::page(404, ['title'=>'No encontrado','message'=>'Usuario no existe.']);
    }

    return $this->view('users/show', [
      'title' => 'Detalle',
      'row' => $row,
    ]);
  }

  public function store()
  {
    $username = (string)$this->request->post('username','');
    $email    = (string)$this->request->post('email','');

    $id = $this->db()->table('users')->insert([
      'username' => $username,
      'email' => $email,
    ]);

    session()->flash('ok', 'Usuario creado: #' . $id);
    return $this->redirect(route_url('users.index'));
  }
}
