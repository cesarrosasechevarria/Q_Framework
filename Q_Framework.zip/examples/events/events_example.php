<?php
// En app/Config/Events.php:
return [
  'controller.before' => [
    ['fn' => function($ctx){
      // $ctx: ['uses'=>'Class@method','params'=>...]
      \System\Core\Logger::info('Before controller', (array)$ctx);
    }, 'priority' => 0],
  ],
];
