# Examples (para copiar/pegar)

Estos ejemplos NO se activan por defecto. Sirven para que copies lo que necesites a tu app.

## Controllers + Views
- `examples/controllers/Home.php`  -> copia a `app/Controllers/Home.php`
  - View: `examples/views/home.php` -> `app/Views/home.php`
- `examples/controllers/Auth.php`  -> `app/Controllers/Auth.php`
  - Views: `examples/views/auth/*` -> `app/Views/auth/*`
- `examples/controllers/Users.php` -> `app/Controllers/Users.php`
  - Views: `examples/views/users/*` -> `app/Views/users/*`
- `examples/controllers/AdminDashboard.php` -> `app/Controllers/AdminDashboard.php`
  - View: `examples/views/admin/dashboard.php` -> `app/Views/admin/dashboard.php`

Luego registra rutas en `app/Config/Routes.php`:

```php
$routes->get('/', 'Home@index');
$routes->get('/login', 'Auth@loginForm');
$routes->post('/login', 'Auth@login');
$routes->get('/users', 'Users@index', ['filter' => 'auth']);
$routes->get('/admin', 'AdminDashboard@index', ['filter' => 'auth']);
```

## Modules
- `examples/modules/Blog` -> copia a `app/Modules/Blog`
  - Ruta incluida en `Routes.php`: `/blog`

## Seguridad (CSRF)
El ejemplo de login ya incluye CSRF:
- Genera token en el formulario: `csrf_field()`
- Verifica automáticamente si `CSRF_ENABLED=1`

## Nota
- Puedes mantener estos ejemplos y solo “copiar” la lógica a tus controladores reales.
