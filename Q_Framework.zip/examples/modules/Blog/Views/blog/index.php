<?php
$posts = $posts ?? [];
?>
<div class="qfw-card">
  <h1 style="margin:0 0 8px"><?= e($title ?? 'Blog') ?></h1>
  <ul>
    <?php foreach ($posts as $p): ?>
      <li>#<?= e((string)$p['id']) ?> — <?= e((string)$p['title']) ?></li>
    <?php endforeach; ?>
  </ul>
  <p class="qfw-muted" style="margin-top:10px">Este view viene desde <code>app/Modules/Blog/Views</code> (si lo copias y habilitas).</p>
</div>
