<?php
declare(strict_types=1);

namespace Modules\Blog\Controllers;

use System\Core\View;

final class Blog
{
  public function index(): void
  {
    echo View::render('blog/index', [
      'title' => 'Módulo Blog',
      'posts' => [
        ['id'=>1,'title'=>'Post 1'],
        ['id'=>2,'title'=>'Post 2'],
      ],
    ]);
  }
}
