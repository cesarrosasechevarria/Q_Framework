<?php
declare(strict_types=1);

use System\Core\RouteCollection;

return function(RouteCollection $routes){
  $routes->group('/blog', [], function(RouteCollection $r){
    $r->get('/', 'Modules\\Blog\\Controllers\\Blog@index');
  });
};
