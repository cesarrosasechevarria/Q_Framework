<div class="qfw-card">
  <h2 style="margin-top:0"><?= e($title ?? 'Login') ?></h2>
  <?php if (!empty($error)): ?>
    <div class="qfw-alert err"><?= e($error) ?></div>
  <?php endif; ?>
  <form method="post" action="<?= base_url('/login') ?>" class="qfw-form">
    <?= csrf_field() ?>
    <label>Usuario</label>
    <input name="username" required>
    <label>Clave</label>
    <input name="password" type="password" required>
    <button class="qfw-btn primary" type="submit">Entrar</button>
  </form>
  <p class="qfw-muted">Ejemplo mínimo. Implementa validación real y filtro auth.</p>
</div>
