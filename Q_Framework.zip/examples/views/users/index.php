<div class="qfw-card">
  <h2 style="margin-top:0"><?= e($title ?? 'Usuarios') ?></h2>

  <?php if ($m = session_optional()?->flash('ok')): ?>
    <div class="qfw-alert ok"><?= e($m) ?></div>
  <?php endif; ?>

  <form method="post" action="<?= base_url('/users') ?>" class="qfw-form" style="margin:14px 0">
    <?= csrf_field() ?>
    <div class="qfw-row">
      <input name="username" placeholder="username" required>
      <input name="email" placeholder="email" required>
      <button class="qfw-btn primary">Crear</button>
    </div>
  </form>

  <table class="qfw-table" style="width:100%">
    <thead><tr><th>ID</th><th>Username</th><th>Email</th></tr></thead>
    <tbody>
    <?php foreach (($rows ?? []) as $r): ?>
      <tr>
        <td><?= e($r['id'] ?? '') ?></td>
        <td><a href="<?= route_url('users.show', ['id'=>$r['id'] ?? '']) ?>"><?= e($r['username'] ?? '') ?></a></td>
        <td><?= e($r['email'] ?? '') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <div style="margin-top:12px">
    <?= $pager ?? '' ?>
  </div>
</div>
