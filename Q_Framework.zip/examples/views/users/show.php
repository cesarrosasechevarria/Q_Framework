<div class="qfw-card">
  <h2 style="margin-top:0"><?= e($title ?? 'Detalle') ?></h2>
  <pre><?= e(json_encode($row ?? [], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)) ?></pre>
  <a class="qfw-btn" href="<?= route_url('users.index') ?>">↩️ Volver</a>
</div>
